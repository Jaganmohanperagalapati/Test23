import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'kyfb-user-location-info',
  templateUrl: './user-location-info.component.html',
  styleUrls: ['./user-location-info.component.scss']
})
export class UserLocationInfoComponent implements OnInit {
  public time = new Date();
  public date = new Date();

  public steps: any = { hour: 1, minute: 15 };
  public value: Date = new Date(2000, 2, 10, 10, 30, 0);
  //public values: Date = new Date(2000, 2, 10);
  public min: Date = new Date(2017, 2, 10);
  public maxDate: Date = new Date();
  public maxTime: Date = null;
  datedd: any = "";
  selectedPolicyData: any[]=[];
  formSubmitted: boolean = false;
  constructor(private router: Router) { }

  ngOnInit() {
    this.selectedPolicyData = JSON.parse(localStorage.getItem('selectedPolicy'));
  }

  goToPrevious() {
    if (this.selectedPolicyData['type'] == "A" || this.selectedPolicyData['type'] == "B") {
      this.router.navigate(['/claims/claims-tabs/report-type-auto']);
    } else {
      this.router.navigate(['/claims/claims-tabs/report-type-property']);
    }
  }

  goToNext(isValid) {
    this.formSubmitted = true;
    if(isValid) {
      if (this.selectedPolicyData['type'] == "A" || this.selectedPolicyData['type'] == "B") {
        this.router.navigate(['/claims/claims-tabs/auto-claim-details']);
      } else {
        this.router.navigate(['/claims/claims-tabs/property-claim-detail']);
      }
    }  
  }

  dateChange(event) {
    this.value = null;
    this.maxTime = null;
    if (this.getFormattedDate(event) == this.getFormattedDate(new Date())) {
      this.maxTime = new Date();
    }
  }

  getFormattedDate(date) {
    let year = date.getFullYear();

    let month = (1 + date.getMonth()).toString();
    month = month.length > 1 ? month : '0' + month;

    let day = date.getDate().toString();
    day = day.length > 1 ? day : '0' + day;

    return month + '/' + day + '/' + year;
  }



}

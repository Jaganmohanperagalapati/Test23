import { Component, OnInit } from '@angular/core';
import { ClaimService } from 'src/app/services/claim.service';
import { Router } from '@angular/router';

@Component({
    selector: 'msw-navbar',
    templateUrl: './navbar.component.html'
})

export class NavbarComponent implements OnInit {

    isReportTypeAutoProcess = false;
    isUserLocationInfoProcess = false;
    isAutoClaimDetailProcess = false;
    isContactInfoProcess = false;
    isConfirmationAutoProcess = false;
    isReportTypeAutoDone: boolean = false;
    isUserLocationInfoDone: boolean = false;
    isAutoClaimDetailDone: boolean = false;
    isContactInfoDone: boolean = false;
    isConfirmationAutoDone: boolean = false;
    selectedPolicyData: any[] = [];
    constructor(private claimsService: ClaimService, private router: Router) {
        this.selectedPolicyData = JSON.parse(localStorage.getItem('selectedPolicy'));
        router.events.subscribe((val) => {
            let href = this.router.url;
            if (href.indexOf('report-type-auto') > -1 || href.indexOf('report-type-property') > -1) {
                this.isReportTypeAutoDone = false;
                this.isReportTypeAutoProcess = true;
                this.isUserLocationInfoProcess = false;
            }
            else if (href.indexOf('user-location-info') > -1) {
                this.isUserLocationInfoDone = false;
                this.isUserLocationInfoProcess = true;
                this.isReportTypeAutoDone = true;
                this.isReportTypeAutoProcess = false;
                this.isAutoClaimDetailProcess = false;
            }
            else if (href.indexOf('auto-claim-details') > -1 || href.indexOf('property-claim-detail') > -1) {
                this.isAutoClaimDetailDone = false;
                this.isAutoClaimDetailProcess = true;
                this.isReportTypeAutoDone = true;
                this.isUserLocationInfoDone = true;
                this.isReportTypeAutoProcess = false;
                this.isUserLocationInfoProcess = false;
                this.isContactInfoProcess = false;
            }
            else if (href.indexOf('contact-info') > -1) {
                this.isContactInfoDone = false;
                this.isContactInfoProcess = true;
                this.isReportTypeAutoDone = true;
                this.isUserLocationInfoDone = true;
                this.isAutoClaimDetailDone = true;
                this.isReportTypeAutoProcess = false;
                this.isUserLocationInfoProcess = false;
                this.isAutoClaimDetailProcess = false;
                this.isConfirmationAutoProcess = false;
            }
            else if (href.indexOf('confirmation-auto') > -1 || href.indexOf('confirmation-property') > -1) {
                this.isConfirmationAutoDone = false;
                this.isConfirmationAutoProcess = true;
                this.isReportTypeAutoDone = true;
                this.isUserLocationInfoDone = true;
                this.isAutoClaimDetailDone = true;
                this.isContactInfoDone = true;
                this.isReportTypeAutoProcess = false;
                this.isUserLocationInfoProcess = false;
                this.isAutoClaimDetailProcess = false;
                this.isContactInfoProcess = false;
            }

        });
    }


    ngOnInit() {
    }
}

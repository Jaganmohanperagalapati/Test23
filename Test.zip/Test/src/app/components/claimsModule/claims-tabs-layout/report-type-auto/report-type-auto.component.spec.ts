import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportTypeAutoComponent } from './report-type-auto.component';

describe('ReportTypeAutoComponent', () => {
  let component: ReportTypeAutoComponent;
  let fixture: ComponentFixture<ReportTypeAutoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportTypeAutoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportTypeAutoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

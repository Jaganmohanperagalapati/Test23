import { Component, OnInit, TemplateRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';

@Component({
  selector: 'kyfb-report-type-property',
  templateUrl: './report-type-property.component.html',
  styleUrls: ['./report-type-property.component.scss']
})
export class ReportTypePropertyComponent implements OnInit {
  reportModalRef: BsModalRef;
  public claimType: any;
  public submitted: boolean = false;
  public x: boolean = false;
  public y: boolean = false;
  constructor( private router: Router, private modalService: BsModalService) { }

  ngOnInit() {
  }

  openModalConfirmation(template1: TemplateRef<any>) {
    this.reportModalRef = this.modalService.show(template1);
  }


  
  goToNext() {
    // this.router.navigate(['/claims/claims-tabs/user-location-info']);
    console.log(this.claimType);
    this.submitted = true;
    if (this.claimType) {
      this.router.navigate(['/claims/claims-tabs/user-location-info']);
    }
  }
  goBackToDashboard(template1: TemplateRef<any>) {
    this.reportModalRef.hide();
    this.router.navigate(['/claims']);
  }

}

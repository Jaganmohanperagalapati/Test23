import { Component, OnInit, Input } from '@angular/core';
import { SwiperConfigInterface } from 'ngx-swiper-wrapper';

@Component({
    selector: 'kyfb-benefits',
    templateUrl: './benefits.component.html',
    styleUrls: ['./benefits.component.scss']
})
export class BenefitsComponent implements OnInit {
    @Input() benefits: number | 'auto' = 'auto';

    public swiper: SwiperConfigInterface = {
        slidesPerView: 'auto',
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        breakpoints: {
            768: {
                slidesPerView: 1,
            }
        }
    };

    constructor() { }

    ngOnInit() {
        this.swiper.slidesPerView = this.benefits;
    }

}

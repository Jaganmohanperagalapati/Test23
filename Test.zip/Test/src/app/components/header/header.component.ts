import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AccountInformation } from '../../kyfb/account-information';
import { Router } from '@angular/router';

@Component({
    selector: 'kyfb-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
    @Input() accountInformation: AccountInformation;
    @Output() toggleMenu = new EventEmitter<any>();

    constructor(private router:Router) { }

    ngOnInit() {

    }
 returnTo(){
     this.router.navigate(['/dashboard']);
 }
}

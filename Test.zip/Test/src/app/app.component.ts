import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { PortalService } from './services/portal.service';
import { ClaimService } from './services/claim.service';

import { NavigationEnd, Router,Event } from '@angular/router';

@Component({
    selector: 'kyfb-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit {
    public portalService: PortalService;
    public menuOpen = false;
    public sidebarOpen = false;
    isClaimsHalfLayout:boolean=false;
   // _routerSub: import("c:/Users/SVRTEMP/Desktop/Project Details/Portal Re-write/project/Project-making/node_modules/rxjs/internal/Subscription").Subscription;

    constructor(portalService: PortalService, private cd: ChangeDetectorRef, private claimsService: ClaimService, private router: Router) {
        this.portalService = portalService;
    }

    ngOnInit() {}

    onToggleMenu() {
        this.menuOpen ? this.closeMenu() : this.openMenu();
        return false;
    }

    closeMenu() {
        this.menuOpen = false;
        return false;
    }

    openMenu() {
        this.menuOpen = true;
        return false;
    }

    onToggleSidebar() {
        this.sidebarOpen ? this.closeSidebar() : this.openSidebar();
        return false;
    }

    closeSidebar() {
        this.sidebarOpen = false;
        return false;
    }

    openSidebar() {
        this.sidebarOpen = true;
        return false;
    }
}

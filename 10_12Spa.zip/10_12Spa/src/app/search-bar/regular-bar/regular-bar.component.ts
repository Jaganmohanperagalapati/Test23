///<reference types="@types/googlemaps" />
import { Component, OnInit, NgZone } from '@angular/core';
import { SearchCriteriaService } from "../../services/search-criteria.service";
import { ShareDataService } from "../../services/share-data/share-data.service";
import { FormGroup, FormControl, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { Router, NavigationEnd, ActivatedRoute, Params } from '@angular/router';
import * as moment from "moment";
import { StorageService } from '../../shared/storage/storage.service';

@Component({
  selector: 'app-regular-bar',
  templateUrl: './regular-bar.component.html'
})
export class RegularBarComponent implements OnInit {
  public downloadSearchData:any;
  public dropDownValue: string = "All Homes for Sale";
  private auctionProgramValue;
  private auctionProgramValue2;
  searchInfo: any;
  breadcrumbLocation:any={};
  searchForm: FormGroup;
  public addrKeys: string[];
  public addr: any;
  public isLoggedIn = false;
  public searchResp:any;
  // public isCheckHome;
  geoCoder = new google.maps.Geocoder();
  constructor(private _fb: FormBuilder, private router: Router, private zone: NgZone, private _searchCriteriaService: SearchCriteriaService,
    private _shareData: ShareDataService, private activatedRoute: ActivatedRoute, private storageService: StorageService) {
      this.storageService.loginSession$.subscribe((data) => {
        this.isLoggedIn = data.isLoggedIn; 
      }
      );

    }
    ngOnInit() {
      this.searchForm = this._fb.group({
        searchData: ""
      });
      this._shareData.currentAuctionProgram.subscribe(auctionProgram => this.auctionProgramValue = auctionProgram);
      this._shareData.currentAuctionProgram2.subscribe(auctionProgram => this.auctionProgramValue2 = auctionProgram);
       this._shareData.sr1Value.subscribe(sr1=> this.searchResp=sr1);
      this._shareData.currentLocation.subscribe(location => this.breadcrumbLocation = location)
      // this.isCheckHome=this.isHome(this.activatedRoute.snapshot.url.length);
      // console.log('this.isHome(this.activatedRoute.snapshot.url.length)', this.isCheckHome);

    }

    setAddress(addrObj) {
      this.zone.run(() => {
        console.log("setAddressObject",addrObj);
        this.addr = addrObj;
        this.addrKeys = Object.keys(addrObj);
        this.router.navigate(["/properties"]);
        this.breadcrumbLocation={};
        console.log("addr", this.addr);
        if(this.addr.locality && this.addr.state&&this.addr.postal_code){
          console.log("there")
          // this.breadcrumbLocation=this.addr.locality+","+this.addr.state;
          this.breadcrumbLocation["city"]=this.addr.locality;
          this.breadcrumbLocation["state"]=this.addr.state;
          this.breadcrumbLocation["postalCode"]=this.addr.postal_code;
        }
        else if (this.addr.locality&&this.addr.state){
          this.breadcrumbLocation["city"]=this.addr.locality;
          this.breadcrumbLocation["state"]=this.addr.state;
        }
        else if(this.addr.county){
          this.breadcrumbLocation["county"]=this.addr.county;
          this.breadcrumbLocation["state"]=this.addr.state;
        }
        else if (this.addr.admin_area_l1) {
          console.log("state");
          this.breadcrumbLocation["state"] = this.addr.state;
        }
        this._shareData.changeAuctionProgram2(this.auctionProgramValue);
        this._shareData.onChangeLocation(this.breadcrumbLocation)
        console.log("bclocation", this.breadcrumbLocation);
        console.log("addrKeys", this.addrKeys);
      });
    }
    geoCodeInput(address){
      let search_obj = {};
      this.geoCoder.geocode({ address: address },(results, status)=> {
        if (status === google.maps.GeocoderStatus.OK) {
          const R = results[0];
          search_obj["type"] = R.types[0];
          console.log("r", R)
          console.log("type", search_obj["type"])
          // let stateCode;
          if (R.address_components[0].types[0] == 'administrative_area_level_1') {
            search_obj['stateCode'] = R.address_components[0].short_name;

          } else if (R.address_components[1] && R.address_components[1].types[0] == 'administrative_area_level_1') {
            search_obj['stateCode'] = R.address_components[1].short_name;

          } else if (R.address_components[2] && R.address_components[2].types[0] == 'administrative_area_level_1') {
            search_obj['stateCode'] = R.address_components[2].short_name;

          } else if (R.address_components[3] && R.address_components[3].types[0] == 'administrative_area_level_1') {
            search_obj['stateCode'] = R.address_components[3].short_name;

          } else if (R.address_components[4] && R.address_components[4].types[0] == 'administrative_area_level_1') {
            search_obj['stateCode'] = R.address_components[4].short_name;

          } else if (R.address_components[5] && R.address_components[5].types[0] == 'administrative_area_level_1') {
            search_obj['stateCode'] = R.address_components[5].short_name;

          }
          console.log("state=", search_obj['stateCode']);
          for (let i in R.address_components) {
            if (R.address_components[i].types[0] == "administrative_area_level_2") {
              search_obj["county"] = R.address_components[i].short_name;
              console.log("county name", search_obj["county"])
            }
            else {
              console.log("no code");
            }
            if (R.address_components[i].types[0] == "postal_code") {
              search_obj['postal_code'] = R.address_components[i].short_name;
              console.log("postalCode=", search_obj['postal_code']);
            }
            else {
              console.log("no code")
            }

          }
          //extracting the city 
          // let city;
          if (R.address_components.length > 3) {
            for (let i = 0; i < R.address_components.length; i++) {
              if (R.address_components[i].types[0] == 'locality') {
                search_obj["city"] = R.address_components[i].long_name.toLowerCase();

              }
            }
          }

          //extracting the state
          // let street = address
          search_obj["street"] = address
            .toLowerCase()
            .split(' ')
            .join('');
          console.log("street=", search_obj["street"]);
          search_obj["formatted address"] = R.formatted_address;

          // Street exception for New York
          if (R.address_components[0].long_name == 'New York' && (search_obj["type"] == 'locality' || search_obj["type"] == 'text')) {
            if (search_obj["street"].includes('city')) {
              console.log('logic for new york city');
              // If they select New York city, then do logic for city
              search_obj["type"] = 'locality';
            } else {
              console.log('NEW YORK STATE');
              // If they select New York state, then create new stateCode using [1].short_name
              search_obj["type"] = 'administrative_area_level_1';
              search_obj['stateCode'] = R.address_components[1].short_name;
            }
          }

          //coordinates
          const latitude = R.geometry.location.lat();
          console.log("lat", latitude)
          const longitude = R.geometry.location.lng();
          console.log("long", longitude)
          const location = new google.maps.LatLng(latitude, longitude);
          //sessionStorage.setItem('dataKey', json.strin(latitude));
          const center = {
            lat: latitude,
            lng: longitude
          };
          console.log("loc", location);
          console.log("cen", center);
          
          console.log("search_obj",search_obj)
          this._shareData.getSResp(search_obj);
        }
      });
      // this._searchCriteriaService.setAddressEntity(search_obj);
      // this._shareData.onChangeLocation(this.breadcrumbLocation);
    }


    
    // isHome(isLength){
    // if(isLength ==0){
    // return false;
    // }else{
    // return true;
    // }
    // }
    onSearch(): void {
      // console.log("sVal="+this.searchForm.controls.searchData.value);
      if(this.searchForm.controls.searchData.value== "") {
        this._shareData.getSResp({});
        console.log("getting data?",this.searchResp)
      this._shareData.changeAuctionProgram2(this.auctionProgramValue);
        // this.getUserLocation()
      this.router.navigate(["/properties"])
    }
  else {
      this.router.navigate(["/properties"])
      this._shareData.changeAuctionProgram2(this.auctionProgramValue)
      console.log("sVal=" + this.searchForm.controls.searchData.value);
      console.log("search Obj", this.addr)
      console.log("brcr", this.breadcrumbLocation)
      this.geoCodeInput(this.searchForm.controls.searchData.value);
      if(this.searchResp!={}){

        console.log("if entered",this.searchResp)
      }

    }
  }
  onAuctionProgramChange(e): void {
    console.log("drop event:", e.target.innerText)
    this.dropDownValue = e.target.innerText;


  }


//Download the search results in a CSV file:
convertToCSV(objArray) {
  var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
  var str = '';
  for (var i = 0; i < array.length; i++) {
      var line = '';
      for (var index in array[i]) {
          if (line != '') line += ','
          line += array[i][index];
      }
      str += line + '\r\n';
  }
  return str;
}
exportCSVFile(headers, items, fileTitle) {
  if (headers) {
      items.unshift(headers);
  }
  var jsonObject = JSON.stringify(items);
  var csv = this.convertToCSV(jsonObject);
  var exportedFileName = fileTitle + '.csv' || 'export.csv';
  var blob = new Blob([csv], {
      type: 'text/csv;charset=utf-8;'
  });
  if (navigator.msSaveBlob) {
      navigator.msSaveBlob(blob, exportedFileName);
  } else {
      var link = document.createElement("a");
      if (link.download !== undefined) {
          var url = URL.createObjectURL(blob);
          link.setAttribute("href", url);
          link.setAttribute("download", exportedFileName);
          link.style.visibility = 'hidden';
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
      }
  }
}

onDownloadResults() {
  console.log("on download",this.searchResp)
  
  this.downloadSearchData=this.searchResp
      if (this.downloadSearchData.data.length > 0) {
          var headers = {
              auctionProgram:"Auction Program",
              address:"Address",
              city:"City",
              state:"State",
              zip:"Zip",
              county:"County",
              propertyType:"Property Type",
              bedrooms:"Bedrooms",
              bathrooms:"Bathrooms",
              squareFeet:"Square Feet",
              lotSizeValue:"Lot Size Value",
              lotSizeType:"Lot Size Type",
              yearBuilt:"Year Built",
              occupancyStatus:"Occupancy Status",
              preAuctionStartDate:"Pre-Auction Start Date",
              preAuctionEndDate:"Pre-Auction Start Date",
              auctionStartDate:"Auction Start Date",
              auctionEndDate:"Auction End Date",
              foreclosureSaleStatus:"Foreclosure Sale Status",
              foreclosureSaleDate:"Foreclosure Sale Date",
              listingAgent:"Listing Agent",
              agentEmail:"Agent Email",
              agentPhone:"Agent Phone",
              brokerCoopPercent:"Broker Co-op Percent",
              websiteUrl:"Property URL",
          };
          var itemsFormatted = [];
          this.downloadSearchData.data.forEach((item) => {
              itemsFormatted.push({
                  auctionProgram: item.listingProgramWebsite? item.listingProgramWebsite:"",
                  address:item.propertyInfo.address?item.propertyInfo.address:"",
                  city:item.propertyInfo.city?item.propertyInfo.city:"",
                  state:item.propertyInfo.state?item.propertyInfo.state:"",
                  zip:item.propertyInfo.postalCode?item.propertyInfo.postalCode:"",
                  county:item.propertyInfo.county?item.propertyInfo.county:"",
                  propertyType:item.propertyInfo.propertyType?item.propertyInfo.propertyType:"",
                  bedrooms:item.propertyInfo.bedrooms?item.propertyInfo.bedrooms:"",
                  bathrooms:item.propertyInfo.fullBathrooms?item.propertyInfo.fullBathrooms:"",
                  squareFeet:item.propertyInfo.interiorSqFt?item.propertyInfo.interiorSqFt:"",
                  lotSizeValue:item.propertyInfo.lotSize?item.propertyInfo.lotSize:"",
                  lotSizeType:item.propertyInfo.lotSizeAcreageDescription?item.propertyInfo.lotSizeAcreageDescription:"",
                  yearBuilt:item.propertyInfo.yearBuilt?item.propertyInfo.yearBuilt:"",
                  occupancyStatus:item.propertyInfo.occupancyStatus?item.propertyInfo.occupancyStatus:"",
                  preAuctionStartDate:(item.auctionRunInfo&&item.auctionRunInfo.preAuctionStartDate)?item.auctionRunInfo.preAuctionStartDate:"",
                  preAuctionEndDate:(item.auctionRunInfo&&item.auctionRunInfo.preAuctionEndDate)?item.auctionRunInfo.preAuctionEndDate:"",
                  auctionStartDate:(item.auctionRunInfo&&item.auctionRunInfo.startDate)?moment(item.auctionRunInfo.startDate).format('MM/DD/YYYY h:mm A'):"",
                  auctionEndDate:(item.auctionRunInfo&&item.auctionRunInfo.endDate)?moment(item.auctionRunInfo.endDate).format('MM/DD/YYYY h:mm A'):"",
                  foreclosureSaleStatus:item.foreclosureSaleStatus? item.foreclosureSaleStatus:"",
                  foreclosureSaleDate:item.foreclosureSaleDate?moment(item.foreclosureSaleDate).format('MM/DD/YYYY'):"",
                  listingAgent:(item.auctionRunInfo&&item.auctionRunInfo.listingAgent)?item.auctionRunInfo.listingAgent:"",
                  agentEmail:(item.auctionRunInfo&&item.auctionRunInfo.agentEmail)?item.auctionRunInfo.agentEmail:"",
                  agentPhone:(item.auctionRunInfo&&item.auctionRunInfo.agentPhone)?item.auctionRunInfo.agentPhone:"",
                  brokerCoopPercent:(item.auctionRunInfo&&item.auctionRunInfo.brokerCoopPercent)?item.auctionRunInfo.brokerCoopPercent:"",
                  websiteUrl:item.propertyInfo.websiteUrl?item.propertyInfo.websiteUrl:""
              });
          });
          var fileTitle = 'SearchResults';
          this.exportCSVFile(headers, itemsFormatted, fileTitle);
      }
  }

}






import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AboutComponent } from './about/about.component'
import { ContactUsComponent } from './contact-us/contact-us.component'
import { FinancingComponent } from './financing/financing.component'
import { HowToBidComponent } from './how-to-bid/how-to-bid.component'
import { PrivacyComponent } from './privacy/privacy.component'
import { TermsComponent } from './terms/terms.component'

const routes: Routes = [ 
    { path: 'about', component: AboutComponent, data:{title:"Bid for a Home Using Servicelink Auction | Hudson and Marshall", description:"Buying auction homes is made easy through Servicelink Auction. Simple, transparent, hassle-free bidding on an actual home. "} },
    { path: 'contactus', component: ContactUsComponent},
    { path: 'financing', component: FinancingComponent, data:{title:"Property Finance | Home Financing Options | Hudson and Marshall", description:"Need help financing for auction homes? Explore our home financing options to find highly qualified lenders that allow you to leverage buying power. "} },
    { path: 'howtobid', component: HowToBidComponent, data:{title:"Bid for a Home Using Servicelink Auction | Hudson and Marshall", description:"Buying auction homes is made easy through Servicelink Auction. Simple, transparent, hassle-free bidding on an actual home. "} },
    { path: 'privacy', component: PrivacyComponent },
    { path: 'terms', component: TermsComponent }
];
//, data:{title:"", description:""}
@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ContentRoutingModule { }

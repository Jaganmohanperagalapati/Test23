import { Component, ChangeDetectionStrategy, ViewEncapsulation } from '@angular/core';
import { CalendarEvent, CalendarMonthViewDay, CalendarDateFormatter } from 'angular-calendar';
import { DayViewHour } from 'calendar-utils';
import {MonthViewService} from '../../services/month-view.service';

@Component({
  selector: 'app-calendar',
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.css'],
  providers:[{
    provide:CalendarDateFormatter,
    useClass: MonthViewService
  }]
})
export class CalendarComponent {

  constructor() { }

  view = 'month';
  viewDate: Date = new Date();
  selectedMonthViewDay: CalendarMonthViewDay;
  selectedDayViewDate: Date;
  dayView: DayViewHour[];
  events: CalendarEvent[] = [];
  selectedDays: any = [];

  dayClicked(day: CalendarMonthViewDay): void {

    this.selectedMonthViewDay = day;

    const selectedDateTime = this.selectedMonthViewDay.date.getTime();

    const dateIndex = this.selectedDays.findIndex(

      selectedDay => selectedDay.date.getTime() === selectedDateTime

    );

    if (dateIndex > -1) {

      delete this.selectedMonthViewDay.cssClass;

      this.selectedDays.splice(dateIndex, 1);

    } else {

      this.selectedDays.push(this.selectedMonthViewDay);

      day.cssClass = 'cal-day-selected';

      this.selectedMonthViewDay = day;

    }
    console.log(this.selectedDays)

  }



  beforeMonthViewRender({ body }: { body: CalendarMonthViewDay[] }): void {

    body.forEach(day => {

      if (

        this.selectedDays.some(

          selectedDay => selectedDay.date.getTime() === day.date.getTime()

        )

      ) {

        day.cssClass = 'cal-day-selected';

      }

    });

  }



  hourSegmentClicked(date: Date) {

    this.selectedDayViewDate = date;

    this.addSelectedDayViewClass();

  }



  beforeDayViewRender(dayView: DayViewHour[]) {

    this.dayView = dayView;

    this.addSelectedDayViewClass();

  }



  private addSelectedDayViewClass() {

    this.dayView.forEach(hourSegment => {

      hourSegment.segments.forEach(segment => {

        delete segment.cssClass;

        if (

          this.selectedDayViewDate &&

          segment.date.getTime() === this.selectedDayViewDate.getTime()

        ) {

          segment.cssClass = 'cal-day-selected';

        }

      });

    });

  }

}

import { Component, OnInit } from '@angular/core';
import { StorageService } from '../../shared/storage/storage.service';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html'
})
export class NotificationsComponent implements OnInit {
  public isLoggedIn = false;
  public loginObj:any;

  constructor(private storageService: StorageService) {
    this.storageService.loginSession$.subscribe((data) => {
      this.loginObj=data;
      this.isLoggedIn = data.isLoggedIn;
    }
    );
  }

  ngOnInit() {
  }
  logOut(){
    this.loginObj.isLoggedIn=false;
    this.storageService.loginSession(this.loginObj);
  }
}

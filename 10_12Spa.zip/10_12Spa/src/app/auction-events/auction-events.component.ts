import { Component, OnInit } from '@angular/core';
import { ApiService } from '../shared/api/api.service';
import { IListingAuctionRun } from '../models/auction-run.model';

@Component({
    selector: 'app-auction-events',
    templateUrl: './auction-events.component.html',
    styleUrls: ['./auction-events.component.scss']
})
export class AuctionEventsComponent implements OnInit {
    public auctionRuns: IListingAuctionRun[];

    constructor(private _api: ApiService) { }

    async ngOnInit() {
        this.auctionRuns = await this._api.getEndPoint<IListingAuctionRun[]>('/assets/data/auction-runs.json', true);
    }
}
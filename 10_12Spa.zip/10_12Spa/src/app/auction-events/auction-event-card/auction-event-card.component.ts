import { Component, OnInit, Input } from '@angular/core';
import { IAuctionRun } from '../../models/auction-run.model';

@Component({
    selector: 'app-auction-event-card',
    templateUrl: './auction-event-card.component.html',
    styleUrls: ['./auction-event-card.component.scss']
})
export class AuctionEventCardComponent implements OnInit {
    @Input() auctionRun: IAuctionRun;
    constructor() { }

    ngOnInit() {
    }

}

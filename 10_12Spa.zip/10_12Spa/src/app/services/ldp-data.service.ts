import { Injectable } from '@angular/core';
import { IListing } from '../models/listing.model';

@Injectable()
export class LdpDataService {
    _listing: IListing

    constructor() { }

    setListing(listing: IListing): void {
        this._listing = listing;
    }

    getListing(): IListing {
        return this._listing;
    }
}

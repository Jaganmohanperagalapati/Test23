import { Injectable } from '@angular/core';
import {BehaviorSubject,Observable} from "rxjs";
import {HttpClient,HttpParams} from "@angular/common/http";
import { ISearchResult } from '../../models/search-result.model';
import { shareReplay } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ShareDataService {
  public resultValue:any;
  public resultValue1:any;
  public urlParameters:string;
  public sr1=new BehaviorSubject<object>({});
  sr1Value=this.sr1.asObservable();
  public searchClick= new BehaviorSubject<boolean>(false);
  searchClickValue=this.searchClick.asObservable();
  public searchObject:any={};
  private auctionProgram=new BehaviorSubject<string>("All Homes for Sale");
  currentAuctionProgram=this.auctionProgram.asObservable();
  private auctionProgram2=new BehaviorSubject<string>("");
  currentAuctionProgram2=this.auctionProgram2.asObservable();
  private location=new BehaviorSubject<object>({});
  currentLocation=this.location.asObservable();


  constructor(private _http:HttpClient) { 
  }
  // setSearchObject(sObj:any):void{
  //   console.log("searchObject in service",sObj.city)
  //   this.searchObject=sObj;
  // }

  //trying to write proper code


	setSearchParams(searchResult) {	
    console.log('searchResult', searchResult);
  let params;
  let param=new HttpParams();
  if(searchResult.city && searchResult.stateCode&&searchResult.postal_code){
    console.log("there");
    params=param.append("city",searchResult.city)
    params=param.append("state",searchResult.stateCode)
    params=param.append("postalCode",searchResult.city)

  }else if(searchResult.city&&searchResult.stateCode){
    params=param.append("city",searchResult.city)
    params=param.append("state",searchResult.stateCode)
  }
  else if(searchResult.county){
    params=param.append("county",searchResult.county)
    params=param.append("state",searchResult.stateCode)
   
  }else if(searchResult.stateCode){
    console.log("state");
    params=param.append("state",searchResult.stateCode)
  }
  if(searchResult.postal_code){
     // console.log("postalCode")
  // params=param.set("city",searchResult.city)
 params= param.set("postalCode",searchResult.postal_code)
  }
  // console.log('params--', params.toString());
 
 return this._http.get<ISearchResult>('http://listingsvc-s1-v1.dev.exostechnology.local/api/v1/listings?limit=100',{params})   
	}


// proper code ends




//sam
getSResp(sResp:object){
  console.log("sResp",sResp);
  this.setSearchParams(sResp).subscribe(res=>{
    console.log("res res",res);
this.resultValue=res
// this.sr1.next(sResp);
  this.sr1.next(this.resultValue);
  })
  

  
// console.log("resvalue outside",this.resultValue)
}

// setSearchParams(searchResult:any){
//   console.log(searchResult);
//   let params;
//   let param=new HttpParams();
//   // if(searchResult.city){
//   //     console.log("city")
//   //     params=param.append("city",searchResult.city);
//   // }
//   // if(searchResult.county){
//   //     console.log("county")
//   //     params=param.append("county",searchResult.county);
//   // }
//   // if(searchResult.state){
//   //     console.log("state")
//   //     params=param.append("state",searchResult.state);
//   // }
//   // if(searchResult.formattedAddress){
//   //     console.log("formattedAddress")
//   //     params=param.append("formattedAddress",searchResult.formattedAddress);
//   // }
//   if(searchResult.postal_code){
//       console.log("postalCode")
//   // params=param.set("city",searchResult.city)
//  params= param.set("postalCode",searchResult.postal_code)
//   // .set("state",searchResult.stateCode);
//   }
//   // if(searchResult.stateCode){
//   //     console.log("stateCode")
//   //     params=param.append("state",searchResult.stateCode);
//   // }

//   // console.log("searchParams this",params.toString());

//   return this._http.get<ISearchResult>("http://listingsvc-s1-v1.dev.exostechnology.local/api/v1/listings?",{params})
  
   
// }



  setSearchObject(searchResult):void{
    console.log("searchResult in service",searchResult);
    this.searchObject=searchResult;
  }

  getSearchObject():any{
// return this.searchObject;
return this.urlParameters;
  }

  setAuctionProgram(data:any){
    this.auctionProgram = data;
    console.log("auctionProgram",this.auctionProgram);
    this.changeAuctionProgram(data)
}

getAuctionProgram():any{
    return this.auctionProgram;
}
changeAuctionProgram(message:string){
  this.auctionProgram.next(message)
  console.log("cap",this.auctionProgram)
}
changeAuctionProgram2(auctionProgramValue:string){
  this.auctionProgram2.next(auctionProgramValue);
  // console.log("cap2",this.auctionProgram2);
}
onChangeLocation(currLocation:object){
  console.log("currl",currLocation)
  this.location.next(currLocation)
  
}
onSearchClick(searchClick:boolean){
  console.log("search click value",searchClick);
  this.searchClick.next(searchClick)

}
}

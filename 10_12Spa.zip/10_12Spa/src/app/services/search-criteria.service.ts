import { Injectable } from '@angular/core';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import {HttpClient,HttpParams} from "@angular/common/http";
import {BehaviorSubject} from "rxjs";
import {ApiService} from "../shared/api/api.service";
import { ISearchResult } from '../models/search-result.model';
@Injectable()
export class SearchCriteriaService {
    private _searchContext: string;
    private _addressObj: any;
public searchResp= new BehaviorSubject<object>({});
searchRespValue=this.searchResp.asObservable();
public city: any;
public county: any;
public formattedAddress: any;
public stateCode: any;
public street: any;
public type: any;
public searchObject:any;
public params:any="empty";
public searchResultResponse:any;
    constructor(private _api:ApiService,private _http:HttpClient) { }

    setSearchContext(searchContext: string): void {
        this._searchContext = searchContext;
        console.log("service st", this._searchContext)
    }

    
        

        setSearchObject(searchResult):void{
            console.log("searchResult in service",searchResult);
            this.searchObject=searchResult;
          }


        setSearchParams(searchResult:any){
            console.log(searchResult);
            let params;
            let str:string="state=PA";
            let param=new HttpParams();
            // if(searchResult.city){
            //     console.log("city")
            //     params=param.append("city",searchResult.city);
            // }
            // if(searchResult.county){
            //     console.log("county")
            //     params=param.append("county",searchResult.county);
            // }
            // if(searchResult.state){
            //     console.log("state")
            //     params=param.append("state",searchResult.state);
            // }
            // if(searchResult.formattedAddress){
            //     console.log("formattedAddress")
            //     params=param.append("formattedAddress",searchResult.formattedAddress);
            // }
            if(searchResult.postal_code){
                console.log("postalCode")
            // params=param.set("city",searchResult.city)
           params= param.set("postalCode",searchResult.postal_code)
            // .set("state",searchResult.stateCode);
            }
            // if(searchResult.stateCode){
            //     console.log("stateCode")
            //     params=param.append("state",searchResult.stateCode);
            // }

            // console.log("searchParams this",params.toString());
            console.log("str",str)
            return this._http.get<ISearchResult>("http://listingsvc-s1-v1.dev.exostechnology.local/api/v1/listings?",{params})
            
             
        }

        //
        getSearchResp(searchObj:object){
            console.log("searchObj in search criteria service",searchObj)
            this.searchResp.next(searchObj);

        }


        getSearchResponse(){
            console.log("sresp",this.searchResultResponse)
            return this.searchResultResponse;
        }
        



    getCriteria(): any {
        //TODO - ensure we whitelist incoming URL values (e.g., bank-owned-homes, foreclosures, occupied, etc.)
        return {
            searchContext: this._searchContext,
            // city: this._addressObj['city'],
            // county: this._addressObj['city'],
            // postal_code:this._addressObj['postal_code'],
            // stateCode:this._addressObj['stateCode'],
            // street:this._addressObj['street']

        };
    }

    async search(url: string) {        
        return  this._api.getEndPoint<ISearchResult>(url);
    }
}

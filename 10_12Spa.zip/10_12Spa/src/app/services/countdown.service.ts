import { Injectable } from '@angular/core';
import * as signalR from '@aspnet/signalr';
import * as Moment from 'moment-timezone';
import { HubConnection } from '@aspnet/signalr';
import { ApiService } from '../shared/api/api.service';
import { IBiddingHistory } from '../models/bidding-history.model';
import { IBiddingItem } from '../models/bidding-item.model';
import { IListingView } from '../models/listing-view.model';
import { IListing } from '../models/listing.model';

@Injectable()
export class CountdownService {
    private _hubConnection: HubConnection;
    private _listingViews: IListingView[] = [];
    public userName: string;

    constructor(private _api: ApiService) {
        this.userName = Math.floor(Math.random() * Math.floor(100)) % 2 == 0 ? "1096" : "446";
    }

    async initialize(listings: IListing[]) {
        const listingIds = this.getListingIds(listings);
        const bidHistoriesQuerystring = this.getBidHistoriesQuerystring(listingIds);
        let biddingHistory: IBiddingHistory;

        if (bidHistoriesQuerystring) {
            biddingHistory = await this._api.getEndPoint<IBiddingHistory>(`http://localhost:5000/api/v1/Biddings/Bids/${bidHistoriesQuerystring}`, true);
        }

        await this.mergeListingViewWithBiddingHistory(listings, biddingHistory);

        this.createHubConnection();
        this.registerHubServerEvents();
        this.startHubConnection(listingIds);
    }

    terminate() {
        this.stopHubConnection();
        this._hubConnection = null;
        this._listingViews = [];
    }

    async mergeListingViewWithBiddingHistory(listings: IListing[], biddingHistory: IBiddingHistory) {
        if (listings) {
            listings.forEach(async (listing) => {
                let listingView = <IListingView>{
                    address: listing.propertyInfo.address,
                    images: listing.images,
                    listingId: listing.auctionRunInfo ? listing.auctionRunInfo.awxId : ''
                };

                if (listingView.listingId) {
                    let bidHistoryData = biddingHistory.data.filter((bidHistoryDatum) => {
                        return bidHistoryDatum.listingId === listingView.listingId;
                    });

                    if (bidHistoryData && bidHistoryData.length > 0) {
                        bidHistoryData.sort((d1, d2) => d2.actionId - d1.actionId);
                        listingView.bidHistoryData = bidHistoryData;
                    }
                }

                if (listingView.bidHistoryData && listingView.bidHistoryData.length > 0) {
                    listingView.endDate = this.convertToLocalTime(listingView.bidHistoryData[0].endTime);
                    listingView.currentDTTM = listingView.bidHistoryData[0].currentTime;
                    listingView.price = listingView.bidHistoryData[0].amount;
                    listingView.bidAmount = listingView.bidHistoryData[0].amount;
                    listingView.ctaButtonText = this.getCtaButtonText(listingView);
                }
                else {
                    const biddingItem = await this._api.getEndPoint<IBiddingItem>(`http://localhost:5000/api/v1/Biddings/${listingView.listingId}`, true);
                    listingView.endDate = biddingItem.endDTTM;
                    listingView.currentDTTM = biddingItem.currentDTTM;
                    listingView.price = biddingItem.currentPrice;
                    listingView.bidAmount = biddingItem.currentPrice;
                    listingView.ctaButtonText = this.getCtaButtonText(listingView);
                }

                this._listingViews.push(listingView);
            });
        }
    }

    getListingViews(): IListingView[] {
        return this._listingViews;
    }

    getListingIds(listings: IListing[]): any[] {
        if (!listings) { return []; }

        const reducer = (accumulator, listing) => {
            if (listing.auctionRunInfo) {
                accumulator.push(listing.auctionRunInfo.awxId);
            }

            return accumulator;
        };

        return listings.reduce(reducer, []);
    }

    getBidHistoriesQuerystring(listingIds: any[]) {
        let querystring = listingIds.join('&id=');
        if (querystring) {
            querystring = `?id=${querystring}`;
        }

        return querystring;
    }

    convertToLocalTime(utcDate: string): string {
        const zIndex = utcDate.lastIndexOf('Z');
        if (zIndex > -1) { utcDate = utcDate.substring(0, zIndex); }

        return Moment(utcDate).utc().tz('America/Los_Angeles').format('YYYY-MM-DDTHH:mm:ss') + 'Z';
    }

    getCtaButtonText(listingView: IListingView): string {
        if (this.isUserHighestBidder(listingView))
            return 'You are the highest bidder'

        return 'Submit Bid';
    }

    isUserPartOfBidding(listingView: IListingView): boolean {
        if (!listingView.bidHistoryData || listingView.bidHistoryData.length < 1)
            return false;

        return listingView.bidHistoryData.some(b => b.userName == this.userName);
    }

    isUserHighestBidder(listingView: IListingView): boolean {
        const latestBid = listingView.bidHistoryData && listingView.bidHistoryData.length > 0
            ? listingView.bidHistoryData[0]
            : null;

        return latestBid && this.userName == latestBid.userName;
    }

    isAuctionEnded(listingView: IListingView): boolean {
        //FIXME - look into avoiding excessive digest cycle
        return false;
        // const now = new Date();
        // const latestBid = listingView.bidHistoryData[0];
        // const endDate = new Date(latestBid.endTime);
        // return now > endDate;
    }

    createHubConnection(): void {
        this._hubConnection = new signalR.HubConnectionBuilder()
            .withUrl('http://localhost:5000/notify')
            .configureLogging(signalR.LogLevel.Information)
            .build();
    }

    registerHubServerEvents(): void {
        this._hubConnection.on('SendBidHistory', (data: any) => {
            this.handleOnReceiveSendBidHistoryMessage(data);
        });
    }

    startHubConnection(listingIds: any[]): void {
        this._hubConnection.start()
            .then(() => {
                listingIds.forEach(listingId => this._hubConnection.invoke('JoinGroup', listingId));
            })
            .catch(err => console.error(err.toString()));
    }

    stopHubConnection(): void {
        if (this._hubConnection)
            this._hubConnection.stop();
    }

    async handleOnSubmitBidClick(listingView: IListingView) {
        await this._api.postEndPoint(`http://localhost:5000/api/v1/Biddings/${listingView.listingId}/Bids`, {
            amount: listingView.bidAmount,
            userName: this.userName
        });
    }

    async handleOnCountdownComplete(listingView: IListingView) {
        const biddingItem = await this._api.getEndPoint<IBiddingItem>(`http://localhost:5000/api/v1/Biddings/${listingView.listingId}`, true);
        const biddingHistory = await this._api.getEndPoint<IBiddingHistory>(`http://localhost:5000/api/v1/Biddings/${listingView.listingId}/Bids`, true);
        listingView.bidHistoryData = biddingHistory.data;

        let ctaButtonText = 'Auction Ended'
        if (this.isUserHighestBidder(listingView))
            ctaButtonText = 'Auction Ended, you won champ!';
        else if (this.isUserPartOfBidding(listingView))
            ctaButtonText = 'Auction Ended, you lost ya bum';

        listingView.ctaButtonText = ctaButtonText;
    }

    handleOnReceiveSendBidHistoryMessage(message: any): void {
        if (message && message.data && message.data.length > 0) {
            const latestBid = message.data[0];
            let listingView = this._listingViews.filter(l => l.listingId == latestBid.listingId)[0];
            listingView.bidHistoryData = message.data;

            listingView.ctaButtonText = this.getCtaButtonText(listingView);
            listingView.price = latestBid.amount;
            listingView.bidAmount = latestBid.amount;

            // Update countdown due to sniping
            const bidEndTime = this.convertToLocalTime(latestBid.endTime);
            const listingViewEndTime = this.convertToLocalTime(listingView.endDate);
            if (bidEndTime != listingViewEndTime) {
                listingView.endDate = bidEndTime;
            }
        }
    }
}
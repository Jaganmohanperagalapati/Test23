import { Injectable } from '@angular/core';
import { CalendarDateFormatter, DateFormatterParams } from 'angular-calendar';
import { formatDate } from '\@angular/common';

@Injectable({
  providedIn: 'root'
})
export class MonthViewService extends CalendarDateFormatter {

  public monthViewColumnHeader({date, locale}: DateFormatterParams): string {
       return formatDate(date, 'EEE', locale).slice(0,1); // use short week days
   }
}

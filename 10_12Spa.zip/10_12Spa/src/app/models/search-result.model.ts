import { IListing } from "./listing.model";

export interface ISearchResult {
    totalCount: number;
    // searchResultCount: number;
    data: IListing[];
    continuationToken: string;
}
/// <reference types="@types/googlemaps" />
import { ViewChild, Component, OnInit,AfterContentInit } from '@angular/core';
import {Observable} from "rxjs";
import { ListingCardComponent } from "../listing-card/listing-card.component";
import { ISearchResult } from '../../models/search-result.model';
import { IListing } from "../../models/listing.model";
import { ApiService } from '../../shared/api/api.service';
import { SearchCriteriaService } from '../../services/search-criteria.service';
import {ShareDataService} from "../../services/share-data/share-data.service";
import { PageChangedEvent } from 'ngx-bootstrap';

@Component({
    selector: 'app-srp',
    templateUrl: './srp.component.html',
    styleUrls: ['./srp.component.css']
})
export class SrpComponent implements OnInit {
    @ViewChild('googlemap') googlemapElement: any;
    map: google.maps.Map;
    infoWindow = new google.maps.InfoWindow();
    public searchResult: ISearchResult;
    public returnedArray: IListing[];
    // public _view: string = "grid";
    private _view: string = "grid";
    latitude:number=41.85003;
    longitude:number=-87.6500523;
    zoom:number=5;
    public singleListingData:any;

    constructor(private _api: ApiService, private _searchCriteriaService: SearchCriteriaService) { }

    async ngOnInit() {
        //TODO - populate search criteria, post listing search
        const searchCriteria = this._searchCriteriaService.getCriteria();
        // this.searchResult = await this._api.getEndPoint<ISearchResult>('/assets/data/search-result.json');
                
        this.searchResult = await this._searchCriteriaService.search('/listings?&limit=50');
        

        var mapProp = {
            center: new google.maps.LatLng(41.850033, -87.6500523),
            zoom: 5
        };
        // this.map = new google.maps.Map(this.googlemapElement.nativeElement, mapProp);

        for (let listing of this.searchResult.data) {
            if (listing.propertyInfo.latitude != 0 && listing.propertyInfo.longitude != 0) {
                let location = new google.maps.LatLng(listing.propertyInfo.latitude, listing.propertyInfo.longitude);
                let marker = new google.maps.Marker({
                    position: location,
                    map: this.map,
                    title: listing.propertyInfo.address
                });

                marker.addListener('click', (e) => {
                    console.log("list", listing);
                    // this.markerHandler(marker,e)

                });
            }
        }
    }
    public searchResult2 ;   //trying
    public searchResult22 ;   //trying
    // getSearchResponse(message: any) {
    //     //alert('ghg');
    //     //console.log('message-->>))', message);
    //     this._shareData.setSearchParams(message) //Observable need to subscribe to get value
    //     .subscribe(response => {
    //       console.log("response in srp adding updated code", response);
    //       this.searchResult=response;
    //       this.searchResult2=response.data;
    //       console.log('message-----this.searchResult>>))', this.searchResult2);
    //     },
    //     error => {
    //       //console.error("Error deleting food!" + error);
    //       return Observable.throw(error);
    //     }
    //     );
    //     }
    //ends trying
//     ngAfterContentInit(){
// console.log("this.searchres",this.searchResult2)
// if(this.searchResult2.length>0){
//     this.searchResult22=this.searchResult2;
//     console.log("this.searchResult22",this.searchResult22)
// }
//     }
    
    isGridView(): boolean {
        return this._view === "grid";
    }

    isMapView(): boolean {
        return this._view === "map";
    }

    loadView(view: string): void {
        this._view = view;
        console.log("load view",this._view);
    }
    getListingData(listingData){
        console.log('this.singleListingData', listingData);
         this.singleListingData = listingData;
    }

    onFilterChange(event) {
        this.returnedArray = event;
    }
    async getMoreListings(event) {
        console.log('more is called',event)      
    }
}
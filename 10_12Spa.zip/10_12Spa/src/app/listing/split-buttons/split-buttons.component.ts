import { Component, OnInit,Output,EventEmitter } from '@angular/core';


@Component({
  selector: 'app-split-buttons',
  templateUrl: './split-buttons.component.html'
})
export class SplitButtonsComponent implements OnInit {
  public _view: string = "split";
  @Output() _viewEvent= new EventEmitter<string>()

  constructor() { }

  ngOnInit() {
  }

  
  isMapView(): boolean {
    return this._view === "map";
  }

  isSplitView(): boolean {
    return this._view === "split";
}
  isGridView(): boolean {
    return this._view === "grid";
}
//output the view
shareView(view:string){
  this._view=view;
  console.log("load view",this._view);
  this._viewEvent.emit(this._view);
}

loadView(view: string): void {
    this._view = view;
    console.log("load view",this._view);
}

}

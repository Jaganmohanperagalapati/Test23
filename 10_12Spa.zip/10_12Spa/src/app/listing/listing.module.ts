import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { ListingRoutingModule } from './listing-routing.module';
import {AgmCoreModule} from "@agm/core";
import { AgmOverlays } from "agm-overlays";
import { AgmSnazzyInfoWindowModule } from '@agm/snazzy-info-window';

import { SrpComponent } from './srp/srp.component';
import { LdpComponent } from './ldp/ldp.component';
import { ListingCardComponent } from './listing-card/listing-card.component';
import { ListingRouteManagerComponent } from './listing-route-manager/listing-route-manager.component';
import { LdpHeaderComponent } from './ldp/ldp-header/ldp-header.component';
import { LdpReserveProxyComponent } from './ldp/ldp-reserve-proxy/ldp-reserve-proxy.component';
import { ImageGalleryComponent } from './image-gallery/image-gallery.component';
import { LdpComingSoonComponent } from './ldp/ldp-coming-soon/ldp-coming-soon.component';
import { AuctionTimerComponent } from './auction-timer/auction-timer.component';
import { AuctionStatusComponent } from './auction-status/auction-status.component';
import { AuctionFormComponent } from './auction-form/auction-form.component';
import { LdpPropertyIconsComponent } from './ldp/ldp-property-icons/ldp-property-icons.component';
import { LdpMapComponent } from './ldp/ldp-map/ldp-map.component';
import { CardPaginationComponent } from './card-pagination/card-pagination.component';
import { LdpBiddingHistoryComponent } from './ldp/ldp-bidding-history/ldp-bidding-history.component';
import { LdpPropertyDetailsComponent } from './ldp/ldp-property-details/ldp-property-details.component';
// import { PaginationComponent } from './pagination/pagination.component';
import { BreadcrumbsComponent } from './breadcrumbs/breadcrumbs.component';
import { PaginationBottomComponent } from './pagination-bottom/pagination-bottom.component';
import { MapComponent } from './map/map.component';
import { SplitScreenComponent } from './split-screen/split-screen.component';
import { SplitButtonsComponent } from './split-buttons/split-buttons.component';
import { LdpPropertyDocumentsComponent } from './ldp/ldp-property-documents/ldp-property-documents.component';
import { LdpSellerInformationComponent } from './ldp/ldp-seller-information/ldp-seller-information.component';
import { LdpAgentInformationComponent } from './ldp/ldp-agent-information/ldp-agent-information.component';
import { LdpLicencingComponent } from './ldp/ldp-licencing/ldp-licencing.component';
import { LdpDisclaimerComponent } from './ldp/ldp-disclaimer/ldp-disclaimer.component';
import { LdpAdditionalInformationComponent } from './ldp/ldp-additional-information/ldp-additional-information.component';
import { LdpNearbyPropertiesComponent } from './ldp/ldp-nearby-properties/ldp-nearby-properties.component';
import { PaginationModule } from 'ngx-bootstrap';
import { ListingsDropdownComponent } from './listings-dropdown/listings-dropdown.component';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ListingRoutingModule,
        PaginationModule.forRoot(),
        AgmOverlays,
        AgmCoreModule.forRoot({
            apiKey: 'AIzaSyARw-XELZPGKXVbucz9dDAtqjXKh-uoTME'
        }),
        AgmSnazzyInfoWindowModule,
        
        SharedModule.forRoot()
    ],
    declarations: [
        SrpComponent,
        LdpComponent,
        ListingCardComponent,
        ListingRouteManagerComponent,
        LdpHeaderComponent,
        LdpReserveProxyComponent,
        ImageGalleryComponent,
        LdpComingSoonComponent,
        AuctionTimerComponent,
        AuctionStatusComponent,
        AuctionFormComponent,
        LdpPropertyIconsComponent,
        LdpMapComponent,
        LdpBiddingHistoryComponent,
        LdpPropertyDetailsComponent,
        // PaginationComponent,
        BreadcrumbsComponent,
        PaginationBottomComponent,
        MapComponent,
        SplitScreenComponent,
        CardPaginationComponent,
        SplitButtonsComponent,
        LdpPropertyDocumentsComponent,
        LdpSellerInformationComponent,
        LdpAgentInformationComponent,
        LdpLicencingComponent,
        LdpDisclaimerComponent,
        LdpAdditionalInformationComponent,
        LdpNearbyPropertiesComponent,
        ListingsDropdownComponent,
    ],


    entryComponents: [
        SrpComponent,
        LdpComponent,
        LdpBiddingHistoryComponent,
        LdpPropertyDetailsComponent,
        ListingCardComponent,
        

    ]
})
export class ListingModule {

 }

import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { Router } from "@angular/router";
import { IListing } from '../../models/listing.model';
import { elementStyleProp } from '@angular/core/src/render3/instructions';

@Component({
    selector: 'app-listing-card',
    templateUrl: './listing-card.component.html',
    styleUrls: ['./listing-card.component.css']
})
export class ListingCardComponent implements OnInit, OnChanges {
    @Input() listing: IListing;
    @Input() view: string;
    public cardView;
    public propertyDetailsURL: string;
    public favClicked: boolean = false;
    public address: string;
    @Output() sendListing = new EventEmitter<any>();
    constructor(private _router: Router) {
    }

    ngOnInit() {
        // console.log("listing",this.listing);
        const index = this.listing.propertyInfo.websiteUrl.lastIndexOf("/");
        const urlPart = this.listing.propertyInfo.websiteUrl.substring(index + 1);
        this.propertyDetailsURL = `/property-details/${urlPart}-${this.listing.id}`;
        // console.log("view",this.view)

    }
    ngOnChanges(changes: SimpleChanges) {
        if (this.view) {
            if (changes.view.currentValue == "split") {
                this.cardView = changes.view.currentValue;
                console.log("changes", this.cardView)
            }
        }
    }

    onFavorites(): void {
        this.favClicked = !this.favClicked;
    }

    getInfoWindow(listing) {
        if (this.cardView == "split") {
            console.log('listing--', listing);
            if (listing) {
                this.sendListing.emit(listing);
                console.log('this.sendListing.emit(listing);--', this.sendListing.emit(listing));
            }
        }
        else {
            this._router.navigate([this.propertyDetailsURL])
        }
    }
}
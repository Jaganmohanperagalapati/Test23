import { Component, OnInit, OnChanges, Input, Output, EventEmitter } from '@angular/core';
import { IListing } from "../../models/listing.model";
import { PageChangedEvent } from 'ngx-bootstrap';
import { ISearchResult } from '../../models/search-result.model';

@Component({
  selector: 'app-card-pagination',
  templateUrl: './card-pagination.component.html'
})
export class CardPaginationComponent implements OnInit, OnChanges {

  // lPageSizes: any[] = [
  //   { id: 1, Value: '24' },
  //   { id: 2, Value: '48' }
  // ];
  // curPageSize: any = this.lPageSizes[0];
  @Input('searchResult') searchResult: ISearchResult;
  @Input('curPageSize') curPageSize: any;
  @Input('moreSearchResult') moreSearchResult: any[];
  @Output() onFilterChange: EventEmitter<any> = new EventEmitter<any>();
  @Output() getMoreListings: EventEmitter<any> = new EventEmitter<any>();
  @Output() getPreviousListings: EventEmitter<any> = new EventEmitter<any>();
  public previousClickCount = 1;
  returnedArray: IListing[];
  constructor() { }

  ngOnInit() {
    console.log("curr", this.curPageSize.Value)
  }

  ngOnChanges() {
    if (this.searchResult) {
      console.log('this.searchResult', this.searchResult);
      this.filterData(0, this.curPageSize.Value);
    }
  }

  pageChanged(event: PageChangedEvent): void {
    console.log("page changed", event.page)
    const startItem = (event.page - 1) * event.itemsPerPage;
    const endItem = event.page * event.itemsPerPage;
    console.log("startItem-------", startItem);
    console.log("endItem---------", endItem)
    this.filterData(startItem, endItem);
  }

  // setPageSize(id: any): void {
  //   this.curPageSize = this.lPageSizes.filter(value => value.id === Number(id))[0];
  //   console.log(this.curPageSize);
  //   this.filterData(0, this.curPageSize.Value);
  // }

  filterData(startItem, endItem) {
    this.returnedArray = this.searchResult.data.slice(startItem, endItem);
    this.onFilterChange.emit(this.returnedArray);
  }
  getMoreItems() {
    this.getMoreListings.emit(true);
  }
  getPreviousItems() {
    this.getPreviousListings.emit(this.previousClickCount);
    this.previousClickCount++;
  }
  isMoreItems() {
    // if (this.moreSearchResult.data.length > 100) {
    //   return true;
    // }
    return false;
  }
}

import { Component, OnInit } from '@angular/core';
import { ISearchResult } from '../../models/search-result.model';
import { IListing } from "../../models/listing.model";
import { ApiService } from '../../shared/api/api.service';
import { SearchCriteriaService } from '../../services/search-criteria.service';

@Component({
  selector: 'app-split-screen',
  templateUrl: './split-screen.component.html'
})
export class SplitScreenComponent implements OnInit {
  public searchResult: ISearchResult;
  public moreSearchResult: any[];
  public returnedArray: IListing[];
  public continutionToken = 'O4jA6RpNqXI1J0MW2P7Rs6xGnEr';
  title = 'Auction';
  flag_1: number;
  view: string = "split";
  lPageSizes: any[] = [
    { id: 1, Value: '24' },
    { id: 2, Value: '48' }
  ];
  curPageSize: any = this.lPageSizes[0];
  public singleListingData: any


  constructor(private _api: ApiService, private _searchCriteriaService: SearchCriteriaService) {
    this.flag_1 = 1;
  }


  async ngOnInit() {
    this.moreSearchResult = [];
    //this.searchResult = await this._api.getEndPoint<ISearchResult>("http://listingsvc-s1-v1.dev.exostechnology.local/api/v1/listings?&limit=100");
    this.searchResult = await this._searchCriteriaService.search('/listings?&limit=100');
    //this.moreSearchResult.data = this.moreSearchResult.data.concat(this.searchResult.data);
    //this.moreSearchResult = this.searchResult.data;
    this.moreSearchResult = this.moreSearchResult.concat(this.searchResult.data);
  }

  receiveView($event) {
    this.view = $event
  }


  public switchCondition(): void {
    this.flag_1 += 1;
    if (this.flag_1 == 4)
      this.flag_1 = 1;
  }
  onFilterChange(event) {
    this.returnedArray = event;
  }

  onListingDropChange(event) {
    console.log('drop change', event);
    this.curPageSize = event;

  }
  getListingData(listingData) {
    console.log('this.singleListingData', listingData);
    this.singleListingData = listingData;
  }

  async getMoreListings(event) {
    console.log('Before listings', this.moreSearchResult);
    let moreListings: ISearchResult;
    moreListings = await this._searchCriteriaService.search('/listings?&limit=100&ContinuationToken=' + this.continutionToken);
    this.continutionToken = moreListings.continuationToken;
    this.moreSearchResult = this.moreSearchResult.concat(moreListings.data);
    console.log('this.moreSearchResult', this.moreSearchResult);
  }

  getPreviousListings(previousCount) {
    let startIndex = previousCount * 100;
    let endIndex = startIndex + 100;
    this.searchResult.data = this.moreSearchResult.slice(startIndex, endIndex);
  }
}

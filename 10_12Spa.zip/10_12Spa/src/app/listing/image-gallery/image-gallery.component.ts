import { Component, OnInit, Input } from '@angular/core';
import { IListing } from '../../models/listing.model';

@Component({
    selector: 'app-image-gallery',
    templateUrl: './image-gallery.component.html',
    styleUrls: ['./image-gallery.component.scss']
})
export class ImageGalleryComponent implements OnInit {
    @Input() listing: IListing;

    constructor() { }

    ngOnInit() {
    }

}

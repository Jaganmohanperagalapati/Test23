import { Component, OnInit } from '@angular/core';
import { IListing } from '../../../models/listing.model';
import { LdpDataService } from '../../../services/ldp-data.service';

@Component({
    selector: 'app-ldp-header',
    templateUrl: './ldp-header.component.html',
    styleUrls: ['./ldp-header.component.scss']
})
export class LdpHeaderComponent implements OnInit {
    listing: IListing;

    constructor(private _ldpDataService: LdpDataService) { }

    ngOnInit() {
        this.listing = this._ldpDataService.getListing();
    }
}

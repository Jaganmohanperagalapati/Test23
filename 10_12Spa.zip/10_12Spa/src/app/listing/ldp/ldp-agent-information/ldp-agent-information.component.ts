import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ldp-agent-information',
  templateUrl: './ldp-agent-information.component.html',
  styleUrls: ['./ldp-agent-information.component.scss']
})
export class LdpAgentInformationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit, Input } from '@angular/core';
import { IListing } from '../../../models/listing.model';

@Component({
  selector: 'app-ldp-disclaimer',
  templateUrl: './ldp-disclaimer.component.html',
  styleUrls: ['./ldp-disclaimer.component.scss']
})
export class LdpDisclaimerComponent implements OnInit {
  @Input() listing:IListing;
  constructor() { }

  ngOnInit() {
  }

} 

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../../shared/api/api.service';
import { IListing } from '../../models/listing.model';
import { LdpDataService } from '../../services/ldp-data.service';
import { SearchCriteriaService } from '../../services/search-criteria.service';

@Component({
    selector: 'app-ldp',
    templateUrl: './ldp.component.html',
    styleUrls: ['./ldp.component.css']
})
export class LdpComponent implements OnInit {
    public listing: IListing;

    constructor(private route: ActivatedRoute, private _api: ApiService, private _ldpDataService: LdpDataService, private _searchCriteriaService: SearchCriteriaService) { }

    async ngOnInit() {
        const address = this.route.snapshot.url[0].path;
        const index = address.lastIndexOf('-') + 1;
        const searchResult = await this._searchCriteriaService.search(`/listings?id=${address.substring(index)}`);
        console.log(searchResult);
        this.listing = searchResult.data[0];
        // this.listing = searchResult.listings.filter(l => l.websiteURL.indexOf(address) > -1)[0];
        // this.listing = searchResult.data.filter(l => l.propertyInfo.websiteUrl.indexOf(address) > -1)[0];
        this._ldpDataService.setListing(this.listing);
    }

    isComingSoon(): boolean {
        return false;
    }

    isAuctionReady(): boolean {
        return true;
    }
}

import { Component, OnInit, Input } from '@angular/core';
import { IListing } from '../../../models/listing.model';

@Component({
    selector: 'app-ldp-property-documents',
    templateUrl: './ldp-property-documents.component.html',
    styleUrls: ['./ldp-property-documents.component.scss']
})
export class LdpPropertyDocumentsComponent implements OnInit {
    @Input() listing: IListing;
    constructor() { }

    ngOnInit() { }
}

'use strict';

var webpack = require('webpack');
var HtmlWebpackPlugin = require('html-webpack-plugin');

var path = require('path');
var bourbon = require('node-bourbon').includePaths;
var neat = require('node-neat').includePaths;
var ExtractTextPlugin = require('extract-text-webpack-plugin');

module.exports = {
    entry: {
        app: ['./src/base-components/action-area/index.es6.js', './src/base-components/action-area/index.scss'],
    },
    output: {
        filename: '[name].bundle.js',
        path: path.resolve(__dirname, 'dist/base-action-area')
    },
    module: {
        loaders: [
            {
                test: /\.js$/,
                loader: 'babel-loader',
                query: {
                    presets: ['es2015']
                }
            },
            {
                test: /\.scss$/,
                use: ExtractTextPlugin.extract({
                    fallback: 'style-loader',
                    use: [
                        {
                            loader: 'css-loader' // translates CSS into CommonJS
                        },
                        {
                            loader: 'sass-loader', // compiles Sass to CSS
                            options: {
                                includePaths: [].concat(neat) // Loads Bourbon Neat
                            }
                        }]
                })

            },
            {
                test: /\.(eot|svg|ttf|woff|woff2)$/,
                loader: 'url-loader'
            },
            {
                test: /[^\s]*[^index]\.html/,
                use: 'file-loader?name=views/[name].[ext]'
            }
        ],
        exprContextCritical: false
    },
    resolve: {
        modules: ['node_modules', 'node_modules/styleguide', __dirname + '/src/base-components/action-area'],
        extensions: ['.js', '.ts', '.scss']
    },


    plugins: [
        new HtmlWebpackPlugin({
            template: './src/base-components/action-area/index.html'
        }),
        new webpack.optimize.CommonsChunkPlugin({
            name: 'vendor',
            minChunks: function (module) {
                // this assumes your vendor imports exist in the node_modules directory
                return module.context && module.context.indexOf('node_modules') !== -1;
            }
        }),
        new ExtractTextPlugin('styles.bundle.css')
    ]
};
//This liberation from Webpack is brought to you by https://github.com/monounity/karma-typescript/tree/master/examples/angular2
//This is the main web site that outlined what's in this file - https://www.npmjs.com/package/karma-typescript
module.exports = function(config) {
    config.set({

        frameworks: ["jasmine", "karma-typescript"],

        files: [
            { pattern: "jsonConfigs.mock.js"},
            { pattern: "base.spec.ts" },
            { pattern: "src/app/**/!(*spec).ts" },
            //Note - Uncomment the below line to run all unit tests
            { pattern: "src/app/**/*.spec.ts" }
            //Note - Uncomment and update the below line to run just one unit test file
            //{ pattern: "src/app/services/mcc-config.service.spec.ts" }
        ],

        preprocessors: {
            "**/!(*spec).ts": ["karma-typescript"],
            "**/*.spec.ts": ["karma-typescript"]
        },
        karmaTypescriptConfig: {
            bundlerOptions: {
                entrypoints: /\.spec\.ts$/,
                transforms: [
                    require("karma-typescript-angular2-transform"),
                    require("karma-typescript-es6-transform")()
                ]
            },
            compilerOptions: {
                "allowJs": true,
                lib: ["ES2015", "DOM"]
            },
            reports: {
                "cobertura": {
                    "directory": "target/test_coverage",
                    "subdirectory" : "cobertura",
                    "filename": "cobertura.xml"
                },
                "html": "target/test_coverage/html",
                "text-summary": ""
            }
        },

        coverageReporter: {
            dir : 'coverage/',
            reporters: [
                { type: 'html', subdir:'report-html'},
                { type: 'lcov', subdir:'report-lcov'},
                { type: 'lcovonly', subdir:'.', file:'report-lcovonly.txt'},
                { type: 'text', subdir:'report-text.txt'}
            ]
        },


        reporters: ["progress", "karma-typescript", "coverage"],
        browsers: ["PhantomJS"],

        // list of karma plugins

        plugins : [
            "karma-coverage",
            "karma-jasmine",
            "karma-typescript",
            'karma-chrome-launcher',
            "karma-jasmine",
            "karma-jasmine-html-reporter",
            "karma-phantomjs-launcher"
        ]
    });
};

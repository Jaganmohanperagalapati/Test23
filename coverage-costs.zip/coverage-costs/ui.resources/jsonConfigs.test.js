var jsonConfigs = {
    feature : {
        apiUrl : "ValueDoesntMatterButThisVariableUsedByErrorMessageComponent"
    }
};

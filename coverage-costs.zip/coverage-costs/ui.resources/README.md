# Running the project

To run this project, each component has been designed in such a way that they can be run individually.
* These commands are run through npm. 
* Each component in the project has a corresponding webpack.conig.js.  
* There is an npm task to build and to serve each component locally. (npm run build:\<componentName> or npm run serve:\<componentName> )
* To run the mock server, run the npm task "npm run dyson", which hosts it at localhost:9080

# Contributing 
There are several things that need to be considered when contributing to the project
* To build a new component, the format of the other components must be maintained.
    * A webpack.\<componentName}>.config.js must be created to be able to build and serve the new component
    * The assets folder from styleguide is needed locally to the component itself for webpack to build, so that must be added in the copy:assets section of the gruntfile
    * A build and serve script must be added to package.json that references the new webpack.config, with the copy assets grunt command run first for that component
    * The npm scripts must be added to the buildAem grunt task via the appropriate exec and copy plugins, since CI calls that to build the project to the aem folder
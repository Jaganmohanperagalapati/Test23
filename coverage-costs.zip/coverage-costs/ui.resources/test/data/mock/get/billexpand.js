var guarantor0 = require("./billexpand/guarantor1.json");
var guarantor1 = require("./billexpand/guarantor2.json");


module.exports = {
    cache: false,
    path: '/mycare/v2.0/billexpand',
    template: function(params, query, body, cookie, headers) {
        return guarantor0;
        // let guarantorId = headers["x-guarantorid"];
        // // let billType = headers["x-billtype"];
        // // let billdate = headers["x-billdate"];
        // if( (guarantorId == "51524829") ){
        //     return guarantor0;
        // } else if ((guarantorId == "51525609")) {
        //     return guarantor1;
        // }

        // console.log(headers);
        // return guarantor0;
    }
}

// module.exports = {
//     path: "/mycare/v2.0/billexpand",
//     method: 'GET',
//     status: (req, res, next) => {
//         res.status(404);
//         next();
//     }
// };

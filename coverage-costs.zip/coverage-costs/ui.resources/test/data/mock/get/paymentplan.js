var paymentplan = require("./paymentplan/paymentplan.json")
var paymentplan2 = require("./paymentplan/paymentplan2.json")

module.exports = {
    path: '/mycare/coverage-costs/v1/medical/paymentplan',
    template: function(params, query, body, cookie, headers) {
        var guarantorAccountNumber = headers['x-guarantoraccountnumber'];

        if(decodeURIComponent(query.filter) == '{"where":{"billType":"HB"}}') {
            if (guarantorAccountNumber == "51524829")
                return paymentplan;;
        }
        else if (decodeURIComponent(query.filter) == '{"where":{"billType":"PB"}}'){
            return paymentplan2;
        }
    }
}

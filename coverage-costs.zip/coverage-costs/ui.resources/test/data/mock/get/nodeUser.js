var rSelf = require("./node/user/rSelf");
var r613TASNPXTBB = require("./node/user/r613TASNPXTBB");
var r613KTPFFKLW = require("./node/user/r613KTPFFKLW");
var r613KTP1111 = require("./node/user/r613KTP1111");
var r613KTP1234 = require("./node/user/r613KTP1234");
var r613KTP1201 = require("./node/user/r613KTP1201");

module.exports = {
    cache: false,
    path: '/mycare/coverage-costs/v1/user/plan',
    template: function (params, query, body, cookie, headers) {

        let relId = headers["x-relid"];
        //return member to test member case
        if (relId == "self")
            return rSelf;
        else if (relId == "613TASNPXTBB")
            return r613TASNPXTBB;
        else if (relId == "613KTPFFKLW")
            return r613KTPFFKLW;
        else if (relId == "613KTP1111")
            return r613KTP1111;
        else if (relId == "613KTP1234")
            return r613KTP1234;
        else if (relId == "613KTP1201")
            return r613KTP1201;
        else
            return rSelf;
    }
}
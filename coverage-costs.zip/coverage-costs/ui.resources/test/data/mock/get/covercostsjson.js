var json = require('./covereagecostsjson/coveragecosts.json');


module.exports = {
    path: '/secure/coverage-costs.json.html',
    template: function(params, query, body, cookie) {
        return json;
    }
}

var guarantor = require("./node/newPatient.json");
var nonGuarantor = require("./node/nonGuarantorPatient.json");
var guarantor0 = require("./billexpand/guarantor1.json");
var guarantor1 = require("./billexpand/guarantor2.json");


var zero = require("./node/zero.json");
var newestPatient = require("./node/newPatient.json");

module.exports = {
    path: '/mycare/coverage-costs/v1/medical/bill',
    delay: 5000,
    template: function(params, query, body, cookie,headers) {

        console.log("mock : medicalBill.js ");
        // let qdata1 = `{"fields":"extended","where":{"statementType":"KPHC-HB","billDate":"06/16/2017"}}`;
        //let qdata2 = `{"fields":"extended","where":{"statementType":"KPHC-HB","billDate":"06/15/2017"}}`;
        var hdata = headers["x-guarantoraccountnumber"];
        //console.log("Medical Bill: Filter = " + decodeURIComponent(query.filter));
        if( typeof query.filter !== 'undefined' ) {
            var str = decodeURIComponent(query.filter);
            var obj = JSON.parse(str);
            //console.log("obj.fields=" + obj.fields);
            if(obj.fields=='extended') {
                console.log("mock : medicalBill.js : extented view");
                return '{"detail":[{"amountYouOwe":"537.50","charges":"1,990.75","paidbyInsuranceAdjustments":"-1,453.25","patientName":"WPPSCLCEEDHAIDBDILN, WPPSCLJEBAGGCBCBCFN","paidbyYou":"0.00"}, {"amountYouOwe":"500.50","charges":"2,990.75","paidbyInsuranceAdjustments":"1,000.25","patientName":"Test, User","paidbyYou":"20.00"} ],"total":{"amountYouOwe":"537.50","charges":"1,990.75","paidByInsuranceAdj":"-1,453.25","paidByYou":"0.00"}}';
            }
        }

        if(query.filter == ""){
            return null;
        }
        else if((decodeURIComponent(query.filter) == '{"fields":"extended","where":{"statementType":"HB","billDate":"2017-06-16"}}')){
            return guarantor0;
        }
        else if((decodeURIComponent(query.filter) == '{"fields":"extended","where":{"statementType":"KPHC-HB","billDate":"06/15/2017"}}') && (hdata == "51525609")){
            return guarantor1;
        } else {
            return guarantor;
        }






//        return nonGuarantor;

    }
};

/*
module.exports = {
    path: "/mycare/coverage-costs/v1/medical/bill",
    method: 'GET',
    status: (req, res, next) => {
        res.status(404);
        next();
    }
};*/

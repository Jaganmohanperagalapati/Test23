var messages = require("./messages/conditional.json");

module.exports = {
    path: '/system/messages/conditional/_jcr_content.list.json',
    template: function(params, query, body, cookie) {
        //return guarantor to test the guarantor case
        //change to nonguarantor to test the non-guarantor case
        return messages;
    }
}

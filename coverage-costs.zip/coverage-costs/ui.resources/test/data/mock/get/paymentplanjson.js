var json = require('./paymentplanjson/payment-plan.json');


module.exports = {
    path: '/secure/payment-plan.json.html',
    template: function(params, query, body, cookie) {
        return json;
    }
}

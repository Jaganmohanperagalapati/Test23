var guarantor = require("./patientbilldetails/guarantor.json");
var nonguarantor = require("./patientbilldetails/nonguarantor.json");

module.exports = {
    path: '/mycare/v1.0/billpay/patientbilldetails',
    template: function(params, query, body, cookie) {
        //return guarantor to test the guarantor case
        //change to nonguarantor to test the non-guarantor case
       return guarantor;
    }
}

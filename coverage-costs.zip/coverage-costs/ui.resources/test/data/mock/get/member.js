var proxymemberdata = require("./member/proxymemberdata.json");

module.exports = {
    path: '/mycare/membership/v1.0/account',
    template: function(params, query, body, cookie) {
        return proxymemberdata;
    }
}

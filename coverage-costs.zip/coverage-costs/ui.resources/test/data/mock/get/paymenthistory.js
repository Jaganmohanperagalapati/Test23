var paymentHistory = require("./paymenthistory/paymenthistory.json");

module.exports = {
    path: '/mycare/v1.0/billpay/paymenthistory',
    template: function(params, query, body, cookie) {
        //return proxies to test
        return paymentHistory;
    }
}

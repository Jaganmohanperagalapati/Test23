var positiveAmount = require("./lastPayment/positiveAmount.json");
var none = require("./lastPayment/none.json");

module.exports = {
    path: '/mycare/coverage-costs/v1/medical/latestpayment',
    template: function(params, query, body, cookie) {
        return positiveAmount;
    }
}

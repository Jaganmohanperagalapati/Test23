/**
 * Created by jay.witcher on 4/21/2017.
 */

var patient = {
    path: "/mycare/coverage-costs/v1/medical-bills/billingsummary",
    method: 'GET',
    template: function() {
        return require('./node/newPatient.json');
    }
};

var error = {
    path: "/mycare/coverage-costs/v1/medical-bills/billingsummary",
    method: 'GET',
    status: (req, res, next) => {
        res.status(404);
        next();
    }
};

var zero = {
    path: "/mycare/coverage-costs/v1/medical-bills/billingsummary",
    method: 'GET',
    template: function() {
        return require('./node/zero.json');
    }
};

module.exports = patient;
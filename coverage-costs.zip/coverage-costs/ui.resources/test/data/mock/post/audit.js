var member = require("./user/log.json");
module.exports = {
    path: '/mycare/event/event-handler/v1.0/auditLog',
    delay: 5000,
    template: function(params, query, body, cookie){
      return member;
    }
}

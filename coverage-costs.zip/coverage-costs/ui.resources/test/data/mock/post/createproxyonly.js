var member = require("./user/createproxyresponse.json");
module.exports = {
    path: '/mycare/v2.0/createproxyaccount',
    delay: 5000,
    template: function(params, query, body, cookie){
      return member;
    }
}

//the below (dated) code simulates the jQuery that would be uploaded
//  to higher environments for the modal window component functionality
$(document).ready(function(e){
    console.log('JQuery ready functionality registered');
    var genericmodalId;
	//Show Modal
     $('body').on('click','[data-invoke-modal-by-id]',function(e) {
        genericmodalId = '#'+$(this).data('invoke-modal-by-id');
        $('.kp-modal').hide();
        $(genericmodalId).show();
        $(genericmodalId).addClass('modal-showing');
    });
	//Close Modal on the click of x button
     $('body').on('click','button.-close',function(e) {
       $('.kp-modal').show();
       genericmodalId = '#'+$(this).data('close-modal-id');
       $(genericmodalId).removeClass('modal-showing');
    });
    //Close Modal on clicking outside the modal
    //$('body').on('click','.modal-fade-screen',function(e) {
    //  var clickedOutsideModal = $(e.target).hasClass('modal-fade-screen');
    //  genericmodalId = '#' + $(e.currentTarget).closest('.kp-modal').attr('id');
    //  if(clickedOutsideModal) {
    //    $('.kp-modal').show();
    //    $(genericmodalId).removeClass('modal-showing');
    //  }
    //});
    //Close Modal on the press of escape button
    $('body').keydown(function(e) {
        if (e.keyCode == 27) {
           $('.kp-modal').show();
           $(genericmodalId).removeClass('modal-showing');
        }
        console.log(e);
	});
});

//initiate 'medicalbills' and 'lastpayment' web services calls
  var medicalBillsUrl = window.jsonConfigs.global.apipApiUrl + window.jsonConfigs.feature.medicalBillApiUri;
  var lastPaymentUrl = window.jsonConfigs.global.apipApiUrl + window.jsonConfigs.feature.lastPaymentApiUri;
  var apiTimeout = 10000; //window.jsonConfigs.feature.apiTimeout;
  
  $kp.KPUserProfile.UserProfileClient.load();
 
      var headers = [{      
        'X-apiKey':window.jsonConfigs.feature.apiKey,
        'X-appName':window.jsonConfigs.feature.appName,
        'X-componentName': window.jsonConfigs.feature.componentName,
        'X-useragenttype': navigator.userAgent,
        'X-osversion': navigator.appVersion,
        'X-useragentcategory': 'I',
        'Content-Type': 'application/json; charset=UTF-8'   
      }];
              
      $kp.KPClientCommons.WebUtil.loadBFFAPIs([{
          code: "medicalbills",
          url: medicalBillsUrl,
          headers: headers[0],
          timeout:apiTimeout
      },{
          code: "lastpayment",
          url: lastPaymentUrl,
          headers: headers[0],
          timeout:apiTimeout
      }
      ]);

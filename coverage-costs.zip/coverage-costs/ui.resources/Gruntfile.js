'use strict';

var directories = {
    ui_apps_dest: "../ui.apps/src/main/content/jcr_root/etc/designs/kporg/coverage-costs/clientlib-site/",
    bourbonNeat: require('node-neat').includePaths,
    node_modules: 'node_modules',
    styleguide_modern: 'node_modules/styleguide/lib/modern',
};

function generateAemFileArray() {
    var outValue = [];
    //General Functions
    var addFileFunction = function (srcFilePath, destFileName, subDir) {
        outValue.push({
            expand: true,
            flatten: true,
            rename: function (dest, src) {
                var lastSlashIndexPlusOne = srcFilePath.lastIndexOf('/') + 1;
                var localFileName = srcFilePath.substring(lastSlashIndexPlusOne);
                return dest + "/" + src.replace(localFileName, destFileName);
            },
            src: srcFilePath,
            dest: directories.ui_apps_dest + subDir
        });
    };
    //CSS
    var addCSSFileFunction = function (srcFilePath, destFileName) {
        addFileFunction(srcFilePath, destFileName, 'css');
    };
    addCSSFileFunction('dist/mcc/styles.bundle.css', 'page.css');
	//JS
    var addJSLibFunction = function (srcFilePath, destFileName) {
        addFileFunction(srcFilePath, destFileName, 'js');
    };
    addJSLibFunction('dist/mcc/app.bundle.js', 'app.bundle.js');
    return outValue;
}

module.exports = function (grunt) {
    var styleguidePath = grunt.file.expand(directories.node_modules + '/styleguide');
    grunt.log.write(styleguidePath);

    grunt.initConfig({
        copy: {
            assets_baseActionArea: {
                files: [
                    {
                        expand: true,
                        cwd: directories.styleguide_modern,
                        src: 'assets/**/*',
                        dest: 'src/base-components/action-area'
                    }
                ]
            },
            assets_mcc: {
                files: [
                    {
                        expand: true,
                        cwd: directories.styleguide_modern,
                        src: 'assets/**/*',
                        dest: 'src'
                    }
                ]
            },
            toAem: {
                files: generateAemFileArray()
            }
        },
        exec: {
            base_action_area: {
                command: 'npm run build:base-action-area',
                maxBuffer: 500 * 1024
            },
            mccLocal: {
                command: 'npm run build:mcc',
                maxBuffer: 500 * 1024
            },
            mccAem: {
                command: 'npm run build:mccAem',
                maxBuffer: 500 * 1024
            }
        }
    });

    grunt.registerTask('default', 'Making sure gruntfile runs', function () {
        grunt.log.write("All is good.").ok();
    });

    grunt.loadNpmTasks('grunt-contrib-copy');
    grunt.loadNpmTasks('grunt-exec');

    grunt.registerTask('copyAssets', ['copy:assets_baseActionArea', 'copy:assets_mcc']);
    grunt.registerTask('build', ['exec:mcc']);

    // Full Build
    grunt.registerTask('buildAem', ['exec:mccAem', 'copy:toAem']);

    //Clean Task
    grunt.registerTask('clean', 'Delete directories and files', function () {
var options = this.options();
    	options.force = true;
        grunt.file.delete('dist');
        grunt.file.delete('target');
        grunt.file.delete('src/assets');
        grunt.file.delete('coverage');
        grunt.file.delete(directories.ui_apps_dest + 'js', options);
        grunt.file.delete(directories.ui_apps_dest + 'css', options);
        grunt.log.write("'clean' task has completed").ok();
    });
};

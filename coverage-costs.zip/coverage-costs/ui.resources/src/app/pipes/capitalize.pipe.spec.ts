

import {CapitalizePipe} from "./capitalize.pipe";

describe('Pipe', () => {
    let pipe: CapitalizePipe;

    beforeEach(() =>{
        pipe = new CapitalizePipe();
    });

    it('should capitalize', () => {
        expect(pipe.transform('bob', true)).toEqual('Bob');
        expect(pipe.transform('bob', false)).toEqual('Bob');
        expect(pipe.transform('jones,bob', false)).toEqual('Jones, Bob');
        expect(pipe.transform(null, false)).toBeNull();
    })
})
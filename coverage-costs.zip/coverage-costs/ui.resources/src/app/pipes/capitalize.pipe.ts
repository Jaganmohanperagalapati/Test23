import {Pipe, PipeTransform} from "@angular/core";

@Pipe({
  name: 'capitalize'
})
export class CapitalizePipe implements PipeTransform {

  transform(value:any, words:boolean) {
    if (value) {
       var result = value.charAt(0).toUpperCase() + value.slice(1).toLowerCase();
       if( result.indexOf(",") != -1)
       {
               var inputStr = result.split(",");
               for(var i = 1; i < inputStr.length; i++)
               {
                   inputStr[i] = inputStr[i].trim().charAt(0).toUpperCase() + inputStr[i].trim().slice(1).toLowerCase();
               }
              result = inputStr.join(", ");
        }
        return result;
    }
    return value;
  }
}

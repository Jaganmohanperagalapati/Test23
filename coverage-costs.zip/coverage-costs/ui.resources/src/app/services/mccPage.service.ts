import { Injectable, } from '@angular/core';
import { KPService } from "../services/kp.service";
import { Observable } from "rxjs/Observable";
import 'rxjs/add/observable/combineLatest';
import { JSONConfigsService } from "../services/jsonConfigs.service";
//import { NGWrapperProxyPickerClient } from "ng2-proxy-picker-wrapper";
import { NGWrapperProxyPickerClient } from 'ng2-proxy-picker-wrapper';
import { MCCConstants } from "../util/MCCConstants.util";
import { MedicalBillsService } from "./medical-bills.service";
import {templates} from "./template.service";

declare var jsonConfigs;
declare var $kp;

export class AppObject {

    public errorCode: string;

    constructor( errorCode: string ) {
        this.errorCode = errorCode;
    }
}

@Injectable()
export class MCCPageService {

    private appObject$: Observable<AppObject>;

    constructor( protected kpSvc: KPService,
                 protected jsonConfigSvc: JSONConfigsService,
                 protected medicalBillsSvc: MedicalBillsService,
                 protected proxyPickerWrapper: NGWrapperProxyPickerClient) {
        try {
            if ( this.jsonConfigSvc.isMocked() )
                this.kpSvc.startUserProfileServer( this.jsonConfigSvc.apiUrl() );
        }
        finally {
            this.appObject$ = Observable.combineLatest(
                this.kpSvc.getUserProfileClientLoaded$(),
                this.medicalBillsSvc.getAllBills$(),
                this.proxyPickerWrapper)
                .map( ([clientLoaded, allBills, proxyPicker] ) => {
                    let ao:AppObject;

                    if (clientLoaded == null) {
                        ao = new AppObject(null);
                   } else if (clientLoaded == false) {
                       ao = new AppObject(MCCConstants.ErrorCodes.TechnicalError);
                   } else if (proxyPicker.isEntitlementErrorOccurredForSelf()
                           || proxyPicker.isEntitlementErrorOccurredForCurrentSelection()) {
                       ao = new AppObject(MCCConstants.ErrorCodes.TechnicalError);
                    } else if (clientLoaded == true && this.kpSvc.isMember() == false) {
                        ao = new AppObject(MCCConstants.ErrorCodes.NonMemberAccount);
                    } else if (clientLoaded == true && this.kpSvc.isMember() == true
                            && allBills == MedicalBillsService.ErrorMessage) {
                        ao = new AppObject(MCCConstants.ErrorCodes.TechnicalError);
                    } else {
                        ao = new AppObject("");
                    }

                    return ao;
                } );
        }
    }

    getAppObject$() {
        return this.appObject$;
    }
}

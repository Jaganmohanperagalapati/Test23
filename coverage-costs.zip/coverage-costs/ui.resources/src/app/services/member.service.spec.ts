import { async, inject, TestBed } from '@angular/core/testing';
import { HttpModule, Http, BaseRequestOptions, XHRBackend, Response, ResponseOptions, ResponseType } from "@angular/http";
import { MockBackend } from '@angular/http/testing';
import { MemberService } from "./member.service";
import { JSONConfigsService } from "./jsonConfigs.service";

import * as Mock from "../../app/util/MockResponses.util";
import * as NodeMock from "../../app/util/NodeMockResponses.util";
import {BehaviorSubject} from "rxjs/BehaviorSubject";
import {Observable} from "rxjs/Observable";
import 'rxjs/add/observable/of';


describe('MemberService', () => {


    beforeEach(() => {
        TestBed.configureTestingModule({
            //imports: [HttpModule],
            //providers: [
            //    MedicalBillsService,
            //    JSONConfigsService,
            //    { provide: XHRBackend , useClass: MockBackend }
            //]
        }).compileComponents();
    });

    describe('MemberService', () => {
        it ('should work',
            inject( [ ], ( ) => {
                let http1:any = {
                    get: () => {
                        return new BehaviorSubject<any>(
                            {
                                json: () => ("memberOne")
                            }
                        );
                    }
                };
                let jsonConfigSvc:any = {
                    apiHeaders: () => ({}),
                    apiUrl: () => ("doesntMatter"),
                    memberDataApiUri: () => ("doesntMatter")
                };
                let ms1:MemberService = new MemberService(http1, jsonConfigSvc);
                ms1.loadMemberData$().subscribe(
                    (success) => {expect(success).toBe("memberOne");}
                );
                let http2:any = {
                    get: () => {
                        let outValue:BehaviorSubject<any>;
                        outValue = new BehaviorSubject<any>(
                            {
                                json: () => ("memberOneButErrorWillOccurSoDoesntMatter")
                            }
                        );
                        outValue.error("SomeErrorOccurred");
                        return outValue;
                    }
                };
                let ms2:MemberService = new MemberService(http2, jsonConfigSvc);
                ms2.loadMemberData$().subscribe(
                    (success) => {expect(success).toBe("Error Retrieving Member Data");}
                );
            } )
        );
    });
});
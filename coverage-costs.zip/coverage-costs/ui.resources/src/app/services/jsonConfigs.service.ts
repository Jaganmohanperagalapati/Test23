import { Injectable, Input } from '@angular/core';
import 'rxjs/add/operator/catch';
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";
import { InputDecorator } from "@angular/core/src/metadata/directives";

declare var jsonConfigs;

@Injectable()
export class JSONConfigsService {

    private jCon: any;

    constructor() {
        this.jCon = jsonConfigs;
    }

    public isMocked() {
        return this.jCon.feature.isMocked;
    }

    public apiUrl(): string {
        return this.jCon.global.apiUrl;
    }
    
    public nodeApiUrl(): string {
        return this.jCon.global.apipApiUrl;
    }

    public apiHeaders(): any {
        return this.jCon.feature.apiHeaders;
    }

    public nodeApiHeaders(): any {
        return this.jCon.feature.NodeApiHeaders;
    }

    public exceptionMessageUrl( language: string ): string {
        return this.jCon.feature[ language ].ExceptionMsgURL;
    }

    public mccMessageUrl( language: string ): string {
        return this.jCon.feature[ language ].MCCMsgURL;
    }


    public mccConfigUrl(): string {
        return "/secure/coverage-costs.json.html";
    }

    public ppmConfigUrl(): string {
        return "/secure/payment-plan.json.html";
    }

    public medicalBillApiUri(): string {
        return this.jCon.feature.medicalBillApiUri;
    }
    public mccBffApiPrefixUrl(): string {
        return this.jCon.feature.mccBffApiPrefixUrl;
    }

    public getBillExpandObject(id:string):string {
        return this.jCon.feature[id];
    }

    public billExpandObjectUri():string {
        return this.jCon.feature.billExpandObjectUri;
    }


    public viewBillApiUri():string {
        return this.jCon.feature.viewBillApiUri;
    }

    public lastPaymentApiUri(): string {
        return this.jCon.feature.lastPaymentApiUri;
    }

    public getButtonValue(id: string): string {
        let buttons = this.jCon.feature.conditionalButton;
        for (let btn of buttons) {
            if (btn["id"] == id)
                return btn["value"];
        }
        return "";
    }

    public getControlObject(id: string): any {
        return this.jCon.feature[id];
    }

    public getFeatureEntryID(entry: any): string {
        try {
            return entry["id"];
        }
        catch (e){
            return null;
        }
    }

    public memberDataApiUri(): string {
        return this.jCon.feature.memberDataApiUri;
    }

    public userApiUri(): string{
        return this.jCon.feature.userApiUri;
    }

    public accessibleBillUri(): string{
        return this.jCon.feature.accessibleBillUri;
    }
}
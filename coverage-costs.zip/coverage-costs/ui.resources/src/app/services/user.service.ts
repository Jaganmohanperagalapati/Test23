import { Injectable } from "@angular/core";
import { ApiService } from "./api.service";
import { Http } from "@angular/http";
import { Observable } from "rxjs/Observable";
import 'rxjs/add/observable/of';
import { JSONConfigsService } from "./jsonConfigs.service";
import { KPService } from "./kp.service";
import { NGWrapperProxyPickerClient } from 'ng2-proxy-picker-wrapper';
import { BehaviorSubject } from "rxjs/BehaviorSubject";

@Injectable()
export class UserService extends ApiService {

    userData: any[] = [];
    users$: BehaviorSubject<any>[] = [];

    constructor(http: Http, protected jsonConfigSvc: JSONConfigsService, private proxyPickerWrapper: NGWrapperProxyPickerClient, private kpSvc: KPService) {
        super( http, jsonConfigSvc );
    }

    public getSelectedUser$(): Observable<any> {
		let relId: string = this.proxyPickerWrapper.getValue().getRelationshipId();

        if (!(relId in this.users$)) {
            if (relId == "self")
                // This will be included when we decided we want the information the api provides for self.
                //    this.users$[relId] = this.get(this.jsonConfigSvc.userApiUri(), null, true, true);
                // For now, we dont want to make that extra call
                this.users$[relId] = Observable.of({"self": true, "selfFunded": this.kpSvc.isUserSelfFunded()});
            else
                this.users$[relId] = this.get(this.jsonConfigSvc.userApiUri(), { "x-relid": relId}, true, true);
        }

        return this.users$[relId];
    }

    public getSelectedUserSelffunded$(): Observable<boolean> {
        return this.getSelectedUser$()
            .map((data) => this.mapSelfFunded(data))
            .catch((e) => Observable.of(null));
    }

    private mapSelfFunded(data: any): boolean {
        try {
            let selfFunded: boolean;
            if (data['self'] == true)
                selfFunded = data["selfFunded"];
            else {
                 selfFunded= data[0]["planInfos"][0]["selfFunded"];
            }
            return selfFunded;
        }
        catch (e) {
            return null;
        }
    }
}
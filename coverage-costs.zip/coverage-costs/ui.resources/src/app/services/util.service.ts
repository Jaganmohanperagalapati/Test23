import {Injectable} from "@angular/core";
import {isUndefined} from "util";

@Injectable()
export class UtilService {

    toUSD(toCheck): string {
            let newValue;
            try {
                if (toCheck !== null) {
                    if (toCheck === "-0.00") {
                        newValue = "-$" + (Math.abs(toCheck).toFixed(2)).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                    }
                    else if (toCheck >= 0) {
                        newValue = "$" + (Math.abs(toCheck).toFixed(2).toString()).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                    }
                    else if (toCheck < 0) {
                        newValue = "-$" + (Math.abs(toCheck).toFixed(2).toString()).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                    }
                    else{
                        newValue = toCheck;
                    }
                    return newValue;
                }
                else {
                    return toCheck;
                }
            }
            catch(err) {
                return "error";
            }
        }

    public formatDate(dateString: string){
        let toReturn: string;

        try {
            let date = dateString.split("-");
            let day = parseInt(date[2]);
            let month = parseInt(date[1]);
            let year = parseInt(date[0]);

            let dayString = day.toString();
            let monthString = month.toString();

            if (day < 10)
                dayString = "0" + dayString;

            if (month < 10)
                monthString = "0" + monthString;

            return monthString + "/" + dayString + "/" + year;
        }
        catch (err) {
            return "error";
        }
    }

    public upperCaseEachWord(text: string){
        let toReturn: string = '';
        let toUpper: string;
        try{
            text = text.toLowerCase();
            let split = text.split(' ');
            for (let i = 0; i < split.length; i++){

                if(split[i].charCodeAt(0) >= 97 || split[i].charCodeAt(0) <= 122)
                    toUpper = split[i].charAt(0).toUpperCase() + split[i].slice(1, split[i].length);
                else
                    toUpper = split[i]
                if(i === split.length - 1)
                    toReturn += toUpper;
                else
                    toReturn += toUpper + ' ';
            }
        }
        catch(err){
            return "error";
        }

        return toReturn;
    }


}
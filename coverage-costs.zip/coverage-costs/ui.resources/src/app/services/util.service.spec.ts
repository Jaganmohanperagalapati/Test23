import { async, inject, TestBed } from '@angular/core/testing';
import { HttpModule, Http, BaseRequestOptions, XHRBackend, Response, ResponseOptions, ResponseType } from "@angular/http";
import {UtilService} from "./util.service";


describe('UtilService', () => {

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpModule],
            providers: [
                UtilService
            ]
        });
    });

    describe('toUSD(toCheck)', () => {
        it ('should return a positive number in USD Currency format',
            inject ([ UtilService ], ( utilSvc) => {
                let test = utilSvc.toUSD(100);
                expect(test).toEqual("$100.00");
            }));

        it ('should return a negative number in USD currency format',
            inject ([ UtilService ], ( utilSvc) => {
                let test = utilSvc.toUSD(-100);
                expect(test).toEqual("-$100.00");
            }));

        it ('should format -0.00 to -$0.00', () => {
           inject ( [ UtilService ], ( utilSvc) => {
               let test = utilSvc.toUSD("-0.00");
               expect(test).toEqual("-$0.00");
           })
        });

    });

    describe('formatDate(dateString)', () => {
        it ('should return a yyyy-mm-dd date changed to mm/dd/yyyy format',
            inject ([ UtilService ], ( utilSvc) => {
                let test = utilSvc.formatDate("2015-12-10");
                expect(test).toEqual("12/10/2015");
            }));

        it ("should return an error for invalid date format",
           inject ( [UtilService ], ( utilSvc) => {
                let test = utilSvc.formatDate("hello");
                expect(test).toEqual("NaN/NaN/NaN");
           }));

    });
});
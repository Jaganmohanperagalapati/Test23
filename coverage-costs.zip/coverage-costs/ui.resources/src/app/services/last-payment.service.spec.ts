
import { inject, TestBed } from '@angular/core/testing';
import { HttpModule, XHRBackend, Response, ResponseOptions } from "@angular/http";
import { MockBackend } from '@angular/http/testing';
import { LastPaymentService, LastPayment } from "./last-payment.service";
import { JSONConfigsService } from "./jsonConfigs.service";

import * as NodeMock from "../../app/util/NodeMockResponses.util";
import {Observable} from "rxjs/Observable";
import {RandomDateString, RandomPositiveMoneyString} from "../util/NodeMockResponses.util";
declare var $kp;

describe('LastPaymentService', () => {
    beforeEach(() => {

        TestBed.configureTestingModule({
            imports: [HttpModule],
            providers: [
                LastPaymentService,
                JSONConfigsService,
                { provide: XHRBackend , useClass: MockBackend }
            ]
        });
    });

    describe('getLastPayment()', () => {
        it ('should return an Observable<any> of an instance of LastPayment with the correct values',
            inject( [ LastPaymentService, XHRBackend ], ( lastPaymentSvc, mockBackend ) => {
                lastPaymentSvc.lastPayment$ = Observable.of(JSON.stringify(NodeMock.LastPaymentPositiveValue));
                lastPaymentSvc.getLastPayment$().subscribe( ( data ) => {
                    expect( data ).toEqual(JSON.stringify(NodeMock.LastPaymentPositiveValue))
                } );
            } )
        );

        it ('should return an Observable<any> of an instance of LastPayment with empty string values',
            inject( [ LastPaymentService, XHRBackend ], ( lastPaymentSvc, mockBackend ) => {
                lastPaymentSvc.lastPayment$ = Observable.of(JSON.stringify(NodeMock.LastPaymentNone));
                lastPaymentSvc.getLastPayment$().subscribe( ( data ) => {
                    expect( data ).toEqual(JSON.stringify(NodeMock.LastPaymentNone));
                } );
            } )
        );

        it ('should return an Observable<any> of null if the last payment data is formatted unexpectedly',
            inject( [ LastPaymentService, XHRBackend ], ( lastPaymentSvc, mockBackend ) => {
                lastPaymentSvc.lastPayment$ = Observable.of(JSON.stringify({"test": "wrong"}));
                lastPaymentSvc.getLastPayment$().subscribe( ( data ) => {
                    expect( data ).toEqual(JSON.stringify({"test": "wrong"}));
                } );
            } )
        );

        it ('map lastPayment',
            inject( [ LastPaymentService, XHRBackend ], ( lastPaymentSvc, mockBackend ) => {
                let json = {
                    "latestPayment": [
                        {
                            "amount": "1",
                            "date": "2"
                        }
                    ]
                };
                let test = lastPaymentSvc.mapLastPayment(json);
                expect(test.getAmount()).toEqual("1");
                expect(test.getDate()).toEqual("2");
            } )
        );
        it ('should have a working "mapLastPayment" function',
            inject( [ LastPaymentService, XHRBackend ], ( lastPaymentSvc, mockBackend ) => {
                expect(lastPaymentSvc.mapLastPayment([])).toEqual(new LastPayment("",""));
                expect(lastPaymentSvc.mapLastPayment(null)).toBeNull();
            } )
        );
    });

});

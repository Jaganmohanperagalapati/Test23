
import { async, inject, TestBed } from '@angular/core/testing';
import { HttpModule, Http, BaseRequestOptions, XHRBackend, Response, ResponseOptions, ResponseType } from "@angular/http";
import {UtilService} from "./util.service";
import {JSONConfigsService} from "./jsonConfigs.service";
import {ApiService} from "./api.service";
import {MockBackend} from "@angular/http/testing";

import { SessionCacheService } from "./session-cache.service";
import * as SessionCacheMock from "../../app/util/SessionCacheMock.util";


class Empty { }

describe('SessionCacheService', () => {

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpModule],
            providers: [
                SessionCacheService,
                JSONConfigsService,
                ApiService,
                UtilService,
                { provide: XHRBackend , useClass: MockBackend }
            ]
        });
    });
       
    describe('getCache$()', () => {
        it('should return Empty Resultset',
            inject( [ SessionCacheService, XHRBackend ], ( sessionCacheSvc, mockBackend ) => {
                
                mockBackend.connections.subscribe( ( connection ) => {
                    connection.mockRespond( new Response( new ResponseOptions( {
                        body: JSON.stringify(SessionCacheMock.SessionCacheEmpty)
                    } ) ) );
                } );
                
                sessionCacheSvc.getCache$().subscribe( ( data ) => {
                    console.log("******** SESSION CACHE ********* : data = " + JSON.stringify(data));
                    expect( data ).toEqual(SessionCacheMock.SessionCacheEmpty);
                } );
                //
                //also check the following private function
                (sessionCacheSvc['_serverError'])('SomeError').subscribe(
                    (result) => {expect(true).toBe(false);},
                    (error) => {expect(error).toBe("SomeError");}
                );
            })
        );
    });

    describe('putCache$()', () => {
        it('should put Empty Resultset',
            inject( [ SessionCacheService, XHRBackend ], ( sessionCacheSvc, mockBackend ) => {
                
                mockBackend.connections.subscribe( ( connection ) => {
                    connection.mockRespond( new Response( new ResponseOptions( {
                        body: JSON.stringify(SessionCacheMock.SessionCacheEmpty)
                    } ) ) );
                } );
                
                sessionCacheSvc.putCache$().subscribe( ( data ) => {
                    console.log("******** SESSION CACHE ********* : data = " + JSON.stringify(data));
                    expect( data ).toEqual(SessionCacheMock.SessionCacheEmpty);
                } );
            })
        );
    });

});

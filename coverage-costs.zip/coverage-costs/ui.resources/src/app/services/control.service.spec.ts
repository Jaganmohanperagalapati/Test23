import { async, inject, TestBed } from '@angular/core/testing';
import { JSONConfigsService } from "./jsonConfigs.service";
import { KPService } from './kp.service';
import { NGWrapperProxyPickerClient } from 'ng2-proxy-picker-wrapper';

import * as Mock from "../../app/util/MockResponses.util";
import { ControlService } from "./control.service";
import { GuarantorStatus } from "./medical-bills.service";

class Empty { }

class KpSvcMockHasEntitlement {
    hasEntitlementForCurrentUser( key ) {
        return true;
    }
}

class KpSvcMockDoesNotHaveEntitlement {
    hasEntitlementForCurrentUser( key ) {
        return false;
    }
}

class KpSvcMockUserSelfFunded {
    isUserSelfFunded() {
        return true;
    }
}

class KpSvcMockUserNotSelfFunded {
    isUserSelfFunded() {
        return false;
    }
}

class ProxyWrapperMockProxySelected {
    getValue() {
        return {
            isProxySelected: () => {
                return true;
            }
        }
    }
}

class ProxyWrapperMockProxyNotSelected {
    getValue() {
        return {
            isProxySelected: () => {
                return false;
            }
        }
    }
}

describe( 'ControlService', () => {

    describe('No dependencies', () => {
        beforeEach( () => {
            TestBed.configureTestingModule( {
                providers: [
                    ControlService,
                    {provide: KPService, useClass: Empty},
                    { provide: NGWrapperProxyPickerClient, useClass: Empty }
                ]
            } );
        } );

        describe('findEntryWithValue()', () => {
            it('should return the entry in the list that has a property value matching passed value',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.findEntryWithValue(
                            "testing",
                            [ { value:"testing"} ]
                        )
                    ).toEqual( { value: "testing" });
                })
            )

            it('should return the entry in the list that has a property value matching passed value',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.findEntryWithValue(
                            "testing",
                            [ { value:"Testing"} ]
                        )
                    ).toEqual( { value: "Testing" });
                })
            )

            it('should return the entry in the list that has a property value matching passed value',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.findEntryWithValue(
                            "testing",
                            [ { value:"testing/"} ]
                        )
                    ).toEqual( { value: "testing/" });
                })
            )

            it('should return the entry in the list that has a property value matching passed value',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.findEntryWithValue(
                            "testing/",
                            [ { value:"testing"} ]
                        )
                    ).toEqual( { value: "testing" });
                })
            )

            it('should return null when no matching entry present',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.findEntryWithValue(
                            "nothing",
                            [ { value:"testing"} ]
                        )
                    ).toEqual( null );
                })
            )
        })

        describe('checkEntryMeetsControls()', () => {
            it('should return true if user should be and is Guarantor',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [{
                                    guarantor: true
                                }]
                            },
                            GuarantorStatus.Guarantor,
                        )
                    ).toEqual( true );
                })
            )

            it('should return false if user should be but isn\'t guarantor',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [{
                                    guarantor: true
                                }]
                            },
                            GuarantorStatus.NonGuarantor
                        )
                    ).toEqual( false );
                })
            )

            it('should return false if user should be guarantor but guarantor error',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [{
                                    guarantor: true
                                }]
                            },
                            GuarantorStatus.Error
                        )
                    ).toEqual( false );
                })
            )

            it('should return true if user should have balance and totalBalance is not empty',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [{
                                    hasBalance: true
                                }]
                            },
                            GuarantorStatus.Guarantor,
                            true,
                            "20.00"
                        )
                    ).toEqual( true );
                })
            )

            it('should return false if user should have balance and totalBalance is empty',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [{
                                    hasBalance: true
                                }]
                            },
                            GuarantorStatus.Guarantor,
                            true,
                            ""
                        )
                    ).toEqual( false );
                })
            )

            it('should return false if user shouldn\'t have balance and totalBalance is not empty',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [{
                                    hasBalance: false
                                }]
                            },
                            GuarantorStatus.Guarantor,
                            true,
                            "20.00"
                        )
                    ).toEqual( false );
                })
            )

            it('should return true if user should\'t have balance and totalBalance is empty',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [{
                                    hasBalance: false
                                }]
                            },
                            GuarantorStatus.Guarantor,
                            true,
                            ""
                        )
                    ).toEqual( true );
                })
            )

            it('should return true if user should have payment and lastPayment is not empty',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [{
                                    hasPayment: true
                                }]
                            },
                            GuarantorStatus.Guarantor,
                            true,
                            "",
                            "2.0"
                        )
                    ).toEqual( true );
                })
            )

            it('should return false if user should have payment and lastPayment is empty',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [{
                                    hasPayment: true
                                }]
                            },
                            GuarantorStatus.Guarantor,
                            true,
                            "",
                            ""
                        )
                    ).toEqual( false );
                })
            )

            it('should return false if user shouldn\'t have payment and lastPayment is not empty',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [{
                                    hasPayment: false
                                }]
                            },
                            GuarantorStatus.Guarantor,
                            true,
                            "",
                            "2.00"
                        )
                    ).toEqual( false );
                })
            )

            it('should return true if user should\'t have paymnet and lastPayent is empty',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [{
                                    hasPayment: false
                                }]
                            },
                            GuarantorStatus.Guarantor,
                            true,
                            "",
                            ""
                        )
                    ).toEqual( true );
                })
            )

            it('should return true if proxy should be and is self funded',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [{
                                    "proxy-self-funded": true
                                }]
                            },
                            GuarantorStatus.Guarantor,
                            true
                        )
                    ).toEqual( true );
                })
            )

            it('should return false if proxy should be and is not self funded',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [{
                                    "proxy-self-funded": true
                                }]
                            },
                            GuarantorStatus.Guarantor,
                            false
                        )
                    ).toEqual( false );
                })
            )

            it('should return true if proxy should not be and is self funded',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [{
                                    "proxy-self-funded": false
                                }]
                            },
                            GuarantorStatus.Guarantor,
                            true
                        )
                    ).toEqual( false );
                })
            )

            it('should return true if proxy should not be and is not self funded',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [{
                                    "proxy-self-funded": false
                                }]
                            },
                            GuarantorStatus.Guarantor,
                            false
                        )
                    ).toEqual( true );
                })
            )
        })

    })

    describe('KP Service Current User Has Entitlement', () => {
        beforeEach( () => {
            TestBed.configureTestingModule( {
                providers: [
                    ControlService,
                    {provide: KPService, useClass: KpSvcMockHasEntitlement},
                    { provide: NGWrapperProxyPickerClient, useClass: Empty }
                ]
            } );
        } );

        describe('checkEntryMeetsControls()', () => {
            it( 'should return true if user should have and has entitlement',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [ {
                                    entitlementKey: '1'
                                } ]
                            }
                        )
                    ).toEqual( true );
                } )
            )
        })
    })

    describe('KP Service Current User Does Not Have Entitlement', () => {
        beforeEach( () => {
            TestBed.configureTestingModule( {
                providers: [
                    ControlService,
                    {provide: KPService, useClass: KpSvcMockDoesNotHaveEntitlement},
                    { provide: NGWrapperProxyPickerClient, useClass: Empty }
                ]
            } );
        } );

        describe('checkEntryMeetsControls()', () => {
            it( 'should return false if user should have entitlement and does not have entitlement',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [ {
                                    entitlementKey: '1'
                                } ]
                            }
                        )
                    ).toEqual( false );
                } )
            )
        })
    })

    describe('KP Service User Is Self Funded', () => {
        beforeEach( () => {
            TestBed.configureTestingModule( {
                providers: [
                    ControlService,
                    {provide: KPService, useClass: KpSvcMockUserSelfFunded},
                    { provide: NGWrapperProxyPickerClient, useClass: Empty }
                ]
            } );
        } );

        describe('checkEntryMeetsControls()', () => {
            it( 'should return true if user should be and is self funded',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [ {
                                    'self-funded': true
                                } ]
                            }
                        )
                    ).toEqual( true );
                } )
            )

            it( 'should return false if user should not be and is self funded',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [ {
                                    'self-funded': false
                                } ]
                            }
                        )
                    ).toEqual( false );
                } )
            )
        })
    })

    describe('KP Service User Is Not Self Funded', () => {
        beforeEach( () => {
            TestBed.configureTestingModule( {
                providers: [
                    ControlService,
                    {provide: KPService, useClass: KpSvcMockUserNotSelfFunded},
                    { provide: NGWrapperProxyPickerClient, useClass: Empty }
                ]
            } );
        } );

        describe('checkEntryMeetsControls()', () => {
            it( 'should return false if user should be and is not self funded',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [ {
                                    'self-funded': true
                                } ]
                            }
                        )
                    ).toEqual( false );
                } )
            )

            it( 'should return true if user should not be and is not self funded',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [ {
                                    'self-funded': false
                                } ]
                            }
                        )
                    ).toEqual( true );
                } )
            )
        })
    })

    describe('Proxy Wrapper Proxy Selected', () => {
        beforeEach( () => {
            TestBed.configureTestingModule( {
                providers: [
                    ControlService,
                    {provide: KPService, useClass: Empty},
                    { provide: NGWrapperProxyPickerClient, useClass: ProxyWrapperMockProxySelected }
                ]
            } );
        } );

        describe('checkEntryMeetsControls()', () => {
            it( 'should return true if proxy should be and is selected',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [ {
                                    'proxy-selected': true
                                } ]
                            }
                        )
                    ).toEqual( true );
                } )
            )

            it( 'should return false if proxy should not be and is selected',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [ {
                                    'proxy-selected': false
                                } ]
                            }
                        )
                    ).toEqual( false );
                } )
            )
        })
    })

    describe('Proxy Wrapper Proxy Not Selected', () => {
        beforeEach( () => {
            TestBed.configureTestingModule( {
                providers: [
                    ControlService,
                    {provide: KPService, useClass: Empty},
                    { provide: NGWrapperProxyPickerClient, useClass: ProxyWrapperMockProxyNotSelected }
                ]
            } );
        } );

        describe('checkEntryMeetsControls()', () => {
            it( 'should return false if proxy should be and is not selected',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [ {
                                    'proxy-selected': true
                                } ]
                            }
                        )
                    ).toEqual( false );
                } )
            )

            it( 'should return true if proxy should not be and is not selected',
                inject( [ ControlService ], ( controlSvc ) => {
                    expect(
                        controlSvc.checkEntryMeetsControls(
                            {
                                control: [ {
                                    'proxy-selected': false
                                } ]
                            }
                        )
                    ).toEqual( true );
                } )
            )
        })
    })
});
import { Injectable } from "@angular/core";
import { ApiService } from "./api.service";
import { Http } from "@angular/http";
import { JSONConfigsService } from "./jsonConfigs.service";
import { Observable } from "rxjs/Observable";
import { URLSearchParams} from "@angular/http";
import {PaymentPlanInformationContext} from "../components/payment-plan-information/payment-plan-information.component";
import {UtilService} from "./util.service";

export class PaymentPlanHolder{
    exists: boolean;
    information: PaymentPlanInformationContext

    constructor(exists: boolean, information: PaymentPlanInformationContext){
        this.exists = exists;
        this.information = information;
    }
}

@Injectable()
export class PaymentPlanService extends ApiService {

    paymentPlan$: Observable<any>;

    constructor(http: Http, jsonConfigSvc: JSONConfigsService, private util: UtilService) {
        super( http, jsonConfigSvc );
    }

    makePaymentPlanCall$(guarantorAccount: any, type: string): Observable<any>{

        let myParams = new URLSearchParams();

        myParams.set("filter", `{"where":{"billType":"${type}"}}`);

        super.setSearchParams(myParams);

        this.paymentPlan$ = super.get("/mycare/coverage-costs/v1/medical/paymentplan", {'x-guarantoraccountnumber': guarantorAccount}, true, true);
        return this.paymentPlan$;

    }



    toPaymentPlanObject(name: string, guarantorAccount: any, type: string, json: any): PaymentPlanHolder {

        let response = json['paymentPlan'];
        let information;
        let exists;

        if(JSON.stringify(response) != JSON.stringify([])) {
            information = new PaymentPlanInformationContext(this.util.upperCaseEachWord(name), guarantorAccount, type, this.util.toUSD(json['paymentPlan'].monthlyAmountDue), this.util.formatDate(json['paymentPlan'].nextDueDate), this.util.toUSD(json['paymentPlan'].originalTotalAmount), this.util.formatDate(json['paymentPlan'].startDate), this.util.toUSD(json['paymentPlan'].remainingTotalAmount));

            exists = true;
        }
        else{
            information = null
            exists = false;
        }

        return new PaymentPlanHolder(exists, information);
    }

    getPaymentPlan$(name: string, guarantorAccount: any, type:string): Observable<any> {
        return this.makePaymentPlanCall$(guarantorAccount, type).map(data =>{
            return this.toPaymentPlanObject(name, guarantorAccount, type, data);
        });
    }











}
import { Injectable, NgZone } from "@angular/core";
import { ApiService } from "./api.service";
import { Http } from "@angular/http";
import { JSONConfigsService } from "./jsonConfigs.service";
import { Observable } from "rxjs/Observable";
import { ReplaySubject } from "rxjs/ReplaySubject";
import 'rxjs/add/observable/fromPromise';

declare var $kp: any;

export class LastPayment {
    private amount: string;
    private date: string;

    constructor( amount: string, date: string ) {
        this.amount = amount;
        this.date = date;
    }

    public getAmount() {return this.amount;}
    public getDate() {return this.date;}
}

@Injectable()
export class LastPaymentService extends ApiService {

    public static ErrorMessage: any = null;

    // lastPayment$: ReplaySubject<any> = null;
    lastPayment$: Observable<any> = null;

    constructor( private zone: NgZone, http: Http, jsonConfigSvc: JSONConfigsService ) {
        super( http, jsonConfigSvc );
    }

    getLastPayment$(): Observable<LastPayment> {
        if (this.lastPayment$ == null) {
            this.lastPayment$ = new ReplaySubject<any>(1);
            // var Communicator = $kp.KPClientCommons.Communicator;
            // var promise = Communicator.CHANNEL[Communicator.ENUMS.CHANNEL.GLOBAL]
            //     .request({ topic: Communicator.ENUMS.TOPIC.BFF_API_LOAD});
            this.lastPayment$ = super.get(this.jsonConfigSvc.lastPaymentApiUri(), null, true, true)
               .map((data) => this.mapLastPayment(data))
               .catch((e) => Observable.of(null));
            // promise
            //     .then((data) => {
            //         this.zone.run( () => {
            //             this.lastPayment$.next(
            //                 this.mapLastPayment(data.data['lastpayment'].value) );
            //         } );
            //     })
            //     .catch((error) => {
            //          this.zone.run( () => {
            //             this.lastPayment$.next( null );
            //         });
            //     });
        }

        return this.lastPayment$;
    }

    public mapLastPayment(data: any): LastPayment {
        try {
            if (data.length == 0) {
                return new LastPayment("","");
            }
            let amount: string = data["latestPayment"][0]["amount"];
            let date: string = data["latestPayment"][0]["date"];

            return new LastPayment(amount, date);
        }
        catch (e) {
            return null;
        }
    }
}
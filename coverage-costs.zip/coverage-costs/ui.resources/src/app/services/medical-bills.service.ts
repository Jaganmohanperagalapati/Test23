import { Injectable, NgZone } from "@angular/core";
import { ApiService } from "./api.service";
import { Http } from "@angular/http";
import { JSONConfigsService } from "./jsonConfigs.service";
import { Observable } from "rxjs/Observable";
import { ReplaySubject } from "rxjs/ReplaySubject";
import 'rxjs/add/observable/fromPromise';

declare var $kp: any;

export enum GuarantorStatus {
    Unknown,
    Guarantor,
    NonGuarantor,
    Error
}

@Injectable()
export class MedicalBillsService extends ApiService {

    public static ErrorMessage: any = null;

    // medicalBills$: ReplaySubject<any> = null;
    medicalBills$: ReplaySubject<any> = null;
    guarantorStatus$: Observable<GuarantorStatus> = null;
    totalBill$: Observable<string> = null;

    constructor(private zone: NgZone, http: Http, jsonConfigSvc: JSONConfigsService) {
        super( http, jsonConfigSvc );
    }

    getAllBills$(): Observable<any> {
        if (this.medicalBills$ == null) {
            try {
                this.medicalBills$ = new ReplaySubject<any>(1);
                var Communicator = $kp.KPClientCommons.Communicator;
                var promise = Communicator.CHANNEL[Communicator.ENUMS.CHANNEL.GLOBAL]
                    .request({topic: Communicator.ENUMS.TOPIC.BFF_API_LOAD});
                promise
                    .then((data) => {
                        this.zone.run(() => {
                            this.medicalBills$.next(data.data['medicalbills'].value);
                            this.mapGuarDepId(data.data['medicalbills'].value.guarantor);
                        });
                    });
            } catch (error) {
                this.medicalBills$.next(MedicalBillsService.ErrorMessage)
            }


        }
        return this.medicalBills$;
    }

    getGuarantorStatus$(): Observable<GuarantorStatus> {
        if (this.guarantorStatus$ == null) {
            this.guarantorStatus$ = this.getAllBills$()
                .map((data: any) => {
                    return this.mapGuarantorStatus(data);
                })
                .catch((e) => Observable.of(GuarantorStatus.Error));

        }

        return this.guarantorStatus$;
    }

    getTotalBill$(): Observable<string> {
        if (this.totalBill$ == null)
            this.totalBill$ = this.getAllBills$()
                .map((data) => {
                    return this.mapTotalBill(data);
                })
                .catch((e) => Observable.of(null));

        return this.totalBill$;
    }

    private mapGuarantorStatus(data: any): GuarantorStatus {
        try {
            let isGuarantor = data["isPatientGuarantor"];

            let status: GuarantorStatus;
            if (isGuarantor == true)
                status = GuarantorStatus.Guarantor;
            else if (isGuarantor == false)
                status = GuarantorStatus.NonGuarantor;
            else
                status = GuarantorStatus.Error;

            return status;
        }
        catch (e) {
            return GuarantorStatus.Error;
        }
    }

    private mapTotalBill(data: any): string {
        try {
            if (data["totalBillAmount"])
                return data["totalBillAmount"];
            else
                return null;
        }
        catch (e) {
            return null;
        }
    }

    private mapGuarDepId(data : any){
        try {
            var toStore = {};
            var count = 0;

            data.forEach(function (element) {
                var idString = '"id":"' + element.guarantoraccount + '"';
                var depIdString = '"dep_id":"' + element.deploymentId + '"';
                toStore[count]=("{" + idString + "," + depIdString + "}");
                count++;

            });
            sessionStorage.setItem('deployIds', JSON.stringify(toStore));
        } catch(e){
        }
    }
}

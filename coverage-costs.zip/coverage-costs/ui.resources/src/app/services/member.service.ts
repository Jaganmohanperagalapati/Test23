/**
 * Created by clarklyu on 5/16/17.
 */
import { Injectable }    from "@angular/core";
import { Http } from "@angular/http";
import { Observable } from "rxjs/Observable"; 
import { ApiService } from "./api.service";
import { JSONConfigsService } from "./jsonConfigs.service";

@Injectable()
export class MemberService extends ApiService {

    private member$: Observable<any> = null;

    public static errorMessage: string = "Error Retrieving Member Data";

    constructor(http: Http,  jsonConfigSvc: JSONConfigsService) {
        super(http, jsonConfigSvc);
    }

    public loadMemberData$(): Observable<any> {
        if (this.member$ == null)
            this.member$ = super.get(this.jsonConfigSvc.memberDataApiUri())
                .catch( err => Observable.of(MemberService.errorMessage));

        return this.member$;
    }
}
import { async, inject, TestBed } from '@angular/core/testing';
import { HttpModule, Http, BaseRequestOptions, XHRBackend, Response, ResponseOptions, ResponseType } from "@angular/http";
import {UtilService} from "./util.service";
import {PaymentPlanService} from "./payment-plan.service";
import {JSONConfigsService} from "./jsonConfigs.service";
import {ApiService} from "./api.service";
import {MockBackend} from "@angular/http/testing";

import * as NodeMock from "../../app/util/NodeMockResponses.util";


describe('UtilService', () => {

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpModule],
            providers: [
                PaymentPlanService,
                JSONConfigsService,
                ApiService,
                UtilService,
                { provide: XHRBackend , useClass: MockBackend }
            ]
        });
    });

    describe('makePaymentPlanCall$()', () => {
        it('should return valid data',
            inject( [ PaymentPlanService, XHRBackend ], ( paymentPlanSvc, mockBackend ) => {
                mockBackend.connections.subscribe( ( connection ) => {
                    connection.mockRespond( new Response( new ResponseOptions( {
                        body: JSON.stringify(NodeMock.HasPaymentPlan)
                    } ) ) );
                } );

                paymentPlanSvc.makePaymentPlanCall$('accountNumber', 'type').subscribe( ( data ) => {
                    expect( data ).toEqual(NodeMock.HasPaymentPlan);
                } );
            })
        );
    });

    describe('toPaymentPlanObject()', () => {
        it('should return a payment plan object from JSON data',
            inject([PaymentPlanService] , ( paymentPlanSvc ) => {

            let data = paymentPlanSvc.toPaymentPlanObject('name', 'accountNumber', 'type', NodeMock.HasPaymentPlan);
            expect(data.exists).toBeTruthy();
            expect(data.information.guarantorName).toEqual('Name');
        }));

        it('should return a null payment plan object from empty payment plan',
            inject([PaymentPlanService] , ( paymentPlanSvc ) => {

                let data = paymentPlanSvc.toPaymentPlanObject('name', 'accountNumber', 'type', NodeMock.HasNoPaymentPlan);
                expect(data.exists).toBeFalsy();
                expect(data.information).toEqual(null);
            }));
    });

    describe('getPaymentPlan$()', () => {
        it('should return an observable with valid data being emitted',
            inject([PaymentPlanService, XHRBackend], ( paymentPlanSvc, mockBackend) =>{
                mockBackend.connections.subscribe( ( connection ) => {
                    connection.mockRespond( new Response( new ResponseOptions( {
                        body: JSON.stringify(NodeMock.HasPaymentPlan)
                    } ) ) );
                } );

                let data =  paymentPlanSvc.getPaymentPlan$();

                data.subscribe(
                    next => { expect(next.exists).toEqual(true); }
                );
            }));
    });
});

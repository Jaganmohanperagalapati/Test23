import { KPService } from './kp.service';
import { async, inject, TestBed } from '@angular/core/testing';
import { HttpModule, Http, BaseRequestOptions, XHRBackend, Response, ResponseOptions, ResponseType } from "@angular/http";
import { MockBackend } from '@angular/http/testing';
import { UserService } from "./user.service";
import { JSONConfigsService } from "./jsonConfigs.service";

import * as Mock from "../../app/util/MockResponses.util";
import * as NodeMock from "../../app/util/NodeMockResponses.util";
import { NGWrapperProxyPickerClient } from 'ng2-proxy-picker-wrapper';

class ProxyWrapperMockSelf {
    getValue() {
        return {
            getRelationshipId: () => {
                return "self";
            }
        }
    }
};

class ProxyWrapperMockNotSelf {
    getValue() {
        return {
            getRelationshipId: () => {
                return "12345";
            }
        }
    }
}

class KpServiceMockSelfFunded {
    isUserSelfFunded() {
        return true;
    }
}

class KpServiceMockNotSelfFunded {
    isUserSelfFunded() {
        return false;
    }
}

describe('User Service', () => {
    describe('Proxy Wrapper returns user is self and kp service says user is self funded', () => {
        beforeEach(() => {
            TestBed.configureTestingModule({
                imports: [HttpModule],
                providers: [
                    UserService,
                    JSONConfigsService,
                    { provide: NGWrapperProxyPickerClient, useClass: ProxyWrapperMockSelf },
                    { provide: XHRBackend, useClass: MockBackend },
                    { provide: KPService, useClass: KpServiceMockSelfFunded }
                ]
            });
        })

        describe('getSelectedUser$()', () => {
            it('should return an Observable<any> of user data returned by the http request',
                inject([UserService, XHRBackend], (userSvc, mockBackend) => {

                    mockBackend.connections.subscribe((connection) => {
                        expect(connection.request.headers.get('x-relId')).toBeNull();

                        connection.mockRespond(new Response(new ResponseOptions({
                            body: JSON.stringify(NodeMock.UserSelfFunded)
                        })));
                    });

                    // Put this back when we do the service right
                    /* userSvc.getSelectedUser$().subscribe( ( data ) => {
                        expect( data ).toEqual( NodeMock.UserSelfFunded )
                    } ); */
                    userSvc.getSelectedUser$().subscribe((data) => {
                        expect(data).toEqual({ "self": true, "selfFunded": true });
                    })
                })
            );
        });

        describe('getSelectedUserSelfFunded$()', () => {
            it('should return an Observable<any> of true',
                inject([UserService, XHRBackend], (userSvc, mockBackend) => {

                    mockBackend.connections.subscribe((connection) => {

                        connection.mockRespond(new Response(new ResponseOptions({
                            body: JSON.stringify(NodeMock.UserSelfFunded)
                        })));
                    });

                    userSvc.getSelectedUserSelffunded$().subscribe((data) => {
                        console.log(data);
                        expect(data).toEqual(true)
                    });
                })
            );
        });
    });

    describe('Proxy Wrapper returns user is self and kp service says user is not self funded', () => {
        beforeEach(() => {
            TestBed.configureTestingModule({
                imports: [HttpModule],
                providers: [
                    UserService,
                    JSONConfigsService,
                    { provide: NGWrapperProxyPickerClient, useClass: ProxyWrapperMockSelf },
                    { provide: XHRBackend, useClass: MockBackend },
                    { provide: KPService, useClass: KpServiceMockNotSelfFunded }
                ]
            });
        })

        describe('getSelectedUserSelfFunded$()', () => {
            it('should return an Observable<any> of true',
                inject([UserService, XHRBackend], (userSvc, mockBackend) => {

                    mockBackend.connections.subscribe((connection) => {

                        connection.mockRespond(new Response(new ResponseOptions({
                            body: JSON.stringify(NodeMock.UserSelfFunded)
                        })));
                    });

                    userSvc.getSelectedUserSelffunded$().subscribe((data) => {
                        expect(data).toEqual(false)
                    });
                })
            );
        });

    });

    describe('Proxy Wrapper returns user is not self', () => {
        beforeEach(() => {
            TestBed.configureTestingModule({
                imports: [HttpModule],
                providers: [
                    UserService,
                    JSONConfigsService,
                    { provide: NGWrapperProxyPickerClient, useClass: ProxyWrapperMockNotSelf },
                    { provide: XHRBackend, useClass: MockBackend },
                    { provide: KPService, useClass: KpServiceMockSelfFunded }
                ]
            });
        });

        describe('getSelectedUser$()', () => {
            it('should return an Observable<any> of user data returned by the http request',
                inject([UserService, XHRBackend], (userSvc, mockBackend) => {

                    mockBackend.connections.subscribe((connection) => {
                        expect(connection.request.headers.get('x-relId')).toEqual('12345');

                        connection.mockRespond(new Response(new ResponseOptions({
                            body: JSON.stringify(NodeMock.UserSelfFunded)
                        })));
                    });

                    userSvc.getSelectedUser$().subscribe((data) => {
                        expect(data).toEqual(NodeMock.UserSelfFunded)
                    });
                })
            );
        });

        describe('getSelectedUserSelfFunded$()', () => {
            it('should return an Observable<any> of true',
                inject([UserService, XHRBackend], (userSvc, mockBackend) => {

                    mockBackend.connections.subscribe((connection) => {

                        connection.mockRespond(new Response(new ResponseOptions({
                            body: JSON.stringify(NodeMock.UserSelfFunded)
                        })));
                    });

                    userSvc.getSelectedUserSelffunded$().subscribe((data) => {
                        expect(data).toEqual(true)
                    });
                })
            );
        });

        describe('getSelectedUserSelfFunded$()', () => {
            it('should return an Observable<any> of true',
                inject([UserService, XHRBackend], (userSvc, mockBackend) => {

                    mockBackend.connections.subscribe((connection) => {

                        connection.mockRespond(new Response(new ResponseOptions({
                            body: JSON.stringify(NodeMock.UserNotSelfFunded)
                        })));
                    });

                    userSvc.getSelectedUserSelffunded$().subscribe((data) => {
                        expect(data).toEqual(false)
                    });
                })
            );
        });
    })
});
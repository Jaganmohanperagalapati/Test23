import {ApplicationRef, ChangeDetectorRef, Injectable, NgZone} from '@angular/core';
import 'rxjs/add/operator/catch';
//import { NGWrapperProxyPickerClient } from "ng2-proxy-picker-wrapper";
import { NGWrapperProxyPickerClient } from 'ng2-proxy-picker-wrapper';
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { JSONConfigsService } from "./jsonConfigs.service";
import { Observable } from "rxjs/Observable";
import {templates} from "./template.service";


/*import * as _ from 'lodash';*/

declare var jsonConfigs: any;
declare var $kp: any;

@Injectable()
export class KPService {

    public static ProfileLoadSuccessMsg: string = "Success";
    public static ProfileLoadErrorMsg: string = "Error";

    public static ProxyChangeMsg: string = "Changed";

    private userProfileClientLoaded$: BehaviorSubject<boolean>;

    constructor(
            private zone: NgZone,
            private jsonConfigSvc: JSONConfigsService,
            private proxyPickerWrapper: NGWrapperProxyPickerClient,
            private appRef: ApplicationRef) {
        this.userProfileClientLoaded$ = null;

        this.loadUserProfileClient();
    }

    public startUserProfileServer( any?: any ): any {
        $kp.KPUserProfile.UserProfileServer.start( any );
    }

    /**
     @description loads userProfileClient then makes userProfileClient emit one of three states:
     *                  null: initial value, neither failed nor successful
     *                  true: userProfileClient has successfully loaded
     *                  false: userProfileClient has failed to load
     * @param options
     */
    private loadUserProfileClient( options?: any ): void {
        if ( this.userProfileClientLoaded$ == null ) {
            this.userProfileClientLoaded$ = new BehaviorSubject( null );
            $kp.KPUserProfile.UserProfileClient.load( options )
                .then( () => {
                    this.zone.run( () => {
                        this.userProfileClientLoaded$.next( true );
                    } );
                } )
                .catch( ( e ) => {
                    this.zone.run( () => {
                        console.error( "Error loading user profile: " + e );
                        this.userProfileClientLoaded$.next( false );
                    } );
                } );
        }
    }

    /**
     * @description The returned observable emits one of three states:
     *                  null: initial value, neither failed nor successful
     *                  true: userProfileClient has successfully loaded
     *                  false: userProfileClient has failed to load
     * @returns {BehaviorSubject<boolean>}
     */
    public getUserProfileClientLoaded$(): BehaviorSubject<boolean> {
        return this.userProfileClientLoaded$;
    }

    public isMember(): boolean {
        return $kp.KPUserProfile.UserProfileClient.getUser().isMember;
    }

    public getMccMessageJsonUrlLocation(): string {
        return this.jsonConfigSvc.mccMessageUrl( this.getLanguagePrimarySubCode() );
    }

    public isUserSelfFunded(): boolean {
    	//$kp.KPUserProfile.UserProfileClient.getUser().selfFunded is a string
    	if ('true' == $kp.KPUserProfile.UserProfileClient.getUser().selfFunded)
    		return true;
    	else
    		return false;
    }

    public getUserName(): string{
        return $kp.KPUserProfile.UserProfileClient.getUser().name;
    }

    public isSelectedProxySelfFunded(): boolean {
    	//TODO: $kp.KPUserProfile.UserProfileClient.getUser().selfFunded is only for the signed in user
        return false;
    }

    public getExceptionMessageJsonUrlLocation(): string {
        return this.jsonConfigSvc.exceptionMessageUrl( this.getLanguagePrimarySubCode() );
    }

    public getAccessibleBillUriLocation() : string {
        return this.jsonConfigSvc.accessibleBillUri();
    }

    public getLanguagePrimarySubCode(): string {
        let outValue: string = 'en';
        let lang: any =
            $kp.KPClientCommons.CookieManager.getLanguageCookie();
        if ( lang && lang.length > 4 ) {
            outValue = lang.substring( 0, 2 );
        }
        return outValue;
    }

    public hasEntitlement( entitlementId: number ): boolean {
        return $kp.KPUserProfile.UserProfileClient.hasEntitlement( entitlementId );
    }

    public hasEntitlementForCurrentUser (entitlementId: number): boolean {
        return $kp.KPUserProfile.UserProfileClient.hasEntitlementForCurrentUser( entitlementId);
    }

    public openModalWindow(htmlToLoad: any) {
        let modal = $kp.GS.Modal.init('mccpaymentdetails_modal', {"noContent": true});
        // modal.loadContent(htmlToLoad, true);
        modal.loadContent(htmlToLoad, false);
        modal.show();
    }
}
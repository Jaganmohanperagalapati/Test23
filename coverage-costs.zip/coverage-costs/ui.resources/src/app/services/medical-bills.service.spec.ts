import { async, inject, TestBed } from '@angular/core/testing';
import { HttpModule, Http, BaseRequestOptions, XHRBackend, Response, ResponseOptions, ResponseType } from "@angular/http";
import { MockBackend } from '@angular/http/testing';
import { MedicalBillsService, GuarantorStatus } from "./medical-bills.service";
import { JSONConfigsService } from "./jsonConfigs.service";

import * as Mock from "../../app/util/MockResponses.util";
import * as NodeMock from "../../app/util/NodeMockResponses.util";
import {Observable} from "rxjs/Observable";


describe('MedicalBillsService', () => {


    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpModule],
            providers: [
                MedicalBillsService,
                JSONConfigsService,
                { provide: XHRBackend , useClass: MockBackend }
            ]
        }).compileComponents();
    });

    describe('getAllBills$()', () => {
        it ('should return an Observable<any> of the data returned from api call',
            inject( [ MedicalBillsService, XHRBackend ], ( medicalBillsSvc, mockBackend ) => {

                medicalBillsSvc.medicalBills$ = Observable.of(JSON.stringify(NodeMock.MedicalBillsGuarantor));

                medicalBillsSvc.getAllBills$().subscribe( ( data ) => {
                    expect( data ).toEqual(JSON.stringify(NodeMock.MedicalBillsGuarantor));
                } );
            } )
        );
    });

    describe('getAllBills$() to return an error', () => {
        it ('should return an Observable<any> of the data returned from api call',
            inject( [ MedicalBillsService, XHRBackend ], ( medicalBillsSvc, mockBackend ) => {
                mockBackend.connections.subscribe( ( connection ) => {
                    connection.mockError(new Error('error'));
                } );

                medicalBillsSvc.getAllBills$().subscribe( ( data ) => {
                    expect( data ).toEqual(null);
                } );
            } )
        );
    });

    describe('getGuarantorStatus$()', () => {
        it ('should return an Observable<GuarantorStatus> of GuarantorStatus.Guarantor',
            inject( [ MedicalBillsService, XHRBackend ], ( medicalBillsSvc, mockBackend ) => {

                medicalBillsSvc.medicalBills$ = Observable.of(NodeMock.MedicalBillsGuarantor);

                medicalBillsSvc.getGuarantorStatus$().subscribe( ( data ) => {
                    expect( data ).toEqual(GuarantorStatus.Guarantor);
                } );
            } )
        );


        it ('should return an Observable<GuarantorStatus> of GuarantorStatus.NonGuarantor',
            inject( [ MedicalBillsService, XHRBackend ], ( medicalBillsSvc, mockBackend ) => {

                medicalBillsSvc.medicalBills$ = Observable.of(NodeMock.MedicalBillsNonGuarantor);

                medicalBillsSvc.getGuarantorStatus$().subscribe( ( data ) => {
                    expect( data ).toEqual(GuarantorStatus.NonGuarantor);
                } );
            } )
        );

        it ('should return an Observable<GuarantorStatus> of GuarantorStatus.Error',
            inject( [ MedicalBillsService, XHRBackend ], ( medicalBillsSvc, mockBackend ) => {

                medicalBillsSvc.medicalBills$ = Observable.of(JSON.stringify(NodeMock.MedicalBillsGuarantor));

                medicalBillsSvc.getGuarantorStatus$().subscribe( ( data ) => {
                    expect( data ).toEqual(GuarantorStatus.Error);
                } );
            } )
        );
    })

    describe('getTotalBill()', () => {
        it ('should return an Observable<any> of the total balance from the data',
            inject( [ MedicalBillsService, XHRBackend ], ( medicalBillsSvc, mockBackend ) => {

                medicalBillsSvc.medicalBills$ = Observable.of(NodeMock.MedicalBillsPositiveBalance);

                medicalBillsSvc.getTotalBill$().subscribe( ( data ) => {
                    expect( data ).toEqual(NodeMock.RandomPositiveMoneyString);
                } );
            } )
        );

        it ('should return an Observable<any> of null',
            inject( [ MedicalBillsService, XHRBackend ], ( medicalBillsSvc, mockBackend ) => {
                medicalBillsSvc.medicalBills$ = Observable.of({"test": "should parse wrong"});

                medicalBillsSvc.getTotalBill$().subscribe( ( data ) => {
                    expect( data ).toBeNull();
                } );
            } )
        );
    });

});

/**
 * Created by clarklyu on 9/13/17.
 */
import {async, inject, TestBed} from '@angular/core/testing';
import {HttpModule, Http, BaseRequestOptions, XHRBackend, Response, ResponseOptions, ResponseType} from "@angular/http";
import {MockBackend} from '@angular/http/testing';
import {BillExpandService} from '../services/bill-expand.service';
import {JSONConfigsService} from "./jsonConfigs.service";
import * as NodeMock from "../../app/util/NodeMockResponses.util";
describe('BillExpandService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpModule],
            providers: [BillExpandService, JSONConfigsService, {provide: XHRBackend, useClass: MockBackend}]
        });
    });
    describe('getBillsExpand$()', () => {
        it('should return an Observable<any> of data', inject([BillExpandService, XHRBackend], (billExpandSvc, mockBackend) => {
            mockBackend.connections.subscribe((connection) => {
                connection.mockRespond(new Response(new ResponseOptions({body: JSON.stringify(NodeMock.MedicalBillsGuarantor)})));
            });
            billExpandSvc.getBillsExpand$().subscribe((data) => {
                expect(data).toEqual(NodeMock.MedicalBillsGuarantor);
            });
        }));
        it('should return an Observable<any> of null', inject([BillExpandService, XHRBackend], (billExpandSvc, mockBackend) => {
            mockBackend.connections.subscribe((connection) => {
                connection.mockRespond(new Response(new ResponseOptions({body: JSON.stringify({"test": "should parse wrong"})})));
            });
            billExpandSvc.getBillsExpand$().subscribe((data) => {
                expect(data).toBeDefined();
            });
        }));
    });
});

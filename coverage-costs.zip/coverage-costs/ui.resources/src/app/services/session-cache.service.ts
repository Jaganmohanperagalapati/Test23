import { Injectable }    from "@angular/core";
import { Http } from "@angular/http";
import { Observable } from "rxjs/Observable"; 
import { ApiService } from "./api.service";
import { JSONConfigsService } from "./jsonConfigs.service";

@Injectable()
export class SessionCacheService extends ApiService {

    sessCache$: Observable<any>;
    putResp$: Observable<any>;

    constructor(http: Http,  jsonConfigSvc: JSONConfigsService) {
        super(http, jsonConfigSvc);
    }
    public putCache$(): Observable<any> {
        this.putResp$ = super.put(this.jsonConfigSvc.mccBffApiPrefixUrl() + '/mocks/mcc-store', '', {}, '')
            .map((res: any) => res)
            .catch(this._serverError);
        return this.putResp$;
    }

    public getCache$(): Observable<any> {
        this.sessCache$ = super.get(this.jsonConfigSvc.mccBffApiPrefixUrl() + '/mocks/mcc-store?key=12', '', true,true)
            .map((res: any) => res)
            .catch(this._serverError);
        return this.sessCache$;
    }
    private _serverError(err: any) {
        return Observable.throw(err);
    }

}
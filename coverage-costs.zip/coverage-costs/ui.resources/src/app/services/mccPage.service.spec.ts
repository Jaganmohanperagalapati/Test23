import { async, inject, TestBed } from '@angular/core/testing';
import { Http, HttpModule, XHRBackend, Response, ResponseOptions/*, ResponseType*/ } from "@angular/http";
import { MockBackend } from '@angular/http/testing';
import { ApiService } from "./api.service";
import { KPService } from "./kp.service";
import { MCCPageService } from "./mccPage.service";
import { MCCConstants } from "../util/MCCConstants.util";
import { NGWrapperProxyPickerClient, NGWrapperProxyPickerClientSubject } from 'ng2-proxy-picker-wrapper';
import { JSONConfigsService } from "./jsonConfigs.service";
import { MedicalBillsService } from "./medical-bills.service";
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { ReplaySubject } from 'rxjs/ReplaySubject';

describe('MCCPageService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                JSONConfigsService,
                {
                    provide: KPService,
                    useValue: {
                        //
                    }
                },
                {
                    provide: MedicalBillsService,
                    useValue: {
                        //
                    }
                },
                //{
                //    provide: NGWrapperProxyPickerClient,
                //    useValue: {
                //        //
                //    }
                //}
            ]
        });
    });
    describe(
        'MCCPageService',
        () => {
            it(
                'should work when "getUserProfileClientLoaded$()" returns null values',
                async(
                    inject(
                        [
                            JSONConfigsService, KPService, MedicalBillsService,
                        ],
                        ( jsonConfigSvc, kpSvc, medBillsSvc ) => {
                            jsonConfigSvc.isMocked = () => (false);
                            kpSvc.getUserProfileClientLoaded$ = () => {
                                return new BehaviorSubject<boolean>(null);
                            };
                            medBillsSvc.getAllBills$ = () => {
                                return new BehaviorSubject<boolean>(null);
                            };
                            let ngwPpc:BehaviorSubject<NGWrapperProxyPickerClientSubject> =
                                new BehaviorSubject(null);
                            let mps:MCCPageService = new MCCPageService(
                                kpSvc, jsonConfigSvc, medBillsSvc,
                                <NGWrapperProxyPickerClient>ngwPpc);
                            mps.getAppObject$().subscribe(
                                (data) => {
                                    expect(data.errorCode).toBeNull();
                                }
                            );
                            //expect(1).toBe(2);
                        }
                    )
                )
            );
            it(
                'should work when "getUserProfileClientLoaded$()" returns false values',
                async(
                    inject(
                        [
                            JSONConfigsService, KPService, MedicalBillsService,
                        ],
                        ( jsonConfigSvc, kpSvc, medBillsSvc ) => {
                            jsonConfigSvc.isMocked = () => (false);
                            kpSvc.getUserProfileClientLoaded$ = () => {
                                return new BehaviorSubject<boolean>(false);
                            };
                            medBillsSvc.getAllBills$ = () => {
                                return new BehaviorSubject<boolean>(null);
                            };
                            let ngwPpc:BehaviorSubject<NGWrapperProxyPickerClientSubject> =
                                new BehaviorSubject(null);
                            let mps:MCCPageService = new MCCPageService(
                                kpSvc, jsonConfigSvc, medBillsSvc,
                                <NGWrapperProxyPickerClient>ngwPpc);
                            mps.getAppObject$().subscribe(
                                (data) => {
                                    expect(data.errorCode).toBe(
                                        MCCConstants.ErrorCodes.TechnicalError);
                                }
                            );
                            //expect(1).toBe(2);
                        }
                    )
                )
            );
            it(
                'should work when there was an error for self-entitlted',
                async(
                    inject(
                        [
                            JSONConfigsService, KPService, MedicalBillsService,
                        ],
                        ( jsonConfigSvc, kpSvc, medBillsSvc ) => {
                            jsonConfigSvc.isMocked = () => (false);
                            kpSvc.getUserProfileClientLoaded$ = () => {
                                return new BehaviorSubject<boolean>(true);
                            };
                            medBillsSvc.getAllBills$ = () => {
                                return new BehaviorSubject<boolean>(null);
                            };
                            let ngwPpcs1:any;
                            ngwPpcs1 = {
                                isEntitlementErrorOccurredForSelf: () => (true),
                                isEntitlementErrorOccurredForCurrentSelection: () => (false)
                            }
                            let ngwPpc:BehaviorSubject<NGWrapperProxyPickerClientSubject> =
                                new BehaviorSubject(
                                    <NGWrapperProxyPickerClientSubject>ngwPpcs1);
                            let mps:MCCPageService = new MCCPageService(
                                kpSvc, jsonConfigSvc, medBillsSvc,
                                <NGWrapperProxyPickerClient>ngwPpc);
                            mps.getAppObject$().subscribe(
                                (data) => {
                                    expect(data.errorCode).toBe(
                                        MCCConstants.ErrorCodes.TechnicalError);
                                }
                            );
                            //expect(1).toBe(2);
                        }
                    )
                )
            );
            it(
                'should work when there was an error for other-entitlted',
                async(
                    inject(
                        [
                            JSONConfigsService, KPService, MedicalBillsService,
                        ],
                        ( jsonConfigSvc, kpSvc, medBillsSvc ) => {
                            jsonConfigSvc.isMocked = () => (false);
                            kpSvc.getUserProfileClientLoaded$ = () => {
                                return new BehaviorSubject<boolean>(true);
                            };
                            medBillsSvc.getAllBills$ = () => {
                                return new BehaviorSubject<boolean>(null);
                            };
                            let ngwPpcs1:any;
                            ngwPpcs1 = {
                                isEntitlementErrorOccurredForSelf: () => (false),
                                isEntitlementErrorOccurredForCurrentSelection: () => (true)
                            }
                            let ngwPpc:BehaviorSubject<NGWrapperProxyPickerClientSubject> =
                                new BehaviorSubject(
                                    <NGWrapperProxyPickerClientSubject>ngwPpcs1);
                            let mps:MCCPageService = new MCCPageService(
                                kpSvc, jsonConfigSvc, medBillsSvc,
                                <NGWrapperProxyPickerClient>ngwPpc);
                            mps.getAppObject$().subscribe(
                                (data) => {
                                    expect(data.errorCode).toBe(
                                        MCCConstants.ErrorCodes.TechnicalError);
                                }
                            );
                            //expect(1).toBe(2);
                        }
                    )
                )
            );
            it(
                'should work when user is not member',
                async(
                    inject(
                        [
                            JSONConfigsService, KPService, MedicalBillsService,
                        ],
                        ( jsonConfigSvc, kpSvc, medBillsSvc ) => {
                            jsonConfigSvc.isMocked = () => (false);
                            kpSvc.getUserProfileClientLoaded$ = () => {
                                return new BehaviorSubject<boolean>(true);
                            };
                            kpSvc.isMember = () => (false);
                            medBillsSvc.getAllBills$ = () => {
                                return new BehaviorSubject<boolean>(null);
                            };
                            let ngwPpcs1:any;
                            ngwPpcs1 = {
                                isEntitlementErrorOccurredForSelf: () => (false),
                                isEntitlementErrorOccurredForCurrentSelection: () => (false)
                            }
                            let ngwPpc:BehaviorSubject<NGWrapperProxyPickerClientSubject> =
                                new BehaviorSubject(
                                    <NGWrapperProxyPickerClientSubject>ngwPpcs1);
                            let mps:MCCPageService = new MCCPageService(
                                kpSvc, jsonConfigSvc, medBillsSvc,
                                <NGWrapperProxyPickerClient>ngwPpc);
                            mps.getAppObject$().subscribe(
                                (data) => {
                                    expect(data.errorCode).toBe(
                                        MCCConstants.ErrorCodes.NonMemberAccount);
                                }
                            );
                            //expect(1).toBe(2);
                        }
                    )
                )
            );
            it(
                'should work when there was an error getting bill information',
                async(
                    inject(
                        [
                            JSONConfigsService, KPService, MedicalBillsService,
                        ],
                        ( jsonConfigSvc, kpSvc, medBillsSvc ) => {
                            jsonConfigSvc.isMocked = () => (false);
                            kpSvc.getUserProfileClientLoaded$ = () => {
                                return new BehaviorSubject<boolean>(true);
                            };
                            kpSvc.isMember = () => (true);
                            medBillsSvc.getAllBills$ = () => {
                                return new BehaviorSubject<boolean>(
                                    MedicalBillsService.ErrorMessage);
                            };
                            let ngwPpcs1:any;
                            ngwPpcs1 = {
                                isEntitlementErrorOccurredForSelf: () => (false),
                                isEntitlementErrorOccurredForCurrentSelection: () => (false)
                            }
                            let ngwPpc:BehaviorSubject<NGWrapperProxyPickerClientSubject> =
                                new BehaviorSubject(
                                    <NGWrapperProxyPickerClientSubject>ngwPpcs1);
                            let mps:MCCPageService = new MCCPageService(
                                kpSvc, jsonConfigSvc, medBillsSvc,
                                <NGWrapperProxyPickerClient>ngwPpc);
                            mps.getAppObject$().subscribe(
                                (data) => {
                                    expect(data.errorCode).toBe(
                                        MCCConstants.ErrorCodes.TechnicalError);
                                }
                            );
                            //expect(1).toBe(2);
                        }
                    )
                )
            );
            it(
                'should work when there was no error',
                async(
                    inject(
                        [
                            JSONConfigsService, KPService, MedicalBillsService,
                        ],
                        ( jsonConfigSvc, kpSvc, medBillsSvc ) => {
                            //'shoehorn' testing of 'startUserProfileServer' check here
                            jsonConfigSvc.isMocked = () => (true);
                            kpSvc.startUserProfileServer = () => {};
                            //
                            kpSvc.getUserProfileClientLoaded$ = () => {
                                return new BehaviorSubject<boolean>(true);
                            };
                            kpSvc.isMember = () => (true);
                            medBillsSvc.getAllBills$ = () => {
                                return new BehaviorSubject<boolean>(false);
                            };
                            let ngwPpcs1:any;
                            ngwPpcs1 = {
                                isEntitlementErrorOccurredForSelf: () => (false),
                                isEntitlementErrorOccurredForCurrentSelection: () => (false)
                            }
                            let ngwPpc:BehaviorSubject<NGWrapperProxyPickerClientSubject> =
                                new BehaviorSubject(
                                    <NGWrapperProxyPickerClientSubject>ngwPpcs1);
                            let mps:MCCPageService = new MCCPageService(
                                kpSvc, jsonConfigSvc, medBillsSvc,
                                <NGWrapperProxyPickerClient>ngwPpc);
                            mps.getAppObject$().subscribe(
                                (data) => {
                                    expect(data.errorCode).toBe("");
                                }
                            );
                            //expect(1).toBe(2);
                        }
                    )
                )
            );
        }
    );
});
/**
 * Created by clarklyu on 7/26/17.
 */
import { Injectable } from "@angular/core";
import { ApiService } from "./api.service";
import { Http, Response, Headers, URLSearchParams, RequestOptions  } from "@angular/http";
import { JSONConfigsService } from "./jsonConfigs.service";
import { Observable } from "rxjs/Observable";
import 'rxjs/add/operator/catch'

@Injectable()

export class BillExpandService extends ApiService {
    public static ErrorMessage: any = null;
    public static Id:any = null;
    public static Type:any = null;
    public static Date:any = null;

    constructor(http: Http, jsonConfigSvc: JSONConfigsService) {
        super(http, jsonConfigSvc);
    }

    private expandBill$: Observable<any> = null;
    getBillsExpand$(guarantoraccountnumber, statementtype, billdate): Observable<any>{
        // let myHeaders = new Headers();
        // myHeaders.append('x-guarantoraccountnumber', `${guarantoraccountnumber}`);


        let billtype;
        if(statementtype == "KPHC-HB"){
            billtype = "HB"
        }else if(statementtype == "KPHC-PB"){
            billtype = "PB"
        }else if(statementtype == 'KPHC-ENT' || statementtype == 'KPHC-DB'){
            billtype = "Enterprise"
        }

        let newbillDate = this.GetFormattedDate(billdate);

        let myParams = new URLSearchParams();
        myParams.set("filter",`{"fields":"extended","where":{"statementType":"${billtype}","billDate":"${newbillDate}"}}`);
        // myParams.set("filter",`{"fields":"extended"`+ encodeURIComponent(`,"where":{"statementType":"${statementtype}","billDate":"${billdate}"}}`));

        super.setSearchParams(myParams);
        this.expandBill$ = super.get(this.jsonConfigSvc.medicalBillApiUri(),{"x-guarantoraccountnumber":guarantoraccountnumber},true,true)
            .map((res: any) => res)
            .catch(this._serverError);

        return this.expandBill$;
    }

    private _serverError(err: any) {
        return Observable.throw(err);
    }

    private GetFormattedDate(date) {
        let d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2) month = '0' + month;
        if (day.length < 2) day = '0' + day;

        return [year, month, day].join('-');
    }
}

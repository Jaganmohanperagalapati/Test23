import { async, inject, TestBed } from '@angular/core/testing';
import { Http, HttpModule, XHRBackend } from "@angular/http";
import { MockBackend } from '@angular/http/testing';
import { PaymentPlanConfig, MCCConfigService } from "./mcc-config.service";
import { JSONConfigsService } from "./jsonConfigs.service";
import { Observable } from 'rxjs/Observable';
import {ValidMccConfigActionArea, ValidPaymentPlanConfig} from "../util/MockResponses.util";
import * as NodeMock from "../util/NodeMockResponses.util";


var html = '<div class="content-fragment-container" data-analytics-location="content-fragment"> <div class="content-fragment" data-analytics-location="content-fragment-main-area"> <div class="payment-plan-detail parbase"> {"compname":"payment_plan_detail","accountlabel":"Account","hospbillpmtplanlabel":"Hospital billing payment plan","profbillpmtplanlabel":"Professional billing payment plan","hospprofbillpmtplanlabel":"Hospital/Professional billing payment plan","recurringbillpmtplanlabel":"Payment Amount test","nextpmtplanlabel":"Next payment due","begplanballabel":"Beginning balance","pmtplanstartdatelabe":"Payment plan start date","remainballabel":"Remaining balance","pmtplandetailsdesc":"<p>Your statement for medical services shows your account balance as of the date of this statement. If you made a payment on your current payment plan after your last statement, the payment isn’t shown in your statement. If you had new services since your last statement, the new charges will be reflected on your next statement. New charges won’t be included in your payment plan unless you ask us to add them to your plan. If you would like to update your payment plan, please call the phone number listed on your statement.</p>\r\n"} </div> </div> </div>'
describe('MCCConfigService', () => {
    describe('PaymentPlanConfig', () => {
        it('should work', () => {
            let payplanConfig = new PaymentPlanConfig({"testData":"testValue"}, "testDesc");
            expect(payplanConfig.jsonObject).toEqual({"testData":"testValue"});
            expect(payplanConfig.desc).toEqual('testDesc');

        });
    });

    describe('MCC Config Service should exist', () => {
        beforeEach(() => {
            TestBed.configureTestingModule({
                imports: [HttpModule],
                providers: [
                    {
                        provide: Http,
                        useValue: {
                            get : () => {return Observable.of('test')}
                        }
                    },
                    JSONConfigsService,
                    {
                        provide: XHRBackend,
                        useClass: MockBackend
                    }
                ]
            });
        });

        it('should exist', async(inject([Http, JSONConfigsService, XHRBackend], (http, jsonConfig, mockBackend) => {
            let mccConfigSvc = new MCCConfigService(http, jsonConfig);
            expect(mccConfigSvc).toBeDefined();
        })));
    });

    describe('MCC Config Service: testing mccConfig$', () => {
        beforeEach(() => {
            TestBed.configureTestingModule({
                imports: [HttpModule],
                providers: [
                    {
                        provide: Http,
                        useValue: {
                            get : () => {return Observable.of(ValidMccConfigActionArea)}
                        }
                    },
                    JSONConfigsService,
                    {
                        provide: XHRBackend,
                        useClass: MockBackend
                    }
                ]
            });
        });

        it('should exist', async(inject([Http, JSONConfigsService, XHRBackend], (http, jsonConfig, mockBackend) => {
            let mccConfigSvc = new MCCConfigService(http, jsonConfig);
            mccConfigSvc.getActionAreaConfig$().subscribe(
                next =>{expect(next).toEqual(null)}
            );
            
           /*  mccConfigSvc.getPaymentPlanConfig$().subscribe();

            mccConfigSvc.ppmConfig$ = Observable.of(null);
            mccConfigSvc.getPaymentPlanConfig$().subscribe();

            mccConfigSvc.mccConfig$ = Observable.of(null);
            mccConfigSvc.getActionAreaConfig$().subscribe();


            mccConfigSvc.mccConfig$ = Observable.of(ValidMccConfigActionArea);
            mccConfigSvc.getActionAreaConfig$().subscribe(); */
        })));
    });



});
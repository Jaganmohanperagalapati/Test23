/*import { Injectable, Input } from '@angular/core';
import 'rxjs/add/operator/catch';
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";
import "rxjs/Rx";
import { InputDecorator } from "@angular/core/src/metadata/directives";
import { ApiService } from "./api.service";
import { Http } from "@angular/http";

declare var $kp;
declare var jsonConfigs;

@Injectable()
export class ErrorMessageService extends ApiService {

    message$: Observable<any>;

    constructor(private http: Http) {
        super(http);
    }



}*/

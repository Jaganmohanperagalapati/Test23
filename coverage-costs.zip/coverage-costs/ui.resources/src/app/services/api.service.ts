import { Injectable, OnInit } from '@angular/core';

import 'rxjs/add/operator/publishLast';
import 'rxjs/add/operator/map';

import * as extend from '../../../node_modules/lodash/extend.js';

import { Http, Response, Headers, URLSearchParams, RequestOptions  } from "@angular/http";
import { Observable } from "rxjs";
import { JSONConfigsService } from "./jsonConfigs.service";

declare var jsonConfigs: any;

@Injectable()
export class ApiService implements OnInit {

    protected http: Http;
    protected jsonConfigSvc: JSONConfigsService;
    private queryParams : URLSearchParams;

    static headers: any = {
        'X-useragenttype': navigator.userAgent,
        'X-osversion': navigator.appVersion
    };

    constructor( http: Http, jsonConfigSvc: JSONConfigsService ) {
        this.http = http;
        this.jsonConfigSvc = jsonConfigSvc;
    }

    ngOnInit() {
    }

    get( resource: string, additionalHeaders: any = null, useRoot: boolean = true, nodeHeaders: boolean = false) {
        var root = this.jsonConfigSvc.apiUrl();
			
        let headers: any;
        headers = extend(headers, ApiService.headers);

        if (nodeHeaders) {
        	root = this.jsonConfigSvc.nodeApiUrl();
        	headers = extend(headers, this.jsonConfigSvc.nodeApiHeaders());
        } else {
            headers = extend(headers, this.jsonConfigSvc.apiHeaders());
        }

        if (additionalHeaders != null)
            headers = extend(headers, additionalHeaders);

        let url;

        if (useRoot)
            url = root + resource;
        else
            url = resource;

        return this.http.get( url, { headers: headers,search: this.queryParams, withCredentials: true } )
            .map( this._map, this )
            .publishLast()
            .refCount()
    }
    formatHttpObservable(obs:any):any {
        return obs//.map( this._map, this )
            .publishLast()
            .refCount();
    }

    setSearchParams(params: URLSearchParams){
        this.queryParams = params;
    }

    _map( value: any, index: any ) {
        return value.json();
    }

    _error(err: any, caught: Observable<any>): any {
        return caught;
    }

    put(
        url: string,
        specificHeaders: any,
        body: any,
        queryParams?: any
    ) {
        //add the common headers
        let headers: any;
        headers = extend(specificHeaders, ApiService.headers);

        return this.http.put(url, body, {
            search: queryParams,
            headers: headers,
            withCredentials: true
        })
        .map(res => {
            //this.httpResponseStatus$.next(res.status);
            return this._map(res, 0);
        })
        .publishLast()
        .refCount();
    }

}

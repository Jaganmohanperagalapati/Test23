import {Injectable} from '@angular/core';
import {Http} from '@angular/http';
import {ApiService} from './api.service';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import {JSONConfigsService} from "./jsonConfigs.service";

declare var jsonConfigs: any;

export class ActionAreaConfig {

    conditionalTexts: any;
    conditionalButtons: any;

    constructor(texts: any, buttons: any) {
        this.conditionalTexts = texts;
        this.conditionalButtons = buttons;
    }
}

export class PaymentPlanConfig {
    jsonObject: {};
    desc: string;
    constructor(jsonObject: {}, desc: string) {
        this.jsonObject = jsonObject;
        this.desc = desc;
    }
}

@Injectable()
export class MCCConfigService extends ApiService {

    public mccConfig$: Observable<any> = null;
    public ppmConfig$: Observable<any> = null;

    constructor(http: Http, jsonConfigSvc: JSONConfigsService) {
        super(http, jsonConfigSvc);
        this.load$();
    }
    private load$() {
        if (this.mccConfig$ == null) {
            let url;
            let url2;
            let useRoot;
            if (this.jsonConfigSvc.isMocked()) {
                url = this.jsonConfigSvc.mccConfigUrl();
                url2 = this.jsonConfigSvc.ppmConfigUrl();
                useRoot = true;
                this.ppmConfig$ = super.get(url2, {}, useRoot)
                    .map((res) => { return res; })
                    .catch(err => Observable.of(null));
            }
            else {
                url = window.location.href.replace(".html", "") + ".kpjson.html";
                url2 = window.location.href.replace(/(\/secure.*)/g, "") + "/content-fragments/mcc/payment-plan.kpjson.html";
                useRoot = false;
                this.ppmConfig$ = this.http.get(url2)
                    .map((res) => { return res; })
                    .catch(err => Observable.of(null));
            }
            this.mccConfig$ = super.get(url, {}, useRoot)
                .catch(err => Observable.of(null));
        }
    }
    public getActionAreaConfig$(): Observable<ActionAreaConfig> {
        return this.mccConfig$
            .map((data) => {
                if (data == null)
                    return null;
                else
                    return this.parseActionAreaConfig(data);
            })
    }
    private parseActionAreaConfig(data: any): ActionAreaConfig {
        let texts: any;
        let buttons: any;
        try {
            for (let comp of data["comps"]) {
                if (comp["compname"] == "actionareamcc") {
                    for (let subcomp of comp["subcomps"]) {
                        if (subcomp["compname"] == "conditionaldesc") {
                            texts = subcomp["conditionaltexts"];
                        }
                        else if (subcomp["compname"] == "calltoactionbtn") {
                            buttons = subcomp["conditionalBtns"];
                        }
                    }
                }
            }
            return new ActionAreaConfig(texts, buttons);
        }
        catch (e) {
            return null;
        }
    }
    public getPaymentPlanConfig$(): Observable<PaymentPlanConfig> {
        return this.ppmConfig$
            .map((data) => {
                if (data == null) {
                    return null;
                }
                else {
                    let regexFirstHalf =/\{([^}]+)\",(\s*(.*)\s*)pmtplandetailsdesc/g;
                    let regexSecondHalf = /"pmtplandetailsdesc"?(.*)/g
                    let regObjFirstHalf = regexFirstHalf.exec(data._body);
                    let firstHalf =JSON.parse('{'+regObjFirstHalf[1]+'"}');
                    let secondHalf = regexSecondHalf.exec(data._body)[0]
                        .replace(/(""pmtplandetailsdesc": "<p>)/g, '')
                        .replace(/(\\\u)/g, '')
                        .replace(/(<\\\/p>\\r\\n"")/g, '')
                        .replace(/rn}/g, '');

                    return new PaymentPlanConfig(firstHalf, secondHalf);
                }
            })
    }
}
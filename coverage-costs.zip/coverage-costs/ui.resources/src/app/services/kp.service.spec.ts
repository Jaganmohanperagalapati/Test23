import { async, inject, TestBed } from '@angular/core/testing';
import { ApplicationRef, NgZone } from "@angular/core";
import { Http, HttpModule, XHRBackend, Response, ResponseOptions } from "@angular/http";
import { MockBackend } from '@angular/http/testing';
import { ApiService } from "./api.service";
import { KPService } from "./kp.service";
import { MCCPageService } from "./mccPage.service";
import { MCCConstants } from "../util/MCCConstants.util";
import { NGWrapperProxyPickerClient, NGWrapperProxyPickerClientSubject } from 'ng2-proxy-picker-wrapper';
import { JSONConfigsService } from "./jsonConfigs.service";
import { MedicalBillsService } from "./medical-bills.service";
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import 'rxjs/add/observable/of';

//let p:Observable<any>;

describe('KPService', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                //{
                //    provide: NgZone,
                //    useValue: {
                //        run: (a) => {
                //            a();
                //        }
                //    }
                //},
                {
                    provide: JSONConfigsService,
                    useValue: {}
                },
                //{
                //    provide: ApplicationRef,
                //    useValue: {}
                //},
                {
                    provide: ApplicationRef,
                    useValue: {}
                },
                {
                    provide: NGWrapperProxyPickerClient,
                    useValue: {
                        //
                    }
                }
            ]
        });
    });
    describe(
        'KPService',
        () => {
            it('should work when "getUserProfileClientLoaded$()" returns null values',
                async(inject([JSONConfigsService, NGWrapperProxyPickerClient, ApplicationRef],
                        ( /*zone,*/ jsonConfigSvc, proxyPickerWrapper, appRef ) => {
                            jsonConfigSvc.isMocked = () => (false);
                            jsonConfigSvc.mccMessageUrl = () => ("abc");
                            jsonConfigSvc.exceptionMessageUrl = () => ("EXCEPTION_MESSAGE_URL");
                            jsonConfigSvc.accessibleBillUri = () => ("ACCESSIBLE_BILL_URL");

                            let runIsDone:ReplaySubject<boolean> = new ReplaySubject(1);
                            window["$kp"] = {
                                KPUserProfile: {
                                    UserProfileClient: {
                                        load: () => {
                                            return Observable.of(true).toPromise();
                                        },
                                        getUser: () => {
                                            return {
                                                name: "Friday",
                                                selfFunded: 'true',
                                                isMember: false
                                            };
                                        },
                                        hasEntitlement: () => {
                                            return true;
                                        },
                                        hasEntitlementForCurrentUser: () => {
                                            return false;
                                        }
                                    },
                                    UserProfileServer: {
                                        start: () => {}
                                    },
                                },
                                KPClientCommons: {
                                    CookieManager: {
                                        getLanguageCookie: () => ("LANGUAGE_CODE")
                                    }
                                }
                            };
                            let fauxZone:any = {
                                run: (a) => {
                                    a();
                                    runIsDone.next(true);
                                }
                            };
                            //
                            //
                            let ks:KPService = new KPService(
                                <NgZone>fauxZone, jsonConfigSvc, proxyPickerWrapper, appRef);
                            //
                            //confirm following call doesn't throw exception
                            ks.startUserProfileServer();
                            runIsDone.subscribe(
                                //wait for 'run' call to finish,
                                //  otherwise initial Null value will be returned
                                //  instead of true
                                () => {
                                    //
                                    ks.getUserProfileClientLoaded$().subscribe(
                                        (result) => {
                                            //console.log('result1 - ' + result);
                                            expect(result).toBe(true);
                                        }
                                    );
                                }
                            );
                            expect(ks.getUserName()).toBe("Friday");
                            expect(ks.isSelectedProxySelfFunded()).toBe(false);
                            expect(ks.hasEntitlement(123)).toBe(true);
                            expect(ks.hasEntitlementForCurrentUser(123)).toBe(false);
                            expect(ks.isUserSelfFunded()).toBe(true);
                            expect(ks.isMember()).toBe(false);
                            expect(ks.getMccMessageJsonUrlLocation()).toBe("abc");
                            expect(ks.getExceptionMessageJsonUrlLocation()).toBe("EXCEPTION_MESSAGE_URL");
                            expect(ks.getAccessibleBillUriLocation()).toBe("ACCESSIBLE_BILL_URL");
                        }
                    )
                )
            );
        }
    );
});
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/catch';

//import { NGWrapperProxyPickerClient } from "ng2-proxy-picker-wrapper";
import { NGWrapperProxyPickerClient } from 'ng2-proxy-picker-wrapper';
import { KPService } from "./kp.service";
import { Observable } from "rxjs/Observable";
import { GuarantorStatus, MedicalBillsService } from "./medical-bills.service";

declare var jsonConfigs;

@Injectable()
export class ControlService {

    constructor(
            private kpSvc: KPService,
            private proxyPickerWrapper: NGWrapperProxyPickerClient ) {

    }

    public findEntryWithValue( value: string, object: any ): any {
        try {
            for ( let entry of object ) {
                // If value is url, match with or without ending '/'
                let newVal = value.charAt( value.length - 1 ) == '/' ? value.substr( 0, value.length - 1 ) : value;
                let newEntryVal = entry[ "value" ].charAt( entry[ "value" ].length - 1 ) == '/' ? entry[ "value" ].substr( 0, entry[ "value" ].length - 1 ) : entry[ "value" ];

                if ( newEntryVal.toLowerCase() == newVal.toLowerCase() )
                    return entry;
            }
            return null;
        }
        catch ( e ) {
            return null;
        }
    }

    public checkEntryMeetsControls( entry: any, guarantorStatus: GuarantorStatus, selectedUserSelfFunded: boolean, totalBalance: string = "", lastPayment: string = "" ): boolean {
        try {
            let meetsControl: boolean;
            for ( let control of entry[ "control" ] )
            {
                if (this.checkControls(control, guarantorStatus, selectedUserSelfFunded, totalBalance, lastPayment))
                    return true;
            }

            return false;
        }
        catch ( e ) {
            return false;
        }
    }

    private checkControls(controlEntry: any, guarantorStatus: GuarantorStatus, selectedUserSelfFunded: boolean, totalBalance: string, lastPayment: string): boolean {
        let meetsControl: boolean = true;
        if ( controlEntry[ "entitlementKey" ] != null )
            meetsControl = this.ctrlHasEntitlementKey( controlEntry[ "entitlementKey" ] );
        if ( meetsControl && controlEntry[ "guarantor" ] != null )
            meetsControl = this.ctrlHasGuarantorStatus( controlEntry[ "guarantor" ], guarantorStatus );
        if ( meetsControl && controlEntry[ "proxy-selected" ] != null )
            meetsControl = this.ctrlProxySelected( controlEntry[ "proxy-selected" ] );
        if (meetsControl && controlEntry["hasBalance"] != null)
            meetsControl = this.ctrlHasBalance(controlEntry["hasBalance"], totalBalance);
        if (meetsControl && controlEntry["hasPayment"] != null)
            meetsControl = this.ctrlHasPayment(controlEntry["hasPayment"], lastPayment);
        if (meetsControl && controlEntry["self-funded"] != null)
            meetsControl = this.ctrlSelfFunded(controlEntry["self-funded"]);
        if (meetsControl && controlEntry["proxy-self-funded"] != null)
            meetsControl = this.ctrlProxySelfFunded(controlEntry["proxy-self-funded"], selectedUserSelfFunded);

        return meetsControl;
    }

    private ctrlHasEntitlementKey( entitlementKey: number ) {
        return this.kpSvc.hasEntitlementForCurrentUser( entitlementKey );
    }

    private ctrlHasGuarantorStatus( shouldBeGuarantor: boolean, guarantorStatus: GuarantorStatus ): boolean {
        return shouldBeGuarantor ? (guarantorStatus == GuarantorStatus.Guarantor) : (guarantorStatus != GuarantorStatus.Guarantor);
    }

    private ctrlProxySelected( shouldBeSelected: boolean ) {
        return shouldBeSelected == this.proxyPickerWrapper.getValue().isProxySelected();
    }

    private ctrlHasBalance(shouldHaveBalance: boolean, balance: string )
    {
        return shouldHaveBalance == (balance != null && balance != "" && Number(balance.replace(/[^0-9\.]+/g,"")) != 0);
    }

    private ctrlHasPayment(shouldHavePayment: boolean, payment: string )
    {
        return shouldHavePayment ==  (payment != null && payment != "" && Number(payment.replace(/[^0-9\.]+/g,"")) != 0);
    }

    private ctrlSelfFunded(shouldBeSelfFunded: boolean)
    {
        return shouldBeSelfFunded == this.kpSvc.isUserSelfFunded();
    }

    private ctrlProxySelfFunded(shouldProxyBeSelfFunded: boolean, selectedUserSelfFunded)
    {
        return shouldProxyBeSelfFunded == selectedUserSelfFunded;
    }
    
    public hasNoAmount(amount): boolean
    {
    	return (amount == null || amount == "" || Number(amount.replace(/[^0-9\.]+/g,"")) == 0);
    }
}
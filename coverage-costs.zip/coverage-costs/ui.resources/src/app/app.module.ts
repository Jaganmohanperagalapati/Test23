import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ActionAreaComponent } from "./components/action-area/action-area.component";
import { ApiService } from "./services/api.service";
import { HttpModule } from "@angular/http";
import { ErrorMessageComponent } from "./components/error-message/error-message.component";
import { JSONConfigsService } from "./services/jsonConfigs.service";
import { KPService } from "./services/kp.service";
import { NGWrapperProxyPickerClientModule } from "ng2-proxy-picker-wrapper";
import { NGWrapperProxyPickerClient } from "ng2-proxy-picker-wrapper";
import { ProxyPickerComponent } from "./components/proxy-picker-component/proxy-picker.component";
import { MCCPageService } from "./services/mccPage.service";
import { FeedContainerComponent } from "./components/feed-container/feed-container.component";
import { PaymentPlanInformationComponent } from "./components/payment-plan-information/payment-plan-information.component";
import { MCCConfigService } from "./services/mcc-config.service";
import { ControlService } from "./services/control.service";
import {ViewBillDirective} from "./directives/view-bill.directive";
import {CapitalizePipe} from "./pipes/capitalize.pipe";
import { AppComponent } from "./app.component";
import { KPShowDirective } from "./directives/kp-show.directive";
import { KPIconLinkShowDirective } from "./directives/kp-icon-link-show.directive";
import { MedicalBillsService } from "./services/medical-bills.service";
import { LastPaymentService } from "./services/last-payment.service";
import { UserService } from "./services/user.service";
import {BillExpandService} from "./services/bill-expand.service";
import {PaymentPlanService} from "./services/payment-plan.service";
import {UtilService} from "./services/util.service";
import {SessionCacheService} from "./services/session-cache.service";

@NgModule({
    imports: [
        BrowserModule,
        HttpModule,
        NGWrapperProxyPickerClientModule
    ],
    declarations: [
        //-- Components --//
        AppComponent,
        ActionAreaComponent,
        ProxyPickerComponent,
        ErrorMessageComponent,
        FeedContainerComponent,
        PaymentPlanInformationComponent,
        ViewBillDirective,
        CapitalizePipe,
        
        //-- Directives --//
        KPShowDirective,
        KPIconLinkShowDirective
    ],
    providers: [
        ApiService,
        MCCPageService,
        MCCConfigService,
        JSONConfigsService,
        KPService,
        NGWrapperProxyPickerClient,
        ControlService,
        MedicalBillsService,
        LastPaymentService,
        UserService,
        BillExpandService,
        PaymentPlanService,
        UtilService,
        SessionCacheService
    ],
    bootstrap: [
        AppComponent
        //ActionAreaComponent,
        //ProxyPickerComponent,
        //ErrorMessageComponent
    ]
})
export class AppModule {}

import {ElementRef} from '@angular/core';
import { async, inject, TestBed } from '@angular/core/testing';
import { BaseRequestOptions, Http, HttpModule, Response, ResponseOptions, XHRBackend } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { ReplaySubject } from "rxjs/ReplaySubject";
import { Subject } from "rxjs/Subject";
import { Observable } from "rxjs/Observable";
import { ActionAreaComponent, ActionAreaObject } from "./action-area.component"
import { KPService } from "../../services/kp.service";
import { AppObject, MCCPageService } from "../../services/mccPage.service";
import { MCCConstants } from "../../util/MCCConstants.util";
import { ActionAreaConfig, MCCConfigService } from "../../services/mcc-config.service";
import { GuarantorStatus, MedicalBillsService } from "../../services/medical-bills.service";
import { LastPayment, LastPaymentService } from "../../services/last-payment.service";
import { JSONConfigsService } from "../../services/jsonConfigs.service";
import { ControlService } from "../../services/control.service";
import { UserService } from "../../services/user.service";
import { NGWrapperProxyPickerClient, NGWrapperProxyPickerClientSubject } from 'ng2-proxy-picker-wrapper';
import { CurrencyPipe, DatePipe } from "@angular/common";

function initializeActionAreaComponentServices(
    mccPageSvc: MCCPageService, mccConfigSvc: MCCConfigService, kpSvc: KPService,
        medicalBillsSvc: MedicalBillsService, lastPaymentSvc: LastPaymentService,
        jsonConfigSvc: JSONConfigsService, controlSvc: ControlService,
        userSvc: UserService, datePipe: DatePipe, currencyPipe: CurrencyPipe,
        proxyPickerWrapper: NGWrapperProxyPickerClient, ref: ElementRef,
        guarantor: GuarantorStatus, aaConfig: ActionAreaConfig, totalBill: string,
        lastPayment: LastPayment, selectedUserSelfFunded: boolean,
        appObject: AppObject):void {
    //
    mccPageSvc.getAppObject$ = () => new BehaviorSubject<AppObject>(appObject);
    //
    medicalBillsSvc.getGuarantorStatus$ =
        () => new BehaviorSubject<GuarantorStatus>(guarantor),
    medicalBillsSvc.getTotalBill$ =
        () => new BehaviorSubject<string>(totalBill),
    lastPaymentSvc.getLastPayment$ =
        () => new BehaviorSubject<LastPayment>(lastPayment),
    mccConfigSvc.getActionAreaConfig$ =
        () => new BehaviorSubject<ActionAreaConfig>(aaConfig),
    userSvc.getSelectedUserSelffunded$ = () =>
        new BehaviorSubject<boolean>(selectedUserSelfFunded)
}
function mockProviderArray(ngwppcs: NGWrapperProxyPickerClientSubject):any[] {
    return [
        {
            provide: MCCPageService,
            useValue: {}
        },
        {
            provide: MCCConfigService,
            useValue: {}
        },
        {
            provide: KPService,
            useValue: {
                openModalWindow : () =>{console.log('do nothing');}
            }
        },
        {
            provide: MedicalBillsService,
            useValue: {}
        },
        {
            provide: LastPaymentService,
            useValue: {}
        },
        {
            provide: JSONConfigsService,
            useValue: {
                getControlObject: () => {
                    return null;//doesn't matter
                },
                getFeatureEntryID: () => {
                    return "featureEntryId";
                }
            }
        },
        {
            provide: ControlService,
            useValue: {
                findEntryWithValue: () => {
                    return {'descriptionKey' : 'someDescriptionKey'};
                },
                checkEntryMeetsControls: () => true
            }
        },
        {
            provide: UserService,
            useValue: {}
        },
        {
            provide: DatePipe,
            useValue: {
                transform: () => "someDatePipe"
            }
        },
        {
            provide: CurrencyPipe,
            useValue: {}
        },
        {
            provide: NGWrapperProxyPickerClient,
            useValue: new BehaviorSubject<NGWrapperProxyPickerClientSubject>(s)
        },
        {
            provide: ElementRef,
            useValue: {}
        }
    ];
}

describe('ActionAreaObject test', () => {
    it('should use zero-length string as default for all member variables', () => {
        let emh:ActionAreaObject = new ActionAreaObject();
        expect(emh.conditionalMessage).toBe('');
        expect(emh.buttonText).toBe('');
        expect(emh.buttonHref).toBe('');
        expect(emh.buttonEnabled).toBeFalsy();
        expect(emh.messageDataPqe).toBe('');
        expect(emh.buttonDataPqe).toBe('');
        expect(emh.isError).toBeNull();
    });
    it('should retain valid input arguments', () => {
        let emh:ActionAreaObject = new ActionAreaObject('A', 'B', 'C', false, 'D', 'E', true);
        expect(emh.conditionalMessage).toBe('A');
        expect(emh.buttonText).toBe('B');
        expect(emh.buttonHref).toBe('C');
        expect(emh.buttonEnabled).toBeFalsy();
        expect(emh.messageDataPqe).toBe('D');
        expect(emh.buttonDataPqe).toBe('E');
        expect(emh.isError).toBeTruthy();
    });
});
describe('ActionAreaComponent for proxy', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            //declarations: [ ],
            //imports: [ ],
            providers: mockProviderArray(
                new NGWrapperProxyPickerClientSubject('ProxySelected', true))
        });
        TestBed.compileComponents();
    });
    it('should work', async(inject(
        [MCCPageService, MCCConfigService, KPService, MedicalBillsService,
            LastPaymentService, JSONConfigsService, ControlService, UserService,
            DatePipe, CurrencyPipe, NGWrapperProxyPickerClient, ElementRef],
        (mccPageSvc, mccConfigSvc, kpSvc, medicalBillsSvc, lastPaymentSvc, jsonConfigSvc,
            controlSvc, userSvc, datePipe, currencyPipe, proxyPickerWrapper, ref
        ) => {
            let selectedUserSelfFunded: boolean = false;
            //
            initializeActionAreaComponentServices(
                mccPageSvc, mccConfigSvc, kpSvc, medicalBillsSvc, lastPaymentSvc,
                jsonConfigSvc, controlSvc, userSvc, datePipe, currencyPipe,
                proxyPickerWrapper, ref,
                GuarantorStatus.Guarantor, new ActionAreaConfig('texts', 'buttons'),
                'totalBill', new LastPayment('amount', 'date'), (selectedUserSelfFunded),
                new AppObject('ABC'));
            //
            let aac: ActionAreaComponent;
            //
            //Part 1 - Proxy selected, ActionAreaComponent is empty
            aac = new ActionAreaComponent(
                mccPageSvc, mccConfigSvc, kpSvc, medicalBillsSvc, lastPaymentSvc,
                jsonConfigSvc, controlSvc, userSvc, datePipe, currencyPipe,
                proxyPickerWrapper, ref);
            aac.ngOnInit();
            aac.ngAfterViewInit();
            mccPageSvc.getAppObject$().subscribe(
                (data) => {expect(data.errorCode).toBe('ABC');});
            //
            aac.buttonDataPqe$.subscribe(
                (data) => {expect(data).toBe('');});
            aac.conditionalButton$.subscribe(
                (data) => {expect(data).toBe('');});
            aac.conditionalButtonHref$.subscribe(
                (data) => {expect(data).toBe('');});
            aac.conditionalMessage$.subscribe(
                (data) => {expect(data).toBe('');});
            aac.messageDataPqe$.subscribe(
                (data) => {expect(data).toBe('');});
            //
    })));

});
describe('ActionAreaComponent for proxy will null for userSelected', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            //declarations: [ ],
            //imports: [ ],
            providers: mockProviderArray(
                new NGWrapperProxyPickerClientSubject('ProxySelected', true))
        });
        TestBed.compileComponents();
    });
    it('should work', async(inject(
        [MCCPageService, MCCConfigService, KPService, MedicalBillsService,
            LastPaymentService, JSONConfigsService, ControlService, UserService,
            DatePipe, CurrencyPipe, NGWrapperProxyPickerClient, ElementRef],
        (mccPageSvc, mccConfigSvc, kpSvc, medicalBillsSvc, lastPaymentSvc, jsonConfigSvc,
         controlSvc, userSvc, datePipe, currencyPipe, proxyPickerWrapper, ref
        ) => {
            let selectedUserSelfFunded: boolean = null;
            //
            initializeActionAreaComponentServices(
                mccPageSvc, mccConfigSvc, kpSvc, medicalBillsSvc, lastPaymentSvc,
                jsonConfigSvc, controlSvc, userSvc, datePipe, currencyPipe,
                proxyPickerWrapper, ref,
                GuarantorStatus.Error, new ActionAreaConfig('texts', 'buttons'),
                'totalBill', new LastPayment('amount', 'date'), null,
                new AppObject('ABC'));
            //
            let aac: ActionAreaComponent;
            //
            //Part 1 - Proxy selected, ActionAreaComponent is empty
            aac = new ActionAreaComponent(
                mccPageSvc, mccConfigSvc, kpSvc, medicalBillsSvc, lastPaymentSvc,
                jsonConfigSvc, controlSvc, userSvc, datePipe, currencyPipe,
                proxyPickerWrapper, ref);
            aac.ngOnInit();
        })));

});
describe('ActionAreaComponent for not proxy', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            //declarations: [ ],
            //imports: [ ],
            providers: mockProviderArray(
                new NGWrapperProxyPickerClientSubject('self', true))
        });
        TestBed.compileComponents();
    });
    it('should work', async(inject(
        [MCCPageService, MCCConfigService, KPService, MedicalBillsService,
            LastPaymentService, JSONConfigsService, ControlService, UserService,
            DatePipe, CurrencyPipe, NGWrapperProxyPickerClient, ElementRef],
        (mccPageSvc, mccConfigSvc, kpSvc, medicalBillsSvc, lastPaymentSvc, jsonConfigSvc,
            controlSvc, userSvc, datePipe, currencyPipe, proxyPickerWrapper, ref
        ) => {
            let selectedUserSelfFunded: boolean = false;
            //
            initializeActionAreaComponentServices(
                mccPageSvc, mccConfigSvc, kpSvc, medicalBillsSvc, lastPaymentSvc,
                jsonConfigSvc, controlSvc, userSvc, datePipe, currencyPipe,
                proxyPickerWrapper, ref,
                GuarantorStatus.Guarantor, new ActionAreaConfig('texts', 'buttons'),
                'totalBill', new LastPayment('amount', 'date'), (selectedUserSelfFunded),
                new AppObject('ABC'));
            //
            let aac: ActionAreaComponent;
            //
            //Part 2 - Proxy not selected, ActionAreaComponent is not empty
            aac = new ActionAreaComponent(
                mccPageSvc, mccConfigSvc, kpSvc, medicalBillsSvc, lastPaymentSvc,
                jsonConfigSvc, controlSvc, userSvc, datePipe, currencyPipe,
                proxyPickerWrapper, ref);
            aac.ngOnInit();
            mccPageSvc.getAppObject$().subscribe(
                (data) => {expect(data.errorCode).toBe('ABC');});
            //
            aac.buttonDataPqe$.subscribe(
                (data) => {expect(data).toBe('featureEntryId');});
            aac.conditionalButton$.subscribe(
                (data) => {expect(data).toBe('');});
            aac.conditionalButtonHref$.subscribe(
                (data) => {expect(data).toBe('');});
            aac.conditionalMessage$.subscribe(
                (data) => {expect(data).toBe('t');});
            aac.messageDataPqe$.subscribe(
                (data) => {expect(data).toBe('0');});
    })));
    describe('ActionAreaComponent miscellaneous functionality', () => {
        it ('should work',
            inject( [ ], ( ) => {
                let aac:ActionAreaComponent = new ActionAreaComponent(
                    null, null, null, null, null, null,
                    null, null, null, null, null, null
                );
                expect(aac.isProxy()).toBe(false);
                expect(aac.getMessageObject( null, null, null, null, false )).toBeNull();
            } )
        );
    });
});

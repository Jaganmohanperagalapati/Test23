import {AfterViewInit, Component, ElementRef, Inject, OnInit} from '@angular/core';
import { templates } from '../../services/template.service';
import { Observable } from "rxjs/Observable";
import 'rxjs/add/operator/mergeMap';
import { NGWrapperProxyPickerClient } from 'ng2-proxy-picker-wrapper';
import { KPService } from "../../services/kp.service";
import { CurrencyPipe, DatePipe } from "@angular/common";
import { MCCConstants } from "../../util/MCCConstants.util";
import { AppObject, MCCPageService } from "../../services/mccPage.service";
import { ActionAreaConfig, MCCConfigService } from "../../services/mcc-config.service";
import { JSONConfigsService } from "../../services/jsonConfigs.service";
import { ControlService } from "../../services/control.service";
import { GuarantorStatus, MedicalBillsService } from "../../services/medical-bills.service";
import { LastPayment, LastPaymentService } from "../../services/last-payment.service";
import { UserService } from "../../services/user.service";


declare var $;

export class ActionAreaObject {
    conditionalMessage: string;
    buttonText: string;
    buttonHref: string;
    buttonEnabled: boolean;
    messageDataPqe: string;
    buttonDataPqe: string;
    isError: boolean;

    constructor( conditionalMessage: string = "", buttonText: string = "", buttonHref: string = "", buttonEnabled: boolean = false, messageDataPqe: string = "", buttonDataPqe: string = "", isError: boolean = null ) {
        this.conditionalMessage = conditionalMessage;
        this.buttonText = buttonText;
        this.buttonHref = buttonHref;
        this.buttonEnabled = buttonEnabled;
        this.messageDataPqe = messageDataPqe;
        this.buttonDataPqe = buttonDataPqe;
        this.isError = isError;
    }
}

@Component( {
    selector: 'mcc-action-area',
    template: templates.GetTemplate( 'actionareamcc.html' ),
    providers: [ DatePipe, CurrencyPipe ]
} )

export class ActionAreaComponent implements OnInit, AfterViewInit {

    appObject$: Observable<AppObject>;

    /** The observable used to hold the data the action area needs */
    actionAreaObject$: Observable<ActionAreaObject>;

    /** Observable that contains the message to be displayed in action messages.  This is needed because of baseActionArea setup (Even though we can't and don't follow it, future point of concern) */
    conditionalMessage$: Observable<any>;
    conditionalButton$: Observable<any>;
    conditionalButtonHref$: Observable<any>;
    conditionalButtonEnabled$: Observable<any>;
    messageDataPqe$: Observable<any>;
    buttonDataPqe$: Observable<any>;


    private buttons: any = [];

    constructor( private mccPageSvc: MCCPageService,
                 private mccConfigSvc: MCCConfigService,
                 private kpSvc: KPService,
                 private medicalBillsSvc: MedicalBillsService,
                 private lastPaymentSvc: LastPaymentService,
                 private jsonConfigSvc: JSONConfigsService,
                 private controlSvc: ControlService,
                 private userSvc: UserService,
                 private datePipe: DatePipe,
                 private currencyPipe: CurrencyPipe,
                 private proxyPickerWrapper: NGWrapperProxyPickerClient,
                 private ref: ElementRef) {
    }

    /**
     * @description Initializes the observables that the view uses
     */
    ngOnInit() {
        this.appObject$ = this.mccPageSvc.getAppObject$();

        this.actionAreaObject$ = this.proxyPickerWrapper
            .flatMap(() => Observable.combineLatest(
                this.medicalBillsSvc.getGuarantorStatus$(),
                this.medicalBillsSvc.getTotalBill$(),
                this.lastPaymentSvc.getLastPayment$(),
                this.mccConfigSvc.getActionAreaConfig$(),
                this.userSvc.getSelectedUserSelffunded$()
            ))
            .map(([guarantor, totalBill, lastPayment, aaConfig, selectedUserSelfFunded]) => {

                return this.createActionAreaObject(guarantor, aaConfig, totalBill, lastPayment, selectedUserSelfFunded);
            });

        this.conditionalMessage$ = this.actionAreaObject$.map( ( actionAreaObj ) => actionAreaObj.conditionalMessage );
        this.conditionalButton$ = this.actionAreaObject$.map( ( actionAreaObj ) => actionAreaObj.buttonText );
        this.conditionalButtonHref$ = this.actionAreaObject$.map( ( actionAreaObj ) => actionAreaObj.buttonHref );
        this.conditionalButtonEnabled$ = this.actionAreaObject$.map( ( actionAreaObj ) => actionAreaObj.buttonEnabled );
        this.messageDataPqe$ = this.actionAreaObject$.map( ( actionAreaObj ) => actionAreaObj.messageDataPqe );
        this.buttonDataPqe$ = this.actionAreaObject$.map( ( actionAreaObj ) => actionAreaObj.buttonDataPqe );
    }

    ngAfterViewInit() {
        try {
            $( this.ref.nativeElement ).on( 'click', 'button', function () {

                var $buttonURL = $( this ).data( "url" ); //---------------------- Getting URL from button.

                var $buttonTarget = $( this ).data( "target" ); //----------- New window or same window
                if ( $buttonTarget == null )
                    $buttonTarget = "_self";

                if ( $buttonURL != null && $buttonURL != "" )
                    window.open( $buttonURL, $buttonTarget, "toolbar=0,location=0,menubar=0" );
            } );
        }
        catch ( e ) {
        }

        MCCConstants.initializeVoiceOverModeOnIPhone(
            'ActionAreaComponent', 'ngAfterViewInit');
    }

    /**
     * @description Creates the action area object with the correct values based if the user is a guarantor, and the messages retrieved
     * @param guarantor
     * @param messages
     * @returns {ActionAreaObject}
     */
    createActionAreaObject( guarantor: GuarantorStatus, aaConfig: ActionAreaConfig, totalBill: string, lastPayment: LastPayment, selectedUserSelfFunded: boolean ): ActionAreaObject {
        if ( this.proxyPickerWrapper.getValue().isProxySelected() == false ) {
            let aaObj = this.getMessageObject( guarantor, aaConfig, totalBill, lastPayment, selectedUserSelfFunded );
            let isError = aaObj == null;

            let conditionalMessage: string = "";
            let buttonText: string = "";
            let buttonHref: string = "";
            let buttonEnabled: boolean = false;
            let messageDataPqe: string = "";
            let buttonDataPqe: string = "";
            if ( !isError ) {
                conditionalMessage = aaObj[ "conditional-text" ];
                buttonText = aaObj[ "button-text" ];
                buttonHref = aaObj[ "button-href" ];
                buttonEnabled = aaObj["button-enabled"];
                messageDataPqe = aaObj[ "message-data-pqe" ];
                buttonDataPqe = aaObj[ "button-data-pqe" ]
            }

            return new ActionAreaObject( conditionalMessage, buttonText, buttonHref, buttonEnabled, messageDataPqe, buttonDataPqe, isError );
        }
        else
            return new ActionAreaObject( "", "", "", false, "", "", true );
    }

    /**
     * @description Get the proper messages based on entitlements and user status, then replaces the expected 'variables' with their correct values
     * @param guarantor
     * @param messages
     * @returns {any}
     */
    getMessageObject( guarantor: GuarantorStatus, aaConfig: ActionAreaConfig, totalBill: string, lastPayment: LastPayment, selectedUserSelfFunded: boolean ): any {
        //do not check totalBill or lastPayment is null
        if ( guarantor == GuarantorStatus.Error || aaConfig == null || selectedUserSelfFunded == null)
            return null;
        else {
            try {

                let conditionalText: string = "";
                let messagePqe: string = "";
                let buttonText: string = "";
                let buttonHref: string = "";
                let buttonEnabled: boolean = true;
                let buttonPqe: string = "";

                for ( let entry of aaConfig.conditionalTexts ) {
                    let descriptionKey;
                    for ( let key in entry ) {
                        descriptionKey = key;
                        break;
                    }
                    let jsonConfigEntry = this.controlSvc.findEntryWithValue( descriptionKey, this.jsonConfigSvc.getControlObject( MCCConstants.OSGIControlIDs.ConditionalMessages ) );

                    if (jsonConfigEntry == null || (jsonConfigEntry != null && this.controlSvc.checkEntryMeetsControls(jsonConfigEntry, guarantor, selectedUserSelfFunded, totalBill, lastPayment.getAmount()))) {
                        let cText = entry[ descriptionKey ];

                        conditionalText = cText == null ? "" : cText;

                        messagePqe = descriptionKey;

                        break;
                    }
                }

                for ( let button of aaConfig.conditionalButtons ) {
                    let jsonConfigEntry = this.controlSvc.findEntryWithValue( button[ "path" ], this.jsonConfigSvc.getControlObject( MCCConstants.OSGIControlIDs.ConditionButton ) );

                    if ( jsonConfigEntry == null || (jsonConfigEntry != null && this.controlSvc.checkEntryMeetsControls( jsonConfigEntry, guarantor, selectedUserSelfFunded )) ) {
                        let bText = button[ "text" ];

                        buttonText = bText == null ? "" : bText;
                        buttonHref = button[ "path" ];

                        let pqe: string = this.jsonConfigSvc.getFeatureEntryID( jsonConfigEntry );
                        buttonPqe = pqe == null ? "" : pqe;

						if (MCCConstants.OSGIControlIDs.MedicalBill == pqe && this.controlSvc.hasNoAmount(totalBill)){
							buttonEnabled = false;
						}

                        break;
                    }
                }

                return {
                    "conditional-text": conditionalText
                        .replace( "{{lastStatementBalance}}", totalBill )
                        .replace( "{{lastPaymentAmount}}", lastPayment.getAmount() )
                        .replace( "{{lastPaymentDate}}",  this.formatDate( lastPayment.getDate() )),
                    "button-text": buttonText,
                    "button-href": buttonHref,
                    "button-enabled": buttonEnabled,
                    "message-data-pqe": messagePqe,
                    "button-data-pqe": buttonPqe
                };
            }
            catch ( e ) {
                return null;
            }
        }
    }

    /**
     * @description Formats the passed string as Date using the Angular DatePipe
     * @param date
     * @returns {string}
     */
    private formatDate( date: string ): string {
        return this.datePipe.transform( date, 'MM/dd/yyyy' );
    }

    isProxy(): boolean {
        return false;
    }
}

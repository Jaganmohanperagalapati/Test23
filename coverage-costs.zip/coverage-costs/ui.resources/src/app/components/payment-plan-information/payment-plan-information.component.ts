
import { AfterViewInit, Component, ElementRef, OnInit } from '@angular/core';
import { templates } from '../../services/template.service';
import { Observable } from "rxjs/Observable";
import { ReplaySubject } from "rxjs/ReplaySubject";
import 'rxjs/add/operator/mergeMap';
import { KPService } from "../../services/kp.service";
import { CurrencyPipe, DatePipe } from "@angular/common";
import { MCCConstants } from "../../util/MCCConstants.util";
import { AppObject, MCCPageService } from "../../services/mccPage.service";
import { ActionAreaConfig, MCCConfigService } from "../../services/mcc-config.service";
import { JSONConfigsService } from "../../services/jsonConfigs.service";
import { ControlService } from "../../services/control.service";
import { GuarantorStatus, MedicalBillsService } from "../../services/medical-bills.service";
import { LastPayment, LastPaymentService } from "../../services/last-payment.service";
import { UserService } from "../../services/user.service";

export class PaymentPlanInformationContext {
    public readonly guarantorName:string;
    public readonly accountNumber:string;
    public readonly paymentPlanType:string;
    public readonly recurringPaymentAmount:string;
    public readonly nextPaymentDue:string;
    public readonly beginningPlanBalance:string;
    public readonly paymentPlanStartDate:string;
    public readonly remainingPlanBalance:string;
    constructor(
            private inGuarantorName:string,
            private inAccountNumber:string,
            private inPaymentPlanType:string,
            private inRecurringPaymentAmount:string,
            private inNextPaymentDue:string,
            private inBeginningPlanBalance:string,
            private inPaymentPlanStartDate:string,
            private inRemainingPlanBalance:string) {
        this.guarantorName = inGuarantorName;
        this.accountNumber = inAccountNumber;
        this.paymentPlanType = inPaymentPlanType;
        this.recurringPaymentAmount = inRecurringPaymentAmount;
        this.nextPaymentDue = inNextPaymentDue;
        this.beginningPlanBalance = inBeginningPlanBalance;
        this.paymentPlanStartDate = inPaymentPlanStartDate;
        this.remainingPlanBalance = inRemainingPlanBalance;
    }
}

@Component( {
    selector: 'mcc-payment-plan-detail',
    template: templates.GetTemplate( 'payment_plan_detail.html' ),
    providers: []
} )
export class PaymentPlanInformationComponent implements OnInit, AfterViewInit {
    context$:ReplaySubject<PaymentPlanInformationContext>;
    constructor() {
        this.context$ = new ReplaySubject<PaymentPlanInformationContext>(1);
    }
    ngOnInit() {
    }
    ngAfterViewInit() {
    }
    updateContext(nextContext:PaymentPlanInformationContext) {
        this.context$.next(nextContext);
    }
}


import { async, inject, TestBed } from '@angular/core/testing';
import {PaymentPlanInformationComponent, PaymentPlanInformationContext} from "./payment-plan-information.component";

function mockProviderArray():any[] {
    return [
    ];
}


describe('FeedContainerComponent test', () => {

    describe('testArea 1', () => {

        beforeEach(() => {
            TestBed.configureTestingModule({
                //    //declarations: [ ],
                //    //imports: [ ],
                providers: mockProviderArray(
                )
            });
        });

        it('should exist', async(inject(
            [],
            () => {
                TestBed.compileComponents();
                let ppi:PaymentPlanInformationComponent = new PaymentPlanInformationComponent();
                let ppic: PaymentPlanInformationContext = new PaymentPlanInformationContext('name', '12345', 'type', '0.00', '01/01/2017', '0.00', '01/01/2017', '0.00');

                expect(ppi).toBeDefined();
                expect(ppic).toBeDefined();
                ppi.ngOnInit();
                ppi.ngAfterViewInit();
                ppi.updateContext(null);
                ppi.context$.subscribe((result) => {expect(result).toBeNull()});

                expect(ppic.guarantorName).toEqual('name');
                expect(ppic.accountNumber).toEqual('12345');

            })));
    });

});

import { async, inject, TestBed } from '@angular/core/testing';
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import {BillExpandMessageHolder, FeedContainerComponent, FeedMessageHolder} from "./feed-container.component"
import { GuarantorStatus, MedicalBillsService } from "../../services/medical-bills.service";
import { AppObject, MCCPageService } from "../../services/mccPage.service";
import { NGWrapperProxyPickerClient, NGWrapperProxyPickerClientSubject } from 'ng2-proxy-picker-wrapper';
import { BillExpandService } from "../../services/bill-expand.service";
import { KPService } from "../../services/kp.service";
import {isUndefined} from "util";
import {PaymentPlanService} from "../../services/payment-plan.service";
import {UtilService} from "../../services/util.service";
import {MedicalBillsGuarantor} from "../../util/NodeMockResponses.util";
import {PaymentPlanInformationContext} from "../payment-plan-information/payment-plan-information.component";
import {ResponseOptions, XHRBackend} from "@angular/http";
import {MockBackend} from "@angular/http/testing";
import {MCCConfigService, PaymentPlanConfig} from "../../services/mcc-config.service";



function mockProviderArray(ngwppcs: NGWrapperProxyPickerClientSubject, gs: GuarantorStatus):any[] {
    return [
        {
            provide: MCCPageService,
            useValue: {
                getAppObject$: () => Observable.of(new AppObject('ABC'))
            }
        },
        {
            provide: MedicalBillsService,
            useValue: {
                getAllBills$ : () => Observable.of({"feedData" : "someFeedData" }),
                getGuarantorStatus$: () => Observable.of(gs)
            }
        },
        {
            provide: NGWrapperProxyPickerClient,
            useValue: new BehaviorSubject<NGWrapperProxyPickerClientSubject>(new NGWrapperProxyPickerClientSubject("ProxySelected", true))
        },
        {
            provide: BillExpandService,
            useValue: {
                getBillsExpand$: (id,type,date)=>Observable.of(isUndefined)
            }
        },
        {
            provide: KPService,
            useValue: {
                getUserName : () => { return "name";},
                openModalWindow : () => {}
            }
        },
        {
            provide: PaymentPlanService,
            useValue:{

            }
        },
        {
            provide: UtilService,
            useValue:{

            }
        },
        {
            provide: MCCConfigService,
            useValue: {
                getPaymentPlanConfig$: ()=> {return new PaymentPlanConfig({}, 'desc');}
            }
        }
    ];
}

class MockMCCConfigService {
    public getPaymentPlanConfig$() : Observable<PaymentPlanConfig>{
        return Observable.of(new PaymentPlanConfig({}, 'desc'));
    }
}

describe('FeedContainerComponent test', () => {

    describe('testArea 1', () => {

        beforeEach(() => {
            TestBed.configureTestingModule({
                providers: mockProviderArray(
                    new NGWrapperProxyPickerClientSubject("ProxySelected", true),
                    GuarantorStatus.Guarantor
                )
            });
        });
        it ('should working utility functions',
            inject( [ ], ( ) => {
                let fcc:FeedContainerComponent = new FeedContainerComponent(
                    null, null, null, null, null, null, null, null
                );
                let bemh:BillExpandMessageHolder =
                    (fcc['getDefaultErrorBillExpandMessageHolder'])();
                expect(bemh.billDate).toEqual(false);
                expect(bemh.billType).toEqual(false);
                expect(bemh.error).toEqual(true);
                expect(bemh.expandData).toEqual(false);
                expect(bemh.guarantorId).toEqual(false);
            } )
        );
        it('should exist', async(inject(
            [MCCPageService, MedicalBillsService, NGWrapperProxyPickerClient,BillExpandService, KPService, PaymentPlanService, UtilService, MCCConfigService],
            (mps, mbs, nppc,bs, ks, pps, util, mcs) => {
                TestBed.compileComponents();
                let bemh: BillExpandMessageHolder = new BillExpandMessageHolder('test', 'test', 'test', false);
                let fcc:FeedContainerComponent = new FeedContainerComponent(mps, mbs, nppc,bs, ks, pps, util, mcs);

                let planInfo$ = fcc.planInformation$;
                let appObj$ = fcc.appObject$;
                let feedD$ = fcc.feedData$;
                let isGuar$ = fcc.isGuarantorData$;
                let mBillFeed$ = fcc.medicalBillFeedItems$;
                let proxy$ = fcc.proxySelected$;

                expect(fcc).toBeDefined();
                fcc.ngOnInit();
                fcc.feedData$.subscribe(
                    (data) => {
                        expect(data.feedData).toBe('someFeedData');
                    }
                );
                fcc.appObject$.subscribe(
                    (data) => {
                        expect(data.errorCode).toBe('ABC');
                    }
                );
                fcc.isGuarantorData$.subscribe(
                    (data) => {
                        expect(data).toBe(GuarantorStatus.Guarantor);
                    }
                );


                expect(fcc.feedItemsError).toBeFalsy();
                fcc.getFeedMessage().subscribe(
                    (data) => {
                        expect(data.feedData.feedData).toBe('someFeedData');
                        expect(data.guarantor).toBe(GuarantorStatus.Guarantor);
                        expect(data.error).toBeFalsy();
                    }
                );
                fcc.proxySelected$.subscribe(
                    (data) => {
                        expect(data).toBeTruthy();
                    }
                );
                expect(fcc.isGuarantor(GuarantorStatus.Guarantor)).toBeTruthy();
                expect(fcc.isGuarantor(GuarantorStatus.NonGuarantor)).toBeFalsy();

                fcc.expandData$[999].subscribe(
                    (data) =>{
                        expect(data).toBeDefined();
                    }
                )

            })));
    });

    describe('test area 2', () => {
        beforeEach(() => {
            TestBed.configureTestingModule({
                providers: [
                    {
                        provide: MCCPageService,
                        useValue: {
                            getAppObject$: () => Observable.of(new AppObject('ABC'))
                        }
                    },
                    {
                        provide: MedicalBillsService,
                        useValue: {
                            getAllBills$ : () => Observable.throw(new Error("Error")),
                            getGuarantorStatus$: () => Observable.throw(new Error("Error"))
                        }
                    },
                    {
                        provide: NGWrapperProxyPickerClient,
                        useValue: new BehaviorSubject<NGWrapperProxyPickerClientSubject>(new NGWrapperProxyPickerClientSubject("ProxySelected", true))
                    },
                    {
                        provide: BillExpandService,
                        useValue: {
                            getBillsExpand$: (id,type,date)=>Observable.of(isUndefined)
                        }
                    },
                    {
                        provide: KPService,
                        useValue: {
                            getUserName : () => { return "name";},
                            getAccessibleBillUriLocation : () => {return "google.com"; },
                            openModalWindow : () => {}
                        }
                    },
                    {
                        provide: PaymentPlanService,
                        useValue: {
                            getPaymentPlan$ : (name, account, bill) => {return Observable.of("yes");}
                        }
                    },
                    {
                        provide: UtilService,
                        useValue: {

                        }
                    },
                    {
                        provide: XHRBackend,
                        useClass: MockBackend
                    },
                    {
                        provide: MCCConfigService,
                        useClass: MockMCCConfigService
                    }

                ]
            }).compileComponents();
        });

        it('test error catches', async(inject(
            [MCCPageService, MedicalBillsService, NGWrapperProxyPickerClient,BillExpandService, KPService, PaymentPlanService, UtilService, MCCConfigService],
            (mps, mbs, ngwppc,bs, ks, pps, util, mcs) => {

                let fcc: FeedContainerComponent = new FeedContainerComponent(mps, mbs, ngwppc,bs, ks, pps, util, mcs);
                fcc.ngOnInit();

                console.log("IN SECOND DESC");

                fcc.feedData$.subscribe((x) => {
                    console.log(x);
                    expect(x).toBeDefined();
                });
                expect(fcc.feedItemsError).toBeTruthy();

            })));

        it('test error catches', async(inject(
            [MCCPageService, MedicalBillsService, NGWrapperProxyPickerClient,BillExpandService, KPService, PaymentPlanService, UtilService, XHRBackend, MCCConfigService],
            (mps, mbs, ngwppc,bs, ks, pps, util, mockBackend, mcs) => {

                let fcc: FeedContainerComponent = new FeedContainerComponent(mps, mbs, ngwppc,bs, ks, pps, util, mcs);
                fcc.ngOnInit();
                const spy = spyOn(ngwppc, 'getValue')
                    .and.returnValue(Observable.throw(new Error("Error!")));

                fcc.proxySelected$.subscribe((x) => {
                    console.log(x);
                    expect(x).toBeDefined();
                });

                fcc.billExpandError[999] =false;
                fcc.willShow[999] ="none";
                fcc.loadingSign[999] = 1;
                fcc.expandData$[999] =null;
                fcc.viewToggle([],999,"type","date",999).subscribe();
                let expItems$ = fcc.billExpandItems$;
                expItems$.subscribe();

                fcc.billExpandError[999] =true;
                fcc.willShow[999] ="none";
                fcc.loadingSign[999] = 1;
                fcc.expandData$[999] =null;
                fcc.viewToggle([],999,"type","date",999);
                //mbs.getE

                expect(fcc.viewToggle).toBeTruthy();
                expect(fcc.proxySelected$).toBeTruthy();

                fcc.accountPlansInformation = new BehaviorSubject("test");
                fcc.openAccessibleBillWindow(1, "KPHC-HB", "2017-05-25");
                fcc.openAccessibleBillWindow(1, "KPHC-PB", "2017-05-25");
                fcc.openAccessibleBillWindow(1, "KPHC-ENT", "2017-05-25");
                let ppic: PaymentPlanInformationContext = new PaymentPlanInformationContext('name', '12345', 'type', '0.00', '01/01/2017', '0.00', '01/01/2017', '0.00');
                expect(ppic.guarantorName).toEqual('name');
                expect(ppic.accountNumber).toEqual('12345');

                fcc.addUsd(null);
                fcc.addUsd("1,990.75");
                fcc.addUsd("-0.00");
                fcc.addUsd("-1,990.75");
                let planInfo:any = {
                    "inGuarantorName" : "A",
                    "inAccountNumber" : "B",
                    //paymentPlanType - "C"
                    "inRecurringPaymentAmount" : "D",
                    "inNextPaymentDue" : "E",
                    "inBeginningPlanBalance" : "F",
                    "inPaymentPlanStartDate" : "G",
                    "inRemainingPlanBalance" : "H"
                };
                let planConfig:any = {
                    "accountLabel" : "I",
                    "recurringBillPmtPlanLabel" : "J",
                    "nextPmtLabel" : "K",
                    "begBalanceLabel" : "L",
                    "pmtPlanStartDateLabel" : "M",
                    "remBalLabel" : "N",
                    "pmtplandetailsdesc" : "O"
                };
                fcc.replaceHTML(planInfo, planConfig);



                fcc.pullPaymentPlanInformation(MedicalBillsGuarantor);

                let $tp: any = {
                    offset : () => { return {left: 5}},
                    outerWidth : () => {return 1}
                }

                fcc.offscreenTest($tp);

                fcc.accountPlansInformation['1111hb'] = Observable.of('test');
                fcc.getPaymentPlanDetails('1111', 'hb');

                spyOn(fcc, 'offscreenTest');

            })));
    });

}); 

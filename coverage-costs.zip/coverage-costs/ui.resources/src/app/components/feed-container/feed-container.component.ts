import { AfterViewInit, Component, EventEmitter, OnInit, Output, ViewChild } from "@angular/core";
import { templates } from "../../services/template.service";
import { Observable } from "rxjs/Observable";
import 'rxjs/add/observable/throw';
import { AppObject, MCCPageService } from "../../services/mccPage.service";
import { NGWrapperProxyPickerClient } from 'ng2-proxy-picker-wrapper';
import { GuarantorStatus, MedicalBillsService } from "../../services/medical-bills.service";
import { MCCConstants } from "../../util/MCCConstants.util";
import { BillExpandService } from "../../services/bill-expand.service";
import { KPService } from "../../services/kp.service";
import { PaymentPlanInformationComponent, PaymentPlanInformationContext }
  from "../payment-plan-information/payment-plan-information.component";
import {PaymentPlanService, PaymentPlanHolder} from "../../services/payment-plan.service";
import {BehaviorSubject} from "rxjs/BehaviorSubject";
import {UtilService} from "../../services/util.service";

import * as $ from 'jquery';
import {MCCConfigService, PaymentPlanConfig} from "../../services/mcc-config.service";

export class FeedMessageHolder {

    guarantor: any;
    feedData: any;
    error: boolean;

    constructor( feedData, guarantor, error? ) {
        this.feedData = feedData;
        this.guarantor = guarantor;
        this.error = error;
    }
}

export class BillExpandMessageHolder {
    guarantorId: any;
    expandData: any;
    billType: any;
    billDate: any;
    error: boolean;

    constructor(expandData, guarantorId, billType, billDate,  error? ) {
        this.expandData = expandData;
        this.guarantorId = guarantorId;
        this.billType = billType;
        this.billDate = billDate;
        this.error = error;
    }
}

@Component({
    selector: "mcc-feed-container",
    template: templates.GetTemplate("feedcontainermcc.html")
})
export class FeedContainerComponent implements AfterViewInit, OnInit {
    feedItemsError: boolean = false;
    loadingSign = [];
    callcompleted=[];
    billExpandError=[];
    accountPlansInformation = {} ;
    accountPlansExists = {};
    planInformation$: Observable<any>;
    appObject$: Observable<AppObject>;
    feedData$: Observable<any>;
    isGuarantorData$: Observable<any>;
    medicalBillFeedItems$: Observable<FeedMessageHolder>;
    proxySelected$: Observable<any>;
    billExpandItems$: Observable<any>;

    expandData$:Observable<any>[]=[];
    public feedList = [];
    willShow = new Array(99);
    paymentPlanConfigs: PaymentPlanConfig;


    private showDisplay(index) {
        this.willShow[index] = "block";
        return this.willShow[index];
    }

    public show:boolean = false;

    @Output() preparePaymentPlanDetailsEvent: EventEmitter<PaymentPlanInformationContext>;

    constructor(
        private mccPageSvc: MCCPageService,
        private medicalBillsSvc: MedicalBillsService,
        private NGProxyPickerWrapper: NGWrapperProxyPickerClient,
        private billExpandSvc: BillExpandService,
        private kpSvc: KPService,
        private paymentPlanSvc: PaymentPlanService,
        private utilSvc: UtilService,
        private mccConfigSvc: MCCConfigService,) {

        this.preparePaymentPlanDetailsEvent = new EventEmitter<PaymentPlanInformationContext>();
    }

    ngOnInit(): void {
        this.appObject$ = this.mccPageSvc.getAppObject$();
        this.proxySelected$ = this.NGProxyPickerWrapper.map((data) => {
            return this.NGProxyPickerWrapper.getValue().isProxySelected();
        }).catch((err: any) => {
            this.feedItemsError = true;
            return Observable.of(this.getDefaultErrorFeedMessageHolder());
        });

        this.medicalBillFeedItems$ = Observable.combineLatest(
            this.medicalBillsSvc.getAllBills$(),
            this.medicalBillsSvc.getGuarantorStatus$()
        ).map(([feed, guarantor]) => {
                return new FeedMessageHolder(feed, guarantor);
        }).catch((err: any) => {
                this.feedItemsError = true;
                return Observable.of(this.getDefaultErrorFeedMessageHolder());
            }
        );

        this.feedData$ = this.medicalBillFeedItems$.map((feedObj) => {
            return feedObj.feedData;
        });

        this.planInformation$ = this.feedData$.map((data) => {
            return this.pullPaymentPlanInformation(data);
        });

        this.isGuarantorData$ = this.medicalBillFeedItems$.map((guarantorObj) => {
            return guarantorObj.guarantor;
        });

        this.expandData$[999]=this.billExpandSvc.getBillsExpand$(null,null,null);
    }

    viewToggle(data, guarantorId, billType, billDate,index) {
        this.billExpandError[index] = false;
        this.callcompleted[index] = false;
        this.loadingSign[index] = 1;
        this.willShow[index] ="none";
        if (this.feedList.indexOf(index) < 0 || this.billExpandError[index] == true) {
            this.billExpandItems$ = Observable.combineLatest(
                this.billExpandSvc.getBillsExpand$(guarantorId, billType, billDate)
            ).map(([expandData, guarantorId, billType, billDate]) => {
                this.callcompleted[index] = true;
                this.loadingSign[index] = 0;
                this.billExpandError[index] = false;
                this.showDisplay(index);
                this.feedList.push(index);
                return new BillExpandMessageHolder(expandData, guarantorId, billType, billDate);
            }).catch((err: any) => {
                this.billExpandError[index] = true;
                this.loadingSign[index] = 0;
                return Observable.of(this.getDefaultErrorBillExpandMessageHolder());
            });
            this.expandData$[index] = this.billExpandItems$.map((expandObj) => {return expandObj.expandData;});

            this.expandData$[index].subscribe(
                next => {
                    var xpos = window.scrollX || document.documentElement.scrollLeft;
                    var ypos = window.scrollY || document.documentElement.scrollTop;
                    MCCConstants.shockExpandedViewAndScroll(window.document.body, xpos, ypos);
                }
            );
            data.show = !data.show;

            return this.expandData$[index];

        } else {
            this.loadingSign[index] = 0;
            data.show = !data.show;
            return this.expandData$[index];
        }
    }

    public ngAfterViewInit(): void {
        MCCConstants.initializeVoiceOverModeOnIPhone(
            'FeedContainerComponent', 'ngAfterViewInit');
    }

    public getPaymentPlanDetails(accountNumber: string, billType: string): void {
        let allPaymentPlanInfo$ = Observable.combineLatest(
            this.accountPlansInformation[accountNumber + billType],
            this.mccConfigSvc.getPaymentPlanConfig$()
        ).map(([planInfo, planConfig]) => {
            let htmlToLoad = this.replaceHTML(planInfo, planConfig);
            this.kpSvc.openModalWindow(htmlToLoad);
        });
        allPaymentPlanInfo$.subscribe();
    }

    public pullPaymentPlanInformation(data: any){
        let toReturn = {};
        data.guarantor.forEach(data =>{
           data.statements.forEach(statements => {
               let billName: string;
               if(statements.docSourceSystem === "KPHC-HB"){
                   billName = "HB";
               } else if (statements.docSourceSystem === "KPHC-PB"){
                   billName = "PB";
               } else if (statements.docSourceSystem === "KPHC-ENT" || statements.docSourceSystem === "KPHC-DB") {
                   billName = "HB_PB";
               }
               toReturn[data.guarantoraccount+ statements.docSourceSystem] = this.paymentPlanSvc.getPaymentPlan$(this.kpSvc.getUserName(), data.guarantoraccount, billName).map(payment =>{
                        this.accountPlansInformation[data.guarantoraccount + statements.docSourceSystem] = Observable.of(payment.information);
                        this.accountPlansExists[data.guarantoraccount + statements.docSourceSystem] = Observable.of(payment.exists);
                        return payment.exists;
               });
           });
        });

        return toReturn;
    }

    public isGuarantor( data ) {
        if ( data == GuarantorStatus.Guarantor)
            return true;
        else
            return false;
    }


    public getFeedMessage(): Observable<any> {
        return this.medicalBillFeedItems$;
    }


    public getExpandMessage(): Observable<any> {
        return this.billExpandItems$
    }

    private getDefaultErrorFeedMessageHolder(): FeedMessageHolder {
        let outValue: FeedMessageHolder;

        outValue = new FeedMessageHolder(false, false, true);
        return outValue;
    }
    public openAccessibleBillWindow(
            guarantorId: number, docSourceSystem: string, billDate: string):void {

        let ckValGuarantorId:number = guarantorId;
        let ckValBillType:string;
        if (docSourceSystem === 'KPHC-PB') {
            ckValBillType = 'Professional billing';
        } else if (docSourceSystem === 'KPHC-HB') {
            ckValBillType = 'Hospital billing';
        } else if (docSourceSystem === 'KPHC-ENT' || docSourceSystem === 'KPHC-DB') {
            ckValBillType = 'ENT';
        } else {
            throw "Document source system '" + docSourceSystem + "' isn't recognized";
        }
        let ckValBillDate:string;
        if (billDate.length === 10) {
            ckValBillDate = billDate.substring(6, 10) + "-"
                + billDate.substring(0, 2) + "-" + billDate.substring(3, 5);
        } else {
            throw "Date value '" + billDate + "' isn't valid";
        }
        //Note - 'guarantorId' shouldn't be sent in unsecure (plain 'http')
        //  transmissions, so include 'secure' flag in cookie setting
        document.cookie = 'guarantorId=' + ckValGuarantorId + '; path=/; secure';//NOSONAR
        document.cookie = 'billDate=' + ckValBillDate + '; path=/; secure';//NOSONAR
        document.cookie = 'billType=' + ckValBillType + '; path=/; secure';//NOSONAR
        window.open(this.kpSvc.getAccessibleBillUriLocation());
    }

    private getDefaultErrorBillExpandMessageHolder(): BillExpandMessageHolder {
        let outValue: BillExpandMessageHolder;

        outValue = new BillExpandMessageHolder(false,false,false,false, true);
        return outValue;
    }

  offscreenTest($tp) {
    var w = $(window).width();
    var tpoffset = $tp.offset();
    var tpwidth = $tp.outerWidth();

    if (tpoffset.left < 0) {
      $tp.css({
        'transform': 'none'
      }).offset({
        left: 5
      }); // 5px nudge from edge
    }

    if ((tpoffset.left + tpwidth) > w) {
      $tp.css({
        'transform': 'none'
      }).offset({
        left: (w - (tpwidth + 5))
      });
    }
  };

    addUsd(elem){
        let newValue;
        let newNum;
        if(elem !== null){
             newNum = elem.replace(/^[, ]+|[, ]+$|[, ]+/g, "");

            let newformat = Math.abs(newNum).toFixed(2);
            let newT = newformat.toString();

            if(newNum === "-0.00"){
                newValue = "-$"+newT.toLocaleString();

            } else if( newNum >= 0) {
                newValue = "$"+newT.toLocaleString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");

            } else if( newNum < 0 ){
                newValue = "-$"+newT.toLocaleString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            }
            return newValue;
        } else {
            newValue = "";
            return newValue;
        }
    }

    navigateToPayBills(link: string){
        location.href=link;
    }

    replaceHTML(planInfo: any, planConfig: PaymentPlanConfig): string{
        try{
            let paymentPlanType: string;
            if(planInfo.paymentPlanType == 'HB') {
                paymentPlanType = planConfig.jsonObject["hospbillpmtplanlabel"];
            }
            else if(planInfo.paymentPlanType == 'PB') {
                paymentPlanType = planConfig.jsonObject["profbillpmtplanlabel"];
            }
            else if(planInfo.paymentPlanType == 'HB_PB') {
                paymentPlanType = planConfig.jsonObject["hospprofbillpmtplanlabel"];
            }
            console.log('paymentPlanType');
            console.log(paymentPlanType);

            console.log('planConfig');
            console.log(planConfig);

            return templates.GetTemplate( 'payment_plan_detail.html' )
                .replace("{{context$.guarantorName}}", planInfo.inGuarantorName)
                .replace("{{context$.accountNumber}}", planInfo.inAccountNumber)
                .replace("{{context$.paymentPlanType}}", paymentPlanType)
                .replace("{{context$.recurringPaymentAmount}}", planInfo.inRecurringPaymentAmount)
                .replace("{{context$.nextPaymentDue}}", planInfo.inNextPaymentDue)
                .replace("{{context$.beginningPlanBalance}}", planInfo.inBeginningPlanBalance)
                .replace("{{context$.paymentPlanStartDate}}", planInfo.inPaymentPlanStartDate)
                .replace("{{context$.remainingPlanBalance}}", planInfo.inRemainingPlanBalance)
                .replace("{{accountLabel}}", planConfig.jsonObject["accountlabel"])
                .replace("{{recurringbillpmtplanlabel}}", planConfig.jsonObject["recurringbillpmtplanlabel"])
                .replace("{{nextpmtplanlabel}}", planConfig.jsonObject["nextpmtplanlabel"])
                .replace("{{begplanballabel}}", planConfig.jsonObject["begplanballabel"])
                .replace("{{pmtplanstartdatelabel}}", planConfig.jsonObject["pmtplanstartdatelabe"])
                .replace("{{remainballabel}}", planConfig.jsonObject["remainballabel"])
                .replace("{{PmtPlanDetailsDesc}}",
                    planConfig.desc
                        .replace('pmtplandetailsdesc', '')
                        .replace('<p>', '')
                        .replace(/<\\\/p>\\r\\n/g, '')
                        .replace(/2019/g, "'")
                        .replace(/["\\/:]/g, '')
                        .replace(/rn}/g, '')
                );
        }
        catch(err){}


    }
}

import { FeedItemComponent } from "./feed-item.component"

describe('FeedItemComponent test', () => {
    it('should exist', () => {
        let fic:FeedItemComponent = new FeedItemComponent();
        fic.ngOnInit();
        expect(fic).toBeDefined();
        fic.expandBill();
        fic.payBill();
        fic.viewBill();
    });
});

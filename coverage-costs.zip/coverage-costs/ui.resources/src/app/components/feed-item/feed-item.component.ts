import { OnInit } from '@angular/core';
/**
 * Created by clarklyu on 4/3/17.
 */
import {AfterViewInit, Component, Input} from '@angular/core';
import { Feed } from '../../models/feed';
import { templates } from '../../services/template.service';
import { MCCConstants } from "../../util/MCCConstants.util";



@Component({
    selector: 'mcc-feed-items',
    template: templates.GetTemplate('feeditemsmcc.html'),
})
export class FeedItemComponent implements OnInit, AfterViewInit {

    @Input() feed:Feed;
    @Input('idx') idx;

    ngOnInit():void {}

    viewBill(): void {}

    expandBill():void {}

    payBill(): void {}

    ngAfterViewInit():void {
        MCCConstants.initializeVoiceOverModeOnIPhone(
            'FeedItemComponent', 'ngAfterViewInit');
    }
}
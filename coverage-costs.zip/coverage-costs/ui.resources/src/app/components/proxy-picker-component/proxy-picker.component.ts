import { AfterViewInit, Component, OnInit } from '@angular/core';
import { templates } from '../../services/template.service';
import { Observable } from "rxjs/Observable";
import { AppObject, MCCPageService } from "../../services/mccPage.service";
import { MCCConstants } from "../../util/MCCConstants.util";

declare let $kp: any;

@Component( {
    selector: 'mcc-proxy-picker',
    template: `<div id="proxy-picker-container"></div>`
} )
export class ProxyPickerComponent implements AfterViewInit, OnInit {

    appObject$: Observable<AppObject>;

    constructor( private mccPageSvc: MCCPageService ) {}

    ngOnInit() {
        this.appObject$ = this.mccPageSvc.getAppObject$();
    }
    public ngAfterViewInit() {
        $kp.KPProxyPicker.ProxyPickerWidget.render(
                {"selector": "#proxy-picker-container"});
        MCCConstants.initializeVoiceOverModeOnIPhone(
            'ProxyPickerComponent', 'ngAfterViewInit');
    }
}

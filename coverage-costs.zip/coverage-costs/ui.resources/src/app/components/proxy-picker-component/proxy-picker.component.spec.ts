import { async, inject, TestBed } from '@angular/core/testing';
import { Observable } from "rxjs/Observable";
import { ProxyPickerComponent } from "./proxy-picker.component"
import { AppObject, MCCPageService } from "../../services/mccPage.service";

describe('ProxyPickerComponent test', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
        //    //declarations: [ ],
        //    //imports: [ ],
            providers: [
                {
                    provide: MCCPageService,
                    useValue: {
                        getAppObject$: () => Observable.of(new AppObject('ABC'))
                    }
                }
            ]
        });
        TestBed.compileComponents();
    });
    it('should exist', async(inject(
        [MCCPageService],
        (mps) => {
            let ppc:ProxyPickerComponent = new ProxyPickerComponent(mps);
            expect(ppc).toBeDefined();
            ppc.ngOnInit();
            ppc.appObject$.subscribe(
                (data) => {
                    expect(data.errorCode).toBe('ABC');
                }
            );
    })));
});

import { async, inject, TestBed } from '@angular/core/testing';
import { BaseRequestOptions, Http, HttpModule, Response, ResponseOptions, XHRBackend } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { ReplaySubject } from "rxjs/ReplaySubject";
import { Subject } from "rxjs/Subject";
import { Observable } from "rxjs/Observable";
import { ErrorMessageComponent, ErrorMessageHolder } from "./error-message.component"
import { KPService } from "../../services/kp.service";
import { AppObject, MCCPageService } from "../../services/mccPage.service";
import { MCCConstants } from "../../util/MCCConstants.util";

describe('ErrorMessageHolder test', () => {
    it('should not modify input values', () => {
        let emh:ErrorMessageHolder = new ErrorMessageHolder('MESSAGE', 'CODE');
        expect(emh.getMessage()).toBe('MESSAGE');
        expect(emh.getCode()).toBe('CODE');
    });
    it('should not modify input values (even HTML tags)', () => {
        let emh:ErrorMessageHolder = new ErrorMessageHolder('<MESSAGE></MESSAGE>', 'CODE');
        expect(emh.getMessage()).toBe('<MESSAGE></MESSAGE>');
        expect(emh.getCode()).toBe('CODE');
    });
});
describe('ErrorMessageComponent test', () => {
    //let mockHttp : ReplaySubject<Response>;
    //let mockMccPageService : ReplaySubject<AppObject>;
    //let emc : ErrorMessageComponent;
    beforeEach(() => {
        //mockKpService = new BehaviorSubject<any>();
        //let r : Response = new Response(new ResponseOptions({}));
        //mockHttp = new ReplaySubject<Response>();
        //mockMccPageService = new ReplaySubject<AppObject>();
        TestBed.configureTestingModule({
            //declarations: [ ],
            //imports: [ ],
            providers: [
                {
                    provide: Http,
                    useValue: {}//{get: () => mockHttp}//Observable.of( 'ABC' )}
                },
                {
                    provide: KPService,
                    useValue: {
                        getMccMessageJsonUrlLocation: () => "DoesNotMatter",
                        getExceptionMessageJsonUrlLocation: () => "DoesNotMatter",
                        getLanguagePrimarySubCode: () => "en-US",
                        //getDefaultErrorMessage: () => "<h4>Unable to display content</h4>"
                    }
                },
                {
                    provide: MCCPageService,
                    useValue: {}//{getAppObject$: () => mockMccPageService}//Observable.of()}
                }
            ]
        });
        TestBed.compileComponents();
    });
    it('should have blank error message/code when internal app error code is blank', async(inject(
        [MCCPageService, KPService, Http], (mccps, kps, http) => {
        http.get = () => new BehaviorSubject(new Response(new ResponseOptions()));
        mccps.getAppObject$ = () => new BehaviorSubject(new AppObject(""));
        let emc : ErrorMessageComponent = new ErrorMessageComponent(mccps, kps, http);
        emc.ngOnInit();
        expect(emc.getErrorType(MCCConstants.ErrorCodes.NonMemberAccount)).toBe("-hard-interruption");
        expect(emc.getErrorType("SomethingElse")).toBe("-hard-interruption");
        //
        emc.getErrorMessage().subscribe(
            (data) => {
                expect(data.getCode()).toBe("");
                expect(data.getMessage()).toBe("");
            });
        //emc.getErrorMessage().
        //expect(result).toBeDefined();
        //let a : ReplaySubject<AppObject> = new ReplaySubject<AppObject>();
        //a.onNext(new AppObject(""));
        //mccps.onNext(new AppObject(""));
        //mockMccPageService.on
        //var dataTwo;
        //http.call('XYZ').subscribe((data) => {dataTwo = data});
        //expect(dataTwo).toBeTruthy();
        //expect(dataTwo).toBe('ABC');
    })));
    it('should have blank error message/code when internal app error code is null', async(inject(
        [MCCPageService, KPService, Http], (mccps, kps, http) => {
        http.get = () => new BehaviorSubject(new Response(new ResponseOptions()));
        mccps.getAppObject$ = () => new BehaviorSubject(new AppObject(null));
        let emc : ErrorMessageComponent = new ErrorMessageComponent(mccps, kps, http);
        emc.ngOnInit();
        expect(emc.getErrorType(MCCConstants.ErrorCodes.NonMemberAccount)).toBe("-hard-interruption");
        expect(emc.getErrorType("SomethingElse")).toBe("-hard-interruption");
        //
        emc.getErrorMessage().subscribe(
            (data) => {
                expect(data.getCode()).toBe("");
                expect(data.getMessage()).toBe("");
            });
    })));
    it('should have error-specific message when valid error code specified', async(inject(
        [MCCPageService, KPService, Http], (mccps, kps, http) => {
        http.get = () => new BehaviorSubject(
            new Response(
                new ResponseOptions(
                    {body: '{"' + MCCConstants.ErrorCodes.NonMemberAccount +'":{"message":"SomeError"}}'})));
        mccps.getAppObject$ = () => new BehaviorSubject(new AppObject(MCCConstants.ErrorCodes.NonMemberAccount));
        let emc : ErrorMessageComponent = new ErrorMessageComponent(mccps, kps, http);
        emc.ngOnInit();
        expect(emc.getErrorType(MCCConstants.ErrorCodes.NonMemberAccount)).toBe("-hard-interruption");
        expect(emc.getErrorType("SomethingElse")).toBe("-hard-interruption");
        //
        emc.getErrorMessage().subscribe(
            (data) => {
                expect(data.getCode()).toBe(MCCConstants.ErrorCodes.NonMemberAccount);
                expect(data.getMessage()).toBe("SomeError");
            });
    })));
    it('should have generic error message and error code when unexpected exception occurs in processing', async(inject(
        [MCCPageService, KPService, Http], (mccps, kps, http) => {
        http.get = () => new BehaviorSubject(new Response(new ResponseOptions({body: 'InvalidJsonToCauseException'})));
        mccps.getAppObject$ = () => new BehaviorSubject(new AppObject(MCCConstants.ErrorCodes.NonMemberAccount));
        let emc : ErrorMessageComponent = new ErrorMessageComponent(mccps, kps, http);
        emc.ngOnInit();
        expect(emc.getErrorType(MCCConstants.ErrorCodes.NonMemberAccount)).toBe("-hard-interruption");
        expect(emc.getErrorType("SomethingElse")).toBe("-hard-interruption");
        //
        emc.getErrorMessage().subscribe(
            (data) => {
                expect(data.getCode()).toBe(
                    MCCConstants.ErrorCodes.NonMemberAccount + "_notfound");
                expect(data.getMessage()).toBe(
                    '');
            });
    })));
});

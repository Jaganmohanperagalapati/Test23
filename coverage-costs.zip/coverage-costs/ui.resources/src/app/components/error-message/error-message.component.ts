import { AfterViewInit, Component, OnInit } from '@angular/core';
import { templates } from '../../services/template.service';
import { Http, Response } from '@angular/http';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
//import 'rxjs/add/operator/catch';
//import 'rxjs/add/operator/map';
//import 'rxjs/add/operator/mergeMap';
import 'rxjs/add/operator/share';
import 'rxjs/add/observable/throw';
import { KPService } from "../../services/kp.service";
import { JSONConfigsService } from "../../services/jsonConfigs.service";
//import { NGWrapperProxyPickerClient } from "ng2-proxy-picker-wrapper";
import { NGWrapperProxyPickerClient } from 'ng2-proxy-picker-wrapper';
import { AppObject, MCCPageService } from "../../services/mccPage.service";
import { MCCConstants } from "../../util/MCCConstants.util";

declare var jsonConfigs;

export class ErrorMessageHolder {
    private message: string;
    private code: string;

    constructor( private inMessage: string, private inCode: string ) {
        //let firstHeadingTagIndex = inMessage.indexOf( '<h' );
        //if (firstHeadingTagIndex != -1) {
        //    let firstRightAngleBracketIndex = inMessage.indexOf( '>', firstHeadingTagIndex );
        //    if ( firstRightAngleBracketIndex != -1 ) {
        //        inMessage = inMessage.substring( 0, firstRightAngleBracketIndex )
        //            + ' class="-heading"'
        //            + inMessage.substring( firstRightAngleBracketIndex );
        //    }
        //}
        this.message = inMessage;
        this.code = inCode;
    }

    public getMessage(): string {
        return this.message;
    }

    public getCode(): string {
        return this.code;
    }
}

@Component( {
    selector: 'mcc-error-message',
    template: templates.GetTemplate('message.html' ),
    providers: []
} )
export class ErrorMessageComponent implements AfterViewInit, OnInit {

    private lastAppObjectEmitted$: BehaviorSubject<AppObject>;
    //the below variable ('appObject$') is used by the HTML template
    private appObject$: Observable<AppObject>;

    private errorMessage: Observable<ErrorMessageHolder>;

    constructor( private mccPageSvc: MCCPageService,
                 private kpSvc: KPService,
                 private http: Http ) {
    }

    public ngOnInit(): void {
        this.lastAppObjectEmitted$ = new BehaviorSubject<AppObject>(null);
        this.mccPageSvc.getAppObject$().subscribe(
            (nextAppObject) => this.lastAppObjectEmitted$.next(nextAppObject));
        this.appObject$ = this.mccPageSvc.getAppObject$();

        this.errorMessage = Observable.combineLatest(
                this.mccPageSvc.getAppObject$(),
                this.http.get( this.kpSvc.getMccMessageJsonUrlLocation() ),
                this.http.get( this.kpSvc.getExceptionMessageJsonUrlLocation() ) )
            .share()
            .map( ( [ appObj, mccMsgs, exceptionMsgs ] ) => {
                    let emh: ErrorMessageHolder;
                    if ( appObj.errorCode != "" && appObj.errorCode != null ) {
                        let errMess:string =
                            this.determineErrorMessage(appObj, mccMsgs, exceptionMsgs);
                        if (errMess != null) {
                            emh = new ErrorMessageHolder(errMess, appObj.errorCode);
                        } else {
                            emh = this.getDefaultErrorMessageHolder();
                        }
                    } else {
                        emh = new ErrorMessageHolder( "", "" );
                    }
                    return emh;
                }
            )
            .catch(
                ( err: any ) => {
                    return Observable.of( this.getDefaultErrorMessageHolder() );
                }
            );
    }

    public ngAfterViewInit(): void {
        MCCConstants.initializeVoiceOverModeOnIPhone(
            'ErrorMessageComponent', 'ngAfterViewInit');
    }

    public getErrorMessage(): Observable<ErrorMessageHolder> {
        return this.errorMessage;
    }

    public getErrorType( errorCode: string ): string {
        let outValue: string;
        outValue = "-hard-interruption";
        return outValue;
    }

    private determineErrorMessage(
            appObj: AppObject, mccMsgs: Response, exceptionMsgs: Response): string {
        let outValue: string;
        try {
            if (appObj.errorCode == MCCConstants.ErrorCodes.NonMemberAccount) {
                outValue = mccMsgs.json()[ appObj.errorCode ].message;
            } else if (appObj.errorCode == MCCConstants.ErrorCodes.TechnicalError) {
                outValue = exceptionMsgs.json().message;
            } else {
                outValue = null;
            }
        } catch (err) {
            outValue = null;
        }
        return outValue;
    }
    private getDefaultErrorMessageHolder(): ErrorMessageHolder {
        let outValue: ErrorMessageHolder;
        let currentAppObject : AppObject = this.lastAppObjectEmitted$.getValue();
        let currentErrorCode : string = "";
        if (currentAppObject != null && currentAppObject.errorCode != null) {
            currentErrorCode = currentAppObject.errorCode;
        }

        //if ( this.kpSvc.getLanguagePrimarySubCode() == 'es' ) {
            outValue = new ErrorMessageHolder(
                '',
                currentErrorCode + '_notfound' );
        //} else {
        //    outValue = new ErrorMessageHolder(
        //        '<h4>Unable to display content</h4>',
        //        currentErrorCode + '_notfound' );
        //}
        return outValue;
    }
}

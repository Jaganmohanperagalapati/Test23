import { async, inject, TestBed } from '@angular/core/testing';
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import { Http } from '@angular/http';
import { MemberContentComponent } from "./member-non-guarantor.component"
import { GuarantorStatus, MedicalBillsService } from "../../services/medical-bills.service";
import { AppObject, MCCPageService } from "../../services/mccPage.service";
import { MemberService } from '../../services/member.service';
import { NGWrapperProxyPickerClient, NGWrapperProxyPickerClientSubject } from 'ng2-proxy-picker-wrapper';

function mockProviderArray():any[] {
    return [
        {
            provide: MCCPageService,
            useValue: {
                getAppObject$: () => Observable.of(new AppObject('ABC'))
            }
        },
        {
            provide: MemberService,
            useValue: {
                loadMemberData$: () => Observable.of("Doesn'tMatter")
            }
        },
        {
            provide: Http,
            useValue: {}
        }
    ];
}
describe('MemberContentComponent test', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
        //    //declarations: [ ],
        //    //imports: [ ],
            providers: mockProviderArray()
        });
        TestBed.compileComponents();
    });
    it('should exist', async(inject(
        [MCCPageService, MemberService, Http],
        (mps, ms, h) => {
            let mcc:MemberContentComponent = new MemberContentComponent(mps, ms, h);
            expect(mcc).toBeDefined();
            mcc.ngOnInit();
            mcc.getMemberMessage().subscribe(
                (data) => {
                    expect(data.getMessage()).toBe('Not A Member!');
                }
            );
            expect(mcc['getDefaultMemberMessageHolder']().memberContent).toBe(
                '<h4>Unable to display content</h4>'
            );
    })));
});

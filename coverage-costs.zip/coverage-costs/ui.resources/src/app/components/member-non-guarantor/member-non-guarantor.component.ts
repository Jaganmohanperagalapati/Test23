/**
 * Created by clarklyu on 5/11/17.
 */
import { AfterViewInit, Component, OnInit } from '@angular/core';
import { templates } from "../../services/template.service";
import { Observable } from 'rxjs/Observable';
import { Http, Response } from '@angular/http';
import { JSONConfigsService } from "../../services/jsonConfigs.service";
import { MemberService } from '../../services/member.service';
import { AppObject, MCCPageService } from "../../services/mccPage.service";
import { MCCConstants } from "../../util/MCCConstants.util";

declare var jsonConfigs;

class MemberMessageHolder {

    memberContent: string;

    constructor( memberContent: string = "") {
        this.memberContent = memberContent;
    }

    public getMessage(): string {
        return this.memberContent;
    }

}

@Component( {
    selector: 'mcc-member-non-guarantor',
    template: templates.GetTemplate('nonguarantormcc.html'),
    providers: []
} )


export class MemberContentComponent implements AfterViewInit, OnInit {
    appObject$: Observable<AppObject>;
    private memberMessage: Observable<MemberMessageHolder>;

    constructor( private mccPageSvc: MCCPageService,
                 private memberSvc: MemberService,
                 private http: Http
    ){}

    ngOnInit() {
        this.appObject$ = this.mccPageSvc.getAppObject$();
        this.memberMessage = Observable.combineLatest(
            this.appObject$,
            this.memberSvc.loadMemberData$())
            .map( ( [ appObj, data ] ) => {
                    if ( appObj.errorCode != "" && appObj.errorCode != null ) {
                        return new MemberMessageHolder("Not A Member!");
                    }
                    else
                        return new MemberMessageHolder(
                            // "Member, from kp"
                        )
                    }
            )
            .catch(
                ( err: any ) => {
                    return Observable.of( this.getDefaultMemberMessageHolder() );
                }
            );
    }

    public ngAfterViewInit(): void {
        MCCConstants.initializeVoiceOverModeOnIPhone(
            'MemberContentComponent', 'ngAfterViewInit');
    }

    public getMemberMessage(): Observable<any> {
        return this.memberMessage;
    }

    private getDefaultMemberMessageHolder(): MemberMessageHolder {
        let outValue: MemberMessageHolder;

        outValue = new MemberMessageHolder(
            '<h4>Unable to display content</h4>')
        return outValue;
    }

}
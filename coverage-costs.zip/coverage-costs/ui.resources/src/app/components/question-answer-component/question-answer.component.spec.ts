import { QuestionAnswerComponent } from "./question-answer.component"

describe('QuestionAnswerComponent test', () => {
    it('should exist', () => {
        let qac:QuestionAnswerComponent = new QuestionAnswerComponent();
        expect(qac).toBeDefined();
    });
});

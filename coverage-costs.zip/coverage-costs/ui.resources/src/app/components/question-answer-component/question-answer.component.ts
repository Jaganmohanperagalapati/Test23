/**
 * Created by clarklyu on 6/1/17.
 */
import { AfterViewInit, Component } from '@angular/core';
import { templates } from '../../services/template.service';
import { MCCConstants } from "../../util/MCCConstants.util";

@Component( {
    selector: 'mcc-faq',
    template: templates.GetTemplate('mcc-faq')
})

export class QuestionAnswerComponent implements AfterViewInit {
    public ngAfterViewInit():void {
        MCCConstants.initializeVoiceOverModeOnIPhone(
            'QuestionAnswerComponent', 'ngAfterViewInit');
    }
}

import { Directive, ElementRef, Input, OnInit, Renderer } from '@angular/core';
import { ControlService } from "../services/control.service";
import { Observable } from "rxjs/Observable";
import { JSONConfigsService } from "../services/jsonConfigs.service";
import { NGWrapperProxyPickerClient } from "ng2-proxy-picker-wrapper";
import { MedicalBillsService } from "../services/medical-bills.service";
import { UserService } from "../services/user.service";

declare var $;

@Directive({ selector: '[kpIconLinkShow]'})
export class KPIconLinkShowDirective implements OnInit {

    /*@Input("data-kp-hide") */

    controlValue: string;

    @Input('kpIconLinkShowAcl') acl: string;

    displayStyle$: Observable<boolean>;

    constructor(private renderer: Renderer,
                private el: ElementRef,
                private controlSvc: ControlService,
                private jsonConfigSvc: JSONConfigsService,
                private medicalBillsSvc: MedicalBillsService,
                private proxyPickerWrapper: NGWrapperProxyPickerClient,
                private userSvc: UserService) {
        this.controlValue = this.el.nativeElement.getAttribute('kpIconLinkShow');
    }

    ngOnInit() {
        this.el.nativeElement.className += " icon-link-show";
        this.displayStyle$ = this.proxyPickerWrapper
            .flatMap(() => Observable.combineLatest(this.medicalBillsSvc.getGuarantorStatus$(), this.userSvc.getSelectedUserSelffunded$()))
            .map(([status, selfFunded]) => {
                let entry = this.controlSvc.findEntryWithValue(this.controlValue, this.jsonConfigSvc.getControlObject('rightrail1'));
                if (entry == null || this.controlSvc.checkEntryMeetsControls(entry, status, selfFunded))
                    return true;
                return false;
            });
        this.displayStyle$.subscribe((show:boolean) => {
            //this.renderer.setElementStyle(this.el.nativeElement, 'display', show ? "inherit" : "none");
            $(this.el.nativeElement).css( 'display', show ? "inherit" : "none");
        });
    }
}
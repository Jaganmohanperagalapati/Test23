import { AfterViewInit, Directive, ElementRef, EventEmitter, Input, OnInit, Output, Renderer } from '@angular/core';
import { ControlService } from "../services/control.service";
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";
import { JSONConfigsService } from "../services/jsonConfigs.service";
import { NGWrapperProxyPickerClient } from 'ng2-proxy-picker-wrapper';
import { MedicalBillsService } from "../services/medical-bills.service";
import { UserService } from "../services/user.service";

/**
 * (For DE21378 - Hide link list title when all its links are hidden)
 * This class holds state information for a specific link in a linked list.
 * acl - The linked list that the link is assigned to
 * controlValue - The URL-condition to check to determine whether the link is visible/hidden
 * updateCount - The current number of times this link's KPShowDirective directive has been executed
 * updateResult - The current show/hide state of the link
 * 
 * Note - The 'updateCount' result is used by 'isLinkedListReady' function
 * to determine whether all links in a linked list have been updated
 * (not just in the process of updating).
 */
export class KPShowDirectiveUpdateInformation {
    constructor(
        readonly acl: string,
        readonly controlValue: string,
        readonly updateCount: number,
        readonly updateResult: boolean) {
    }
    /**
     * Organize/group all monitored links into their respective lists.
     * @param links all monitored links on the web page
     * @return object with each link list handle as a key and its array of monitoried links as its value
     */
    static organizeLinksByList(links:KPShowDirectiveUpdateInformation[]):object {
        var outValue:object = {};
        if (links != null && links.length > 0) {
            for (var i = 0; i < links.length; i++) {
                var nextLink:KPShowDirectiveUpdateInformation = links[i];
                if (outValue[nextLink.acl] == null) {
                    outValue[nextLink.acl] = [];
                }
                (<Array<KPShowDirectiveUpdateInformation>>outValue[nextLink.acl]).push(nextLink);
            }
        }
        return outValue;
    }
    /**
     * This function checks whether the links in a linked list can be evaluated
     * to determine whether the linked list should be shown/hidden.
     * 
     * If the links in a linked list have differing 'updateCount' values,
     * that means that the linked list is in the process of being updated
     * and 'show/hide' decisions of the linked list shouldn't be made yet,
     * otherwise flickering (repeated show/hide) could occur while
     * the linked list is still in the process of being updated.
     * 
     * @param links all the monitored links in a linked list
     * @return true if linked list is ready to be evaluated, false otherwise
     */
    static isLinkedListReady(links:KPShowDirectiveUpdateInformation[]):boolean {
        //
        var outValue:boolean = true;
        if (links != null && links.length > 0) {
            var linkUpdateVersion:number = links[0].updateCount;
            for (var i = 0; i < links.length; i++) {
                outValue = outValue && (links[i].updateCount == linkUpdateVersion);
            }
        }
        return outValue;
    }
    /**
     * Evaluate whether a linked list should be visible,
     * it should be visible only if at least one of its links are visible.
     * 
     * @param links all the monitored links in a linked list
     * @return true if the overall linked list should be shown, false otherwise
     */
    static isLinkedListVisible(links:KPShowDirectiveUpdateInformation[]):boolean {
        //
        var outValue:boolean = false;
        if (links != null && links.length > 0) {
            for (var i = 0; i < links.length; i++) {
                outValue = outValue || links[i].updateResult;
            }
        }
        return outValue;
    }
}

@Directive({ selector: '[kpShow]'})
export class KPShowDirective implements AfterViewInit, OnInit {

    /*@Input("data-kp-hide") */

    controlValue: string;

    @Input('kpShowAcl') acl: string;

    displayStyle$: Observable<boolean>;

    //(For DE21378 - Hide link list title when all its links are hidden)
    //'updateInformation$' emits state (show/hide) information about link
    //'updateCount' records the number of times this directive has been executed
    //'registerLinkListItems$' sends an Observable emitting state information to AppComponent
    //'completionRegistrationLinkListItems$' notifies AppComponent to start monitoring of linked lists
    private updateInformation$: Subject<KPShowDirectiveUpdateInformation>;
    private updateCount: number = 0;
    @Output() registerLinkListItems$: EventEmitter<Observable<KPShowDirectiveUpdateInformation>>;
    @Output() completionRegistrationLinkListItems$: EventEmitter<boolean>;

    constructor(private renderer: Renderer,
                private el: ElementRef,
                private controlSvc: ControlService,
                private jsonConfigSvc: JSONConfigsService,
                private medicalBillsSvc: MedicalBillsService,
                private proxyPickerWrapper: NGWrapperProxyPickerClient,
                private userSvc: UserService) {
        this.controlValue = this.el.nativeElement.getAttribute('kpShow');
        this.updateInformation$ = new Subject<KPShowDirectiveUpdateInformation>();
        this.registerLinkListItems$ = new EventEmitter<Observable<KPShowDirectiveUpdateInformation>>();
        this.completionRegistrationLinkListItems$ = new EventEmitter<boolean>();
    }

    ngOnInit() {
        //(For DE21378 - Hide link list title when all its links are hidden)
        //Notify AppComponent that this link has/sends state information.
        this.registerLinkListItems$.emit(this.updateInformation$.asObservable());

        this.displayStyle$ = this.proxyPickerWrapper
            .flatMap(() => Observable.combineLatest(this.medicalBillsSvc.getGuarantorStatus$(), this.userSvc.getSelectedUserSelffunded$()))
            .map(([status, selfFunded]) => {
                let entry = this.controlSvc.findEntryWithValue(this.controlValue, this.jsonConfigSvc.getControlObject(this.acl));
                if (entry == null || this.controlSvc.checkEntryMeetsControls(entry, status, selfFunded)) {
                    let pqe = this.jsonConfigSvc.getFeatureEntryID(entry);
                    this.el.nativeElement.setAttribute("kpPqe", pqe == null ? "" : pqe);
                    return true;
                }
                return false;
            });
        this.displayStyle$.subscribe((show:boolean) => {
            this.renderer.setElementStyle(this.el.nativeElement, 'display', show ? "inherit" : "none");

            //(For DE21378 - Hide link list title when all its links are hidden)
            //Send updated state information about this link to AppComponent.
            this.updateCount++;
            this.updateInformation$.next(
                new KPShowDirectiveUpdateInformation(
                    this.acl, this.controlValue, this.updateCount, show));
        });
    }
    ngAfterViewInit() {
        /*
        (For DE21378 - Hide link list title when all its links are hidden)
        Notify AppComponent that it can start monitoring linked list.
        Each link makes this call, but AppComponent only cares about the first one.

        Note - Unfortunately, both 'ngOnInit' and 'ngAfterViewInit' are called
        in AppComponent before even 'ngOnInit' is called for this directive.
        But 'ngAfterViewInit' is always called after 'ngOnInit' is called for
        each of these directives. So by the time this function is called,
        all monitoried links have been registered, but AppComponent needs
        to be notified that it can start monitoring linked lists and the
        following call is that notification.
        */
        this.completionRegistrationLinkListItems$.next(true);
    }
}
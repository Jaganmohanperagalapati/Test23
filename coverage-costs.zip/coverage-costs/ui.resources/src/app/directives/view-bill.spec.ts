/**
 * Created by Jay on 7/11/2017.
 */

import {
    Component, ContentChild, DebugElement, ElementRef, HostListener, Input, Renderer,
    ViewChild
} from "@angular/core";
import {ComponentFixture, inject, TestBed} from "@angular/core/testing";
import {ViewBillDirective} from "./view-bill.directive";
import {JSONConfigsService} from "../services/jsonConfigs.service";
import {FeedContainerComponent} from "../components/feed-container/feed-container.component";
import {MCCPageService} from "../services/mccPage.service";
import {MedicalBillsService} from "../services/medical-bills.service";
import {NGWrapperProxyPickerClient} from 'ng2-proxy-picker-wrapper';
import {async} from "@angular/core/testing";
import {By} from "@angular/platform-browser";
import {BrowserDynamicTestingModule} from "@angular/platform-browser-dynamic/testing";


@Component({
    template:'<a id="viewBill" href="#" [kpViewBill]=bills></a>',
})
export class MockViewBillComponent{
    bills: any;

    ngOnInit(): void{
        this.bills = {
            "getDoc": {
                "validationKey": "Yd/6kdd1AVG+gn2GyzCz7CQ0Z7UunJgaccCvKrBRoDih2dl3uexytS+b0qVs/HTWk1MDYT6+4ceasvf8mY0YVLR+FiB9Zig7hb7NRaUxRAzd4KoYG7GLWJdkLcPgCrHIkydaEeHVyEvd/u374gOuiPyhYJdXuXpHAl6wzqh3BmXB+hEdpVnpMwhKbvnJUpwxo9QOGud2iA8+NJbO5wT9Rg1v1hjkhe9XIF5jM5vUDreWDvYt6CTy5LwG6iLRxzTn4H97DjD8nK9FVupB4Flf1Ha0ZOAWcjgaHMiBFPd0V9C91TvrdZtYmEGy1LLLVKnaVzZOu9zAZlwFRHVJgJgso9nExXzds9rKiANakgDU0I3DUKhngUqEfAf2ZaYUDYxAOIwwHyST3fY753Y1ukU2mMAiRgWGg9YqLG1z2dcGXNfi4HbTMq+FzCh8jCaiHEWmHxdw/eYnUpEJleRoaNYgJfioUvbhxC6QetZEFro0q+fsbZOYy4GGc48YBL/jpFF9FiW748djr59QWIQDLm7H9TODdF8lMEilrvLk14XB5AQbFjJ1spmJy1YpWCW1asX6RfDP0ecu9fpfZh8McL2SWvhNBncKcuru19cQjap4sIaQlfJCBtyZFMZKUQNfi6w/7xRAFSUs0LOAvcHnGE0OoB6FDUeh40jFLbQoIt9OSoxU2Gp7p9ojzvt+jrnySHRfWNNSNJql9UDmqFFeXRQlIWTRtAcW+SKPWCtCbZRpMWCXm6ZWk5rHlBUjGXEXCR1QxLXq17Z0mtKJQ1z4pf7dRrfqMUx32DgePK6abB6yISZydZwkysxUJfir6dSczKcoMZuKKRixVhw09Ri/doubsAHIsVryDvrHnfA6mhqKrSQvTdbcUqbJaYEcK5u6DTMS8CBd2uqg+bIpdtLrAM2T0eWaFoH5MOfDuTckyif7RinAM1UadO3vh2bXHTDQxdiinNm61XDOV7UbggUNYKVpPClqTJGpx9C3z1+6xeXpvzCdyDV4jQaVA+0/WNu27EDkOciFZImReABIsuzYsdQfV2ssOJQLz4G4+6Mz9A2k+Va0vo6cvaaa6hDqh7x9u1BCTT2OxUrvtS1kD6sUE+nBw669TcRNY/rr7rDfmNDf7rDI2xpG3uQFtdRyACTe9HostX062p7s6VLxIBr1jqPrxCR/9LJRhDo/tIt2MMm1kWmrAK3GPo7NhuYI5jJhkD2oiZNUTIfIYno9BA+jUOhOINOXmcFqxeAAh/mWEgtjYVTPjBWncRIiaBH/Og/LybJrfMoMzeWI6bvt0/P1bLV1FHvMJLgGSNbJRCSMcBNe6NwaloI79ThxJpGvBlIl+1k7",
                "url": "https://service-bus-uat.kp.org:2008/carsgetdoc/getDoc"
            }
        };
    }

}


describe('test view bill', () => {

    describe('test set 1 ',() => {
        beforeEach(() => {
            TestBed.configureTestingModule({
                providers: [
                    //ElementRef,
                    Renderer,
                    JSONConfigsService
                ],
            }).compileComponents();
        });

        it('should assign bill value', async(inject(
            [Renderer, JSONConfigsService],
            (rend, json) => {
                let eref: ElementRef;
                let vbd: ViewBillDirective = new ViewBillDirective(eref, rend, json);
                expect(vbd).toBeDefined();

                let bills = {
                    "getDoc": {
                        "validationKey": "Yd/6kdd1AVG+gn2GyzCz7CQ0Z7UunJgaccCvKrBRoDih2dl3uexytS+b0qVs/HTWk1MDYT6+4ceasvf8mY0YVLR+FiB9Zig7hb7NRaUxRAzd4KoYG7GLWJdkLcPgCrHIkydaEeHVyEvd/u374gOuiPyhYJdXuXpHAl6wzqh3BmXB+hEdpVnpMwhKbvnJUpwxo9QOGud2iA8+NJbO5wT9Rg1v1hjkhe9XIF5jM5vUDreWDvYt6CTy5LwG6iLRxzTn4H97DjD8nK9FVupB4Flf1Ha0ZOAWcjgaHMiBFPd0V9C91TvrdZtYmEGy1LLLVKnaVzZOu9zAZlwFRHVJgJgso9nExXzds9rKiANakgDU0I3DUKhngUqEfAf2ZaYUDYxAOIwwHyST3fY753Y1ukU2mMAiRgWGg9YqLG1z2dcGXNfi4HbTMq+FzCh8jCaiHEWmHxdw/eYnUpEJleRoaNYgJfioUvbhxC6QetZEFro0q+fsbZOYy4GGc48YBL/jpFF9FiW748djr59QWIQDLm7H9TODdF8lMEilrvLk14XB5AQbFjJ1spmJy1YpWCW1asX6RfDP0ecu9fpfZh8McL2SWvhNBncKcuru19cQjap4sIaQlfJCBtyZFMZKUQNfi6w/7xRAFSUs0LOAvcHnGE0OoB6FDUeh40jFLbQoIt9OSoxU2Gp7p9ojzvt+jrnySHRfWNNSNJql9UDmqFFeXRQlIWTRtAcW+SKPWCtCbZRpMWCXm6ZWk5rHlBUjGXEXCR1QxLXq17Z0mtKJQ1z4pf7dRrfqMUx32DgePK6abB6yISZydZwkysxUJfir6dSczKcoMZuKKRixVhw09Ri/doubsAHIsVryDvrHnfA6mhqKrSQvTdbcUqbJaYEcK5u6DTMS8CBd2uqg+bIpdtLrAM2T0eWaFoH5MOfDuTckyif7RinAM1UadO3vh2bXHTDQxdiinNm61XDOV7UbggUNYKVpPClqTJGpx9C3z1+6xeXpvzCdyDV4jQaVA+0/WNu27EDkOciFZImReABIsuzYsdQfV2ssOJQLz4G4+6Mz9A2k+Va0vo6cvaaa6hDqh7x9u1BCTT2OxUrvtS1kD6sUE+nBw669TcRNY/rr7rDfmNDf7rDI2xpG3uQFtdRyACTe9HostX062p7s6VLxIBr1jqPrxCR/9LJRhDo/tIt2MMm1kWmrAK3GPo7NhuYI5jJhkD2oiZNUTIfIYno9BA+jUOhOINOXmcFqxeAAh/mWEgtjYVTPjBWncRIiaBH/Og/LybJrfMoMzeWI6bvt0/P1bLV1FHvMJLgGSNbJRCSMcBNe6NwaloI79ThxJpGvBlIl+1k7",
                        "url": "https://service-bus-uat.kp.org:2008/carsgetdoc/getDoc"
                    }
                };

                vbd.billItem = bills;
                expect(vbd.billItem).not.toBeNull();

            })));
    });

    describe('test set 2', () => {

        let comp: MockViewBillComponent;
        let fixture: ComponentFixture<MockViewBillComponent>;

        beforeEach(() => {
            TestBed.configureTestingModule({
                imports: [BrowserDynamicTestingModule],
                declarations: [MockViewBillComponent,
                ViewBillDirective
                ],
                providers: [
                    JSONConfigsService,
                    Renderer,
                ],
            }).compileComponents();
        });

        beforeEach(() => {
            fixture = TestBed.createComponent(MockViewBillComponent);
            comp = fixture.componentInstance;
            fixture.autoDetectChanges();

        });

        it('click event with nonnull', function(){


                let de = fixture.debugElement.query(By.css('#viewBill'));
                de.triggerEventHandler('click', new Event('mousedown'));

        });

        it('click event with null', function(){

            comp.bills = null;
            let de = fixture.debugElement.query(By.css('#viewBill'));
            de.triggerEventHandler('click', new Event('mousedown'));
        });

    });

});
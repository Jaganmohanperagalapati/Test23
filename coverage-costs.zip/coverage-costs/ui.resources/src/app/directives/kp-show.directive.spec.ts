import {async, inject, TestBed, ComponentFixture} from "@angular/core/testing";
import {GuarantorStatus, MedicalBillsService} from "../services/medical-bills.service";
import {Observable} from "rxjs/Observable";
import {UserService} from "../services/user.service";
import {ControlService} from "../services/control.service";
import {Component, ElementRef, Renderer} from "@angular/core";
import {JSONConfigsService} from "../services/jsonConfigs.service";
import {NGWrapperProxyPickerClient, NGWrapperProxyPickerClientSubject} from 'ng2-proxy-picker-wrapper';
import {KPShowDirective, KPShowDirectiveUpdateInformation} from "./kp-show.directive";
import {KPService} from "../services/kp.service";
import {BehaviorSubject} from "rxjs/BehaviorSubject";
import {BrowserModule, By} from "@angular/platform-browser";
import {AppObject, MCCPageService} from "../services/mccPage.service";
import {BrowserDynamicTestingModule} from "@angular/platform-browser-dynamic/testing";
import {LastPaymentService} from "../services/last-payment.service";
import {MCCConfigService} from "../services/mcc-config.service";
import {CurrencyPipe, DatePipe} from "@angular/common";


/**
 * Created by Jay on 7/11/2017.
 */
class ProxyWrapperMockNotSelf {
    getValue () {
        return {
            getRelationshipId: () => {
                return "12345";
            }
        }
    }
}

@Component({
    template: `<div kpShow="/health/mycare/consumer/my-health-manager/my-plan-and-coverage/out-of-pocket" [kpShowAcl]="'linklist1'"> <li> <a id="viewKP" href="#">Out Of Pocket Summary</a> </li> </div>`,
})
export class MockKPShowComponent{

    ngOnInit():void{
    }
}

describe ('test kp-show', () => {

    describe('test kp-show for true', () => {
        let comp: MockKPShowComponent;
        let fixture: ComponentFixture<MockKPShowComponent>;
        beforeEach(() => {
            TestBed.configureTestingModule({
                imports: [
                    BrowserDynamicTestingModule
                ],
                declarations: [
                    MockKPShowComponent,
                    KPShowDirective
                ],
                providers: [
                    {
                        provide: MedicalBillsService,
                        useValue: {
                            getGuarantorStatus$: () => Observable.of(GuarantorStatus.Guarantor)
                        }
                    },
                    {
                        provide: UserService,
                        useValue: {
                            getSelectedUserSelffunded$: () => {Observable.of(true)}
                        }

                    },
                    {
                        provide: NGWrapperProxyPickerClient,
                        useClass: ProxyWrapperMockNotSelf
                    },
                    {
                        provide: ControlService,
                        useValue: {
                            ctrlHasEntitlementKey: () => true
                        }
                    },
                    {
                        provide: ElementRef,
                        useValue: {}
                    },
                    Renderer,
                    JSONConfigsService
                ]
            }).compileComponents();
        });

        beforeEach(() => {
            fixture = TestBed.createComponent(MockKPShowComponent);
            comp = fixture.componentInstance;
        });

        it('should exist', async(inject([Renderer, ElementRef, ControlService, JSONConfigsService, MedicalBillsService, NGWrapperProxyPickerClient, UserService],
            (rend, ref, cs, jcs, mbs, proxy, us) => {
            ref = fixture.debugElement.query(By.css('#viewKP'));
            let kpShowDir = new KPShowDirective(rend, ref, cs, jcs, mbs, proxy, us);
            kpShowDir.ngAfterViewInit();
            expect(kpShowDir).toBeDefined();
        })));

        it('test error catches', () => {
            let de = fixture.debugElement.query(By.css('#viewKP'));
            de.triggerEventHandler('click', new Event('mousedown'));
        });
    });


    describe('test kp-show for false', () => {

    });
    describe('test KPShowDirectiveUpdateInformation', () => {
        it('should work', () => {
            let a:KPShowDirectiveUpdateInformation =
                new KPShowDirectiveUpdateInformation("A", "AA", 1, true);
            let b:KPShowDirectiveUpdateInformation =
                new KPShowDirectiveUpdateInformation("A", "BB", 1, false);
            expect(a.acl).toBe("A");
            expect(a.controlValue).toBe("AA");
            expect(a.updateCount).toBe(1);
            expect(a.updateResult).toBe(true);
            //
            let kpsduiArray:KPShowDirectiveUpdateInformation[] = [a, b];
            let kpsduiArrayResponse:any =
                KPShowDirectiveUpdateInformation.organizeLinksByList(kpsduiArray);
            expect(kpsduiArrayResponse["A"][0]).toEqual(a);
            expect(kpsduiArrayResponse["A"][1]).toEqual(b);
            //
            expect(KPShowDirectiveUpdateInformation.isLinkedListReady(kpsduiArray)).toBe(true);
            //
            expect(KPShowDirectiveUpdateInformation.isLinkedListVisible(kpsduiArray)).toBe(true);
        });
    });
});

/**
 * Created by Jay on 5/22/2017.
 */
import {Directive, ElementRef, HostListener, Input, Renderer} from '@angular/core';
import {JSONConfigsService} from '../services/jsonConfigs.service'

@Directive({
    selector: '[kpViewBill]'
})
export class ViewBillDirective {

    constructor(private el: ElementRef, private renderer: Renderer, private jsonConfigSvc: JSONConfigsService) {

    }

    @Input('kpViewBill') billItem: any;

    @HostListener('click', ['$event']) onClick($event) {
        console.info('clicked: ' + $event);
        // if(this.billItem.getDoc !== null) {
            let form = document.createElement("form");
            form.method = "POST";
            form.target = "_blank";
            //form.action = "/health/mycare/consumer/my-health-manager/my-plan-and-coverage/my-health-plan-documents/getDoc";
            form.action = this.jsonConfigSvc.viewBillApiUri();
            ViewBillDirective.createHiddenInputNode(form, "ValidationKey", this.billItem.getDoc.validationKey);
            document.body.appendChild(form);
            form.submit();
        // }
    }

    static createHiddenInputNode(node, itemName, itemValue): void {
        let inNode = document.createElement("input");
        inNode.setAttribute("type", "hidden");
        inNode.setAttribute("name", itemName);
        inNode.setAttribute("id", itemName);
        inNode.setAttribute("value", itemValue);

        node.appendChild(inNode);

    }
}
export var RandomPositiveMoneyString = "$2.11";
export var RandomDateString = "2017-05-01";

export var LastPaymentPositiveValue = {
    "latestPayment": [
        {
            "amount": RandomPositiveMoneyString,
            "date": RandomDateString
        }
    ]
};

export var LastPaymentNone = [];

export var MedicalBillsGuarantor = {
    "totalBillAmount": RandomPositiveMoneyString,
    "isPatientGuarantor": true,
    "guarantor": [
        {
            "guarantoraccount": "613900421765",
            "statements": [
                {
                    "docType": "KPHCSTMT",
                    "docDate": "2017-05-25",
                    "regionMrnPrefix": "16",
                    "docSourceSystem": "KPHC-PB",
                    "statementBalance": "$140.00",
                    "paymentDueDate": "2017-05-25"
                },
                {
                    "docType": "KPHCSTMT",
                    "docDate": "2017-05-25",
                    "regionMrnPrefix": "16",
                    "docSourceSystem": "KPHC-HB",
                    "statementBalance": "$140.00",
                    "paymentDueDate": "2017-05-25"
                }
            ]
        },
        {
            "guarantoraccount": "613900421775",
            "statements": [
                {
                    "docType": "KPHCSTMT",
                    "docDate": "2017-05-25",
                    "regionMrnPrefix": "16",
                    "docSourceSystem": "KPHC-PB",
                    "statementBalance": "$140.00",
                    "paymentDueDate": "2017-05-25"
                },
                {
                    "docType": "KPHCSTMT",
                    "docDate": "2017-05-25",
                    "regionMrnPrefix": "16",
                    "docSourceSystem": "KPHC-HB",
                    "statementBalance": "$140.00",
                    "paymentDueDate": "2017-05-25"
                }
            ]
        }
    ]
}

export var MedicalBillsNonGuarantor = {
    "isPatientGuarantor": false
}

export var MedicalBillsPositiveBalance = {
    "totalBillAmount": RandomPositiveMoneyString
}

export var UserSelfFunded = [{
    "guid": "100042528",
    "regionId": "MID",
    "firstName": "SPOUSE",
    "lastName": "MASBBIABBJFBEELN",
    "dob": "1978-07-15",
    "planInfos": [
        {
            "selfFunded": true,
            "dhmoStatus": false,
            "dpaStatus": false
        }
    ]
}
]

export var UserNotSelfFunded = [{
    "guid": "100042528",
    "regionId": "MID",
    "firstName": "SPOUSE",
    "lastName": "MASBBIABBJFBEELN",
    "dob": "1978-07-15",
    "planInfos": [
        {
            "selfFunded": false,
            "dhmoStatus": false,
            "dpaStatus": false
        }
    ]
}
]


export var HasPaymentPlan = {
    "paymentPlan": {
        "isLate": false,
        "monthlyAmountDue": 250,
        "nextDueDate": "2017-03-11",
        "paymentsLeft": 0,
        "originalTotalAmount": 9848.88,
        "remainingTotalAmount": 0.0,
        "startDate": "2017-01-16"
    }
}

export var HasNoPaymentPlan = {
    "paymentPlan": []
}
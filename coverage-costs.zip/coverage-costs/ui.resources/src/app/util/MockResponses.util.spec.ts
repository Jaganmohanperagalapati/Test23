
import { async, inject } from '@angular/core/testing';
import {
    ErrorMessage, InvalidMccConfigActionAreaButtons, InvalidMccConfigActionAreaTexts, MCCConditionalButtons,
    MCCConditionalTexts,
    ValidMccConfigActionArea, ValidPaymentPlanConfig
} from "./MockResponses.util";


describe('MockResponses', () => {

    describe('test constants', () =>{

        it('ErrorMessage', async(inject(
            [],
            () => {
                expect(ErrorMessage).toEqual({ err: "Error Message" });
            })));

        it('MCCConditionalTexts', async(inject(
            [],
            () => {
                expect(MCCConditionalTexts).toEqual([{
                        "estimate-a-cost": "Need to know the cost of a service?  We can help.<\/p>\n"
                    },
                    {
                        "medical-bill-balance-with-payment": "The amount owed on your last medical billing statement is {{lastStatementBalance}}<\/span>.\nYour last payment was {{lastPaymentAmount}} <\/span>on {{lastPaymentDate}}<\/span>\n<\/p>\n"
                    },
                    {
                        "medical-bill-balance-no-payment": "The amount owed on your last medical billing statement is {{lastStatementBalance}}<\/span>.<\/p>\n"
                    },
                    {
                        "no-balance-no-payment": "The amount owed on your last medical billing statement is {{lastStatementBalance}}<\/span>.<\/p>\n"
                    },
                    {
                        "no-balance-with-payment": "The amount owed on your last medical billing statement is {{lastStatementBalance}}<\/span>.\nYour last payment was {{lastPaymentAmount}}<\/span> on {{lastPaymentDate}}<\/span>\n<\/p>\n"
                    }]);
            })));

        it('MCCConditionalButtons', async(inject(
            [],
            () => {
                expect(MCCConditionalButtons).toEqual([
                    {
                        "text": "Estimate a cost",
                        "path": "/content/kporg/en/national/shop-plans/individual-and-family-plans",
                        "target": "_self"
                    }
                ]);
            })));

        it('ValidMccConfigActionArea', async(inject(
            [],
            () => {
                expect(ValidMccConfigActionArea).toEqual({
                    "pagename": "coverage-costs",
                    "comps": [
                        {
                            "compname": "actionareamcc",
                            "subcomps": [
                                {
                                    "compname": "conditionaldesc",
                                    "conditionaltexts": MCCConditionalTexts
                                },
                                {
                                    "compname": "calltoactionbtn",
                                    "conditionalBtns": MCCConditionalButtons
                                }
                            ]
                        }
                    ]
                });
            })));

        it('InvalidMccConfigActionAreaTexts', async(inject(
            [],
            () => {
                expect(InvalidMccConfigActionAreaTexts).toEqual({
                    "pagename": "coverage-costs",
                    "comps": [
                        {
                            "compname": "actionareamcc",
                            "subcomps": [
                                {
                                    "compname": "conditionaldesc",
                                    "conditionaltexts": "INVALID"
                                },
                                {
                                    "compname": "calltoactionbtn",
                                    "conditionalBtns": MCCConditionalButtons
                                }
                            ]
                        }
                    ]
                });
            })));

        it('InvalidMccConfigActionAreaButtons', async(inject(
            [],
            () => {
                expect(InvalidMccConfigActionAreaButtons).toEqual({
                    "pagename": "coverage-costs",
                    "comps": [
                        {
                            "compname": "actionareamcc",
                            "subcomps": [
                                {
                                    "compname": "conditionaldesc",
                                    "conditionaltexts": MCCConditionalTexts
                                },
                                {
                                    "compname": "calltoactionbtn",
                                    "conditionalBtns": "INVALID"
                                }
                            ]
                        }
                    ]
                });
            })));

        it('ValidPaymentPlanConfig', async(inject(
            [],
            () => {
                expect(ValidPaymentPlanConfig).toEqual({
                    "compname":"payment_plan_detail",
                    "accountlabel":"Account",
                    "hospbillpmtplanlabel":"Hospital billing payment plan test",
                    "profbillpmtplanlabel":"Professional billing payment plan",
                    "hospprofbillpmtplanlabel":"Hospital/Professional billing payment plan",
                    "recurringbillpmtplanlabel":"Payment Amount",
                    "nextpmtplanlabel":"Next payment due",
                    "begplanballabel":"Beginning balance",
                    "pmtplanstartdatelabe":"Payment plan start date",
                    "remainballabel":"Remaining balance",
                    "pmtplandetailsdesc":"Your statement for medical services shows your account balance as of the date of this statement. If you made a payment on your current payment plan after your last statement, the payment isn\u2019t shown in your statement. If you had new services since your last statement, the new charges will be reflected on your next statement. New charges won\u2019t be included in your payment plan unless you ask us to add them to your plan. If you would like to update your payment plan, please call the phone number listed on your statement. test<\/p>\r\n"
                });
            })));
    });
});
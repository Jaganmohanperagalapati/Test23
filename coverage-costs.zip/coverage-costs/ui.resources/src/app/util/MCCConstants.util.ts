/**
 * Used for references to constant values that may be used across the application
 */

declare function tempDE21074(callerName : string, functionName: string);
declare function tempDE22251();
declare var $;

export var genericmodalId;
export var modalInvokingElement;
export let modalWindowInitializerTracker = {};

export class MCCConstants {

    private static initiateActionAreaTimer:boolean = true;
    private static actionAreaButtonEvent:boolean = true;

    public static ErrorCodes = {
        NonMemberAccount: "1004",
        TechnicalError: "1003"
    };

    public static OSGIControlIDs = {
        ConditionButton: "conditionalButton",
        ConditionalMessages: "conditionalDescription",
        IconLink1: "rightrail1",
        MedicalBill:"medical-bill"
    }

    public static initializeVoiceOverModeOnIPhone(
            callerName: string, functionName: string) {
        var overrideFunctionCalled = false;
        try {
            tempDE21074(callerName, functionName);
            overrideFunctionCalled = true;
        } catch (e) {
        }
        if (!overrideFunctionCalled) {
            //DE21074 - Current candidate resolution
            if (callerName === 'ActionAreaComponent' || callerName === 'ErrorMessageComponent'
                    || callerName === 'ProxyPickerComponent' || callerName === 'FeedContainerComponent') {
                //https://stackoverflow.com/questions/9038625/detect-if-device-is-ios
                var deviceIsIPhone = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(<any>window).MSStream;
                if (deviceIsIPhone) {
                    //
                    //console.log('DE21074 - Candidate Remediation - apply remediation because userAgent is ' + navigator.userAgent);
                    MCCConstants.experiment1WithElement(document.body);
                    //console.log('DE21074 - Candidate Remediation - applied, initiated by ' + callerName + ' in function ' + functionName);
                    //
                    //Note - This is a supplemental remediation
                    //  The above 'experiment1WithElement()' function is called
                    //  whenever major components of the page are initially rendered,
                    //  but the action area button appears afterwards and is
                    //  sometimes still skipped in VoiceOver mode
                    //  By waiting for that button to first appear before calling
                    //  the 'experiment1WithElement()' function, that button becomes
                    //  selectable in VoiceOver mode
                    if (MCCConstants.initiateActionAreaTimer) {
                        MCCConstants.initiateActionAreaTimer = false;
                        setInterval(
                            function() {
                                if (document.getElementById('actionAreaButton') != null
                                        && MCCConstants.actionAreaButtonEvent) {
                                    //console.log('actionAreaButton rendered, initiate hide/show');
                                    MCCConstants.actionAreaButtonEvent = false;
                                    MCCConstants.experiment1WithElement(document.body);
                                }
                            },
                            250);
                    }
                }
            }
        }
    }
    //https://silvantroxler.ch/2016/setting-voiceover-focus-with-javascript/
    //  also include call to 'experiment1WithElement()'
    public static reallyFocusOnElementOnIPhone( ele : any ) {
        //
        var focusInterval = 250; // ms, time between function calls
        var focusTotalRepetitions = 1; // number of repetitions

        ele.setAttribute('tabindex', '0');
        ele.blur();

        var focusRepetitions = 0;
        var interval = window.setInterval(function() {
            MCCConstants.experiment1WithElement(document.body);
            ele.focus();
            focusRepetitions++;
            if (focusRepetitions >= focusTotalRepetitions) {
                window.clearInterval(interval);
            }
        }, focusInterval);
    }
    public static isEventClickInsteadOfEnter(inEvent : any) {
        //
        //https://stackoverflow.com/questions/7465006/differentiate-between-mouse-and-keyboard-triggering-onclick
        //https://stackoverflow.com/questions/9716468/is-there-any-function-like-isnumeric-in-javascript-to-validate-numbers
        var outValue = false;
        try {
            var xNonZero = !isNaN(parseFloat(inEvent.screenX))
                && isFinite(inEvent.screenX)
                && (parseFloat(inEvent.screenX) != 0);
            var yNonZero = !isNaN(parseFloat(inEvent.screenY))
                && isFinite(inEvent.screenY)
                && (parseFloat(inEvent.screenY) != 0);
            //iPhone/Safari doesn't process this logic correctly
            //  for now, always assume enter for iPhone/Safari
            var deviceIsIPhone = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(<any>window).MSStream;
            var browserIsSafari =
                (navigator.userAgent.indexOf('Safari') != -1
                    && navigator.userAgent.indexOf('Chrome') == -1);
            var alwaysUseEnter = (deviceIsIPhone || browserIsSafari);
            //console.log('navigator.userAgent = ' + navigator.userAgent);
            //
            outValue = xNonZero || yNonZero;
            outValue = (outValue && !alwaysUseEnter);
        } catch (e) {}
        //
        return outValue;
    }
    public static reapplyFocusAfterModalWindowClosed( e : any ) {
        //
        //https://stackoverflow.com/questions/2066162/how-can-i-get-the-button-that-caused-the-submit-from-the-form-submit-event
        //
        if (!MCCConstants.isEventClickInsteadOfEnter(e)) {
            var deviceIsIPhone = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(<any>window).MSStream;
            if (!deviceIsIPhone) {
                modalInvokingElement.focus();
            } else {
                MCCConstants.reallyFocusOnElementOnIPhone(modalInvokingElement);
            }
        } else {
            modalInvokingElement.focus();
            modalInvokingElement.blur();
        }
    }
    //Note - For DE21074, this is the only remedy that seems to work
    //  The remedy is to instantaneously hide then show the entire page
    public static experiment1WithElement( ele : any ) {
        //https://stackoverflow.com/questions/3485365/how-can-i-force-webkit-to-redraw-repaint-to-propagate-style-changes
        var displayType = ele.style.display;
        ele.style.display = 'none';
        try {
            ele.offsetHeight = ele.offsetHeight;//NOSONAR
        } catch (e) {
        }
        ele.style.display = displayType;//'block';

    }

    // Used to fix a similiar defect as the function experiment1WithElement Above
    // Shocks the page, then scrolls back down to the element that has focus.
    public static shockExpandedViewAndScroll(ele : any, xpos : any, ypos : any){

        var displayType = ele.style.display;
        ele.style.display = 'none';
        try {
            ele.offsetHeight = ele.offsetHeight;//NOSONAR
        } catch (e) {
        }
        ele.style.display = displayType;//'block';
        try {
            var alert = document.getElementById("alerts-notification-placeholder-id").getElementsByClassName("alert");
            for(var i=0; i < alert.length; i++){
                alert[i].removeAttribute('role');
            }

            window.scrollTo(xpos, ypos);
        } catch (e) {

        }
    }
}

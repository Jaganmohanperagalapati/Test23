
import { async, inject } from '@angular/core/testing';
import {
    HasNoPaymentPlan,
    HasPaymentPlan,
    LastPaymentNone, LastPaymentPositiveValue, MedicalBillsGuarantor, MedicalBillsNonGuarantor,
    MedicalBillsPositiveBalance, RandomDateString,
    RandomPositiveMoneyString, UserNotSelfFunded, UserSelfFunded
} from "./NodeMockResponses.util";

describe('NodeMockResponses', () => {

    describe('test constants', () =>{

        it('LastPaymentPositiveValue', async(inject(
            [],
            () => {
                expect(LastPaymentPositiveValue).toEqual({
                    "latestPayment": [
                        {
                            "amount": RandomPositiveMoneyString,
                            "date": RandomDateString
                        }
                    ]
                });
            })));

        it('LastPaymentNone', async(inject(
            [],
            () => {
                expect(LastPaymentNone).toEqual([]);
            })));

        it('MedicalBillsGuarantor', async(inject(
            [],
            () => {
                expect(MedicalBillsGuarantor).toEqual({
                    "totalBillAmount": RandomPositiveMoneyString,
                    "isPatientGuarantor": true,
                    "guarantor": [
                        {
                            "guarantoraccount": "613900421765",
                            "statements": [
                                {
                                    "docType": "KPHCSTMT",
                                    "docDate": "2017-05-25",
                                    "regionMrnPrefix": "16",
                                    "docSourceSystem": "KPHC-PB",
                                    "statementBalance": "$140.00",
                                    "paymentDueDate": "2017-05-25"
                                },
                                {
                                    "docType": "KPHCSTMT",
                                    "docDate": "2017-05-25",
                                    "regionMrnPrefix": "16",
                                    "docSourceSystem": "KPHC-HB",
                                    "statementBalance": "$140.00",
                                    "paymentDueDate": "2017-05-25"
                                }
                            ]
                        },
                        {
                            "guarantoraccount": "613900421775",
                            "statements": [
                                {
                                    "docType": "KPHCSTMT",
                                    "docDate": "2017-05-25",
                                    "regionMrnPrefix": "16",
                                    "docSourceSystem": "KPHC-PB",
                                    "statementBalance": "$140.00",
                                    "paymentDueDate": "2017-05-25"
                                },
                                {
                                    "docType": "KPHCSTMT",
                                    "docDate": "2017-05-25",
                                    "regionMrnPrefix": "16",
                                    "docSourceSystem": "KPHC-HB",
                                    "statementBalance": "$140.00",
                                    "paymentDueDate": "2017-05-25"
                                }
                            ]
                        }
                    ]
                });
            })));

        it('MedicalBillsNonGuarantor', async(inject(
            [],
            () => {
                expect(MedicalBillsNonGuarantor).toEqual({
                    "isPatientGuarantor": false
                });
            })));

        it('MedicalBillsPositiveBalance', async(inject(
            [],
            () => {
                expect(MedicalBillsPositiveBalance).toEqual({
                    "totalBillAmount": RandomPositiveMoneyString
                });
            })));

        it('UserSelfFunded', async(inject(
            [],
            () => {
                expect(UserSelfFunded).toEqual([{
                    "guid": "100042528",
                    "regionId": "MID",
                    "firstName": "SPOUSE",
                    "lastName": "MASBBIABBJFBEELN",
                    "dob": "1978-07-15",
                    "planInfos": [
                        {
                            "selfFunded": true,
                            "dhmoStatus": false,
                            "dpaStatus": false
                        }
                    ]
                }
                ]);
            })));

        it('UserNotSelfFunded', async(inject(
            [],
            () => {
                expect(UserNotSelfFunded).toEqual([{
                    "guid": "100042528",
                    "regionId": "MID",
                    "firstName": "SPOUSE",
                    "lastName": "MASBBIABBJFBEELN",
                    "dob": "1978-07-15",
                    "planInfos": [
                        {
                            "selfFunded": false,
                            "dhmoStatus": false,
                            "dpaStatus": false
                        }
                    ]
                }
                ]);
            })));

        it('HasPaymentPlan', async(inject(
            [],
            () => {
                expect(HasPaymentPlan).toEqual({
                    "paymentPlan": {
                        "isLate": false,
                        "monthlyAmountDue": 250,
                        "nextDueDate": "2017-03-11",
                        "paymentsLeft": 0,
                        "originalTotalAmount": 9848.88,
                        "remainingTotalAmount": 0.0,
                        "startDate": "2017-01-16"
                    }
                });
            })));

        it('HasNoPaymentPlan', async(inject(
            [],
            () => {
                expect(HasNoPaymentPlan).toEqual(
                {
                    "paymentPlan": []
                });
            })));
    });
});
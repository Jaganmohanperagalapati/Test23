import {MCCConstants} from "./MCCConstants.util";
import { async, inject, TestBed } from '@angular/core/testing';


declare var $: any;
describe('MCCConstants', () => {

    describe('test constants', () =>{

        it('ErrorCodes', async(inject(
            [],
            () => {
                expect(MCCConstants.ErrorCodes.NonMemberAccount).toEqual("1004");
                expect(MCCConstants.ErrorCodes.TechnicalError).toEqual("1003");
            })));

        it('OSGIControlIDs', async(inject(
            [],
            () => {
                expect(MCCConstants.OSGIControlIDs.ConditionButton).toEqual("conditionalButton");
                expect(MCCConstants.OSGIControlIDs.ConditionalMessages).toEqual("conditionalDescription");
                expect(MCCConstants.OSGIControlIDs.IconLink1).toEqual("rightrail1");
                expect(MCCConstants.OSGIControlIDs.MedicalBill).toEqual("medical-bill");
                MCCConstants.isEventClickInsteadOfEnter('');
                MCCConstants.reallyFocusOnElementOnIPhone(document.createElement('p'));
                MCCConstants.experiment1WithElement(document.createElement('p'));
                let newEle = document.createElement('p');
                newEle.setAttribute('class', 'alert');
                MCCConstants.shockExpandedViewAndScroll(newEle, 0, 0);
            })));



        it(' call initializeVoiceOverModeOnIPhone', async(inject(
            [],
            () => {
                MCCConstants.initializeVoiceOverModeOnIPhone(null, null);
            })));
    });
});
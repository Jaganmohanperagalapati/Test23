import {Feed} from "./feed";
/**
 * Created by Jay on 7/11/2017.
 */


describe('feed tests', () => {

    it('should construct', function(){
        let feedObj: Feed = new Feed("guarantor", "doSourceSystem", "statementBalance","docDate", "paymentDueDate");
        expect(feedObj).toBeDefined();
        expect(feedObj.guarantoraccount).toBe("guarantor");
        expect(feedObj.docSourceSystem).toBe("doSourceSystem");
        expect(feedObj.statementBalance).toBe("statementBalance");
        expect(feedObj.docDate).toBe("docDate");
        expect(feedObj.paymentDueDate).toBe("paymentDueDate");

    });
});
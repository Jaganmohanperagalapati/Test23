/**
 * Created by clarklyu on 4/3/17.
 */

export class Feed {

    guarantoraccount:string;
    docSourceSystem:string;
    statementBalance: string;
    docDate: string;
    paymentDueDate: string;

    constructor(guarantoraccount: string,
                docSourceSystem: string,
                statementBalance: string,
                docDate: string,
                paymentDueDate: string,) {
        this.guarantoraccount = guarantoraccount;
        this.docSourceSystem = docSourceSystem;
        this.statementBalance = statementBalance;
        this.docDate = docDate;
        this.paymentDueDate = paymentDueDate;
    }
}


import { Component, OnInit, ViewChild } from '@angular/core';
import { templates } from './services/template.service';
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";
import { Subscription } from "rxjs/Subscription";
import { AppObject, MCCPageService } from "./services/mccPage.service";
import { KPShowDirectiveUpdateInformation } from "./directives/kp-show.directive";
import { PaymentPlanInformationComponent, PaymentPlanInformationContext }
  from "./components/payment-plan-information/payment-plan-information.component";

declare var $kp;


@Component( {
    selector: 'mcc-root-comp',
    template: templates.GetTemplate('mccrootcomp.html')
} )

export class AppComponent implements OnInit {

    appObject$:Observable<AppObject>;
    //(For DE21378 - Hide link list title when all its links are hidden)
    //Note - The following variable is an array of Observables, not an Observable.
    linkListLinks:Observable<KPShowDirectiveUpdateInformation>[];
    //Note - The following two variables are used to notify this class
    //that it can begin checking the links in linked lists to determine
    //whether the linked lists should be hidden (when none of its links are showing).
    startMonitoringLinkLists$:Subject<boolean>;
    startMonitoringLinkListsSubscription:Subscription;

    @ViewChild(PaymentPlanInformationComponent) private ppic: PaymentPlanInformationComponent;

    constructor(private mccPageSvc: MCCPageService) {

        //(For DE21378 - Hide link list title when all its links are hidden)
        //Initialize variables that will collect Observables containing linked
        //list state ('linkListLinks') and initiate monitoring of linked lists
        //after all link Observables have been collected ('startMonitoringLinkLists$'
        // and 'startMonitoringLinkListsSubscription').
        this.linkListLinks = [];

        this.startMonitoringLinkLists$ = new Subject<boolean>();
        this.startMonitoringLinkListsSubscription = this.startMonitoringLinkLists$
            .subscribe(() => {
                Observable.combineLatest(this.linkListLinks).subscribe(
                    (currentState:KPShowDirectiveUpdateInformation[]) => {
                        this.updateDisplayStateOfLinkListsThatAreReady(currentState);
                    }
                );
                //Note - only initiate monitoring of link lists when this Observable
                //receives its first signal to do so, don't keep initiating monitoring.
                this.startMonitoringLinkListsSubscription.unsubscribe();
            });
    }

    ngOnInit() {
        this.appObject$ = this.mccPageSvc.getAppObject$();
        window.onbeforeunload = function() {window.scrollTo(0,0);}
    }

    /**
     * (For DE21378 - Hide link list title when all its links are hidden))
     * For each monitored linked list, check whether all of its links are
     * ready to check ('isLinkedListReady'), determine ('isLinkedListVisible')
     * whether the linked list should appear, then ('if (showLinkedList) {')
     * show/hide the linked list based on this determination.
     * @param currentState contains the state of all monitored links
     */
    updateDisplayStateOfLinkListsThatAreReady(currentState:KPShowDirectiveUpdateInformation[]) {
        var linksLists:object = KPShowDirectiveUpdateInformation.organizeLinksByList(currentState);
        for (var nextLinkListHandle in linksLists) {
            if (linksLists.hasOwnProperty(nextLinkListHandle)) {
                var linksInList = <KPShowDirectiveUpdateInformation[]>linksLists[nextLinkListHandle];
                if (KPShowDirectiveUpdateInformation.isLinkedListReady(linksInList)) {
                    var showLinkedList:boolean =
                        KPShowDirectiveUpdateInformation.isLinkedListVisible(linksInList);
                    var linkListEle:any = document.getElementById(nextLinkListHandle);
                    if (linkListEle != null) {
                        if (showLinkedList) {
                            linkListEle.style.display = '';
                        } else {
                            linkListEle.style.display = 'none';
                        }
                    }
                }
            }
        }
    }
    /**
     * (For DE21378 - Hide link list title when all its links are hidden)
     * This function collects an Observable for each link in a linked list
     * and each of these Observables emits the current state of its link.
     * @param registerUpdates$ The state change information from an individual KPShowDirective
     */
    registerLinkListItems(
            registerUpdates$: Observable<KPShowDirectiveUpdateInformation>) {
        this.linkListLinks.push(registerUpdates$);
    }
    /**
     * (For DE21378 - Hide link list title when all its links are hidden)
     * This function notifies AppComponent that it can start monitoring linked lists.
     * @param unusedArg This argument isn't used right now
     */
    startMonitoringLinkLists(unusedArg: boolean) {
        this.startMonitoringLinkLists$.next(unusedArg);
    }

    preparePaymentPlanDetails(ppic:PaymentPlanInformationContext) {
        this.ppic.updateContext(ppic);
    }
}

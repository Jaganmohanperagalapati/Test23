import {AppObject, MCCPageService} from "./services/mccPage.service";
import {Observable} from "rxjs/Observable";
import { async, inject, TestBed } from '@angular/core/testing';
import {AppComponent} from "./app.component";
import {KPShowDirectiveUpdateInformation} from "./directives/kp-show.directive";



function mockProviderArray():any[] {
    return [
        {
            provide: MCCPageService,
            useValue: {
                getAppObject$: () => Observable.of(new AppObject('ABC'))
            }
        }
    ];
}

describe('FeedContainerComponent test', () => {

    describe('test app.comp constructor', () => {

        beforeEach(() => {
            TestBed.configureTestingModule({providers: mockProviderArray()}).compileComponents();
        });

        it('app.comp should exist', async(inject([MCCPageService], (mps) =>{
            let appComp: AppComponent = new AppComponent(mps);

            expect(appComp).toBeDefined();
            appComp.ngOnInit();
        })))

        describe('test functions of app.comp', () => {
            it('test startMonitoringLinkLists', async(inject([MCCPageService], (mps) =>{
                let appComp: AppComponent = new AppComponent(mps);

                appComp.startMonitoringLinkLists(false);
                appComp.startMonitoringLinkLists$.subscribe(
                    next => {expect(next).toBeTruthy();}
                )
            })))

            it('test registerLinkListItems', async(inject([MCCPageService], (mps) =>{
                let appComp: AppComponent = new AppComponent(mps);
                let toPass: KPShowDirectiveUpdateInformation = new KPShowDirectiveUpdateInformation('acl', 'controlValue', 1, true);

                appComp.registerLinkListItems(Observable.of(toPass));
                appComp.linkListLinks[appComp.linkListLinks.length - 1].subscribe(
                    next => {expect(next).toEqual(toPass);}
                );
            })))
        });
    });
});
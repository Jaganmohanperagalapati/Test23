var path = require('path')
var fs = require('fs')
var webpack = require('webpack')
var WebpackShellPlugin = require('webpack-shell-plugin')
var CopyWebpackPlugin = require('copy-webpack-plugin')

module.exports = {
  context: path.join(__dirname, 'src'),
  entry: './main.js',
  output: {
    path: path.resolve(__dirname, './dist'),
    filename: 'build.js'
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        loader: 'babel-loader',
        exclude: /node_modules/
      },
      {
      //Font loader
      test: /\.(woff|woff2|ttf|eot)$/,
        loader: 'file-loader',
        options: {
          name: '[name].[ext]?[hash]'
        }
     },
      {
        test: /\.(png|jpg|gif|svg)$/,
        loader: 'file-loader',
        options: {
          name: '[name].[ext]?[hash]'
        }
      }
    ]
  },
  devServer: {
    contentBase: path.join(__dirname, 'dist'),
    historyApiFallback: true,
    noInfo: true,
    hot: false
  },
  performance: {
    hints: false
  },
  devtool: '#eval-source-map',
  plugins: []
}
if (process.env.NODE_ENV === 'development') {
  module.exports.plugins = (module.exports.plugins || []).concat([
    new webpack.DefinePlugin({
      'process.env': {
        NODE_ENV: '"development"'
      }
    }),
    new CopyWebpackPlugin([
      { from: '**/*.html', to: path.join(__dirname, 'dist') }
    ]),
    new WebpackShellPlugin({ onBuildStart: ['echo starting in development...'], onBuildEnd: ['npm run sass-watch'] })
  ])
}
if (process.env.NODE_ENV === 'production') {
  module.exports.devtool = '#source-map'
  module.exports.plugins = (module.exports.plugins || []).concat([
    new webpack.DefinePlugin({
      'process.env': {
        NODE_ENV: '"production"'
      }
    }),
    new webpack.optimize.UglifyJsPlugin({
      sourceMap: true,
      compress: {
        warnings: false
      }
    }),
    new webpack.LoaderOptionsPlugin({
      minimize: true
    }),
    new CopyWebpackPlugin([
      { from: '**/*.html', to: path.join(__dirname, 'dist') },
      { from: '**/_images/*', to: path.join(__dirname, 'dist') }
    ]),
    new WebpackShellPlugin({ onBuildStart: ['npm run copy-assets'], onBuildEnd: ['npm run sass'] })
  ])
}

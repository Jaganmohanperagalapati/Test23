# poc-work

> POC template for static stuff

## Build Setup

``` bash
# install dependencies
npm install

#First time running the project you will not have the /dist 
npm run build

# serve with hot reload at localhost:8080 (will run SASS separately)
npm run dev

# build for production with minification; will generate in /dist(will run SASS separately)
npm run build

#run sass on it's own
node sass

# Push to a server (assuming you have your keys on the server)
npm run push
```
import $ from 'jquery';

import customScriptsInit from './_scripts/customScripts';

$(function() {
	customScriptsInit();
});
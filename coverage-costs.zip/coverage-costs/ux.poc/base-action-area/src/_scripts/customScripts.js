import $ from 'jquery';

export default function customScriptsInit(e) { 
	// :: for local (only)
  $(".header-component").load("_includes/header-include.html");
  $(".container").load("_includes/body-include.html");
  $(".footer-component").load("_includes/footer-include.html");

  // :: for server (only)
  // $(".header-component").load("../_includes/header-include.html");
  // $(".container").load("../_includes/body-include.html");
  // $(".footer-component").load("../_includes/footer-include.html");
}
# Bobcat
Message Center project has a Test Suite for user acceptance testing that is designed around Bobcat test framework.
Bobcat framework provides us with helper methods to interact with AEM on page, parsys, component and component
 dialog levels. It also provides an easy way to authenticate with AEM server for both Author and Publish instances.
Underneath Bobcat uses the Selenium WebDriver technology and provides to the developer all the raw helper methods to
interact with browser supported by this technology.
  You can access the instance of WebDriver as soon as your class has "private WebDriver webDriver" injected via @Inject
notation. So you can access WedDriver as 'webDriver' at this point.

## Prerequisites:
* Selenium instance
* AEM instance 

## To get Selenium installed locally:
* open the Terminal
* ```npm install -g webdriver-manager```
more info [here](https://www.npmjs.com/package/webdriver-manager)

## Run test suite
To run the test suite **locally** you need to: 
* open the Terminal
* start AEM server locally (http://localhost:4502 for author instance and port 4503 for publish instance)
* start Selenium server by doing ```webdriver-manager start``` 
* clone the global-shared project
* cd into global-shared
* run ```mvn clean install -P autoInstallPackage```
* cd into global-shared/it.test/bobcat
* run ```mvn clean test```

Without any options tests would run against local instances of AEM and Selenium.

To run against **remote** AEM and Selenium instances the test suite setup provides these command line options:
 -Dwebdriver.url
 -Dauthor.url
 -Dauthor.login
 -Dauthor.password
 -Dpublish.url
 -Dpublish.login
 -Dpublish.password
 -Dconfiguration.paths
                        
**Example:**

 ```mvn clean test -Dwebdriver.url=some_selenim_instance_url -Dauthor.url=some_aem_instane_url```

## Cucumber

Test suite is using Cucumber BDD test framework.
It allows us to write test cases (called Scenario's) in .feature files in plain English.
 Then each English phrase should be defined in .java files under step_definitions folder.
**Given**, **When**, **Then** annotations together with RegEx patterns allows Cucumber to match English phrases with 
Java methods.
More on Cucumber [here](https://cucumber.io/docs/reference/jvm#java)   
package bobcat.support;

import java.util.List;

import bobcat.stepdefinitions.CommonSteps;
import com.cognifide.qa.bb.aem.ui.wcm.SiteAdminPage;
import org.openqa.selenium.*;
import com.cognifide.qa.bb.logging.BrowserLogEntryCollector;
import com.cognifide.qa.bb.logging.entries.BrowserLogEntry;
import com.cognifide.qa.bb.logging.entries.LogEntry;
import com.google.inject.Inject;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Hooks {

    protected WebDriver driver;


    public void initialize() {
        if (driver == null)
            createNewDriverInstance();
    }

    private void createNewDriverInstance() {
        driver = new ChromeDriver();
    }

    public WebDriver getDriver() {
        return driver;
    }

    public void destroyDriver() {
        driver.quit();
        driver = null;
    }
    @Inject
    @SuppressWarnings("unused")
    private WebDriver webDriver;

    @Inject
    @SuppressWarnings("unused")
    private BrowserLogEntryCollector browserLogEntryCollector;

    @Inject
    @SuppressWarnings("unused")
    private SiteAdminPage siteadminPage;

    @After
    public void tearDown(Scenario scenario) {
        if (scenario.isFailed()) {
            if (webDriver instanceof TakesScreenshot)
                addScreenshot(scenario);
            addPageLink(scenario);
            addJSConsoleErrors(scenario);
            webDriver.quit();

        }

       /* siteadminPage.open(CommonSteps.DESTINATION_PATH);
        while (siteadminPage.isPagePresent(CommonSteps.pageTitle)) {
            siteadminPage.clickDeleteAndConfirm(CommonSteps.pageTitle);
        }*/

        webDriver.quit();
    }

    private void addJSConsoleErrors(Scenario scenario) {
        List<LogEntry> browserLogEntries = browserLogEntryCollector.getBrowserLogEntries();
        for (LogEntry browserLogEntry : browserLogEntries) {
            scenario.write("Console Error: " + ((BrowserLogEntry) browserLogEntry).getMessage());
        }
    }

    private void addPageLink(Scenario scenario) {
        scenario.write("Test page: " + "<a href=" + webDriver.getCurrentUrl() + ">link</a>");
    }

    private void addScreenshot(Scenario scenario) {
        byte[] screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.BYTES);
        scenario.embed(screenshot, "image/png");
    }
}
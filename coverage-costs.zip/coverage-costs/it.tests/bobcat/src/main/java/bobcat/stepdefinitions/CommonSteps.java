package bobcat.stepdefinitions;
import com.cognifide.qa.bb.aem.AemLogin;
import com.cognifide.qa.bb.aem.touch.data.pages.Pages;
import com.cognifide.qa.bb.aem.touch.pageobjects.pages.AuthorPage;
import com.cognifide.qa.bb.aem.touch.pageobjects.pages.AuthorPageFactory;
import com.cognifide.qa.bb.aem.touch.pageobjects.touchui.ConfigDialog;
import com.cognifide.qa.bb.aem.ui.wcm.SiteAdminPage;
import com.cognifide.qa.bb.provider.selenium.BobcatWait;
import com.google.inject.Inject;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import java.util.*;
import static bobcat.stepdefinitions.CoverageCostsUIConstants.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class CommonSteps {
    private static WebDriver webDriver1;
    private final String PARSYS_CONFIG = "Main Parsys";
    public final String DESTINATION_PATH = "/content/kporg/en/national/secure/";
    private By componentConfig = By.cssSelector("button[title='Configure']");
    public static String pageTitle;
    private String pageName;
    private AuthorPage page;
    @Inject
    @SuppressWarnings("unused")
    private Pages pages;
    @Inject
    @SuppressWarnings("unused")
    private WebDriver webDriver;
    @Inject
    @SuppressWarnings("unused")
    private AemLogin aemLogin;
    @Inject
    @SuppressWarnings("unused")
    private AuthorPageFactory authorPageFactory;
    @Inject
    @SuppressWarnings("unused")
    private SiteAdminPage siteadminPage;
    @Inject
    @SuppressWarnings("unused")
    private ConfigDialog configDialog;
    public void moveFocusTo(WebElement ele1){
        Actions actions = new Actions(webDriver);
        actions.moveToElement(ele1);
        actions.click();
        actions.build().perform();
    }
    public void sendKeysTo(WebElement ele1, String keyString){
        Actions actions = new Actions(webDriver);
        actions.moveToElement(ele1);
        actions.sendKeys(keyString);
        actions.build().perform();
    }


    @Then("^I set (text field|dropdown) with name \"(.*?)\" to \"(.*?)\"$")
    public void iSetTextFieldWithNameTo(String elementType, String name, String value) {
        if (Objects.equals(elementType, "text field")) {
            webDriver.findElement(By.name(name)).clear();
            webDriver.findElement(By.name(name)).sendKeys(value);
        } else new Select(webDriver.findElement(By.name(name))).selectByVisibleText(value);
    }
    @And("^I switch to \"(Edit|Preview)\" mode$")
    public void iSwitchModes(String mode) {
        if (Objects.equals(mode, "Edit")) {
            webDriver.switchTo().defaultContent();
            BobcatWait.sleep(3);
            webDriver.findElement(By.cssSelector(".editor-GlobalBar-item.js-editor-GlobalBar-layerCurrent.editor-GlobalBar-layerCurrent.js-editor-LayerSwitcherTrigger.coral-MinimalButton")).click();
        } else {
            webDriver.findElement(By.cssSelector(".editor-GlobalBar-previewTrigger.js-editor-GlobalBar-previewTrigger")).click();
            webDriver.switchTo().frame(0);
        }
    }
    @Then("^I should see (text field|dropdown|label) with name \"(.*?)\" set to \"(.*?)\"$")
    public void iShouldSeeFieldWithNameSetTo(String fieldType, String name, String content) {
        if (Objects.equals(fieldType, "text field"))
            assertEquals(content, getDialogTextFieldValue(name));
        else assertEquals(content, getDialogDropdownValue(name));
    }
    private String getDialogTextFieldValue(String name) {
        return webDriver.findElement(By.name(name)).getAttribute("value");
    }
    private String getDialogDropdownValue(String name) {
        WebElement element = webDriver.findElement(By.name(name));
        return new Select(element).getFirstSelectedOption().getText();
    }
    @When("^I save the dialog$")
    public void iSaveTheDialog() {
        BobcatWait.sleep(2);
        webDriver.findElement(By.cssSelector(".cq-dialog-submit")).click();
    }
    @When("^I open the dialog for the \"(.*?)\" component$")
    public void iOpenTheDialogForTheComponent(String componentName) {
        if (Objects.equals(componentName, "Container")) {
            webDriver.findElement(By.cssSelector("div[data-path*='/containerpar/']")).click();
            webDriver.findElement(By.cssSelector("button[data-action='PARENT']")).click();
            List<WebElement> listElements = webDriver.findElements(By.cssSelector(".cq-select-parent-item.coral-List-item"));
            Iterator<WebElement> iterator = listElements.iterator();
            WebElement listElement = iterator.next();
            while (iterator.hasNext() && !Objects.equals(listElement.getText(), "Container")) {
                listElement = iterator.next();
            }
            listElement.click();
            webDriver.findElement(componentConfig).click();
        } else if (Objects.equals(componentName, "Link List")) {
            BobcatWait.sleep(1);
            webDriver.findElement(By.cssSelector("div[data-path*='/bodypar/link_list")).click();
            webDriver.findElement(componentConfig).click();
        } else if (Objects.equals(componentName, "Title Text Link")) {
            configDialog = page.getParsys(pages.getParsys(PARSYS_CONFIG)).getComponent(componentName).openDialog();
        } else if (Objects.equals(componentName, "Action Area Component - Base")) {
            webDriver.findElement(By.cssSelector("div[data-path*='/bodypar")).click();
            webDriver.findElement(componentConfig).click();
        } else if (Objects.equals(componentName, "Utility Component")) {
            webDriver.findElement(By.cssSelector("div[data-path*='/bodypar/utility")).click();
            webDriver.findElement(componentConfig).click();
        } else if (Objects.equals(componentName, "sub-nav Component")) {
            webDriver.findElement(By.cssSelector("div[data-path*='/bodypar/sub_nav")).click();
            webDriver.findElement(componentConfig).click();
        } else if (Objects.equals(componentName, "Button Component - Extension")) {
            webDriver.findElement(By.cssSelector("div[data-path*='/bodypar/button_extended")).click();
            webDriver.findElement(componentConfig).click();
        } else if (Objects.equals(componentName, "Data-feed Component - Message Center")) {
            webDriver.findElement(By.cssSelector("div[data-path*='/bodypar/data_feed/icon-link")).click();
            webDriver.findElement(componentConfig).click();
        } else if(componentName.startsWith("/")){
            BobcatWait.sleep(3);
            WebElement ele1 = webDriver.findElement(By.xpath(componentName));
            //Used points class to get x and y coordinates of element.
            Point point = ele1.getLocation();
            int xcord = point.getX();
            System.out.println("Position of the webelement from left side is "+xcord +" pixels");
            //int ycord = point.getY();
            //System.out.println("Position of the webelement from top side is "+ycord +" pixels");
            // Using Actions class
            Actions action = new Actions(webDriver);
            //clicking on the logo based on x coordinate and y coordinate
            //you will be redirecting to the home page of softwaretestingmaterial.com
            action.moveToElement(ele1, xcord, xcord).click().build().perform();
            webDriver.findElement(componentConfig).click();
            System.out.println("AFTER CONFIG CLICK");
        }
        else{
            page.getParsys("/bodypar").getComponent(componentName).openDialog();
        }
    }
    @And("^I drag a \"(.*?)\" component on the parsys$")
    public void iDragAComponent(String componentName) {
        BobcatWait.sleep(1);
        page.addComponent("/bodypar", componentName);
    }
    @Given("^I am logged in$")
    public void iAmLoggedIn() {
        webDriver.manage().window().setSize(new Dimension(1500, 1000));
        aemLogin.authorLogin();
    }
    @And("^I create a \"(.*?)\" page using the \"(.*?)\" template$")
    public void iCreateAPageUsingTheTemplate(String newPage, String templateName) {
        pageName = newPage;
        String[] array = pageName.toLowerCase().split(" ");
        pageName = array[0] + "-" + array[1] + "-page";
        pageTitle = array[0].substring(0, 1).toUpperCase() + array[0].substring(1) +
                " " + array[1].substring(0, 1).toUpperCase() + array[1].substring(1) + " Page";
        System.out.println("DESTINATION PATH:"+DESTINATION_PATH);
        System.out.println("pageTitle:"+pageTitle);
        siteadminPage.open(DESTINATION_PATH);
        siteadminPage.createNewPage(pageTitle, pageName, templateName);
        page = authorPageFactory.create(DESTINATION_PATH + pageName + ".html");
        page.open();
    }
    @Then("^I delete the page created$")
    public void deletePage() {
        System.out.println("DESTINATION PATH:"+DESTINATION_PATH);
        System.out.println("pageTitle:"+pageTitle);
        siteadminPage.open(DESTINATION_PATH);
        siteadminPage.deletePage(pageTitle);
    }
    @And("^I publish the page$")
    public void iPublishThePage() {
        siteadminPage.open(DESTINATION_PATH);
        siteadminPage.activatePage(pageTitle);
    }
    @Then("^I open the published page$")
    public void iOpenThePublishedPage() {
        webDriver.navigate().to(System.getProperty("publish.url") + DESTINATION_PATH + pageName + ".html");
    }
    @And("^I wait for \"(.*?)\" seconds$")
    public void iWaitForSeconds(String numSeconds) {
        BobcatWait.sleep(Integer.parseInt(numSeconds));
    }
    @Then("^I switch to tab \"(.*?)\"$")
    public void iShouldSwitchTheTabTo(String tabName) {
        configDialog.switchTab(tabName);
    }
    @And("^I open the \"(.*?)\" page$")
    public void iOpenThePage(String url) {
        String fullUrl = "https://" + System.getProperty("environment") + "." + url;
        webDriver.navigate().to(fullUrl);
    }
    @Then("^I should be on the \"([^\"]*)\" page$")
    public void iShouldBeOnThePage(String url) {
        String fullUrl = "https://" + System.getProperty("environment") + "." + url;
        assertEquals(fullUrl, webDriver.getCurrentUrl());
    }
    @And("^I should see the \"([^\"]*)\" label$")
    public void iShouldSeeTheLabel(String label) {
        assertEquals(label, webDriver.findElement(By.id("mailbox-filter-sent")).getText());
    }
    @Then("^I should see the \"([^\"]*)\" and \"([^\"]*)\" label$")
    public void iShouldSeeTheAndLabel(String label, String label1) {
        assertEquals(label, webDriver.findElement(By.id("mailbox-filter-inbox")).getText());
        assertEquals(label1, webDriver.findElement(By.id("mailbox-filter-sent")).getText());
    }
    @And("^I click on sign out button$")
    public void iClickOnSignOutButton() {
        webDriver.findElement(By.id("acct_user_name-topnav")).click();
        webDriver.findElement(By.id("sign_out_link-topnav")).click();
    }
    @Then("^I click on browser back button$")
    public void iClickOnBrowserBackButton() {
        webDriver.navigate().back();
    }
    @Then("^I should be navigated to sign on page$")
    public void iShouldBeNavigatedToSignOnPage() {
        assertTrue(webDriver.findElement(By.id(("userid"))).isEnabled());
        assertTrue(webDriver.findElement(By.id(("password"))).isEnabled());
        assertTrue(webDriver.findElement(By.name(("signonButton"))).isEnabled());
    }

    public static void hashMapValidation(HashMap<String, By> hashMapToValidate){

        System.out.println("HASMAP:"+hashMapToValidate);

        Set set = hashMapToValidate.entrySet();
        Iterator iterator = set.iterator();
        boolean isDisplayed = false;
        String elementName = "";
        while(iterator.hasNext()) {
            Map.Entry elementEntry = (Map.Entry)iterator.next();
            elementName = (String) elementEntry.getKey();
            System.out.print("key is: "+ elementName + " & Value is: ");
            By identifierVal = (By) elementEntry.getValue();
            System.out.println(identifierVal);
            WebElement element1 = webDriver1.findElement(identifierVal);
            ((JavascriptExecutor) webDriver1).executeScript("arguments[0].scrollIntoView(true);", element1);
            isDisplayed = element1.isDisplayed();
            System.out.println(elementName+" is displayed."+isDisplayed);
        }

        assertTrue(elementName+" is displayed.", isDisplayed);

    }

    @And("^I click on \"([^\"]*)\" button$")
    public void click_button (String btnAction){
        if (btnAction.equals("Pay Bills")) {
            webDriver.findElement(By.cssSelector(CommonElements.PAY_BILLS_BUTTON)).click();
        }
        if (btnAction.equals("Get a cost estimate")) {
            webDriver.findElement(By.xpath(CommonElements.GET_A_COST_ESTIMATE_BUTTON)).click();
        }

        if (btnAction.equals("Browser Back")) {
            webDriver.navigate().back();
        }

    }

    @Then("^I am routed to \"([^\"]*)\" page$")
    public void routedPages(String page) {

        if(page.equals("Medical Bills Portal")) {
            assertEquals(CommonElements.pageTitleMedicalBills, webDriver.getTitle());
        }

        if(page.equals("Estimates Portal")) {
            assertEquals(CommonElements.pageTitleCostEstimates, webDriver.getTitle());
        }

         if(page.equals("Coverage Costs Landing")){
            assertEquals(CommonElements.pageTitleCoverageAndCosts, webDriver.getTitle());
            String currentUrl = webDriver.getCurrentUrl();
            System.out.println(currentUrl);
            assertTrue("User is not on Coverage and Costs Landing page",currentUrl.endsWith("secure/coverage-costs"));
            assertTrue(webDriver.findElement(By.cssSelector(CoverageCostsUIConstants.LandingPage.ACTION_AREA_HEADER)).isDisplayed());
        }
    }

    @And("^the \"([^\"]*)\" button is enabled$")
    public void enabledButton(String btn) throws Throwable {
        if(btn.equals("Pay Bills")) {
        assertTrue(webDriver.findElement(By.cssSelector(CommonElements.PAY_BILLS_BUTTON)).isEnabled());
         }
        if(btn.equals("Get a cost estimate")) {
            assertTrue(webDriver.findElement(By.xpath(CommonElements.GET_A_COST_ESTIMATE_BUTTON)).isEnabled());
        }
    }
}
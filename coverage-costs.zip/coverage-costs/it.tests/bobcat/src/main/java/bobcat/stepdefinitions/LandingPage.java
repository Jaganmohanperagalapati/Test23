package bobcat.stepdefinitions;

import com.cognifide.qa.bb.provider.selenium.BobcatWait;
import com.google.inject.Inject;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

import static org.junit.Assert.*;
import static bobcat.stepdefinitions.CoverageCostsUIConstants.*;

public class LandingPage {
    @Inject
    @SuppressWarnings("unused")
    private WebDriver webDriver;

    private static String messageId;

    @Given("^I am logged in to Environment as \"([^\"]*)\"$")
    public void iAmLoggedInToEnvironment(String userId) {
        String url = "kaiserpermanente.org/";
        String fullUrl = "https://" + System.getProperty("env") + "." + url;
        System.out.println("Logged in using " + userId);
        // String fullUrl = "https://" + System.getProperty("env") + "." + url + "secure/coverage-costs.html";
        webDriver.navigate().to(fullUrl);
        webDriver.findElement(By.id("userid")).sendKeys(userId);
        webDriver.findElement(By.id("password")).sendKeys("password7");
        webDriver.findElement(By.name("signonButton")).click();
        BobcatWait.sleep(3);
        System.out.println("Logged in using " + userId + " on " + fullUrl);
    }

    @When("^I should navigate to coverage and costs landing page$")
    public void iShouldNavigateToLandingPage() {
        waitForLoaderToDisappear(30);

    }

    @When("^I navigate to Coverage and Costs landing page$")
    public void navigate_to_page() {
        String url = "kaiserpermanente.org/";
        String fullUrl = "https://" + System.getProperty("env") + "." + url;
        String finalUrl = fullUrl + "secure/coverage-costs";
        webDriver.navigate().to(finalUrl);
        System.out.println(finalUrl);
    }

    @Then("^I should see Your last online payment$")
    public void IShouldSeeYourLastOnlinePayment() {
        BobcatWait.sleep(10);
        assertNotNull(webDriver.findElement(By.cssSelector(".screen-only>a")));

    }

    @Then("^I should see \"([^\"]*)\" in the action area container$")
    public void iShouldSeeTextInActionAreaContainer(String text) throws Throwable {
        if (text.equals("Coverage and costs")) {
            assertTrue(webDriver.findElement(By.cssSelector(CoverageCostsUIConstants.LandingPage.ACTION_AREA_HEADER)).isDisplayed());
            String actionAreaContainerText = webDriver.findElement(By.cssSelector(CoverageCostsUIConstants.LandingPage.ACTION_AREA_HEADER)).getText();
            assertTrue("This is not a valid action area header text", actionAreaContainerText.startsWith(CoverageCostsUIConstants.LandingPage.ACT_HEADER));
            System.out.println("1");
        }
        if (text.equals("Recent bill with no payment")) {
            assertTrue(webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.ACTION_AREA_CONTAINER_GUARANTOR)).isDisplayed());
            String actionAreaContainerText = webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.ACTION_AREA_CONTAINER_GUARANTOR)).getText();
            assertTrue("This is not a valid action area container text", actionAreaContainerText.startsWith(CoverageCostsUIConstants.LandingPage.AA_CONTAINER_TEXT_GUARANTOR_NO_PAYMENT));
            System.out.println("2");
        }
        if (text.equals("Information to get a cost estimate")) {
            assertTrue(webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.ACTION_AREA_CONTAINER_NON_GUARANTOR)).isDisplayed());
            String actionAreaContainerText = webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.ACTION_AREA_CONTAINER_NON_GUARANTOR)).getText();
            assertTrue("This is not a valid action area container text", actionAreaContainerText.startsWith(CoverageCostsUIConstants.LandingPage.AA_CONTAINER_NON_GUARANTOR));
        }
    }

    public void waitForLoaderToDisappear(int timeout) {
        BobcatWait.sleep(1);
        int timer = 0;
        while (timer < timeout) {
            if (webDriver.getPageSource().contains("overlay-active")) {
                BobcatWait.sleep(1);
                timer++;
            } else break;
        }
        assertTrue("Loading indicator is still present after " + timeout + " seconds", timer < timeout);
    }

    @Then("^I should see Your last online payment is \"([^\"]*)\"$")
    public void iShouldSeeYourLastOnlinePaymentIs(String paidAmt) {
        BobcatWait.sleep(10);
        WebElement ele1 = webDriver.findElement(By.cssSelector("div.kp-body-component div.mcc-row div.action-area-container div.action-area div.actions-container:nth-child(2) div.action-messages.desktop-only div:nth-child(1) div:nth-child(1) p:nth-child(1) > span.styling-5.--medium:nth-child(3)"));
        assertNotNull(ele1);
        String paidAmtText = ele1.getText();
        System.out.println("AMOUNT FROM ELE:" + paidAmtText);
        System.out.println("AMOUNT FROM VAL:" + paidAmt);
        assertEquals(paidAmtText, paidAmt);

    }

    @And("^I should see Amount Owed in Action area as \"([^\"]*)\"$")
    public void iShouldSeeAmountOwedInActionAreaAs(String amtOwed) {
        BobcatWait.sleep(10);
        WebElement ele1 = webDriver.findElement(By.cssSelector("div.kp-body-component div.mcc-row div.action-area-container div.action-area div.actions-container:nth-child(2) div.action-messages.desktop-only div:nth-child(1) div:nth-child(1) p:nth-child(1) > span.styling-5.--medium:nth-child(1)"));
        assertNotNull(ele1);
        String amtOwedText = ele1.getText();
        System.out.println("AMOUNT FROM ELE:" + amtOwedText);
        System.out.println("AMOUNT FROM VAL:" + amtOwed);
        assertEquals(amtOwedText, amtOwed);
    }


    @Then("^I should see \"([^\"]*)\" and \"([^\"]*)\" in collapsed view of the feedarea$")
    public void iShouldSeeAndInCollapsedViewOfTheFeedarea(String guarantorId, String totalAmt) {
        BobcatWait.sleep(10);
        WebElement gIdEle = webDriver.findElement(By.cssSelector("div.kp-body-component div.mcc-container div.mcc-row:nth-child(2) div.data-feed-area div.icon-link-list-container-mb section.icon-link-list-mb div:nth-child(1) div.icon-link-mb-desktop:nth-child(2) div.icon-link-content div.icon-container-top:nth-child(1) > div.guarantor-id"));
        assertNotNull(gIdEle);
        String gIdEleText = gIdEle.getText();
        System.out.println("guarantorId FROM ELE:" + gIdEleText);
        System.out.println("guarantorId FROM VAL:" + guarantorId);
        assertEquals(gIdEleText, guarantorId);
        WebElement totAmtEle = webDriver.findElement(By.cssSelector("div.kp-body-component div.mcc-container div.mcc-row:nth-child(2) div.data-feed-area div.icon-link-list-container-mb section.icon-link-list-mb div:nth-child(1) div.icon-link-mb-desktop:nth-child(2) div.icon-link-content div.icon-container-top:nth-child(1) > div.bill-amt"));
        assertNotNull(totAmtEle);
        String totAmtEleText = totAmtEle.getText();
        System.out.println("totAmtEle FROM ELE:" + totAmtEleText);
        System.out.println("totAmtEle FROM VAL:" + totalAmt);
        assertEquals(totAmtEleText, totalAmt);

    }

    @Then("^I should see payment plan link and click to open modal window$")
    public void iShouldSeePaymentPlanLinkAndClickToOpenModalWindow() {

        WebElement viewPaymentPlanModalEle = webDriver.findElement(By.cssSelector("div.kp-body-component div.mcc-container div.mcc-row:nth-child(2) div.data-feed-area div.icon-link-list-container-mb section.icon-link-list-mb div:nth-child(1) div.icon-link-mb-desktop:nth-child(2) div.icon-link-content div.icon-container:nth-child(3) > a.icon-link-link.view-payment-plan-details:nth-child(4)"));
        assertNotNull(viewPaymentPlanModalEle);
        viewPaymentPlanModalEle.click();

    }

    @Then("^I should see guarantor name as \"([^\"]*)\" and guarantor number as \"([^\"]*)\"$")
    public void iShouldSeeGuarantorNameAsAndGuarantorNumberAs(String guarantorName, String accountNum) {
        String guarantorNameAndAccountNum = guarantorName + " | " + accountNum;
        System.out.println("guarantorNameAndAccountNum:" + guarantorNameAndAccountNum);
        String valueFromEle = webDriver.findElement(By.xpath("//p[@class='mcc-ppd-modal-guarantor-and-account']")).getText();
        System.out.println("valueFromEle:" + valueFromEle);
        assertEquals(guarantorNameAndAccountNum, valueFromEle);
    }


    //Kalyani Code
    @Then("^User should able to see expanded view details in the feed area correctly based on \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
    public void UserShouldAbleToSeeChargesExpandedViewDeatails(String Member, String Charges, String AmountOwed, String TotalAmount) {
        waitForLoaderToDisappear(5);
        webDriver.findElement(By.xpath("//*[@id=\"icon-link-mb-desktop-0\"]/div[1]")).click();
        waitForLoaderToDisappear(5);
        WebElement expandedMemberTable = webDriver.findElement(By.xpath("//*[@class='table-content']//tr[1]/td[1]"));
        WebElement expandedChargesTable = webDriver.findElement(By.xpath("//*[@class='table-content']//tr[1]/td[2]"));
        WebElement expandedAmountOwedTable = webDriver.findElement(By.xpath("//*[@class='table-content']//tr[1]/td[5]"));
        WebElement expandedTableTotal = webDriver.findElement(By.xpath("//*[@class='table-content']//tr[3]/th[2]"));
        String ExpMember = expandedMemberTable.getText();
        String ExpCharges = expandedChargesTable.getText();
        String ExpAmountOwed = expandedAmountOwedTable.getText();
        String ExpTableTotal = expandedTableTotal.getText();
        System.out.println("Member: " + ExpMember);
        System.out.println("Charges: " + ExpMember);
        System.out.println("AmountOwed: " + ExpAmountOwed);
        System.out.println("TableTotal: " + ExpTableTotal);
        assertEquals(Member, ExpMember);
        assertEquals(Charges, ExpCharges);
        assertEquals(AmountOwed, ExpAmountOwed);
        assertEquals(TotalAmount, ExpTableTotal);
    }

    @And("^I should see the \"([^\"]*)\" in the right rail with \"([^\"]*)\"$")
    public void allTheACHLabelsAreDisplayed(String iconLinks, String planType) {
        System.out.println("in i_should_see_iconLinks " + iconLinks);
        String[] links = iconLinks.split("#");

        if (planType.equals("SF")) {

            for (int i = 0; i < links.length; i++) {

                if (links[i].equals("EstCost")) {
                    BobcatWait.sleep(3);
                    assertTrue(webDriver.findElement(By.cssSelector(CoverageCostsUIConstants.LandingPage.CALC_ICON)).isDisplayed());
                    assertTrue(webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.COST_EST_LINK)).isDisplayed());
                    continue;
                }
                if (links[i].equals("PayHistory")) {
                    BobcatWait.sleep(3);
                    assertTrue(webDriver.findElement(By.cssSelector(CoverageCostsUIConstants.LandingPage.PAY_HIS_ICON)).isDisplayed());
                    assertTrue(webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.PAY_HIS_LINK)).isDisplayed());
                    continue;
                }
                if (links[i].equals("MedicalBills")) {
                    BobcatWait.sleep(3);
                    assertTrue(webDriver.findElement(By.cssSelector(CoverageCostsUIConstants.LandingPage.MED_BILLS_ICON)).isDisplayed());
                    assertTrue(webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.MED_BILLS_LINK)).isDisplayed());
                    continue;
                }
            }
        }
        if (planType.equals("FI-INDEX")) {

            for (int i = 0; i < links.length; i++) {

                if (links[i].equals("EstCost")) {
                    BobcatWait.sleep(3);
                    assertTrue(webDriver.findElement(By.cssSelector(CoverageCostsUIConstants.LandingPage.CALC_ICON)).isDisplayed());
                    assertTrue(webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.COST_EST_LINK)).isDisplayed());
                    continue;
                }
                if (links[i].equals("PayHistory")) {
                    BobcatWait.sleep(3);
                    assertTrue(webDriver.findElement(By.cssSelector(CoverageCostsUIConstants.LandingPage.PAY_HIS_ICON)).isDisplayed());
                    assertTrue(webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.PAY_HIS_LINK)).isDisplayed());
                    continue;
                }
                if (links[i].equals("MedicalBills")) {
                    BobcatWait.sleep(3);
                    assertTrue(webDriver.findElement(By.cssSelector(CoverageCostsUIConstants.LandingPage.MED_BILLS_ICON)).isDisplayed());
                    assertTrue(webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.MED_BILLS_LINK)).isDisplayed());
                    continue;
                }
                if (links[i].equals("PayPremiumBill")) {
                    BobcatWait.sleep(3);
                    assertTrue(webDriver.findElement(By.cssSelector(CoverageCostsUIConstants.LandingPage.PAY_PREM_BILL_ICON)).isDisplayed());
                    assertTrue(webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.PAY_PREM_BILL_LINK)).isDisplayed());
                    continue;
                }
            }
        }
        if (planType.equals("SF-NG")) {

            for (int i = 0; i < links.length; i++) {

                if (links[i].equals("PlanBen")) {
                    BobcatWait.sleep(3);
                    assertTrue(webDriver.findElement(By.cssSelector(CoverageCostsUIConstants.LandingPage.PLAN_BEN_ICON)).isDisplayed());
                    assertTrue(webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.PLAN_BEN_LINK)).isDisplayed());
                    continue;
                }
                if (links[i].equals("ClaimStat")) {
                    BobcatWait.sleep(3);
                    assertTrue(webDriver.findElement(By.cssSelector(CoverageCostsUIConstants.LandingPage.CLAIM_STAT_ICON)).isDisplayed());
                    assertTrue(webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.CLAIM_STAT_LINK)).isDisplayed());
                    continue;
                }
            }
        }
    }

    @Then("^I click on \"([^\"]*)\" to navigate to portal and back to landing page$")
    public void clickLinks(String iconLinks) throws Throwable {
        System.out.println("in i_should_click_iconLinks " + iconLinks);
        String[] links = iconLinks.split("#");
        for (int i = 0; i < links.length; i++) {

            if (links[i].equals("EstCost")) {
                BobcatWait.sleep(3);
                webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.COST_EST_LINK)).click();
                assertEquals(CommonElements.pageTitleCostEstimates, webDriver.getTitle());
                webDriver.navigate().back();
                webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.COST_EST_LINK)).click();
                assertEquals(CommonElements.pageTitleCostEstimates, webDriver.getTitle());
                webDriver.findElement(By.xpath(CommonElements.PortalPage_Header_Link)).click();
                assertTrue(webDriver.findElement(By.cssSelector(CoverageCostsUIConstants.LandingPage.ACTION_AREA_HEADER)).isDisplayed());
                continue;
            }
            if (links[i].equals("PayHistory")) {
                BobcatWait.sleep(3);
                webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.PAY_HIS_LINK)).click();
                assertEquals(CommonElements.pageTitlePaymentHistory, webDriver.getTitle());
                webDriver.navigate().back();
                assertTrue(webDriver.findElement(By.cssSelector(CoverageCostsUIConstants.LandingPage.ACTION_AREA_HEADER)).isDisplayed());
                continue;
            }
            if (links[i].equals("MedicalBills")) {
                BobcatWait.sleep(3);
                webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.MED_BILLS_LINK)).click();
                assertEquals(CommonElements.pageTitleMedicalBills, webDriver.getTitle());
                webDriver.navigate().back();
                webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.MED_BILLS_LINK)).click();
                assertEquals(CommonElements.pageTitleMedicalBills, webDriver.getTitle());
                webDriver.findElement(By.xpath(CommonElements.PortalPage_Header_Link)).click();
                assertTrue(webDriver.findElement(By.cssSelector(CoverageCostsUIConstants.LandingPage.ACTION_AREA_HEADER)).isDisplayed());
                continue;
            }
            if (links[i].equals("PayPremiumBill")) {
                BobcatWait.sleep(3);
                webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.PAY_PREM_BILL_LINK)).click();
                assertEquals(CommonElements.pageTitlePayPremiumBill, webDriver.getTitle());
                webDriver.navigate().back();
                webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.PAY_PREM_BILL_LINK)).click();
                assertEquals(CommonElements.pageTitlePayPremiumBill, webDriver.getTitle());
                webDriver.findElement(By.xpath(CommonElements.PortalPage_Header_Link)).click();
                assertTrue(webDriver.findElement(By.cssSelector(CoverageCostsUIConstants.LandingPage.ACTION_AREA_HEADER)).isDisplayed());
                continue;
            }
            if (links[i].equals("PlanBen")) {
                BobcatWait.sleep(3);
                webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.PLAN_BEN_LINK)).click();
                assertEquals(CommonElements.pageTitlePlanBenefits, webDriver.getTitle());
                webDriver.navigate().back();
                webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.PLAN_BEN_LINK)).click();
                assertEquals(CommonElements.pageTitlePlanBenefits, webDriver.getTitle());
                webDriver.findElement(By.xpath(CommonElements.PortalPage_Header_Link)).click();
                assertTrue(webDriver.findElement(By.cssSelector(CoverageCostsUIConstants.LandingPage.ACTION_AREA_HEADER)).isDisplayed());
                continue;
            }
            if (links[i].equals("ClaimStat")) {
                BobcatWait.sleep(3);
                webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.CLAIM_STAT_LINK)).click();
                assertEquals(CommonElements.pageTitleClaimsSummary, webDriver.getTitle());
                webDriver.navigate().back();
                webDriver.findElement(By.xpath(CoverageCostsUIConstants.LandingPage.CLAIM_STAT_LINK)).click();
                assertEquals(CommonElements.pageTitleClaimsSummary, webDriver.getTitle());
                webDriver.findElement(By.xpath(CommonElements.PortalPage_Header_Link)).click();
                assertTrue(webDriver.findElement(By.cssSelector(CoverageCostsUIConstants.LandingPage.ACTION_AREA_HEADER)).isDisplayed());
                continue;
            }
        }
    }
}

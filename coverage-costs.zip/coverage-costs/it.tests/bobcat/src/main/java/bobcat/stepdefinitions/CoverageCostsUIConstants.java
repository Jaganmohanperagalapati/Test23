package bobcat.stepdefinitions;

public interface CoverageCostsUIConstants {

    interface LandingPage {
        String ACTION_AREA_HEADER=".l1-action-area-heading";
        String ACTION_AREA_CONTAINER_GUARANTOR="//div[@class='action-messages desktop-only']";
        String ACTION_AREA_CONTAINER_NON_GUARANTOR="//div[@data-pqe='estimate-a-cost']";
        String ACT_HEADER="Coverage and costs";
        String AA_CONTAINER_TEXT_GUARANTOR_NO_PAYMENT="The amount you owe from your last billing statement for your bill is  this the balance";
        String AA_CONTAINER_NON_GUARANTOR="Our estimates tool gives you a personalized estimate to help you plan your next visit.";
        String CALC_ICON="i.fa.icon-calculator.neutral-icon-circle-lg";
        String COST_EST_LINK="//a[@href='/health/mycare/consumer/my-health-manager/my-plan-and-coverage/estimates']";
        String PAY_HIS_ICON="i.fa.icon-zpayment-history.neutral-icon-circle-lg";
        String PAY_HIS_LINK="//a[@data-analytics-click='View my payment history']";
        String MED_BILLS_ICON="i.fa.icon-document.neutral-icon-circle-lg";
        String MED_BILLS_LINK="//a[@data-analytics-click='View my medical bills']";
        String PAY_PREM_BILL_ICON="i.fa.icon-zpay-bill.neutral-icon-circle-lg";
        String PAY_PREM_BILL_LINK="//a[@data-analytics-click='Pay my premium bill']";
        String PLAN_BEN_ICON="i.fa.icon-zchoose.neutral-icon-circle-lg";
        String PLAN_BEN_LINK="//a[@data-analytics-click='Plan benefits details']";
        String CLAIM_STAT_ICON="i.fa.icon-zclaim.neutral-icon-circle-lg";
        String CLAIM_STAT_LINK="//a[@data-analytics-click='Claim status']";
        String HELP_LINK="//a[@href='/northern-california/secure/coverage-costs/help.html']";

    }

    interface CommonElements {
        String PAY_BILLS_BUTTON="button.-primary-action";
        String GET_A_COST_ESTIMATE_BUTTON="//button[@data-url='/health/mycare/consumer/my-health-manager/my-plan-and-coverage/estimates']";
        String pageTitleMedicalBills ="Medical bills - Kaiser Permanente";
        String pageTitleCostEstimates = "Estimates - Kaiser Permanente";
        String pageTitleCoverageAndCosts = "Coverage and costs";
        String pageTitlePaymentHistory="Payment history";
        String PortalPage_Header_Link="//a[@id='kp-header-nav-link6']";
        String pageTitlePayPremiumBill="Premium bills - Kaiser Permanente";
        String pageTitlePlanBenefits="Eligibility and benefits - Kaiser Permanente";
        String pageTitleClaimsSummary="Claims summary - Kaiser Permanente";
    }
}

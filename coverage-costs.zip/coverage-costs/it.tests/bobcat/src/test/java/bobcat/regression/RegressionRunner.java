package bobcat.regression;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/main/features/",
        format = {"pretty", "html:target/cucumber-report", "json:target/cucumber-report/regressionreport.json"},
        tags = {"~@wip", "~@author","~@manual","~@regression","~@smoke"},
        glue = "bobcat")
public class RegressionRunner {

}




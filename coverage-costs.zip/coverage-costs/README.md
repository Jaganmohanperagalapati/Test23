# Coverage & Costs AEM Project

This is a project  for Coverage & Costs AEM-based application..

## Some general coding check in & out and validation steps

step 1: sync up coding often to get the latest coding checked in - at least daily. 

step 2:  for any coding changes to be checked in:  

	* adding/modifying the unit testing cases if required (notes: java coding in the core project has junit tests)
	* preferred to add the unit test cases for the expected functionality of a method before implementing it.  

	* after the needed implementation, run unit testing to make sure all existing unit test cases pass  

	* test locally with the relevant AEM component html update(s) in the index.html and the needed mock API responses  

	* Note: test locally for any sass coding changes. The index.html includes the main.css file generated from sass file compilation

	* After the above, you can check in, including the updates to index.html

	Note: there is always the option to do "fork and a pull request" if preferred.

	There are drawbacks: you may miss the coding updates if it takes too long working on the fork
	and the reviewer will have to approve the pull request.

	The fork and pull option still requires all the unit testing, local testing needed.

step 3. any coding affecting an AEM component (**AEM component dialogs, js and html changes all do**), it is better to deploy to your local AEM authoring server and check the project page and the AEM component(s)


step 4: check project build to make sure the triggered build is successful, and if not, do whatever needed

step 5: test on the dev authoring server to check the mcc landing page and the component(s) being impacted still functioning correctly

step 6: test to check that the application works and the new/changed functionality is up to the story specifications

step 7: do code review

step 8: notify the testing team to do their testing

	NOTE: please check in your coding often.
	Check in during the last few days in a sprint does not let our testing team to do their work in time.


## Modules

The main parts of the template are:

* core: Java bundle containing all core functionality like OSGi services, listeners or schedulers, as well as component-related Java code such as servlets or request filters.
* ui.apps: contains the /apps (and /etc) parts of the project, ie JS & CSS clientlibs, components, templates, runmode specific configs as well as Hobbes-tests (Note: there is no Hobbes-tests in this project as we do not have a way to automatically invoke them with our build process).
* ui.content (Not used) contains sample content using the components from the ui.apps ( Note: If you want the content to be created on Dev 10,please add the conetent to https://stash.kp.org/projects/KPWEB/repos/aem-kporg-content/browse stash repo).
* ui.tests (Not used) Java bundle containing JUnit tests that are executed server-side. This bundle is not to be deployed onto production.
* ui.launcher (Not used): contains glue code that deploys the ui.tests bundle (and dependent bundles) to the server and triggers the remote JUnit execution
* ui.resources: contains the UI/UX assets and build process generates the api.bundle.js and copies it to ui.apps projects clientlibs folder.

## Setting up ssh with SourceTree
1. Open GitBash
2. run the following: ssh-keygen -t rsa -C "your_email@example.com"
3. Enter a file name when prompted, or press enter to accept the default
4. Leave blank when prompted for a security phrase
5. Open SourceTree, then click Tools->Launch SSH Agent, the Putty agent is now in your task tray.
6. In Sourcetree, click Tools->Create or Import SSH Keys
7. Press load key, then select the private key created in step 3, and copy the public key created in the top box
8. In stash, go to your account settings, choose SSH Keys, add key, then paste the public key here

## How to set up with Eclipse & Mac

1. clone git repository ssh://git@stash.kp.org/kpweb/coverage-costs.git
2. import as general project so you will have the coverage-costs project that contains core, ui.apps, ui.resources projects
3. set up ui.resources project as following:

	3.1 set up the ssh key to stash if not done yet
 	first go to https://stash.kp.org/plugins/servlet/ssh/account/keys to check whether there is any ssh key set

	3.1.1 go to terminal (this is for Mac) run the below command
 		https://help.github.com/articles/generating-a-new-ssh-key-and-adding-it-to-the-ssh-agent/
 		(more info for checking whether you have a ssh key already)

		ssh-keygen -t rsa -b 4096 -C "your email address"
		press enter for all prompts without any value, no value for password either

	3.1.2 after the above, enter this command to copy the generated key:  pbcopy < -/.ssh/id_rsa.pub

	3.1.3 then go to the stash https://stash.kp.org/plugins/servlet/ssh/account/keys
		to add the SSH keys

	3.2 using Terminal window, go to coverage-costs/ui.resources
	first do npm install (fix whatever it may say missing by npm install --save-dev  most likely it is a dev dependency)
	 (make sure your node.js version should be 5.x)
	then do grunt tsAEM

4. to build other projects to your local Adobe AEM authoring server  
	* read about how to set it up and run it first  
	* run your local Adobe AEM authoring server

5. go to coverage-costs folder, find the pom.xml file, comment out the ui.resources in its modules section at the top
using Terminal, run mvn clean install -PautoInstallPackage

## How to setup AEM local server

1. First download the files from kp.box.com https://kp.box.com/s/dcaqwkesxr2h3boqsvklsf9hjj9v5uh0 you will get two files in that "cq-author-p4502.jar" and 			"license.properties" files
2. Now go your documents folder in your computer and create a folder called "AEM Local" in that folder create new two folders called "Author" and "Publisher" now copy the above two files and paste them once in Author folder and paste them in Publisher folder.
3. after creating two folders not change the name of "cq-author-p4502.jar" in publisher folder to "cq-publish-p4503.jar" for different urls for local and publisher and keep the file in author folder as it is
4. now click the jar files in two folders it unpacks all the local files
5. now go to the browser and enter http://localhost:4502/ for Local author access and http://localhost:4503/ for local publisher access
6. deploy projects to local AEM authoring server: follow the readme in the following projects to build and deploy
	
	 https://stash.kp.org/projects/KPWEB/repos/kporg-site-structure/browse (do this one first)
	 https://stash.kp.org/projects/KPWEB/repos/kp-environment-config/browse
	 https://stash.kp.org/projects/KPWEB/repos/kp-foundation/browse
	 coverage and costs
	 https://stash.kp.org/projects/KPWEB/repos/aem-kporg-content/browse 
7. the aem-kporg-content project may not have the latest contents.
	we can download the contents from mcc-dev20 authoring server if needed.
	will add the steps later with Tory
    
8. Now go to your http://localhost:4502/  and login with username and password as "admin" , "admin" and upload packages which you downloaded before all the three and instal l them after uploading.

9. now go to the link http://localhost:4502/content/kporg/en/national/coverage-costs.html for accessing the local AEM page.


## How to test locally without AEM
* run sudo npm install dyson -g (This is one time setup)
	(For Windows, use npm install dyson -g)
* start the mock API server: go to ui.resources folder with your Terminal, run dyson test/data/mock 9080  
	(This starts dyson server at http://localhost:9080)  
	(This URL is defined as apiUrl in the app_config/local.json file and is used in MCCController.ts)  
* go to ui.resources folder with Another Terminal, run grunt tsLocal
* using a browser: localhost:4321 (this requires the item 1 & 2 commands to be running)

## How to mock API responses
* review the js files at /data/mock/get that implement the API responses
* run mcc page on a dev server and grab the API responses to use for local testing.
* check in those files with the file name convention as below:
* member-guid.json, nma-guid.json for user API
* proxyinformation-guid.json for proxyinformation API
* guarantor-guid.json for patientbilldetails API
* entitlement API is different, it uses the RelID from the proxyinformation response for the signed in user, use entitlements-guid-relid.json
* add the new json file and change the response of an API to the file you need for the test case by updating the js file

## How to build

To build the project properly and deploy to local AEM instance use following command

mvn clean install -PautoInstallPackage

## Unit Testing

There are three levels of testing contained in the project:

*unit test in core: this show-cases classic unit testing of the code contained in the bundle. To test, execute:

    mvn clean test

*unit testing in ui.resources:
unit tests in ui.resources is invoked by npm test for its build process specified in the pom.xml of the project.
search for exec-npm-test in the pom.xml file.

The karam.conf.js is used to specify the settings.  Please review the settings to see which files are loaded and we are measuring the coverage on the built mcc-web.js under target/whitehat folder.  This mcc-web.js is not uglified.
The mcc-web.js under target/dist will be uglified.

locally, you can also run the unit tests:

	1. using Terminal window, go to coverage-costs/ui.resources

	2 first do grunt tsAEM or grunt tsLocal (either will create the mcc-web.js file at target/whitehat); then npm test


***** Ignore the server-side integration tests and client-side Hobbes.js tests below
* server-side integration tests: this allows to run unit-like tests in the AEM-environment, ie on the AEM server. To test, execute:

    mvn clean integration-test -PintegrationTests

* client-side Hobbes.js tests: JavaScript-based browser-side tests that verify browser-side behavior. To test:

    in the browser, open the page in 'Developer mode', open the left panel and switch to the 'Tests' tab and find the generated 'MyName Tests' and run them.

## Maven settings

The project comes with the auto-public repository configured. To setup the repository in your Maven settings, refer to:

    http://helpx.adobe.com/experience-manager/kb/SetUpTheAdobeMavenRepository.html

## Accumulated Knowledge
    - Styleguide Tips
        -%center content is not needed when including outer-container from neat, as it has the same functionality
        
    - Mac Runinng Build from Eclipse sometimes run into following issues
    - [ERROR] Failed to execute goal org.codehaus.mojo:exec-maven-plugin:1.3.2:exec (exec-npm-install) on project coverage-costs.ui.resources: Command execution failed. Cannot run program "npm" (in directory "/Users/jpar/projs/prft/kpcode/kpweb/coverage-costs/ui.resources"): error=2, No such file or directory
    - This error can be avoided to by running eclipse from commnad prompt -- Go to eclipse installation folder and excute ./eclipse
    - 
    - Mac Running Build from Eclipse  run into failure of exec-npm-test
    - Failed to execute goal org.codehaus.mojo:exec-maven-plugin:1.3.2:exec (exec-npm-test) on project coverage-costs.ui.resources: Command execution failed. Process exited with an error: 1 (Exit value: 1) ->
    - Cannot start PhantomJS
    - This is issue is related to Mac OS Sierra 10.12.3 and karma-phantomjs-launcher. If karma-phantomjs-launcher updated to newest version (1.0.2) this is not a issue but to upgrade to karma-phantomjs-launcher to version 1.0.2 needs to happen through DevOps as it may break the build on CI server. (Package.json dev dependencies line number 35).
    
    - Build failing in Eclipse IDE om Mac  - try running on command line -- mvn clean install -PautoInstallPackage
    - Errors out with following error --Node Sass could not find a binding for your current environment: OS X 64-bit with Node.js 9.x
    -- remove node_modules
    -- do npm rebuild node-sass on command line
    
    
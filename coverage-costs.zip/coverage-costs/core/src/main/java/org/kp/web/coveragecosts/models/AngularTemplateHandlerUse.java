package org.kp.web.coveragecosts.models;

import java.util.ArrayList;
import java.util.List;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.components.Component;
import com.day.cq.wcm.commons.WCMUtils;


public class AngularTemplateHandlerUse extends WCMUsePojo{

	private static final Logger log = LoggerFactory.getLogger(AngularTemplateHandlerUse.class);
	private boolean debugEnabled = log.isDebugEnabled();
    private static String COMP_ANGULAR_PROPERTY_NAME="compModelType";
    private static String COMP_ANGULAR_PROPERTY_VALUE="Angular";
    
    private List<AngularTemplateModel> angularComps;
    
    private static String ROOT_COMP_TYPE = "kporg/coverage-costs/components/content/root-comp-mcc";
    private boolean rootcomp = false;
    
    @Override
    public void activate() throws Exception {
    	if (debugEnabled)
    		log.debug("--- Started : AngularTemplateHandler : Activate");
    	
    	angularComps = new ArrayList<AngularTemplateModel>();
    	// Iterate through all child components
    	Resource pageResource = getResource();
    	// need to get to page resource as this may be called from root comp also.
        if (pageResource.getResourceType().equalsIgnoreCase(ROOT_COMP_TYPE)){
        	pageResource= getCurrentPage().getContentResource();    
        	rootcomp = true;
        }
    	if (pageResource != null){
    		processChilds(pageResource, angularComps);  
    	} else {
    		// Log warning that not able to get  page resource    		
    	}
    	
    	if (debugEnabled)
    		log.debug("--- End : AngularTemplateHandler : Activate");
    }
    
	public List<AngularTemplateModel> getAngularComps(){
		return angularComps;
		
	}	
	
	private void processChilds (Resource parent, List<AngularTemplateModel> angComps){
		if (!parent.hasChildren()){
			return;
		}
		
		for (Resource childResource : parent.getChildren()) {   
			if (rootcomp && childResource.getResourceType().equalsIgnoreCase(ROOT_COMP_TYPE)){
				//Skip processing 
			} else {
		    	//check id the components is Angular Component
				ValueMap properties = childResource.getValueMap();
				String resourcePath = childResource.getPath();
				// Read compType property on the resource and see if it is angular resource
				String resourceCompType = properties.get(COMP_ANGULAR_PROPERTY_NAME, "");
    	    	// Create AngularTemplateModel 
				Component childResourceComp = WCMUtils.getComponent(childResource);
				if (childResourceComp!=null){
					String componentName = childResource.getName();
					angularComps = processAngularComps(resourceCompType, componentName, resourcePath, angularComps );
					// Process child resources
					if (childResource.hasChildren()){
						processChilds (childResource, angComps);
					}

				} else {
					// Unable to get a reference top the component  - log error
					log.error("Unable to get reference to component for resource:"+resourcePath);
				}
			}
		}		
	}
	
	  /**
	   * Process and Add the angular components to the List
	   * @param resourceCompType
	   *            ComponentType Angular or Other 
	   * @param componentName
	   *            Name of Component
	   * @param resourcePath
	   *            Component Resource Path 
	   * @param angularComps
	   *            List of AngularTemplateModel holding Angular Components          
	   *           	   
	   * @return List <AngularTemplateModel> 
	   */
	private List <AngularTemplateModel> processAngularComps(String resourceCompType, String componentName, String resourcePath, List <AngularTemplateModel> angularComps ){
		Boolean angResource = false;
		// every angular component will have compType=Angular
		angResource = resourceCompType.equalsIgnoreCase(COMP_ANGULAR_PROPERTY_VALUE);

		if (angResource){
			// Angular resource add to list 
			AngularTemplateModel angComp = new AngularTemplateModel();
	    	angComp.setTemplateID(componentName);
	    	angComp.setTemplatePath(resourcePath);
	    	// Add to angularComps list
	    	if (debugEnabled)
	    		log.debug("processChilds: Added TemplateID:"+componentName+" TemplatePath:"+ resourcePath);
	    	angularComps.add(angComp);
		} else {
			// Not a angular resource - skipped adding tp list 							
		}
		return angularComps;

	}


}
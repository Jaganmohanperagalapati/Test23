package org.kp.web.coveragecosts.utils;

import com.adobe.cq.sightly.WCMUsePojo;
import com.adobe.cq.sightly.SightlyWCMMode;
import org.kp.web.coveragecosts.constants.MCCConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MCCWCMUseUtil extends WCMUsePojo {
	private static final Logger log = LoggerFactory.getLogger(MCCWCMUseUtil.class);
	private boolean debugEnabled = log.isDebugEnabled();
	protected boolean isAuthoring =false;
	protected String defaultDisplayStyle;
	
	@Override
	public void activate() throws Exception {
		SightlyWCMMode wcmMode = getWcmMode();
		if(wcmMode.isEdit()
			||wcmMode.isDesign()
			||wcmMode.isPreview()){
			isAuthoring =true;
		}
		
		setDefaultDisplayStyle();
	}
	
	protected void setDefaultDisplayStyle() {
		if (isAuthoring)
			defaultDisplayStyle = MCCConstant.DISPLAY;
		else
			defaultDisplayStyle = MCCConstant.DISPLAY_NONE;
	}
	
	public boolean isAuthoring(){
		if (debugEnabled)
			log.debug("isAuthoring " + isAuthoring);
		
		return isAuthoring;
	}
	
	public String getDefaultDisplayStyle(){
		return defaultDisplayStyle;
	}

}

package org.kp.web.coveragecosts.use;

import java.util.ArrayList;
import java.util.List;

import org.kp.web.coveragecosts.models.LinkModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * FeedContainerRightRailUse class is TBD.
 * 
 * @author Jai Parkash
 *
 */

public class DynamicLinkListUseMCC extends WCMUsePojo {
  private static final Logger LOGGER = LoggerFactory.getLogger(DynamicLinkListUseMCC.class);
  private boolean debugEnabled = LOGGER.isDebugEnabled();
  
  private static final String DYNAMIC_LIST_LINKS = "pageLinks";

  private static final String LINK_LABEL = "linkLabel";
  private static final String LINK_PATH = "linkPath";
  private static final String LINK_TARGET = "linkTarget";
  
  private static final String JSON_ATT_LINK_LABEL = "linkLabel";
  private static final String JSON_ATT_LINK_PATH = "linkPath";
  private static final String JSON_ATT_LINK_TARGET = "linkTarget";
  
  private static final String JSON_COMP_NAME = "compname"; 
  
  private  String componentText; // to  return the text property value
  private  String[] dynamiclists;// Read multi field property values
  
  private  List<LinkModel> dynamicListList= new ArrayList<LinkModel>();
  private  String compName="";
  

  @Override
  public void activate() throws Exception {
  	if (debugEnabled)
		LOGGER.debug("Activating");
    try{
    	compName=getResource().getName();
    	componentText = "";
    	dynamiclists = getProperties().get(DYNAMIC_LIST_LINKS, String[].class);
	    if (dynamiclists!=null && dynamiclists.length >0){
		    for (String s : dynamiclists) {
		    	if (!s.isEmpty()){
		    		JsonObject jObject = new JsonParser().parse(s).getAsJsonObject();
		    		String label = jObject.get(LINK_LABEL).toString();
		            String path = jObject.get(LINK_PATH).toString();
		            String target = jObject.get(LINK_TARGET).toString();
		            String delimter ="";
		            if (!componentText.isEmpty()) {  delimter =",";}
		            componentText = componentText+delimter+s;
		            LinkModel listItem = new LinkModel();
		            listItem.setDisplayText(label);
		            listItem.setResourceLink(path);
		            listItem.setTarget(target);
		            
		            dynamicListList.add(listItem);
	    		} else {
	    			LOGGER.error("The property {0} is empty.", DYNAMIC_LIST_LINKS);
	    		}
	    	    
	    	}
	
	    }
    } catch (Exception e){
    	LOGGER.error("Exception while loading DynamicLinkListMCC:" + e.getMessage());
    }
	if (debugEnabled)
		LOGGER.debug("Done -- Activating");
 
  }

  /**
   * This method is responsible for to get the String representation.
   * 
   * @return String
   */
  public String getComponentText() {
    return componentText;
  }

  /**
   * This method is responsible for to get the  Links as a List of LinkModel Items.
   * 
   * @return List<LinkModel>
   * 	is a list of LinkModel representing various configure Links in component.
   */
  public List<LinkModel> getDynamicLinkList() {
	    return dynamicListList;
  }
  
  /**
   * Return the JSON representation of content authored data
   * 
   * @return String
   */
	public String getJSON() {
		JsonObject jsonObject = new JsonObject();
		try {	
				jsonObject.addProperty(JSON_COMP_NAME, compName);					
				JsonArray jsonArray = new JsonArray();
				for (LinkModel dynamicLists : dynamicListList) {
					JsonObject jsonObjectInner = new JsonObject();
					jsonObjectInner.addProperty(JSON_ATT_LINK_LABEL, dynamicLists.getDisplayText());
					jsonObjectInner.addProperty(JSON_ATT_LINK_PATH, dynamicLists.getResourceLink());
					jsonObjectInner.addProperty(JSON_ATT_LINK_TARGET, dynamicLists.getTarget());
					jsonArray.add(jsonObjectInner);
			    }
				
				jsonObject.add(DYNAMIC_LIST_LINKS, jsonArray);
			
			} catch (Exception e){
				  LOGGER.error("Error in getJSON:"+ e.getMessage());
			}
			return (jsonObject.isJsonNull()==true ? "" : jsonObject.toString());		
	} 
 
}

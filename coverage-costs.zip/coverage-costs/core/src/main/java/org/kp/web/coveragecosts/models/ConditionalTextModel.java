package org.kp.web.coveragecosts.models;



/**
 * The Class ConditionalTextModel.
 */
public class ConditionalTextModel {
	/** The text and text id for conditional texts. */
	private String textid;
	private String text;
	
	
	public ConditionalTextModel(String textid, String text){
		this.textid = textid;
		this.text = text;
	}
	
	/**
	 * Gets the text id.
	 * 
	 * @return the text id
	 */
	public String getTextId() {
		return textid;
	}

	/**
	 * Sets the text id.
	 *
	 * @param text id 
	 *            the new text id value
	 */
	public void setTextId(String textid) {
		this.textid = textid;
	}

	/**
	 * Gets the text.
	 * 
	 * @return the text
	 */
	public String getText() {
		return text;
	}

	/**
	 * Sets the text.
	 *
	 * @param text 
	 *            the new text value
	 */

	public void setText(String text) {
		this.text = text;
	}
	

	@Override
	public String toString() {
		return "ConditionalTextModel [text id=" + textid + ", text=" + text + "]";
	}

}
package org.kp.web.coveragecosts.use;

import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.google.gson.JsonObject;

/**
 * @author Devi Anala
 */

public class FeedContainerUseMCC extends WCMUsePojo {
    private static final Logger LOGGER = LoggerFactory.getLogger(FeedContainerUseMCC.class);
    private String TOTAL_DUE_LABEL = "totalDueLabel";
    private String totalDueLabel;

    @Override
    public void activate() throws Exception {
        ValueMap props= getProperties();
        totalDueLabel=props.get(TOTAL_DUE_LABEL,"");
    }

    public String getJSON() {
    	JsonObject jsonObject = new JsonObject();
		try {	
				jsonObject.addProperty(TOTAL_DUE_LABEL, totalDueLabel);								
			} 
		catch (Exception e){
				  LOGGER.error("Error in getJSON:"+ e.getMessage());
			}
			return (jsonObject.isJsonNull()==true ? "" : jsonObject.toString());
    }

    public String getTotalDueLabel() { return totalDueLabel; }
}
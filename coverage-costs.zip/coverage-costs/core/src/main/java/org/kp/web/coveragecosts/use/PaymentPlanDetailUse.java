package org.kp.web.coveragecosts.use;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.google.gson.JsonObject;

/**
 * PaymentPlanDetailUse class is responsible to read the authored content for Payment Plan Detail.
 * 
 * @author Jai Parkash
 *
 */

public class PaymentPlanDetailUse extends WCMUsePojo {
  private static final Logger LOGGER = LoggerFactory.getLogger(PaymentPlanDetailUse.class);
  private boolean debugEnabled = LOGGER.isDebugEnabled();
  
  private static final String ACCOUNT_LABEL = "accountlabel";
  private static final String HOSPITAL_BILL_PMT_PLAN_LABEL = "hospbillpmtplanlabel";
  private static final String PROFESIONAL_BILL_PMT_PLAN_LABEL = "profbillpmtplanlabel";
  private static final String HOSPITAL_PROFESIONAL_BILL_PMT_PLAN_LABEL = "hospprofbillpmtplanlabel";
  private static final String RECURRING_BILL_PMT_PLAN_LABEL = "recurringbillpmtplanlabel";
  private static final String NEXT_PMT_PLAN_LABEL = "nextpmtplanlabel";
  private static final String BEG_PLAN_BAL_LABEL = "begplanballabel";
  private static final String PMT_PLAN_START_DATE_LABEL = "pmtplanstartdatelabel";
  private static final String REMAINING_BAL_LABEL = "remainballabel";
  private static final String PMT_PLAN_DETAILS_DESC_LABEL = "pmtplandetailsdesc";

  private static final String JSON_COMP_NAME = "compname"; 
  private static final String JSON_ACCOUNT_LABEL_ATTR = "accountlabel";
  private static final String JSON_HOSPITAL_BILL_PMT_PLAN_LABEL_ATTR = "hospbillpmtplanlabel";
  private static final String JSON_PROFESIONAL_BILL_PMT_PLAN_LABEL_ATTR = "profbillpmtplanlabel";
  private static final String JSON_HOSPITAL_PROFESIONAL_BILL_PMT_PLAN_LABEL_ATTR = "hospprofbillpmtplanlabel";
  private static final String JSON_RECURRING_BILL_PMT_PLAN_LABEL_ATTR = "recurringbillpmtplanlabel";
  private static final String JSON_NEXT_PMT_PLAN_LABEL_ATTR = "nextpmtplanlabel";
  private static final String JSON_BEG_PLAN_BAL_LABEL_ATTR = "begplanballabel";
  private static final String JSON_PMT_PLAN_START_DATE_LABEL_ATTR = "pmtplanstartdatelabe";
  private static final String JSON_REMAINING_BAL_LABEL_ATTR = "remainballabel";
  private static final String JSON_PMT_PLAN_DETAILS_DESC_LABEL_ATTR = "pmtplandetailsdesc";
  
  
  private  String componentText; // to  return the text property value

  private  String compName="";
  private  String accountLabel="";
  private  String hospBillPMTPlanLabel="";
  private  String profBillPMTPlanLabel="";
  private  String hospProfBillPMTPlanLabel="";
  private  String recurringBillPMTPlanLabel="";
  private  String nextPMTPlanLabel="";
  private  String begPlanBalLabel="";  
  private  String pmtPlanStartDateLabel="";  
  private  String remainBalLabel="";  
  private  String pmtPlanDetailsDesc="";  

  
  @Override
  public void activate() throws Exception {
  	if (debugEnabled)
		LOGGER.debug("Activating");
    try{
    	Resource resource = getResource();
    	compName=resource.getName();
    	componentText = "";
    	
        ValueMap props =   getProperties();
        accountLabel = props.get(ACCOUNT_LABEL, "");
        hospBillPMTPlanLabel = props.get(HOSPITAL_BILL_PMT_PLAN_LABEL, "");                
        profBillPMTPlanLabel = props.get(PROFESIONAL_BILL_PMT_PLAN_LABEL, "");        
        hospProfBillPMTPlanLabel = props.get(HOSPITAL_PROFESIONAL_BILL_PMT_PLAN_LABEL, "");
        recurringBillPMTPlanLabel = props.get(RECURRING_BILL_PMT_PLAN_LABEL, "");                
        nextPMTPlanLabel = props.get(NEXT_PMT_PLAN_LABEL, "");       
        begPlanBalLabel = props.get(BEG_PLAN_BAL_LABEL, "");
        pmtPlanStartDateLabel = props.get(PMT_PLAN_START_DATE_LABEL, "");                
        remainBalLabel = props.get(REMAINING_BAL_LABEL, "");      
        pmtPlanDetailsDesc = props.get(PMT_PLAN_DETAILS_DESC_LABEL, "");   
        
    } catch (Exception e){
    	LOGGER.error("Exception while loading PaymentPlanDetailUse:" + e.getMessage());
    }
	if (debugEnabled)
		LOGGER.debug("Done -- Activating");
 
  }

  /**
   * This method is responsible for to get the String representation.
   * 
   * @return String
   */
  public String getComponentText() {
    return componentText;
  }

  /**
   * This method is responsible for to get the account label.
   * 
   * @return String
   * 	is content authored account label text.
   */
   public String getAccountLabel() {
	    return accountLabel;
   }
   
  /**
   * This method is responsible for to get hospital bill pmt plan label label.
   * 
   * @return String
   * 	is content authored hospital bill pmt plan label text.
   */
   public String getHospBillPMTPlanLabel() {
	    return hospBillPMTPlanLabel;
   }
   
   /**
    * This method is responsible for to get professional bill payment plan.
    * 
    * @return String
    * 	is content authored professional bill payment plan label text.
    */
    public String getProfBillPMTPlanLabel() {
 	    return profBillPMTPlanLabel;
    }
    
   /**
    * This method is responsible for to get professional hospital bill payment plan label.
    * 
    * @return String
    * 	is content authored professional hospital bill payment plan label text.
    */
    public String getHospProfBillPMTPlanLabel() {
 	    return hospProfBillPMTPlanLabel;
    } 
     
    /**
     * This method is responsible for to get recurring bill payment plan label.
     * 
     * @return String
     * 	is content authored recurring bill payment plan label text.
     */
     public String getRecurringBillPMTPlanLabel() {
  	    return recurringBillPMTPlanLabel;
     } 
 
     
     /**
      * This method is responsible for to get next payment plan label.
      * 
      * @return String
      * 	is content authored next payment plan label text.
      */
      public String getNextPMTPlanLabel() {
   	    return nextPMTPlanLabel;
      }  
            
      /**
       * This method is responsible for to get beginning plan balance label.
       * 
       * @return String
       * 	is content authored beginning plan balance label text.
       */
       public String getBegPlanBalLabel() {
    	    return begPlanBalLabel;
       }       
    
       /**
        * This method is responsible for to get payment plan start date label.
        * 
        * @return String
        * 	is content authored payment plan start date label text.
        */
        public String getPmtPlanStartDateLabel() {
     	    return pmtPlanStartDateLabel;
        }    
               
        /**
         * This method is responsible for to remaining balance label.
         * 
         * @return String
         * 	is content authored remaining balance label text.
         */
         public String getRemainBalLabel() {
      	    return remainBalLabel;
         }       

         /**
          * This method is responsible for to payment plan details description label.
          * 
          * @return String
          * 	is content authored payment plan details description label text.
          */
          public String getPmtPlanDetailsDesc() {
       	    return pmtPlanDetailsDesc;
          } 
          
	  /**
	   * Return the JSON representation of content authored data
	   * 
	   * @return String
	   */
          public String getJSON() {
          	JsonObject jsonObject = new JsonObject();
      		try {	
      				jsonObject.addProperty(JSON_COMP_NAME, compName);					
      				jsonObject.addProperty(JSON_ACCOUNT_LABEL_ATTR, accountLabel);
      				jsonObject.addProperty(JSON_HOSPITAL_BILL_PMT_PLAN_LABEL_ATTR, hospBillPMTPlanLabel);
      				jsonObject.addProperty(JSON_PROFESIONAL_BILL_PMT_PLAN_LABEL_ATTR, profBillPMTPlanLabel);
      				jsonObject.addProperty(JSON_HOSPITAL_PROFESIONAL_BILL_PMT_PLAN_LABEL_ATTR, hospProfBillPMTPlanLabel);
      				jsonObject.addProperty(JSON_RECURRING_BILL_PMT_PLAN_LABEL_ATTR, recurringBillPMTPlanLabel);
      				jsonObject.addProperty(JSON_NEXT_PMT_PLAN_LABEL_ATTR, nextPMTPlanLabel);
      				jsonObject.addProperty(JSON_BEG_PLAN_BAL_LABEL_ATTR, begPlanBalLabel);
      				jsonObject.addProperty(JSON_PMT_PLAN_START_DATE_LABEL_ATTR, pmtPlanStartDateLabel);
      				jsonObject.addProperty(JSON_REMAINING_BAL_LABEL_ATTR, remainBalLabel);
      				jsonObject.addProperty(JSON_PMT_PLAN_DETAILS_DESC_LABEL_ATTR, pmtPlanDetailsDesc);
      			} catch (Exception e){
      				  LOGGER.error("Error in getJSON:"+ e.getMessage());
      			}
      			return (jsonObject.isJsonNull()==true ? "" : jsonObject.toString());
        	
        	  }
 
}

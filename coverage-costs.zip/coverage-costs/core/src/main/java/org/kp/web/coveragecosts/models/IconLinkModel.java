package org.kp.web.coveragecosts.models;


/**
 * The Class IconLinkModel.
 */
public class IconLinkModel {
	  //iconLinkId, componentStyle, titleIcon, title, subTitle, linkLabel, linkPath, linkTarget, linkNoFollow

	/** icon link id */
	private String iconLinkId;

	/** The icon link style */
	private String componentStyle;
	
	/** The icon link icon */
	private String titleIcon;

	/** The icon link title */
	private String title;

	/** The icon link sub title */
	private String subTitle;

	/** The icon link label */
	private String linkLabel;
	
	/** The icon link path */
	private String linkPath;
	
	/** The icon link target */
	private String linkTarget;

	/** The icon link no follow */
	private String linkNoFollow;
	
	/**
	 * Class Constructor
	 * 	 
	 */
	
	public IconLinkModel(String iconLinkId ){
			this.iconLinkId = iconLinkId;

	}
	
	
	/**
	 * Gets the icon link id.
	 * 
	 * @return the icon link id
	 */
	public String getIconLinkId() {
		return iconLinkId;
	}

	/**
	 * Gets the icon link style.
	 * 
	 * @return the componentStyle
	 */
	public String getComponentStyle() {
		return componentStyle;
	}

	/**
	 * Gets the icon link icon.
	 * 
	 * @return the titleIcon
	 */
	public String getTitleIcon() {
		return titleIcon;
	}

	/**
	 * Gets the icon link title .
	 * 
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Gets the icon sub title.
	 * 
	 * @return the subTitle
	 */
	public String getSubTitle() {
		return subTitle;
	}

	/**
	 * Gets the icon link label.
	 * 
	 * @return the linkLabel
	 */
	public String getLinkLabel() {
		return linkLabel;
	}

	/**
	 * Gets the icon link path.
	 * 
	 * @return the linkPath
	 */
	public String getLinkPath() {
		return linkPath;
	}

	/**
	 * Gets the icon link target.
	 * 
	 * @return the linkTarget
	 */
	public String getLinkTarget() {
		return linkTarget;
	}

	/**
	 * Gets the icon link no follow.
	 * 
	 * @return the linkNoFollow
	 */
	public String geLinkNoFollow() {
		return linkNoFollow;
	}
	
	
	
	
	/**
	 * Sets the link id.
	 * 
	 * @param iconLinkId
	 *            the new link id
	 */
	public void setIconLinkId(String iconLinkId) {
		this.iconLinkId = iconLinkId;
	}

	/**
	 * Sets the link style.
	 * 
	 * @param componentStyle
	 *            the new link style
	 */
	public void setComponentStyle(String componentStyle) {
		this.componentStyle = componentStyle;
	}
	
	/**
	 * Sets the link icon.
	 * 
	 * @param titleIcon
	 *            the new link icon
	 */
	public void setTitleIcon(String titleIcon) {
		this.titleIcon = titleIcon;
	}

	/**
	 * Sets the link title.
	 * 
	 * @param title
	 *            the new link title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * Sets the link sub title.
	 * 
	 * @param subTitle
	 *            the new link sub title
	 */
	public void setSubTitle(String subTitle) {
		this.subTitle = subTitle;
	}

	/**
	 * Sets the link link label.
	 * 
	 * @param linkLabel
	 *            the new link link label
	 */
	public void setLinkLabel(String linkLabel) {
		this.linkLabel = linkLabel;
	}
	
	/**
	 * Sets the link path.
	 * 
	 * @param linkPath
	 *            the new link path
	 */
	public void setLinkPath(String linkPath) {
		this.linkPath = linkPath;
	}	

	/**
	 * Sets the link target.
	 * 
	 * @param linkTarget
	 *            the new link target
	 */
	public void setLinkTarget(String linkTarget) {
		this.linkTarget = linkTarget;
	}

	/**
	 * Sets the link no follow.
	 * 
	 * @param linkNoFollow
	 *            the new link no follow
	 */
	public void setLinkNoFollow(String linkNoFollow) {
		this.linkNoFollow = linkNoFollow;
	}

	@Override
	public String toString() {
		return "IconLinkModel [iconLinkId=" + iconLinkId + ", componentStyle=" + componentStyle
				+ ", titleIcon=" + titleIcon + ", title=" + title + ", subTitle=" + subTitle
				+ ", linkLabel=" + linkLabel + ", linkPath=" + linkPath + ", linkTarget=" + linkTarget
				+ ", linkNoFollow="+ linkNoFollow + "]";
	}

}
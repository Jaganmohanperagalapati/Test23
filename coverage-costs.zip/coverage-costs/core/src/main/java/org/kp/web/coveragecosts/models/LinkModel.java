package org.kp.web.coveragecosts.models;

/**
 * The Class LinkModel.
 */
public class LinkModel {
	/** The resource link Language for ADA. */
	private String linkLanguage;

	public String getLinkLanguage() {
		return linkLanguage;
	}

	public void setLinkLanguage(String linkLanguage) {
		this.linkLanguage = linkLanguage;
	}


	/** The resource link. */
	private String resourceLink;

	/** The display text. */
	private String displayText;

	/** Open In New Window. */
	private String target;

	/** Context attribute for sightly href. Default value is uri. */
	private String context = "uri";

	/**
	 * Gets the resource link.
	 * 
	 * @return the resource link
	 */
	public String getResourceLink() {
		return resourceLink;
	}

	/**
	 * Gets the display text.
	 * 
	 * @return the display text
	 */
	public String getDisplayText() {
		return displayText;
	}

	/**
	 * Gets the target.
	 *
	 * @return the target
	 */
	public String getTarget() {
		return target;
	}

	/**
	 * Gets the context value.
	 *
	 * @return the context value
	 */
	public String getContext() { return context; }

	/**
	 * Sets the resource link.
	 * 
	 * @param resourceLink
	 *            the new resource link
	 */
	public void setResourceLink(String resourceLink) {
		this.resourceLink = resourceLink;
	}

	/**
	 * Sets the display text.
	 * 
	 * @param displayText
	 *            the new display text
	 */
	public void setDisplayText(String displayText) {
		this.displayText = displayText;
	}

	/**
	 * Sets the target.
	 *
	 * @param target
	 *            the new target
	 */
	public void setTarget(String target) {
		this.target = target;
	}

	/**
	 * Sets the context.
	 *
	 * @param context
	 *            the new context
	 */
	public void setContext(String context) { this.context = context; }


	@Override
	public String toString() {
		return "LinkModel [linkLanguage=" + linkLanguage + ", resourceLink=" + resourceLink + ", displayText="
				+ displayText + ", target=" + target + ", context=" + context + "]";
	}

}
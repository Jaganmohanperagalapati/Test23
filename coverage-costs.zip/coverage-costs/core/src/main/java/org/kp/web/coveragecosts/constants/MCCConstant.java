package org.kp.web.coveragecosts.constants;

public class MCCConstant {
	 public static final String DISPLAY ="";
	 public static final String DISPLAY_NONE = "display:none";
	 private MCCConstant() {
		    throw new IllegalStateException("Utility class");
	 }
}

package org.kp.web.coveragecosts.use;

import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.google.gson.JsonObject;

/**
 * @author Devi Anala
 */

public class IconLinkUseMCC extends WCMUsePojo {
    private static final Logger LOGGER = LoggerFactory.getLogger(IconLinkUseMCC.class);
    private boolean debugEnabled = LOGGER.isDebugEnabled();

    private String TITLE_ICON = "titleIcon";
    private String P_BILL_TYPE = "pBillType";
    private String H_BILL_TYPE = "hBillType";
    private String PH_BILL_TYPE = "phBillType";
    private String BILL_DATE = "billDate";
    private String DUE_DATE = "dueDate";
    private String VIEW_BILL_LABEL = "viewBillLabel";
    private String PAY_BILL_LABEL = "payBillLabel";
    private String ACC_BILL_LABEL = "accBillLabel";
    private String PAY_BILL_PATH = "payBillPath";
    private String VIEW_PAYMENT_PLAN_LABEL = "viewPaymentPlanLabel";
    private String TOOL_TIP_MODAL = "toolTipModal";
    private String PATIENT_ACCOUNT = "patientAccount";
    private String CHARGES = "charges";
    private String ADJUSTMENTS = "adjustments";
    private String PAID_BY_YOU = "paidByYou";
    private String AMT_YOU_OWE = "amtYouOwe";
    private String CHARGES_MOBILE = "chargesMobile";
    private String ADJUSTMENTS_MOBILE = "adjustmentsMobile";
    private String PAID_BY_YOU_MOBILE = "paidByYouMobile";
    private String AMT_YOU_OWE_MOBILE = "amtYouOweMobile";
    private String DUE = "due";
    private String PAY_BILLS_LABEL = "payBillsLabel";

    private String titleIcon;
    private String pBillType;
    private String hBillType;
    private String phBillType;
    private String billDate;
    private String dueDate;
    private String viewBillLabel;
    private String payBillLabel;
    private String payBillPath;
    private String accBillLabel;
    private String viewPaymentPlanLabel;
    private String toolTipModal;
    private String patientAccount;
    private String chargesAmt;
    private String adjustmentsAmt;
    private String paidByYou;
    private String amtYouOwe;
    private String chargesMobile;
    private String adjustmentsMobile;
    private String paidByYouMobile;
    private String amtYouOweMobile;
    private String dueAmt;
    private String payBillsLabel;

    @Override
    public void activate() throws Exception {
        if (debugEnabled)
            LOGGER.debug("Activating");
        ValueMap props= getProperties();
        titleIcon=props.get(TITLE_ICON,"");
        pBillType=props.get(P_BILL_TYPE,"");
        hBillType=props.get(H_BILL_TYPE,"");
        phBillType=props.get(PH_BILL_TYPE,"");
        billDate=props.get(BILL_DATE,"");
        dueDate=props.get(DUE_DATE,"");
        viewBillLabel=props.get(VIEW_BILL_LABEL,"");
        payBillLabel=props.get(PAY_BILL_LABEL,"");
        payBillPath=props.get(PAY_BILL_PATH,"");
        accBillLabel=props.get(ACC_BILL_LABEL,"");
        viewPaymentPlanLabel=props.get(VIEW_PAYMENT_PLAN_LABEL,"");
        toolTipModal=props.get(TOOL_TIP_MODAL,"");
        patientAccount=props.get(PATIENT_ACCOUNT,"");
        chargesAmt=props.get(CHARGES,"");
        adjustmentsAmt=props.get(ADJUSTMENTS,"");
        paidByYou=props.get(PAID_BY_YOU,"");
        amtYouOwe=props.get(AMT_YOU_OWE,"");
        chargesMobile=props.get(CHARGES_MOBILE,"");
        adjustmentsMobile=props.get(ADJUSTMENTS_MOBILE,"");
        paidByYouMobile=props.get(PAID_BY_YOU_MOBILE,"");
        amtYouOweMobile=props.get(AMT_YOU_OWE_MOBILE,"");
        dueAmt=props.get(DUE,"");
        payBillsLabel=props.get(PAY_BILLS_LABEL,"");
        if (debugEnabled)
            LOGGER.debug("View Payment PLan Label =" + viewPaymentPlanLabel);
        LOGGER.debug("Tool Tip Modal =" + toolTipModal);
        LOGGER.debug("Paid By You Label =" + paidByYouMobile);
    }

	  public String getJSON() {
		  JsonObject jsonObject = new JsonObject();
			try {	
					jsonObject.addProperty(TITLE_ICON, titleIcon);	
					jsonObject.addProperty(P_BILL_TYPE, pBillType);	
					jsonObject.addProperty(H_BILL_TYPE, hBillType);	
					jsonObject.addProperty(PH_BILL_TYPE, phBillType);	
					jsonObject.addProperty(BILL_DATE, billDate);	
					jsonObject.addProperty(DUE_DATE, dueDate);	
					jsonObject.addProperty(VIEW_BILL_LABEL, viewBillLabel);	
					jsonObject.addProperty(PAY_BILL_LABEL, payBillLabel);	
					jsonObject.addProperty(PAY_BILL_PATH, payBillPath);	
					jsonObject.addProperty(ACC_BILL_LABEL, accBillLabel);
					
					jsonObject.addProperty(VIEW_PAYMENT_PLAN_LABEL, viewPaymentPlanLabel);	
					jsonObject.addProperty(TOOL_TIP_MODAL, toolTipModal);	
					jsonObject.addProperty(PATIENT_ACCOUNT, patientAccount);	
					jsonObject.addProperty(CHARGES, chargesAmt);	
					jsonObject.addProperty(ADJUSTMENTS, adjustmentsAmt);	
					jsonObject.addProperty(PAID_BY_YOU, paidByYou);	
					jsonObject.addProperty(AMT_YOU_OWE, amtYouOwe);	
					jsonObject.addProperty(CHARGES_MOBILE, chargesMobile);	
					jsonObject.addProperty(ADJUSTMENTS_MOBILE, adjustmentsMobile);	
					jsonObject.addProperty(PAID_BY_YOU_MOBILE, paidByYouMobile);
					jsonObject.addProperty(AMT_YOU_OWE_MOBILE, amtYouOweMobile);	
					jsonObject.addProperty(DUE, dueAmt);	
					jsonObject.addProperty(PAY_BILLS_LABEL, payBillsLabel);
					
				} catch (Exception e){
					  LOGGER.error("Error in getJSON:"+ e.getMessage());
				}
				return (jsonObject.isJsonNull()==true ? "" : jsonObject.toString());
	
	}



    public String getTitleIcon() {
        return titleIcon;
    }

    public String getPBillType() { return pBillType; }

    public String getHBillType() {
        return hBillType;
    }

    public String getPhBillType() {
        return phBillType;
    }

    public String getBillDate() {
        return billDate;
    }

    public String getDueDate() {
        return dueDate;
    }

    public String getViewBillLabel() {
        return viewBillLabel;
    }

    public String getPayBillLabel() {
        return payBillLabel;
    }

    public String getPayBillPath() { return payBillPath; }

    public String getAccBillLabel() {
        return accBillLabel;
    }

    public String getViewPaymentPlanLabel()  {  return viewPaymentPlanLabel; }

    public String getToolTipModal()  {  return toolTipModal;  }

    public String getPatientAccount() {
        return patientAccount;
    }

    public String getCharges() {
        return chargesAmt;
    }

    public String getAdjustments() {
        return adjustmentsAmt;
    }

    public String getPaidByYou() {
        return paidByYou;
    }

    public String getAmtYouOwe() {
        return amtYouOwe;
    }

    public String getChargesMobile() {
        return chargesMobile;
    }

    public String getAdjustmentsMobile() {
        return adjustmentsMobile;
    }

    public String getPaidByYouMobile() {
        return paidByYouMobile;
    }

    public String getAmtYouOweMobile() {
        return amtYouOweMobile;
    }

    public String getDue() {
        return dueAmt;
    }

    public String getPayBillsLabel() {
        return payBillsLabel;
    }
}
package org.kp.web.coveragecosts.models;

/**
 * The Class AngularTemplate Model. Used by Angular Template Handler
 */
public class AngularTemplateModel {

	/** The template ID. */
	private String templateID;

	/** The template path. */
	private String templatePath;

	
	/**
	 * Gets the template ID.
	 * 
	 * @return the template ID
	 */
	public String getTemplateID() {
		return templateID;
	}

	/**
	 * Gets the template path.
	 * 
	 * @return the template path.
	 */
	public String getTemplatePath() {
		return templatePath;
	}

	
	/**
	 * Sets the template ID.
	 * 
	 * @param templateID
	 *            the new template ID
	 */
	public void setTemplateID(String templateID) {
		this.templateID = templateID;
	}

	/**
	 * Sets the template path.
	 * 
	 * @param templatePath
	 *            the new template path 
	 */
	public void setTemplatePath(String templatePath) {
		this.templatePath = templatePath;
	}

	@Override
	public String toString() {
		return "AngularTemplateModel [Template ID=" + templateID + ", Template Path =" + templatePath + "]";
	}

}
package org.kp.web.coveragecosts.use;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.kp.web.coveragecosts.models.IconLinkModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

/**
 * FeedContainerRightRailUse class is TBD.
 * 
 * @author Jai Parkash
 *
 */

public class FeedContainerRightRailUse extends WCMUsePojo {
  private static final Logger LOGGER = LoggerFactory.getLogger(FeedContainerRightRailUse.class);
  private boolean debugEnabled = LOGGER.isDebugEnabled();
  
  private static final String BODY_PAR = "bodypar";
  private static final String CONTAINED_COMPS_NAME = "icon_links";
  
  private static final String JSON_COMP_NAME = "compname"; 
  //iconLinkId, componentStyle, titleIcon, title, subTitle, linkLabel, linkPath, linkTarget, linkNoFollow

  private String componentText;
  private String compName;
  private List<IconLinkModel> iconLinkList = new ArrayList<IconLinkModel>();

  //iconLinkId, componentStyle, titleIcon, title, subTitle, linkLabel, linkPath, linkTarget, linkNoFollow
  private String PROP_ICON_LINK_ID="iconLinkId";
  private String PROP_COMPONENT_STYLE="componentStyle";
  private String PROP_TITLE_ICON="titleIcon";
  private String PROP_TITLE="title";
  private String PROP_SUB_TITLE="subTitle";
  private String PROP_LINK_LABEL="linkLabel";
  private String PROP_LINK_PATH="linkPath";
  private String PROP_LINK_TARGET="linkTarget";
  private String PROP_LINK_NO_FOLLOW="linkNoFollow";
  

  @Override
  public void activate() throws Exception {
  	if (debugEnabled)
		LOGGER.debug("Activating");
    try{
    	compName=getResource().getName();
    	componentText = "";
	    
	    //Iterate through each component placed in the parsys
    	Resource compParSys = getResource().getChild(BODY_PAR);
    	if (null != compParSys){
    		// Iterate
    		Iterator<Resource> childComps = compParSys.listChildren();
    		while (childComps.hasNext()) {
                Resource child = childComps.next();
                ValueMap props = child.getValueMap();
                String linkId = props.get(PROP_ICON_LINK_ID, "");
                String componentStyle = props.get(PROP_COMPONENT_STYLE, "");                
                String titleIcon = props.get(PROP_TITLE_ICON, "");
                String title = props.get(PROP_TITLE, "");
                String subTitle = props.get(PROP_SUB_TITLE, "");
                String linkLabel = props.get(PROP_LINK_LABEL, "");
                String linkPath = props.get(PROP_LINK_PATH, "");
                String linkTarget = props.get(PROP_LINK_TARGET, "");
                String linkNoFollow = props.get(PROP_LINK_NO_FOLLOW, "");                
               
                IconLinkModel link= new IconLinkModel (linkId);
                link.setComponentStyle(componentStyle);
                link.setTitleIcon(titleIcon);
                link.setTitle(title);
                link.setSubTitle(subTitle);
                link.setLinkLabel(linkLabel);
                link.setLinkPath(linkPath);
                link.setLinkTarget(linkTarget);
                link.setLinkNoFollow(linkNoFollow);
                
                iconLinkList.add(link);

                String delimter ="";
	            if (!componentText.isEmpty()) {  delimter =";";}
	            componentText = componentText+delimter+link.toString();

                
            }
    		
    	} else {
    		// No Parsys in component node.  generally means that the component has not been authored.
    		
    	}
    } catch (Exception e){
    	LOGGER.error("Exception while loading FeedContainerRightRailUse:" + e.getMessage());
    }
	if (debugEnabled)
		LOGGER.debug("Done -- Activating");
 
  }

  /**
   * This method is responsible for to get the String representation.
   * 
   * @return String
   */
  public String getComponentText() {
    return componentText;
  }

  /**
   * This method is responsible for to get the Icon Links as a List of IconLinkModel Items.
   * 
   * @return List<IconLinkModel>
   * 	is a list of IconLinkModel representing various configure Icon Links comps.
   */
  public List<IconLinkModel> getIconLinkList() {
	    return iconLinkList;
  }
  
  /**
   * Return the JSON representation of content author data
   * 
   * @return String
   */
  public String getJSON() {
		JsonObject jsonObject = new JsonObject();
		try {	
				jsonObject.addProperty(JSON_COMP_NAME, compName);					
				JsonArray jsonArray = new JsonArray();
				for (IconLinkModel link : iconLinkList) {
					JsonObject jsonObjectInner = new JsonObject();
					jsonObjectInner.addProperty(PROP_ICON_LINK_ID, link.getIconLinkId());
					jsonObjectInner.addProperty(PROP_COMPONENT_STYLE, link.getComponentStyle());
					jsonObjectInner.addProperty(PROP_TITLE_ICON, link.getTitleIcon());
					jsonObjectInner.addProperty(PROP_TITLE, link.getTitle());
					jsonObjectInner.addProperty(PROP_SUB_TITLE, link.getSubTitle());
					jsonObjectInner.addProperty(PROP_LINK_LABEL, link.getLinkLabel());
					jsonObjectInner.addProperty(PROP_LINK_PATH, link.getLinkPath());
					jsonObjectInner.addProperty(PROP_LINK_TARGET, link.getLinkTarget());
					jsonObjectInner.addProperty(PROP_LINK_NO_FOLLOW, link.geLinkNoFollow());
					
					jsonArray.add(jsonObjectInner);
			    }
				
				jsonObject.add(CONTAINED_COMPS_NAME, jsonArray);
			
			} catch (Exception e){
				  LOGGER.error("Error in getJSON:"+ e.getMessage());
			}
			return (jsonObject.isJsonNull()==true ? "" : jsonObject.toString());

  	}
 
}

package org.kp.web.coveragecosts.use;

import java.util.ArrayList;
import java.util.List;

import org.kp.foundation.core.models.LinkModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * ConditionalButtonUse class is responsible to read the authored content for the Conditional Button component.
 * 
 * @author Jai Parkash 
 *
 */

public class ConditionalButtonUse extends WCMUsePojo {
  private static final Logger LOGGER = LoggerFactory.getLogger(ConditionalButtonUse.class);
  
  private static final String CONDITIONAL_BUTTONS = "conditionalBtns";
  
  private static final String BUTTON_TEXT = "btnText";
  private static final String BUTTON_PATH = "btnPath";
  private static final String BUTTON_TARGET = "btnTarget";
  
  private static final String JSON_ATT_BUTTON_TEXT = "text";
  private static final String JSON_ATT_BUTTON_PATH = "path";
  private static final String JSON_ATT_BUTTON_TARGET = "target";
  
  private static final String JSON_COMP_NAME = "compname"; 
  
  private  String conditionalbutton; // to  return the text propery value
  private  String[] conditionalbuttons;// Read multifield propery values
  
  private  List<LinkModel> conditionalBtnsList= new ArrayList<LinkModel>();
  private  String compName="";

  @Override
  public void activate() throws Exception {

    LOGGER.debug("Activating");
    try{
    	compName=getResource().getName();
		
	    conditionalbutton = "";
	    conditionalbuttons = getProperties().get(CONDITIONAL_BUTTONS, String[].class);
	    
	    if (conditionalbuttons!=null && conditionalbuttons.length >0){
		    for (String s : conditionalbuttons) {

	    		if (!s.isEmpty()){
	    			JsonObject jObject = new JsonParser().parse(s).getAsJsonObject();
		    		String text = jObject.get(BUTTON_TEXT).toString();
		            String path = jObject.get(BUTTON_PATH).toString();
		            String target = jObject.get(BUTTON_TARGET).toString();
		            String delimter ="";
		            if (!conditionalbutton.isEmpty()) {  delimter =",";}
		            conditionalbutton = conditionalbutton+delimter+s;

		            LinkModel condButtonLink = new LinkModel();
		            condButtonLink.setDisplayText(text);
		            // This is not needed as this is done in sigthly code for component.
		            condButtonLink.setResourceLink(path);
		            condButtonLink.setTarget(target);
		            conditionalBtnsList.add(condButtonLink);
	    		} else {
	    			LOGGER.error("The property {0} is empty.", CONDITIONAL_BUTTONS);
	    		}	    	    
	    	}
	
	    }
    } catch (Exception e){
    	LOGGER.error("Exception while loading ConditionalButtonUse:" + e.getMessage());
    }
    LOGGER.debug("Done -- Activating");

  }

  /**
   * This method is responsible for to get the CONDITIONAL BUTTONS String.
   * 
   * @return String
   */
  public String getConditionalTexts() {
    return conditionalbutton;
  }

  /**
   * This method is responsible  to get the CONDITIONAL BUTTONS as a List of LinkModel Items.
   * 
   * @return List<LinkModel>
   * 	is a list of LinkModel representing various button text, path  and target.
   */
  public List<LinkModel> getConditionalButtonsList() {
	    return conditionalBtnsList;
  }
  
  /**
   * Return the JSON representation of content author data
   * 
   * @return String
   */
	public String getJSON() {
		JsonObject jsonObject = new JsonObject();
		try {
	
				jsonObject.addProperty(JSON_COMP_NAME, compName);
						
				JsonArray jsonArray = new JsonArray();
				for (LinkModel condBtn : conditionalBtnsList) {
					JsonObject jsonObjectInner = new JsonObject();
					jsonObjectInner.addProperty(JSON_ATT_BUTTON_TEXT, condBtn.getDisplayText());
					jsonObjectInner.addProperty(JSON_ATT_BUTTON_PATH, condBtn.getResourceLink());
					jsonObjectInner.addProperty(JSON_ATT_BUTTON_TARGET, condBtn.getTarget());
					jsonArray.add(jsonObjectInner);
			    }
				
				jsonObject.add(CONDITIONAL_BUTTONS, jsonArray);
			
			} catch (Exception e){
				  LOGGER.error("Error in getJSON:"+ e.getMessage());
			}
			return (jsonObject.isJsonNull()==true ? "" : jsonObject.toString());	
	}
 
}

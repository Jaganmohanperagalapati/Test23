package org.kp.web.coveragecosts.use;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import org.apache.sling.commons.json.JSONObject;
import org.kp.web.coveragecosts.models.ConditionalTextModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.commons.TidyJSONWriter;

/**
 * ConditionalDescUse class is responsible to read the authored content for the Conditional Description Use component.
 * 
 * @author Jai Parkash
 *
 */

public class ConditionalDescUse extends WCMUsePojo {
  private static final Logger LOGGER = LoggerFactory.getLogger(ConditionalDescUse.class);
  
  private static final String CONDITIONAL_TEXTS = "conditionaltexts";
  private static final String CONDITIONAL_TEXT_ID = "textid";  
  private static final String CONDITIONAL_TEXT = "text";  

  private static final String JSON_COMP_NAME = "compname"; 
  
  
  private  String[] conditionaltexts;
  private  String conditionaltext;
  private  List<ConditionalTextModel> conditionalTextsList= new ArrayList<ConditionalTextModel>();
  private  String compName="";

  @Override
  public void activate() throws Exception {
    LOGGER.debug("Activating");
    try{
    	compName=getResource().getName();
	    conditionaltext = "";
	    conditionaltexts = getProperties().get(CONDITIONAL_TEXTS, String[].class);
	    if (conditionaltexts!=null && conditionaltexts.length >0){
		    for (String s : conditionaltexts) {
		    	if (!s.isEmpty()){
		    		JSONObject jObject = new JSONObject(s);
		    		String id = jObject.get(CONDITIONAL_TEXT_ID).toString();
		            String value = jObject.get(CONDITIONAL_TEXT).toString();
		            String delimter ="";
		            if (!conditionaltext.isEmpty()) {  delimter =",";}
		            conditionaltext = conditionaltext+delimter+s;
		            ConditionalTextModel condtext = new ConditionalTextModel(id, value);
		            conditionalTextsList.add(condtext);
	    		} else {
	    			LOGGER.error("The property {0} is empty.", CONDITIONAL_TEXTS);
	    		}
	    	    
	    	}
	
	    }
    } catch (Exception e){
    	LOGGER.error("Exception while loading ConditionalDescUse:" + e.getMessage());
    }
    LOGGER.debug("Done -- Activating");
 
  }

  /**
   * This method is responsible for to get the CONDITIONAL TEXTS String.
   * 
   * @return String
   */
  public String getConditionalTexts() {
    return conditionaltext;
  }

  /**
   * This method is responsible for to get the CONDITIONAL TEXTS as a List of ConditionalText Items.
   * 
   * @return List<ConditionalTextModel>
   * 	is a list of ConditionalTextModel representing various textid and text.
   */
  public List<ConditionalTextModel> getConditionalTextsList() {
	    return conditionalTextsList;
  }
  
  /**
   * Return the JSON representation of content author data
   * 
   * @return String
   */
  public String getJSON() {
	    // write JSON string o/p iterating over the list of ConditionalTextModel
	  StringWriter wrt = new StringWriter();
      TidyJSONWriter jsonWriter = new TidyJSONWriter(wrt);
      jsonWriter.setTidy(true);
      try {      
	      jsonWriter.object();
	      jsonWriter.key(JSON_COMP_NAME).value(compName);
	      // array of conditional texts
	      jsonWriter.key(CONDITIONAL_TEXTS).array();
	      for (ConditionalTextModel condText : conditionalTextsList) {
	          jsonWriter.object();
	          jsonWriter.key(condText.getTextId()).value(condText.getText());
	          jsonWriter.endObject();
	
	      }
	      jsonWriter.endArray();
	      jsonWriter.endObject();
      } catch (Exception e){
    	  LOGGER.error("Error in getJSON:"+ e.getMessage());
      }
      return wrt.toString();

  }
 
}

package org.kp.web.coveragecosts.use;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceMetadata;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONObject;
import org.kp.web.envconfig.core.service.ConfigValueService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.adobe.granite.ui.components.ds.DataSource;
import com.adobe.granite.ui.components.ds.EmptyDataSource;
import com.adobe.granite.ui.components.ds.SimpleDataSource;
import com.adobe.granite.ui.components.ds.ValueMapResource;

/**
 * ConditionalDescDataSrcUse class is responsible creating with DataSource in request.
 * 
 * @author Jai Parkash
 *
 */

public class ConditionalDescDataSrcUse extends WCMUsePojo {
	
  private static final Logger LOGGER = LoggerFactory.getLogger(ConditionalDescDataSrcUse.class);

  private static final String DATASOURCE_ELEMENT_NAME="datasource";
  private static String DSITEM_KEY_PROPNAME ="value";
  private static String DSITEM_NAME_PROPNAME ="text";
  private static String DS_NODETYPE ="nt:unstructured";	


  @Override
  public void activate() throws Exception {
    
    LOGGER.info("Activating");
    
    getRequest().setAttribute(DataSource.class.getName(), EmptyDataSource.instance());
    Resource datasource = getResource().getChild(DATASOURCE_ELEMENT_NAME);
    // get path property from data path
    ValueMap dsProperties = ResourceUtil.getValueMap(datasource);
    String configPath = dsProperties.get("path", String.class);
    // the path is in coverage-costs.conditionalDescription.json with 
    // first part being feature name and second being the config name
   
    String[] parts = configPath.split("[.]");
    String featureName = parts[0]; 
    String configName = parts[1]; 


    // Use ConfigValueService from KP Env config project
    ConfigValueService service = getSlingScriptHelper().getService(ConfigValueService.class);
    String jsonOSGIValueAsString = service.GetConfigValue(featureName, configName);
    getRequest().setAttribute(DataSource.class.getName(), createDS(getResourceResolver(), configPath, jsonOSGIValueAsString, configName));
    LOGGER.info("Done: Activating");

  }
	public DataSource createDS (ResourceResolver resolver, String datasSourcePath, String jsonOSGIValueAsString, String configName) {
		DataSource ds = null;	
		try {	
			JSONObject jObject = new JSONObject(jsonOSGIValueAsString);
				final JSONArray optionsData = jObject.getJSONArray(configName);
			    final int n = optionsData.length();
			    List<Resource> resourceList = new ArrayList<Resource>();
			    
			    for (int i = 0; i < n; ++i) {
			      final JSONObject option = optionsData.getJSONObject(i);
			      ValueMap vm = new ValueMapDecorator(new HashMap<String, Object>());
			      vm.put(DSITEM_KEY_PROPNAME, option.get(DSITEM_KEY_PROPNAME).toString());
			      vm.put(DSITEM_NAME_PROPNAME, option.get(DSITEM_NAME_PROPNAME).toString());
			      resourceList.add(new ValueMapResource(resolver, new ResourceMetadata(), DS_NODETYPE, vm));	
			    }
	
				ds = new SimpleDataSource(resourceList.iterator());

		} catch (Exception e) {			
			LOGGER.error("Exception: " + e.getMessage(), e);
		}
		return ds;
	}
  
}

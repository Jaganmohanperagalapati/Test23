package org.kp.web.coveragecosts.use;

import static org.junit.Assert.assertEquals;
import static org.powermock.api.mockito.PowerMockito.doReturn;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.spy;

import java.util.ArrayList;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.kp.web.coveragecosts.models.IconLinkModel;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * @author Gary Steinmetz
*/

@RunWith(PowerMockRunner.class)
@PrepareForTest({FeedContainerRightRailUse.class})
public class FeedContainerRightRailUseTest {
    private final static String BODY_PAR = "bodypar";
    private final static String PROP_TOTALDUELABEL = "totalDueLabel";
    private final static String PROP_ICON_LINK_ID = "iconLinkId";
    private final static String PROP_COMPONENT_STYLE = "componentStyle";
    private final static String PROP_TITLE_ICON = "titleIcon";
    private final static String PROP_TITLE = "title";
    private final static String PROP_SUB_TITLE = "subTitle";
    private final static String PROP_LINK_LABEL = "linkLabel";
    private final static String PROP_LINK_PATH = "linkPath";
    private final static String PROP_LINK_TARGET = "linkTarget";
    private final static String PROP_LINK_NO_FOLLOW = "linkNoFollow";

	@Test
	public void testGettersEmptyModel() throws Exception {
        FeedContainerRightRailUse fcum;
        fcum = createFeedContainerRightRailUse(null, null);
        assertEquals("", fcum.getComponentText());
        assertEquals(0, fcum.getIconLinkList().size());
        String compJSON="{ \"compname\": null, \"icon_links\": [  ] }";
		assertEquals(fcum.getJSON().replace(" ", "").replace("\n", "").replace("\\\"", ""),compJSON.replace(" ", "").replace("\n", ""));

        fcum = createFeedContainerRightRailUse("ABC", null);
        assertEquals("", fcum.getComponentText());
        assertEquals(0, fcum.getIconLinkList().size());
        String compJSON2="{ \"compname\": \"ABC\", \"icon_links\": [  ] }";
		assertEquals(fcum.getJSON().replace(" ", "").replace("\n", "").replace("\\\"", ""),compJSON2.replace(" ", "").replace("\n", ""));

		//FeedContainerUseMCC fcum = createFeedContainerUseMCC("totalDueLabel");
        //assertEquals("totalDueLabel", fcum.getTotalDueLabel());
        ////
        //LineNumberReader lnr =
        //    new LineNumberReader(new StringReader(fcum.getJSON()));
        //assertEquals("{", lnr.readLine());
        //assertEquals("  \"totalDueLabel\": \"totalDueLabel\"", lnr.readLine());
        //assertEquals("}", lnr.readLine());
        //assertEquals(null, lnr.readLine());
	}
	@Test
	public void testGettersOneModel() throws Exception {
        //
        IconLinkModel linkOne = new IconLinkModel(
            "someIconLinkIdOne");
        linkOne.setComponentStyle("someComponentStyleOne");
        linkOne.setTitleIcon("someTitleIconOne");
        linkOne.setTitle("someTitleOne");
        linkOne.setSubTitle("someSubTitleOne");
        linkOne.setLinkLabel("someLinkLabelOne");
        linkOne.setLinkPath("someLinkPathOne");
        linkOne.setLinkTarget("someLinkTargetOne");
        linkOne.setLinkNoFollow("someLinkNoFollowOne");
       
        //
        FeedContainerRightRailUse fcum;
        fcum = createFeedContainerRightRailUse(
            "OneLink", new IconLinkModel[]{linkOne});
        assertEquals(
            "IconLinkModel [iconLinkId=someIconLinkIdOne,"
            + " componentStyle=someComponentStyleOne,"
            + " titleIcon=someTitleIconOne,"
            + " title=someTitleOne,"
            + " subTitle=someSubTitleOne,"
            + " linkLabel=someLinkLabelOne,"
            + " linkPath=someLinkPathOne,"
            + " linkTarget=someLinkTargetOne,"
            + " linkNoFollow=someLinkNoFollowOne]", fcum.getComponentText());
        assertEquals(1, fcum.getIconLinkList().size());

        String compJSON="{  \"compname\": \"OneLink\", \"icon_links\": [{ "
        		+" \"iconLinkId\": \"someIconLinkIdOne\","
        		+"      \"componentStyle\": \"someComponentStyleOne\","
        		+"      \"titleIcon\": \"someTitleIconOne\","
                +"      \"title\": \"someTitleOne\","
                +"      \"subTitle\": \"someSubTitleOne\","
                +"      \"linkLabel\": \"someLinkLabelOne\","
                +"      \"linkPath\": \"someLinkPathOne\","
                +"      \"linkTarget\": \"someLinkTargetOne\","
                +"      \"linkNoFollow\": \"someLinkNoFollowOne\""
        		+"}  ] }";
		assertEquals(fcum.getJSON().replace(" ", "").replace("\n", "").replace("\\\"", ""),compJSON.replace(" ", "").replace("\n", ""));
        confirmEqual(linkOne, fcum.getIconLinkList().get(0));
	}
	@Test
	public void testGettersTwoModel() throws Exception {
        //
        IconLinkModel linkOne = new IconLinkModel(
                "someIconLinkIdOne");
            linkOne.setComponentStyle("someComponentStyleOne");
            linkOne.setTitleIcon("someTitleIconOne");
            linkOne.setTitle("someTitleOne");
            linkOne.setSubTitle("someSubTitleOne");
            linkOne.setLinkLabel("someLinkLabelOne");
            linkOne.setLinkPath("someLinkPathOne");
            linkOne.setLinkTarget("someLinkTargetOne");
            linkOne.setLinkNoFollow("someLinkNoFollowOne");
            
            IconLinkModel linkTwo = new IconLinkModel(
                    "someIconLinkIdTwo");
            linkTwo.setComponentStyle("someComponentStyleTwo");
            linkTwo.setTitleIcon("someTitleIconTwo");
            linkTwo.setTitle("someTitleTwo");
            linkTwo.setSubTitle("someSubTitleTwo");
            linkTwo.setLinkLabel("someLinkLabelTwo");
            linkTwo.setLinkPath("someLinkPathTwo");
            linkTwo.setLinkTarget("someLinkTargetTwo");
            linkTwo.setLinkNoFollow("someLinkNoFollowTwo");

        //
        FeedContainerRightRailUse fcum;
        fcum = createFeedContainerRightRailUse(
            "OneLink", new IconLinkModel[]{linkOne, linkTwo});
        System.out.println("JSON fcum.getComponentText() = " + fcum.getComponentText());
        assertEquals(
            "IconLinkModel [iconLinkId=someIconLinkIdOne,"
            + " componentStyle=someComponentStyleOne,"
            + " titleIcon=someTitleIconOne,"
            + " title=someTitleOne,"
            + " subTitle=someSubTitleOne,"
            + " linkLabel=someLinkLabelOne,"
            + " linkPath=someLinkPathOne,"
            + " linkTarget=someLinkTargetOne,"
            + " linkNoFollow=someLinkNoFollowOne];"
            + "IconLinkModel [iconLinkId=someIconLinkIdTwo,"
            + " componentStyle=someComponentStyleTwo,"
            + " titleIcon=someTitleIconTwo,"
            + " title=someTitleTwo,"
            + " subTitle=someSubTitleTwo,"
            + " linkLabel=someLinkLabelTwo,"
            + " linkPath=someLinkPathTwo,"
            + " linkTarget=someLinkTargetTwo,"
            + " linkNoFollow=someLinkNoFollowTwo]", fcum.getComponentText());
        assertEquals(2, fcum.getIconLinkList().size());
        
        String compJSON="{  \"compname\": \"OneLink\", \"icon_links\": [{ "
        		+" \"iconLinkId\": \"someIconLinkIdOne\","
        		+"      \"componentStyle\": \"someComponentStyleOne\","
        		+"      \"titleIcon\": \"someTitleIconOne\","
                +"      \"title\": \"someTitleOne\","
                +"      \"subTitle\": \"someSubTitleOne\","
                +"      \"linkLabel\": \"someLinkLabelOne\","
                +"      \"linkPath\": \"someLinkPathOne\","
                +"      \"linkTarget\": \"someLinkTargetOne\","
                +"      \"linkNoFollow\": \"someLinkNoFollowOne\""
                +"    },{"
                +"      \"iconLinkId\": \"someIconLinkIdTwo\","
                +"      \"componentStyle\": \"someComponentStyleTwo\","
                +"      \"titleIcon\": \"someTitleIconTwo\","
                +"      \"title\": \"someTitleTwo\","
                +"      \"subTitle\": \"someSubTitleTwo\","
                +"      \"linkLabel\": \"someLinkLabelTwo\","
                +"      \"linkPath\": \"someLinkPathTwo\","
                +"      \"linkTarget\": \"someLinkTargetTwo\","
                +"      \"linkNoFollow\": \"someLinkNoFollowTwo\""
        		+"}  ] }";
		assertEquals(fcum.getJSON().replace(" ", "").replace("\n", "").replace("\\\"", ""),compJSON.replace(" ", "").replace("\n", ""));
  
		
        confirmEqual(linkOne, fcum.getIconLinkList().get(0));
        confirmEqual(linkTwo, fcum.getIconLinkList().get(1));
	}

	private static FeedContainerRightRailUse createFeedContainerRightRailUse(
            String inResourceName, IconLinkModel[] inIlmList) throws Exception {
		FeedContainerRightRailUse outValue = spy(new FeedContainerRightRailUse());
        Resource rootResource = mock(Resource.class);
        doReturn(rootResource).when(outValue).getResource();
        doReturn(inResourceName).when(rootResource).getName();
        Resource bodyParResource = mock(Resource.class);
        doReturn(bodyParResource).when(rootResource).getChild(BODY_PAR);
        if (inIlmList != null) {
            ArrayList<Resource> iconLinkModelList = new ArrayList<Resource>();
            for (IconLinkModel nextIlm : inIlmList) {
                Resource nextResource = mock(Resource.class);
                ValueMap nextProps = createProperties(nextIlm);
                doReturn(nextProps).when(nextResource).getValueMap();
                iconLinkModelList.add(nextResource);
            }
            doReturn(iconLinkModelList.iterator()).when(bodyParResource).listChildren();
        } else {
            doReturn(null).when(bodyParResource).listChildren();
        }
		outValue.activate();
		return outValue;
	}
    private static ValueMap createProperties(
            IconLinkModel inIlm) throws Exception {
        ValueMap outValue = mock(ValueMap.class);
        doReturn(inIlm.getIconLinkId()).when(outValue).get(PROP_ICON_LINK_ID,"");
        doReturn(inIlm.getComponentStyle()).when(outValue).get(PROP_COMPONENT_STYLE,"");
        doReturn(inIlm.getTitleIcon()).when(outValue).get(PROP_TITLE_ICON,"");
        doReturn(inIlm.getTitle()).when(outValue).get(PROP_TITLE,"");
        doReturn(inIlm.getSubTitle()).when(outValue).get(PROP_SUB_TITLE,"");
        doReturn(inIlm.getLinkLabel()).when(outValue).get(PROP_LINK_LABEL,"");
        doReturn(inIlm.getLinkPath()).when(outValue).get(PROP_LINK_PATH,"");
        doReturn(inIlm.getLinkTarget()).when(outValue).get(PROP_LINK_TARGET,"");
        doReturn(inIlm.geLinkNoFollow()).when(outValue).get(PROP_LINK_NO_FOLLOW,"");
        return outValue;
    }
    private static void confirmEqual(
            IconLinkModel inIlmOne, IconLinkModel inIlmTwo) {
        //
        assertEquals(inIlmOne.getIconLinkId(), inIlmTwo.getIconLinkId());
        assertEquals(inIlmOne.getComponentStyle(), inIlmTwo.getComponentStyle());
        assertEquals(inIlmOne.getTitleIcon(), inIlmTwo.getTitleIcon());
        assertEquals(inIlmOne.getTitle(), inIlmTwo.getTitle());
        assertEquals(inIlmOne.getSubTitle(), inIlmTwo.getSubTitle());
        assertEquals(inIlmOne.getLinkLabel(), inIlmTwo.getLinkLabel());
        assertEquals(inIlmOne.getLinkPath(), inIlmTwo.getLinkPath());
        assertEquals(inIlmOne.getLinkTarget(), inIlmTwo.getLinkTarget());
        assertEquals(inIlmOne.geLinkNoFollow(), inIlmTwo.geLinkNoFollow());
    }
}

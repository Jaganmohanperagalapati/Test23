package org.kp.web.coveragecosts.use;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.HashMap;

import javax.jcr.RepositoryException;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.kp.web.coveragecosts.use.AbstractUseTest;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.adobe.cq.sightly.WCMUsePojo;

/**
 * The ConditionalButtonUseTest class for ConditionalButtonUse unit test cases.
 *
 * @author Jai Parkash
 * 
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ConditionalButtonUse.class})
public class ConditionalButtonUseTest   extends AbstractUseTest {
	
	  private static final String CONDITIONAL_BUTTONS = "conditionalBtns";
	  private static final String COMP_NAME = "conditionalBtns";

	  
	  private static final String CT_CONDITIONAL_BUTTONS_BLANK="";
	  private static final String CT_CONDITIONAL_BUTTONS_SINGLE="{\"btnText\":\"Pay Bill\",\"btnPath\":\"/content/kporg/en/coverage-costs\",\"btnTarget\":\"_self\"}";
	  private static final String CT_CONDITIONAL_BUTTONS_MULTI="{\"btnText\":\"Pay Bill\",\"btnPath\":\"/content/kporg/en/coverage-costs\",\"btnTarget\":\"_self\"},{\"btnText\":\"Estimate Bill\",\"btnPath\":\"/content/kporg/en/coverage-costs\",\"btnTarget\":\"_self\"}";
	  private static final String CT_CONDITIONAL_BUTTONS_MULTI_1="{\"btnText\":\"Pay Bill\",\"btnPath\":\"/content/kporg/en/coverage-costs\",\"btnTarget\":\"_self\"}";
	  private static final String CT_CONDITIONAL_BUTTONS_MULTI_2="{\"btnText\":\"Estimate Bill\",\"btnPath\":\"/content/kporg/en/coverage-costs\",\"btnTarget\":\"_self\"}";

	  private static final String CT_CONDITIONAL_BUTTONS_JSON="{\n\"compname\": \"" + COMP_NAME + "\",\n \"" + CONDITIONAL_BUTTONS + "\":[{\n  \"text\":\"Pay Bill\",\n  \"path\":\"/content/kporg/en/coverage-costs\",\n  \"target\":\"_self\"\n},{\n  \"text\":\"Estimate Bill\",\n  \"path\":\"/content/kporg/en/coverage-costs\",\n  \"target\":\"_self\"\n  }\n]\n}";

	  
	  private static final int CT_CONDITIONAL_BUTTONS_BLANK_SIZE=0;
	  private static final int CT_CCONDITIONAL_BUTTONS_SINGLE_SIZE=1;
	  private static final int CT_CONDITIONAL_BUTTONS_MULTI_SIZE=2;	  

	  private ConditionalButtonUse classUnderTest = null;

	
	@Before
	public void setup() throws RepositoryException {
		super.setup();
		resource=mock(Resource.class);
		when(classUnderTest.getResource()).thenReturn(resource);
		when (resource.getName()).thenReturn(COMP_NAME);
		
	}

	@Override
	protected WCMUsePojo getClassUnderTest() {
		if (classUnderTest == null) {
			classUnderTest =PowerMockito.spy(new ConditionalButtonUse());
		}
		return classUnderTest;
	
	}
	@Test
	public void getConditionalBtnTextBlankTest() throws Exception {

		String[] values=new String[1];
		values[0]=CT_CONDITIONAL_BUTTONS_BLANK;

		ValueMap properties = new ValueMapDecorator(new HashMap<String, Object>());
		properties.put(CONDITIONAL_BUTTONS, values);
		when(classUnderTest.getProperties()).thenReturn(properties);

		classUnderTest.activate();
		assertEquals(classUnderTest.getConditionalTexts(), CT_CONDITIONAL_BUTTONS_BLANK);
		assertEquals(classUnderTest.getConditionalButtonsList().size(),  CT_CONDITIONAL_BUTTONS_BLANK_SIZE);
		
	}
	
	@Test
	public void getConditionalBtnTextSingleTest() throws Exception {
		String[] values=new String[1];
		values[0]=CT_CONDITIONAL_BUTTONS_SINGLE;

		ValueMap properties = new ValueMapDecorator(new HashMap<String, Object>());
		properties.put(CONDITIONAL_BUTTONS, values);
		when(classUnderTest.getProperties()).thenReturn(properties);	
		
		classUnderTest.activate();
		
		assertEquals(classUnderTest.getConditionalTexts(), CT_CONDITIONAL_BUTTONS_SINGLE);
		assertEquals(classUnderTest.getConditionalButtonsList().size(),  CT_CCONDITIONAL_BUTTONS_SINGLE_SIZE);
	}
	
	@Test
	public void getConditionalBtnTextMultiTest() throws Exception {
		String[] values=new String[2];
		values[0]=CT_CONDITIONAL_BUTTONS_MULTI_1;
		values[1]=CT_CONDITIONAL_BUTTONS_MULTI_2;

		ValueMap properties = new ValueMapDecorator(new HashMap<String, Object>());
		properties.put(CONDITIONAL_BUTTONS, values);
		when(classUnderTest.getProperties()).thenReturn(properties);
		
		classUnderTest.activate();
		
		assertEquals(classUnderTest.getConditionalTexts(), CT_CONDITIONAL_BUTTONS_MULTI);
		assertEquals(classUnderTest.getConditionalButtonsList().size(),  CT_CONDITIONAL_BUTTONS_MULTI_SIZE);
	}	
	
	// Address the case when property not set 
	@Test
	public void getConditionalBtnTextNoProperty() throws Exception {

		ValueMap properties = new ValueMapDecorator(new HashMap<String, Object>());
		when(classUnderTest.getProperties()).thenReturn(properties);
		
		classUnderTest.activate();
		
		assertTrue(classUnderTest.getConditionalTexts().isEmpty());
		assertTrue(classUnderTest.getConditionalButtonsList().isEmpty());
	}

	// Test JSON Output
	@Test
	public void getConditionalBtnJSON() throws Exception {
		String[] values=new String[2];
		values[0]=CT_CONDITIONAL_BUTTONS_MULTI_1;
		values[1]=CT_CONDITIONAL_BUTTONS_MULTI_2;

		ValueMap properties = new ValueMapDecorator(new HashMap<String, Object>());
		properties.put(CONDITIONAL_BUTTONS, values);
		when(classUnderTest.getProperties()).thenReturn(properties);
		
		classUnderTest.activate();
		
		assertEquals(classUnderTest.getJSON().replace(" ", "").replace("\n", "").replace("\\\"", ""),CT_CONDITIONAL_BUTTONS_JSON.replace(" ", "").replace("\n", ""));
	}
	

}

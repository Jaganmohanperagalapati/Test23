package org.kp.web.coveragecosts.use;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.HashMap;

import javax.jcr.Property;
import javax.jcr.RepositoryException;

import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.scripting.SlingScriptHelper;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.kp.web.envconfig.core.service.ConfigValueService;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.adobe.cq.sightly.WCMUsePojo;

/**
 * The ConditionalDescDataSrcUseTest class for ConditionalDescDataSrcUse unit test cases.
 *
 * @author Tirumala Malladi
 * 
 */

@RunWith(PowerMockRunner.class)
@PrepareForTest({ConditionalDescDataSrcUse.class})
public class ConditionalDescDataSrcUseTest  extends AbstractUseTest {
	
	 private static final String jsonOSGIValueAsString="{ \"conditionalDescription\": [{ \"value\": \"<p>Test the value<\\/p>\", \"text\": \"<p>Testing text value<\\/p>\" } ]}";
	 private static final String DATASOURCE_ELEMENT_NAME="datasource";
	  	
	private ConditionalDescDataSrcUse classUnderTest = null;
	Property ctProperty ;
	 
	@Mock	
    SlingScriptHelper slingScriptHelper;
	
	@Mock
	ConfigValueService configValueService;
	
	@Before
	public void setup() throws RepositoryException {
		super.setup();
		ctProperty = mock(Property.class);		
	}

	@Override
	protected WCMUsePojo getClassUnderTest() {
		if (classUnderTest == null) {
			classUnderTest =PowerMockito.spy(new ConditionalDescDataSrcUse());
		}
		return classUnderTest;
	
	}
	@Test
	public void getConditionalTextBlankTest() throws Exception {
		String[] values=new String[1];
		values[0]="coverage-costs.conditionalDescription.json";
		ValueMap properties = new ValueMapDecorator(new HashMap<String, Object>());
		properties.put("path", values);
		when(resource.getChild(DATASOURCE_ELEMENT_NAME)).thenReturn(resource);
		when(ResourceUtil.getValueMap(resource)).thenReturn(properties);
		when(sh.getService(ConfigValueService.class)).thenReturn(configValueService);
		when(configValueService.GetConfigValue("coverage-costs", "conditionalDescription")).thenReturn(jsonOSGIValueAsString);
		
		classUnderTest.activate();
		
	}
	
	
	
}

package org.kp.web.coveragecosts.models;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.HashMap;

import javax.jcr.RepositoryException;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.kp.web.coveragecosts.use.AbstractUseTest;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.adobe.cq.sightly.WCMUsePojo;

/**
 * The AngularTemplateModelTest class for AngularTemplateModel unit test cases.
 *
 * @author Jai Parkash
 * 
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({AngularTemplateModel.class})
public class AngularTemplateModelTest{
	  private AngularTemplateModel classUnderTest = null;
	  protected Resource resource;
	  protected Resource parentResource;
	  protected String templateID;
	  protected String templatePath;
	  protected String toString;
	  
	
	@Before
	public void setup() throws RepositoryException {
		resource=mock(Resource.class);
		parentResource=mock(Resource.class);	
		getClassUnderTest();
	}

	protected AngularTemplateModel getClassUnderTest() {
		if (classUnderTest == null) {
			classUnderTest =PowerMockito.spy(new AngularTemplateModel());
		}
		return classUnderTest;
	
	}
	
	@Test
	public void createObjectTestWithBlankValues() throws Exception {	       
		templateID = "";
		templatePath="";
		toString="AngularTemplateModel [Template ID=" + templateID + ", Template Path =" + templatePath + "]";
		classUnderTest.setTemplateID(templateID);
		classUnderTest.setTemplatePath(templatePath);
		
		assertEquals(classUnderTest.getTemplateID(), templateID);
		assertEquals(classUnderTest.getTemplatePath(), templatePath);
		assertEquals(classUnderTest.toString(), toString);				
	}
	
	@Test
	public void createObjectTestWithValues() throws Exception {	       
		templateID = "Template1";
		templatePath="/content/kp/en/national/secure/coverage-costs";
		toString="AngularTemplateModel [Template ID=" + templateID + ", Template Path =" + templatePath + "]";
		classUnderTest.setTemplateID(templateID);
		classUnderTest.setTemplatePath(templatePath);
		
		assertEquals(classUnderTest.getTemplateID(), templateID);
		assertEquals(classUnderTest.getTemplatePath(), templatePath);
		assertEquals(classUnderTest.toString(), toString);				
	}

}


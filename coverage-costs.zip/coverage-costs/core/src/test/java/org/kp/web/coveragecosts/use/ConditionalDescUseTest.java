package org.kp.web.coveragecosts.use;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.HashMap;

import javax.jcr.Property;
import javax.jcr.RepositoryException;

import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.adobe.cq.sightly.WCMUsePojo;

/**
 * The ConditionalDescUseTest class for ConditionalDescUse unit test cases.
 *
 * @author Jai Parkash
 * 
 */

@RunWith(PowerMockRunner.class)
@PrepareForTest({ConditionalDescUse.class})
public class ConditionalDescUseTest  extends AbstractUseTest {
	
	  private static final String CT_CONDITIONAL_TEXTS = "conditionaltexts";
	  
	  private static final String CT_CONDITIONAL_TEXTS_BLANK="";
	  private static final String CT_CONDITIONAL_TEXTS_SINGLE="{\"text\":\"<p>Test 1</p>\",\"textid\":\"medical-bill-balance-with-payment\"}";
	  private static final String CT_CONDITIONAL_TEXTS_MULTI="{\"text\":\"<p>Test 1</p>\",\"textid\":\"medical-bill-balance-with-payment\"},{\"text\":\"<p>Test 2</p>\",\"textid\":\"medical-bill-balance-no-payment\"}";
	  private static final String CT_CONDITIONAL_TEXTS_MULTI_1="{\"text\":\"<p>Test 1</p>\",\"textid\":\"medical-bill-balance-with-payment\"}";
	  private static final String CT_CONDITIONAL_TEXTS_MULTI_2="{\"text\":\"<p>Test 2</p>\",\"textid\":\"medical-bill-balance-no-payment\"}";
	  
	  private static final String STRING_TO_COMPARE="{  \"compname\": null,  \"conditionaltexts\": [{      \"medical-bill-balance-with-payment\": \"<p>Test 1<\\/p>\"    }  ]}";
	  

	  private static final int CT_CONDITIONAL_TEXTS_BLANK_SIZE=0;
	  private static final int CT_CONDITIONAL_TEXTS_SINGLE_SIZE=1;
	  private static final int CT_CONDITIONAL_TEXTS_MULTI_SIZE=2;

	  private ConditionalDescUse classUnderTest = null;
	  Property ctProperty ;
	
	@Before
	public void setup() throws RepositoryException {
		super.setup();
		ctProperty = mock(Property.class);		
	}

	@Override
	protected WCMUsePojo getClassUnderTest() {
		if (classUnderTest == null) {
			classUnderTest =PowerMockito.spy(new ConditionalDescUse());
		}
		return classUnderTest;
	
	}
	@Test
	public void getConditionalTextBlankTest() throws Exception {
		String[] values=new String[1];
		values[0]="";

		ValueMap properties = new ValueMapDecorator(new HashMap<String, Object>());
		properties.put(CT_CONDITIONAL_TEXTS, values);
		when(classUnderTest.getProperties()).thenReturn(properties);

		
		classUnderTest.activate();
		assertEquals(classUnderTest.getConditionalTexts(), CT_CONDITIONAL_TEXTS_BLANK);
		assertEquals(classUnderTest.getConditionalTextsList().size(),  CT_CONDITIONAL_TEXTS_BLANK_SIZE);
		
	}
	
	@Test
	public void getConditionalTextSingleTest() throws Exception {		
		String[] values=new String[1];
		values[0]=CT_CONDITIONAL_TEXTS_SINGLE;

		ValueMap properties = new ValueMapDecorator(new HashMap<String, Object>());
		properties.put(CT_CONDITIONAL_TEXTS, values);
		when(classUnderTest.getProperties()).thenReturn(properties);
		
		classUnderTest.activate();
		
		assertEquals(classUnderTest.getConditionalTexts(), CT_CONDITIONAL_TEXTS_SINGLE);
		assertEquals(classUnderTest.getConditionalTextsList().size(),  CT_CONDITIONAL_TEXTS_SINGLE_SIZE);
	}
	
	@Test
	public void getConditionalTextMultiTest() throws Exception {
		String[] values=new String[2];
		values[0]=CT_CONDITIONAL_TEXTS_MULTI_1;
		values[1]=CT_CONDITIONAL_TEXTS_MULTI_2;

		ValueMap properties = new ValueMapDecorator(new HashMap<String, Object>());
		properties.put(CT_CONDITIONAL_TEXTS, values);
		when(classUnderTest.getProperties()).thenReturn(properties);
		
		classUnderTest.activate();
		
		assertEquals(classUnderTest.getConditionalTexts(), CT_CONDITIONAL_TEXTS_MULTI);
		assertEquals(classUnderTest.getConditionalTextsList().size(),  CT_CONDITIONAL_TEXTS_MULTI_SIZE);
	}	
	// Address the case when property not set 
	@Test
	public void getConditionalTextNoProperty() throws Exception {

		ValueMap properties = new ValueMapDecorator(new HashMap<String, Object>());
		when(classUnderTest.getProperties()).thenReturn(properties);
		
		classUnderTest.activate();
		
		assertTrue(classUnderTest.getConditionalTexts().isEmpty());
		assertTrue(classUnderTest.getConditionalTextsList().isEmpty());
	}
	
	@Test
	public void getJSONStringTest() throws Exception {
		String[] values=new String[1];
		values[0]=CT_CONDITIONAL_TEXTS_SINGLE;
		ValueMap properties = new ValueMapDecorator(new HashMap<String, Object>());
		properties.put(CT_CONDITIONAL_TEXTS, values);
		when(classUnderTest.getProperties()).thenReturn(properties);
		
		classUnderTest.activate();
		String jsonString = classUnderTest.getJSON().toString();
		jsonString = jsonString.replaceAll("\\r", "").replaceAll("\\n", "");
		assertEquals(jsonString,  STRING_TO_COMPARE);
	}
	
	
	
}

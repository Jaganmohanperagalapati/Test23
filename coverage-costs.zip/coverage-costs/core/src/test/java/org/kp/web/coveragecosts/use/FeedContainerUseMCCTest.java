package org.kp.web.coveragecosts.use;

import static org.junit.Assert.assertEquals;
import static org.powermock.api.mockito.PowerMockito.doReturn;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.spy;

import org.apache.sling.api.resource.ValueMap;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * @author Gary Steinmetz
*/

@RunWith(PowerMockRunner.class)
@PrepareForTest({FeedContainerUseMCC.class})
public class FeedContainerUseMCCTest {
    private static String PROP_TOTALDUELABEL = "totalDueLabel";

	@Test
	public void testGetters() throws Exception {
		FeedContainerUseMCC fcum = createFeedContainerUseMCC("totalDueLabel");
        assertEquals("totalDueLabel", fcum.getTotalDueLabel());
        String outputExpected = "{\"totalDueLabel\":\"totalDueLabel\"}";
        assertEquals(outputExpected, fcum.getJSON());
	}

	private static FeedContainerUseMCC createFeedContainerUseMCC(
            String inTotalDueLabel) throws Exception {
		FeedContainerUseMCC outValue = spy(new FeedContainerUseMCC());
		ValueMap props = createProperties(inTotalDueLabel);
		doReturn(props).when(outValue).getProperties();
		outValue.activate();
		return outValue;
	}
    private static ValueMap createProperties(
            String inTotalDueLabel) throws Exception {
        ValueMap outValue = mock(ValueMap.class);
        doReturn(inTotalDueLabel).when(outValue).get(PROP_TOTALDUELABEL,"");
        return outValue;
    }
}

package org.kp.web.coveragecosts.use;

import static org.junit.Assert.assertEquals;
import static org.powermock.api.mockito.PowerMockito.doReturn;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.spy;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * @author Gary Steinmetz
*/

@RunWith(PowerMockRunner.class)
@PrepareForTest({DynamicLinkListUseMCC.class})
public class DynamicLinkListUseMCCTest {
    private static final String DYNAMIC_LIST_LINKS = "pageLinks";
	@Test
	public void testGettersWithEmptyInput() throws Exception {
        DynamicLinkListUseMCC dllum;
		dllum = createDynamicLinkListUseMCC(
            "ResourceName", new String[]{""});
        assertEquals("", dllum.getComponentText());
        assertEquals(0, dllum.getDynamicLinkList().size());
        String compJSON="{ \"compname\": \"ResourceName\",  \"pageLinks\": [  ] }";
		assertEquals(dllum.getJSON().replace(" ", "").replace("\n", "").replace("\\\"", ""),compJSON.replace(" ", "").replace("\n", ""));

		dllum = createDynamicLinkListUseMCC(
            "ResourceName", new String[]{});
        assertEquals("", dllum.getComponentText());
        assertEquals(0, dllum.getDynamicLinkList().size());
        //
		dllum = createDynamicLinkListUseMCC(null, null);
        assertEquals("", dllum.getComponentText());
        assertEquals(0, dllum.getDynamicLinkList().size());
	}
	@Test
	public void testGettersWithInvalidDllEntry() throws Exception {
        DynamicLinkListUseMCC dllum;
		dllum = createDynamicLinkListUseMCC(
            "ResourceName", new String[]{"InvalidNotJson"});
        assertEquals("", dllum.getComponentText());
        assertEquals(0, dllum.getDynamicLinkList().size());
	}
	@Test
	public void testGettersWithSimpleDllEntry() throws Exception {
        String dllEntryOne = "{"
                + "\"linkLabel\":\"someLinkLabel\","
                + "\"linkPath\":\"someLinkPath\","
                + "\"linkTarget\":\"someLinkTarget\""
                + "}";
        DynamicLinkListUseMCC dllum;
		dllum = createDynamicLinkListUseMCC(
            "ResourceName", new String[]{dllEntryOne});
        assertEquals(dllEntryOne, dllum.getComponentText());
        assertEquals(1, dllum.getDynamicLinkList().size());
        assertEquals("\"someLinkLabel\"", dllum.getDynamicLinkList().get(0).getDisplayText());
        assertEquals("\"someLinkPath\"", dllum.getDynamicLinkList().get(0).getResourceLink());
        assertEquals("\"someLinkTarget\"", dllum.getDynamicLinkList().get(0).getTarget());

        String compJSON="{ \"compname\": \"ResourceName\",  \"pageLinks\": [{ \"linkLabel\": \"someLinkLabel\", \"linkPath\": \"someLinkPath\",\"linkTarget\": \"someLinkTarget\" }]}";
		assertEquals(dllum.getJSON().replace(" ", "").replace("\n", "").replace("\\\"", ""),compJSON.replace(" ", "").replace("\n", ""));

	}
	@Test
	public void testGettersWithTwoDllEntries() throws Exception {
        String dllEntryOne = "{"
                + "\"linkLabel\":\"someLinkLabelOne\","
                + "\"linkPath\":\"someLinkPathOne\","
                + "\"linkTarget\":\"someLinkTargetOne\""
                + "}";
        String dllEntryTwo = "{"
                + "\"linkLabel\":\"someLinkLabelTwo\","
                + "\"linkPath\":\"someLinkPathTwo\","
                + "\"linkTarget\":\"someLinkTargetTwo\""
                + "}";
        DynamicLinkListUseMCC dllum;
		dllum = createDynamicLinkListUseMCC(
            "ResourceName", new String[]{dllEntryOne, dllEntryTwo});
        assertEquals(dllEntryOne + "," + dllEntryTwo, dllum.getComponentText());
        assertEquals(2, dllum.getDynamicLinkList().size());
        //
        assertEquals("\"someLinkLabelOne\"", dllum.getDynamicLinkList().get(0).getDisplayText());
        assertEquals("\"someLinkPathOne\"", dllum.getDynamicLinkList().get(0).getResourceLink());
        assertEquals("\"someLinkTargetOne\"", dllum.getDynamicLinkList().get(0).getTarget());
        //
        assertEquals("\"someLinkLabelTwo\"", dllum.getDynamicLinkList().get(1).getDisplayText());
        assertEquals("\"someLinkPathTwo\"", dllum.getDynamicLinkList().get(1).getResourceLink());
        assertEquals("\"someLinkTargetTwo\"", dllum.getDynamicLinkList().get(1).getTarget());
        
        String compJSON="{ \"compname\": \"ResourceName\",  \"pageLinks\": [{ \"linkLabel\": \"someLinkLabelOne\", \"linkPath\": \"someLinkPathOne\",\"linkTarget\": \"someLinkTargetOne\" },"
        		+"{\"linkLabel\": \"someLinkLabelTwo\", \"linkPath\": \"someLinkPathTwo\",\"linkTarget\": \"someLinkTargetTwo\" } ]}";
		assertEquals(dllum.getJSON().replace(" ", "").replace("\n", "").replace("\\\"", ""),compJSON.replace(" ", "").replace("\n", ""));

	}

	private static DynamicLinkListUseMCC createDynamicLinkListUseMCC(
            String inResourceName, String[] inDll) throws Exception {
		DynamicLinkListUseMCC outValue = spy(new DynamicLinkListUseMCC());
		doReturn(createProperties(inDll)).when(outValue).getProperties();
        doReturn(inDll).when(outValue).get(DYNAMIC_LIST_LINKS, String[].class);
        Resource r = mock(Resource.class);
        doReturn(inResourceName).when(r).getName();
        doReturn(r).when(outValue).getResource();
		outValue.activate();
		return outValue;
	}
    private static ValueMap createProperties(
            String[] inDll) throws Exception {
        ValueMap outValue = mock(ValueMap.class);
        doReturn(inDll).when(outValue).get(DYNAMIC_LIST_LINKS, String[].class);
        return outValue;
    }

}

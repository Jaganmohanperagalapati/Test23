package org.kp.web.coveragecosts.models;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;

import javax.jcr.RepositoryException;

import org.apache.sling.api.resource.Resource;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * The ConditionalTextModelTest class for ConditionalTextModel unit test cases.
 *
 * @author Jai Parkash
 * 
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ConditionalTextModel.class})
public class ConditionalTextModelTest{
	private ConditionalTextModel classUnderTest = null;
	protected Resource resource;	  
	private String toString;	
	private String textid;
	private String text;
	
	@Before
	public void setup() throws RepositoryException {
		resource=mock(Resource.class);
		getClassUnderTest();
	}

	protected ConditionalTextModel getClassUnderTest() {
		textid = "Text1"  ;
		text="The is sample conditional text";
		if (classUnderTest == null) {
			classUnderTest =PowerMockito.spy(new ConditionalTextModel(textid, text));
		}
		return classUnderTest;
	
	}
	@Test
	public void createObjectTestWithBlankValues() throws Exception {	       
		textid = ""  ;
		text="";
		toString="ConditionalTextModel [text id=" + textid + ", text=" + text + "]";
		classUnderTest.setTextId(textid);
		classUnderTest.setText(text);
				
		assertEquals(classUnderTest.getText(), text);
		assertEquals(classUnderTest.getTextId(), textid);
		
		assertEquals(classUnderTest.toString(), toString);				
	}
	
	@Test
	public void createObjectTestWithValues() throws Exception {	       
		textid = "Text1"  ;
		text="The is sample conditional text";
		toString="ConditionalTextModel [text id=" + textid + ", text=" + text + "]";
		classUnderTest.setTextId(textid);
		classUnderTest.setText(text);
				
		assertEquals(classUnderTest.getText(), text);
		assertEquals(classUnderTest.getTextId(), textid);
		
		assertEquals(classUnderTest.toString(), toString);		
	}

}


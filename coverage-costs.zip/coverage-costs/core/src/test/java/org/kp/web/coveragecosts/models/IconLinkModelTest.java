package org.kp.web.coveragecosts.models;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;

import javax.jcr.RepositoryException;

import org.apache.sling.api.resource.Resource;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * The IconLinkModelTest class for IconLinkModel unit test cases.
 *
 * @author Jai Parkash
 * 
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({IconLinkModel.class})
public class IconLinkModelTest{
	private IconLinkModel classUnderTest = null;
	protected Resource resource;	  
	private String iconLinkId;
	private String componentStyle;
	private String titleIcon;
	private String title;
	private String subTitle;
	private String linkLabel;
	private String linkPath;
	private String linkTarget;
	private String linkNoFollow;
	private String toString;	  
	
	@Before
	public void setup() throws RepositoryException {
		resource=mock(Resource.class);
		getClassUnderTest();
	}

	protected IconLinkModel getClassUnderTest() {
		iconLinkId = "IconLink1"  ;
		if (classUnderTest == null) {
			classUnderTest =PowerMockito.spy(new IconLinkModel(iconLinkId));
		}
		return classUnderTest;
	
	}
	@Test
	public void createObjectTestWithBlankValues() throws Exception {	       
		componentStyle = "";
		titleIcon = "";
		title = "";
		subTitle = "";
		linkLabel = "";
		linkPath = "";
		linkTarget = "";		
		linkNoFollow = "";
		toString="IconLinkModel [iconLinkId=" + iconLinkId + ", componentStyle=" + componentStyle
				+ ", titleIcon=" + titleIcon + ", title=" + title + ", subTitle=" + subTitle
				+ ", linkLabel=" + linkLabel + ", linkPath=" + linkPath + ", linkTarget=" + linkTarget
				+ ", linkNoFollow="+ linkNoFollow + "]";
		classUnderTest.setComponentStyle(componentStyle);
		classUnderTest.setTitleIcon(titleIcon);
		classUnderTest.setTitle(title);
		classUnderTest.setSubTitle(subTitle);
		classUnderTest.setLinkLabel(linkLabel);
		classUnderTest.setLinkPath(linkPath);
		classUnderTest.setLinkTarget(linkTarget);
		classUnderTest.setLinkNoFollow(linkNoFollow);
		
		assertEquals(classUnderTest.getComponentStyle(), componentStyle);
		assertEquals(classUnderTest.getTitleIcon(), titleIcon);
		
		assertEquals(classUnderTest.getTitle(), title);
		assertEquals(classUnderTest.getSubTitle(), subTitle);
		assertEquals(classUnderTest.getLinkLabel(), linkLabel);
		assertEquals(classUnderTest.getLinkPath(), linkPath);
		assertEquals(classUnderTest.getTitleIcon(), linkTarget);
		assertEquals(classUnderTest.getLinkTarget(), linkTarget);
		assertEquals(classUnderTest.geLinkNoFollow(), linkNoFollow);
		
		assertEquals(classUnderTest.toString(), toString);				
	}
	
	@Test
	public void createObjectTestWithValues() throws Exception {	       
		componentStyle = "Style1";
		titleIcon = "highlighetd";
		title = "Pay My Bills";
		subTitle = "Click above to pay tour bills";
		linkLabel = "Pay Bills";
		linkPath = "/content/secure/coverage-costs/pay-bills";
		linkTarget = "/content/secure/coverage-costs/pay-bills";		
		linkNoFollow = "true";
		toString="IconLinkModel [iconLinkId=" + iconLinkId + ", componentStyle=" + componentStyle
				+ ", titleIcon=" + titleIcon + ", title=" + title + ", subTitle=" + subTitle
				+ ", linkLabel=" + linkLabel + ", linkPath=" + linkPath + ", linkTarget=" + linkTarget
				+ ", linkNoFollow="+ linkNoFollow + "]";
		classUnderTest.setComponentStyle(componentStyle);
		classUnderTest.setTitleIcon(titleIcon);
		classUnderTest.setTitle(title);
		classUnderTest.setSubTitle(subTitle);
		classUnderTest.setLinkLabel(linkLabel);
		classUnderTest.setLinkPath(linkPath);
		classUnderTest.setLinkTarget(linkTarget);
		classUnderTest.setLinkNoFollow(linkNoFollow);
		
		assertEquals(classUnderTest.getComponentStyle(), componentStyle);
		assertEquals(classUnderTest.getTitleIcon(), titleIcon);		
		assertEquals(classUnderTest.getTitle(), title);
		assertEquals(classUnderTest.getSubTitle(), subTitle);
		assertEquals(classUnderTest.getLinkLabel(), linkLabel);
		assertEquals(classUnderTest.getLinkPath(), linkPath);
		assertEquals(classUnderTest.getLinkTarget(), linkTarget);
		assertEquals(classUnderTest.geLinkNoFollow(), linkNoFollow);
		
		assertEquals(classUnderTest.toString(), toString);				
	}

}


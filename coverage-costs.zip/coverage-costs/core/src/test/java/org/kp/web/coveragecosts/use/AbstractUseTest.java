//------------------------------------------------------------------------------
/*   Application Name: kp-foundation.
 *       Date Created: 10/24/2016
 *           Compiler: Java
 *
 *       Restrictions: None
 *       Dependencies: See import statements
 * NLS Considerations: None
 *
 *     Change History:
 *      Date            Programmer      Description/Comments/DefectID
 */
//------------------------------------------------------------------------------
package org.kp.web.coveragecosts.use;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.jcr.Node;
import javax.jcr.Property;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.script.Bindings;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.scripting.SlingScriptHelper;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.kp.foundation.core.constants.GlobalConstants;
//import org.kp.foundation.core.constants.LanguagePicker;
//import org.kp.foundation.core.constants.RegionPicker;
import org.kp.foundation.core.utils.GenericUtil;
import org.kp.foundation.core.utils.PropertyInheritedUtil;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.i18n.I18n;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;


//------------------------------------------------------------------------------
/**
 * Abstract parent class for component unit test.
 *
 * @author Krishan Rathi
 */
//------------------------------------------------------------------------------
@RunWith(PowerMockRunner.class)
@PrepareForTest({WCMUsePojo.class, LoggerFactory.class, GenericUtil.class, PropertyInheritedUtil.class,ResourceBundle.class,I18n.class})
public abstract class AbstractUseTest
{
	//----------------------------------------------------- Protected data members
	protected Logger   log;
	protected ValueMap properties;
	protected ValueMap inProperties;
	protected ValueMap contentValueMap;
	protected Bindings bindings;
	protected Node     nodeRegion;
	protected Node currentNode;
	protected Session  session;
	protected Property propRegion;
	protected PageManager pageManager;
	protected Page     page;
	protected Page     regionPage;
	protected Page     languagePage;

	protected ResourceResolver         rr;
	protected SlingScriptHelper        sh;
	protected SlingHttpServletRequest  req;
	protected SlingHttpServletResponse res;
	protected Locale curPageLocale;
	protected ResourceBundle resourceBundle;

	protected Resource resource;
	protected String regionCode;


	//----------------------------------------------------------------------------
	/*
	 * Common set up for the test cases.
	 */
	//----------------------------------------------------------------------------
	@Before
	public void setup() throws RepositoryException
	{
		onStartSetup();

		createMocks();

		wireMocks();

		onFinishSetup();

		return;
	} // setup


	//----------------------------------------------------------------------------
	/*
	 *                     Protected Overridable Methods
	 */
	//----------------------------------------------------------------------------
	//----------------------------------------------------------------------------
	/**
	 * Gets the component under test. Must be overridden.
	 *
	 * @return component under test
	 */
	//----------------------------------------------------------------------------
	protected abstract WCMUsePojo getClassUnderTest();


	//----------------------------------------------------------------------------
	/**
	 * Performs specific component test setup before mocks are created.
	 * Can be overridden.
	 */
	//----------------------------------------------------------------------------
	protected void onStartSetup() {}


	//----------------------------------------------------------------------------
	/**
	 * Performs specific component test setup after mocks are created and wired up.
	 * Can be overridden.
	 */
	//----------------------------------------------------------------------------
	protected void onFinishSetup() {}


	//----------------------------------------------------------------------------
	/*
	 *                         Protected Helper Methods
	 */
	//----------------------------------------------------------------------------
	//----------------------------------------------------------------------------
	/**
	 * Creates mock dependencies objects.
	 */
	//----------------------------------------------------------------------------
	protected void createMocks()
	{
		MockitoAnnotations.initMocks(this);
		PowerMockito.mockStatic(LoggerFactory.class);
		PowerMockito.mockStatic(GenericUtil.class); 
		PowerMockito.mockStatic(PropertyInheritedUtil.class); 
		PowerMockito.mockStatic(ResourceBundle.class);
		log = mock(Logger.class);
		nodeRegion = mock(Node.class);
		currentNode = mock(Node.class);
		propRegion = mock(Property.class);
		session = mock(Session.class);
		pageManager = mock(PageManager.class);
		page = mock(Page.class);
		sh = mock(SlingScriptHelper.class);
		rr = mock(ResourceResolver.class);
		bindings = mock(Bindings.class);
		req = mock(SlingHttpServletRequest.class);
		res = mock(SlingHttpServletResponse.class);
		resource = mock(Resource.class);
		properties = new ValueMapDecorator(new HashMap());
		inProperties = new ValueMapDecorator(new HashMap());
		resourceBundle = PowerMockito.mock(ResourceBundle.class);
		curPageLocale = PowerMockito.mock(Locale.class);
		return;
	} // createMocks


	//----------------------------------------------------------------------------
	/**
	 * Wires up created mock objects.
	 */
	//----------------------------------------------------------------------------
	protected void wireMocks() throws RepositoryException
	{

		when(LoggerFactory.getLogger(any(Class.class))).thenReturn(log);
		when(GenericUtil.isAuthorMode()).thenReturn(true);

		WCMUsePojo testClass = getClassUnderTest();
		PowerMockito.doReturn(properties).when(testClass).getProperties();
		PowerMockito.doReturn(properties).when(testClass).getPageProperties();
		PowerMockito.doReturn(inProperties).when(testClass).getInheritedProperties();
		doReturn(rr).when(testClass).getResourceResolver();
		doReturn(resource).when(testClass).getResource();
		doReturn(pageManager).when(testClass).getPageManager();
		doReturn(page).when(testClass).getCurrentPage();
		doReturn(sh).when(testClass).getSlingScriptHelper();
		doReturn(req).when(testClass).getRequest();
		doReturn(res).when(testClass).getResponse();
		doReturn(properties).when(resource).adaptTo(ValueMap.class);
		PowerMockito.when(page.getLanguage(false)).thenReturn(curPageLocale);
		PowerMockito.when(req.getResourceBundle(curPageLocale)).thenReturn(resourceBundle);
		when(rr.adaptTo(Session.class)).thenReturn(session);
		when(bindings.get("sling")).thenReturn(sh);
		when(resource.adaptTo(Node.class)).thenReturn(currentNode);

		return;
	} // wireMocks



	//----------------------------------------------------------------------------
	/**
	 * Sets the region.
	 *
	 * @param  region  region code
	 */
	//----------------------------------------------------------------------------
	protected void setDefaultLangRegion() throws RepositoryException
	{
		setLanguage("en");   
		regionPage=Mockito.mock(Page.class);
		//when(page.getAbsoluteParent(RegionPicker.CUR_REGION_ROOT_LEVEL)).thenReturn(regionPage);
		//when(regionPage.getPath()).thenReturn(GlobalConstants.CONTENT_KPORG_EN_NATIONAL);
		return;
	} // setRegion

	//----------------------------------------------------------------------------
	/**
	 * Sets the region.
	 *
	 * @param  region  region code
	 */
	//----------------------------------------------------------------------------
	protected void setRegion(String region) throws RepositoryException
	{
		regionPage=Mockito.mock(Page.class);
		String pathRegion = "/content/kporg/en/" + region;
		//when(page.getAbsoluteParent(RegionPicker.CUR_REGION_ROOT_LEVEL)).thenReturn(regionPage);
		when(regionPage.getPath()).thenReturn(pathRegion);
		when(regionPage.getName()).thenReturn(region);
		return;
	} // setRegion


	//----------------------------------------------------------------------------
	/**
	 * Sets the region.
	 *
	 * @param  region  region code
	 */
	//----------------------------------------------------------------------------
	protected void setLanguage(String lang) throws RepositoryException
	{
		String pathLanguage = "/content/kporg/"+lang ;
		languagePage=Mockito.mock(Page.class);
		//when(page.getAbsoluteParent(LanguagePicker.SITE_LANGUAGE_PAGE_LEVEL)).thenReturn(languagePage);
		when(languagePage.getPath()).thenReturn(pathLanguage);
		return;
	} // setRegion




	//----------------------------------------------------------------------------
	/**
	 * Sets a property value.
	 *
	 * @param  name   property name
	 * @param  value  property value
	 */
	//----------------------------------------------------------------------------
	protected void setProperty(String name, String value)
	{
		properties.put(name, value);

		return;
	}

	 protected void setProperties(String name, String []value)
	  {
	    properties.put(name, value);

	    return;
	  } 
	protected void setPath(String path) 
	{
		when(page.getPath()).thenReturn(path); 
	}

}
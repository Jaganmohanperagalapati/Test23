package org.kp.web.coveragecosts.utils;

import static org.junit.Assert.assertEquals;
import static org.powermock.api.mockito.PowerMockito.doReturn;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.spy;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.powermock.api.support.membermodification.MemberMatcher.method;
import static org.powermock.reflect.Whitebox.setInternalState;
import com.adobe.cq.sightly.SightlyWCMMode;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest({MCCWCMUseUtil.class})
public class MCCWCMUseUtilTest {
	//this is to bypass AEM layer
	//public class MCCWCMUseUtilStub extends MCCWCMUseUtil {
	//	private SightlyWCMMode swm;
	//	public MCCWCMUseUtilStub(
	//			SightlyWCMMode inSwm, boolean inLogDebugEnabled) {
	//		this.swm = inSwm;
	//		this.debugEnabled = inLogDebugEnabled;
	//	};
	//	public SightlyWCMMode getWcmMode() {
	//		return this.swm;
	//	}
	//}

	@Test
	public void testActivate() throws Exception {
		MCCWCMUseUtil mwuu = createMCCWCMUseUtil(false, false, false, false);
		assertEquals("display:none", mwuu.getDefaultDisplayStyle());
		assertEquals(false, mwuu.isAuthoring());
		verifyAuthoring(false, false, true, false);
		verifyAuthoring(false, true, false, false);
		verifyAuthoring(false, true, true, false);
		verifyAuthoring(true, false, false, false);
		verifyAuthoring(true, false, true, false);
		verifyAuthoring(true, true, false, false);
		verifyAuthoring(true, true, true, true);
	}

	private static void verifyAuthoring(
			boolean inEdit, boolean inDesign, boolean inPreview,
			boolean inLogDebugMode) throws Exception {
		MCCWCMUseUtil mwuu = createMCCWCMUseUtil(
			inEdit, inDesign, inPreview, inLogDebugMode);
		assertEquals("", mwuu.getDefaultDisplayStyle());
		assertEquals(true, mwuu.isAuthoring());
	}
	private static MCCWCMUseUtil createMCCWCMUseUtil(
			boolean inEdit, boolean inDesign, boolean inPreview,
			boolean inLogDebugMode) throws Exception {
		MCCWCMUseUtil outValue = spy(new MCCWCMUseUtil());
		SightlyWCMMode swm = mock(SightlyWCMMode.class);
		when(swm.isEdit()).thenReturn(inEdit);
		when(swm.isDesign()).thenReturn(inDesign);
		when(swm.isPreview()).thenReturn(inPreview);
		//when(outValue.getWcmMode()).thenReturn(swm);
		//when(
		//	outValue, method(MCCWCMUseUtil.class, "getWcmMode"))
		//	.withNoArguments().thenReturn(swm);
		doReturn(swm).when(outValue).getWcmMode();
		setInternalState(outValue, "debugEnabled", inLogDebugMode);
		outValue.activate();
		return outValue;
	}
}

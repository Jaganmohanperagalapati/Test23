package org.kp.web.coveragecosts.constants;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * The MCCConstantTest class for MCCConstant unit test cases.
 *
 * @author Jai Parkash
 * 
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({MCCConstant.class})
public class MCCConstantTest{	
	private String display="";
	private String displayNone="display:none";
	
	@Test
	public void createObjectTestWithBlankValues() throws Exception {	       
		assertEquals(MCCConstant.DISPLAY, display);	
		assertEquals(MCCConstant.DISPLAY_NONE, displayNone);		
	}
	//@Test(expected = IllegalStateException.class)
//	public void testException() {
//		MCCConstant mccConst = new MCCConstant();
//	}
	
	
}


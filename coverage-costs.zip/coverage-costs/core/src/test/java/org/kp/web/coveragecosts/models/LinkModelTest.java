package org.kp.web.coveragecosts.models;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.HashMap;

import javax.jcr.RepositoryException;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.kp.web.coveragecosts.use.AbstractUseTest;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.adobe.cq.sightly.WCMUsePojo;

/**
 * The LinkModelTest class for LinkModel unit test cases.
 *
 * @author Jai Parkash
 * 
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({LinkModel.class})
public class LinkModelTest{
	private LinkModel classUnderTest = null;
	protected Resource resource;
	
	private String linkLanguage;
	private String resourceLink;
	private String displayText;
	private String target;
	private String context;
	private String toString;
	
	@Before
	public void setup() throws RepositoryException {
		resource=mock(Resource.class);
		getClassUnderTest();
	}

	protected LinkModel getClassUnderTest() {
		if (classUnderTest == null) {
			classUnderTest =PowerMockito.spy(new LinkModel());
		}
		return classUnderTest;
	
	}
	@Test
	public void createObjectTestWithBlankValues() throws Exception {	       
		linkLanguage = "";
		resourceLink = "";
		displayText = "";
		target = "";		
		context = "";
		toString="LinkModel [linkLanguage=" + linkLanguage + ", resourceLink=" + resourceLink + ", displayText="
				+ displayText + ", target=" + target + ", context=" + context + "]";
		
		classUnderTest.setLinkLanguage(linkLanguage);
		classUnderTest.setResourceLink(resourceLink);
		classUnderTest.setDisplayText(displayText);
		classUnderTest.setTarget(target);
		classUnderTest.setContext(context);
	
		assertEquals(classUnderTest.getLinkLanguage(), linkLanguage);
		assertEquals(classUnderTest.getResourceLink(), resourceLink);
		assertEquals(classUnderTest.getDisplayText(), displayText);
		assertEquals(classUnderTest.getTarget(), target);
		assertEquals(classUnderTest.getContext(), context);
		
		assertEquals(classUnderTest.toString(), toString);				
	}
	
	@Test
	public void createObjectTestWithValues() throws Exception {	       
		linkLanguage = "";
		resourceLink = "/content/secure/coverage-costs/pay-bills";
		displayText = "Pay Bills";
		target = "/content/secure/coverage-costs/pay-bills";		
		context = "true";
		toString="LinkModel [linkLanguage=" + linkLanguage + ", resourceLink=" + resourceLink + ", displayText="
				+ displayText + ", target=" + target + ", context=" + context + "]";
		
		classUnderTest.setLinkLanguage(linkLanguage);
		classUnderTest.setResourceLink(resourceLink);
		classUnderTest.setDisplayText(displayText);
		classUnderTest.setTarget(target);
		classUnderTest.setContext(context);
	
		assertEquals(classUnderTest.getLinkLanguage(), linkLanguage);
		assertEquals(classUnderTest.getResourceLink(), resourceLink);
		assertEquals(classUnderTest.getDisplayText(), displayText);
		assertEquals(classUnderTest.getTarget(), target);
		assertEquals(classUnderTest.getContext(), context);
		
		assertEquals(classUnderTest.toString(), toString);				
	}

}


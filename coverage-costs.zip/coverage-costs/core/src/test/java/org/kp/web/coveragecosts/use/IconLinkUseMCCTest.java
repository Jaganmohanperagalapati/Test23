package org.kp.web.coveragecosts.use;

import static org.junit.Assert.assertEquals;
import static org.powermock.api.mockito.PowerMockito.doReturn;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.spy;
import org.apache.sling.api.resource.ValueMap;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

/**
 * @author Gary Steinmetz
 */

@RunWith(PowerMockRunner.class)
@PrepareForTest({IconLinkUseMCC.class})
public class IconLinkUseMCCTest {
    private static String PROP_TITLE_ICON = "titleIcon";
    private static String PROP_PBILLTYPE = "pBillType";
    private static String PROP_HBILLTYPE = "hBillType";
    private static String PROP_PHBILLTYPE = "phBillType";
    private static String PROP_BILLDATE = "billDate";
    private static String PROP_DUEDATE = "dueDate";
    private static String PROP_VIEWBILLLABEL = "viewBillLabel";
    private static String PROP_PAYBILLLABEL = "payBillLabel";
    private static String PROP_ACCBILLLABEL = "accBillLabel";
    private static String PROP_PAYBILLPATH = "payBillPath";

    private static String PROP_VIEWPAYMENTPLANLABEL = "viewPaymentPlanLabel";
    private static String PROP_TOOLTIPMODAL = "toolTipModal";
    private static String PROP_PATIENTACCOUNT = "patientAccount";
    private static String PROP_CHARGES = "charges";
    private static String PROP_ADJUSTMENTS = "adjustments";
    private static String PROP_PAIDBYYOU = "paidByYou";
    private static String PROP_AMTYOUOWE = "amtYouOwe";
    private static String PROP_CHARGESMOBILE = "chargesMobile";
    private static String PROP_ADJUSTMENTSMOBILE = "adjustmentsMobile";
    private static String PROP_PAIDBYYOUMOBILE = "paidByYouMobile";
    private static String PROP_AMTYOUOWEMOBILE = "amtYouOweMobile";
    private static String PROP_DUE = "due";
    private static String PROP_PAYBILLSLABEL = "payBillsLabel";

    @Test
    public void testGetters() throws Exception {
        IconLinkUseMCC ilum = createIconLinkUseMCC(
                "titleIcon", "pBillType", "hBillType",
                "phBillType", "billDate", "dueDate",
                "viewBillLabel", "payBillLabel", "payBillPath",
                "accBillLabel", "viewPaymentPlanLabel",
                "toolTipModal", "patientAccount", "charges",
                "adjustments", "paidByYou", "amtYouOwe",
                "chargesMobile", "adjustmentsMobile", "paidByYouMobile",
                "amtYouOweMobile", "due", "payBillsLabel");
        assertEquals("titleIcon", ilum.getTitleIcon());
        assertEquals("pBillType", ilum.getPBillType());
        assertEquals("hBillType", ilum.getHBillType());
        assertEquals("phBillType", ilum.getPhBillType());
        assertEquals("billDate", ilum.getBillDate());
        assertEquals("dueDate", ilum.getDueDate());
        assertEquals("viewBillLabel", ilum.getViewBillLabel());
        assertEquals("payBillLabel", ilum.getPayBillLabel());
        assertEquals("payBillPath", ilum.getPayBillPath());
        assertEquals("accBillLabel", ilum.getAccBillLabel());
        assertEquals("viewPaymentPlanLabel", ilum.getViewPaymentPlanLabel());
        assertEquals("toolTipModal", ilum.getToolTipModal());
        assertEquals("patientAccount", ilum.getPatientAccount());
        assertEquals("charges", ilum.getCharges());
        assertEquals("adjustments", ilum.getAdjustments());
        assertEquals("paidByYou", ilum.getPaidByYou());
        assertEquals("amtYouOwe", ilum.getAmtYouOwe());
        assertEquals("chargesMobile", ilum.getChargesMobile());
        assertEquals("adjustmentsMobile", ilum.getAdjustmentsMobile());
        assertEquals("paidByYouMobile", ilum.getPaidByYouMobile());
        assertEquals("amtYouOweMobile", ilum.getAmtYouOweMobile());
        assertEquals("due", ilum.getDue());
        assertEquals("payBillsLabel", ilum.getPayBillsLabel());
        //
        String outputExpected = "{\"titleIcon\":\"titleIcon\",\"pBillType\":\"pBillType\",\"hBillType\":\"hBillType\",\"phBillType\":\"phBillType\",\"billDate\":\"billDate\",\"dueDate\":\"dueDate\",\"viewBillLabel\":\"viewBillLabel\",\"payBillLabel\":\"payBillLabel\",\"payBillPath\":\"payBillPath\",\"accBillLabel\":\"accBillLabel\",\"viewPaymentPlanLabel\":\"viewPaymentPlanLabel\",\"toolTipModal\":\"toolTipModal\",\"patientAccount\":\"patientAccount\",\"charges\":\"charges\",\"adjustments\":\"adjustments\",\"paidByYou\":\"paidByYou\",\"amtYouOwe\":\"amtYouOwe\",\"chargesMobile\":\"chargesMobile\",\"adjustmentsMobile\":\"adjustmentsMobile\",\"paidByYouMobile\":\"paidByYouMobile\",\"amtYouOweMobile\":\"amtYouOweMobile\",\"due\":\"due\",\"payBillsLabel\":\"payBillsLabel\"}";
        assertEquals(outputExpected, ilum.getJSON());
    }

    private static IconLinkUseMCC createIconLinkUseMCC(
            String titleIcon, String pBillType, String hBillType,
            String phBillType, String billDate, String dueDate,
            String viewBillLabel, String payBillLabel, String payBillPath,
            String accBillLabel, String viewPaymentPlanLabel,
            String toolTipModal, String patientAccount, String charges, String adjustments,
            String paidByYou, String amtYouOwe, String chargesMobile, String adjustmentsMobile,
            String paidByYouMobile, String amtYouOweMobile, String due, String payBillsLabel) throws Exception {
        IconLinkUseMCC outValue = spy(new IconLinkUseMCC());
        ValueMap props = createProperties(
                titleIcon, pBillType, hBillType, phBillType, billDate, dueDate,
                viewBillLabel, payBillLabel, payBillPath, accBillLabel,
                viewPaymentPlanLabel, toolTipModal, patientAccount, charges,
                adjustments, paidByYou, amtYouOwe, chargesMobile, adjustmentsMobile,
                paidByYouMobile, amtYouOweMobile, due, payBillsLabel);
        doReturn(props).when(outValue).getProperties();
        outValue.activate();
        return outValue;
    }
    private static ValueMap createProperties(
            String titleIcon, String pBillType, String hBillType,
            String phBillType, String billDate, String dueDate,
            String viewBillLabel, String payBillLabel, String payBillPath,
            String accBillLabel, String viewPaymentPlanLabel,
            String toolTipModal, String patientAccount, String charges, String adjustments,
            String paidByYou, String amtYouOwe, String chargesMobile, String adjustmentsMobile,
            String paidByYouMobile, String amtYouOweMobile, String due, String payBillsLabel) throws Exception {
        ValueMap outValue = mock(ValueMap.class);
        doReturn(titleIcon).when(outValue).get(PROP_TITLE_ICON,"");
        doReturn(pBillType).when(outValue).get(PROP_PBILLTYPE,"");
        doReturn(hBillType).when(outValue).get(PROP_HBILLTYPE,"");
        doReturn(phBillType).when(outValue).get(PROP_PHBILLTYPE,"");
        doReturn(billDate).when(outValue).get(PROP_BILLDATE,"");
        doReturn(dueDate).when(outValue).get(PROP_DUEDATE,"");
        doReturn(viewBillLabel).when(outValue).get(PROP_VIEWBILLLABEL,"");
        doReturn(payBillLabel).when(outValue).get(PROP_PAYBILLLABEL,"");
        doReturn(payBillPath).when(outValue).get(PROP_PAYBILLPATH,"");
        doReturn(accBillLabel).when(outValue).get(PROP_ACCBILLLABEL,"");
        doReturn(viewPaymentPlanLabel).when(outValue).get(PROP_VIEWPAYMENTPLANLABEL,"");
        doReturn(toolTipModal).when(outValue).get(PROP_TOOLTIPMODAL,"");
        doReturn(patientAccount).when(outValue).get(PROP_PATIENTACCOUNT,"");
        doReturn(charges).when(outValue).get(PROP_CHARGES,"");
        doReturn(adjustments).when(outValue).get(PROP_ADJUSTMENTS,"");
        doReturn(paidByYou).when(outValue).get(PROP_PAIDBYYOU,"");
        doReturn(amtYouOwe).when(outValue).get(PROP_AMTYOUOWE,"");
        doReturn(chargesMobile).when(outValue).get(PROP_CHARGESMOBILE,"");
        doReturn(adjustmentsMobile).when(outValue).get(PROP_ADJUSTMENTSMOBILE,"");
        doReturn(paidByYouMobile).when(outValue).get(PROP_PAIDBYYOUMOBILE,"");
        doReturn(amtYouOweMobile).when(outValue).get(PROP_AMTYOUOWEMOBILE,"");
        doReturn(due).when(outValue).get(PROP_DUE,"");
        doReturn(payBillsLabel).when(outValue).get(PROP_PAYBILLSLABEL,"");
        return outValue;
    }
}
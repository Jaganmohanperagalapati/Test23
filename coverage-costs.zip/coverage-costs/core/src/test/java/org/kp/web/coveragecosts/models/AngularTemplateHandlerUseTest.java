package org.kp.web.coveragecosts.models;

import static org.junit.Assert.assertEquals;
import static org.powermock.api.mockito.PowerMockito.doReturn;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.spy;
import static org.powermock.reflect.Whitebox.setInternalState;

import java.util.Arrays;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.components.Component;
import com.day.cq.wcm.api.components.ComponentManager;
import com.day.cq.wcm.commons.WCMUtils;

@RunWith(PowerMockRunner.class)
@PrepareForTest({AngularTemplateHandlerUse.class})
public class AngularTemplateHandlerUseTest {
    private final static String ROOT_COMP_TYPE =
        "kporg/coverage-costs/components/content/root-comp-mcc";
    private final static String COMP_ANGULAR_PROPERTY_NAME="compModelType";
    private final static String COMP_ANGULAR_PROPERTY_VALUE="Angular";
    
    @Test
    public void testGettersWithoutChildResources() throws Exception {
        AngularTemplateHandlerUse athu;
        Resource resource;
        Resource rootResource;
        resource = createResource(
            false, false, "SomePath", new Resource[]{});
        athu = createAngularTemplateHandlerUse(null, resource, true);
        assertEquals(0, athu.getAngularComps().size());
        //
        resource = createResource(
            true, false, "SomePath", new Resource[]{});
        rootResource = createResource(
            true, false, "SomePath", new Resource[]{});
        athu = createAngularTemplateHandlerUse(rootResource, resource, false);
        assertEquals(0, athu.getAngularComps().size());
    }

    @Test
    public void testGettersWithChildResources() throws Exception {
        AngularTemplateHandlerUse athu;
        Resource resource1, resource2, resource3, resource4, resource5;
        Resource rootResource;
        
        resource2 = createResource(
                false, true, "SomePath", new Resource[]{});
        resource3 = createResource(
                false, true, "SomePath", new Resource[]{});
        resource4 = createResource(
                false, false, "SomePath", new Resource[]{});
        Resource[] childComps = new Resource [3];
        childComps[0]=resource2;
        childComps[1]=resource3;
        childComps[2]=resource4;
        // Angular Resource child of root resource parent of 2 angular and 1 non angular resource       
        resource1 = createResource(
                false, false, "SomePath", childComps);
        athu = createAngularTemplateHandlerUse(null, resource1, true);
        assertEquals(2, athu.getAngularComps().size());
        
        resource5= createResource(
                false, true, "SomePath", new Resource[]{});
        childComps[2]=resource5;
        athu = createAngularTemplateHandlerUse(null, resource1, true);
        assertEquals(3, athu.getAngularComps().size());

    }
    
	private static AngularTemplateHandlerUse createAngularTemplateHandlerUse(
            Resource inRootComp, Resource inResource,
            boolean inLogDebugMode) throws Exception {
        AngularTemplateHandlerUse outValue = spy(new AngularTemplateHandlerUse());
        //Resource pageResource = mock(Resource.class);
        Page page = mock(Page.class);
        doReturn(page).when(outValue).getCurrentPage();
        if (inRootComp != null) {
            //doReturn(ROOT_COMP_TYPE).when(page).getResourceType();
            doReturn(inRootComp).when(page).getContentResource();
        } else {
            //doReturn(null).when(page).getResourceType();
            doReturn(null).when(page).getContentResource();
        }
        doReturn(inResource).when(outValue).getResource();
        setInternalState(outValue, "debugEnabled", inLogDebugMode);
        outValue.activate();
        return outValue;
    }
    private static Resource createResource(
            boolean inRootCompPresent, boolean inUseAngularPropertyName,
            String inPath, Resource[] inChildResources) {
        Resource outValue = mock(Resource.class);
        //
        if (inRootCompPresent) {
            //System.out.println("ZZZ inRootComp = " + inRootComp);
            doReturn(ROOT_COMP_TYPE).when(outValue).getResourceType();
            //System.out.println("ZZZ inRootComp,r = " + outValue.getResourceType());
        } else {
            doReturn("").when(outValue).getResourceType();
        }
        //
        ValueMap vm = mock(ValueMap.class);
        doReturn(vm).when(outValue).getValueMap();
        if (inUseAngularPropertyName) {
            doReturn(COMP_ANGULAR_PROPERTY_VALUE).when(vm).get(
                COMP_ANGULAR_PROPERTY_NAME, "");
        } else {
            doReturn("").when(vm).get(COMP_ANGULAR_PROPERTY_NAME, "");
        }
        //
        doReturn(inPath).when(outValue).getPath();
        //
        if (inChildResources.length>0) {
        	doReturn(true).when(outValue).hasChildren();
        } else {
        	doReturn(false).when(outValue).hasChildren();
        }
        	
        doReturn(Arrays.asList(inChildResources)).when(outValue).getChildren();
        //Component childResourceComp = WCMUtils.getComponent(childResource);
        Component comp = mock(Component.class);
        PowerMockito.mockStatic(WCMUtils.class);
        ResourceResolver resol =mock(ResourceResolver.class);
        PowerMockito.when(outValue.getResourceResolver()).thenReturn(resol);
        ComponentManager compMgr =mock(ComponentManager.class);
        PowerMockito.when(resol.adaptTo(ComponentManager.class)).thenReturn(compMgr);
        PowerMockito.when(compMgr.getComponentOfResource(outValue)).thenReturn(comp);
    
        PowerMockito.when(WCMUtils.getComponent(outValue)).thenReturn(comp);     
        return outValue;
    }
    

}

package org.kp.web.coveragecosts.use;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.HashMap;

import javax.jcr.RepositoryException;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.adobe.cq.sightly.WCMUsePojo;

/**
 * The PaymentPlanDetailUseTest class for PaymentPlanDetailUse unit test cases.
 * @author Jai Parkash
*/

@RunWith(PowerMockRunner.class)
@PrepareForTest({PaymentPlanDetailUse.class})

public class PaymentPlanDetailUseTest extends AbstractUseTest {
	
    private static final String ACCOUNT_LABEL = "accountlabel";
    private static final String HOSPITAL_BILL_PMT_PLAN_LABEL = "hospbillpmtplanlabel";
    private static final String PROFESIONAL_BILL_PMT_PLAN_LABEL = "profbillpmtplanlabel";
    private static final String HOSPITAL_PROFESIONAL_BILL_PMT_PLAN_LABEL = "hospprofbillpmtplanlabel";
    private static final String RECURRING_BILL_PMT_PLAN_LABEL = "recurringbillpmtplanlabel";
    private static final String NEXT_PMT_PLAN_LABEL = "nextpmtplanlabel";
    private static final String BEG_PLAN_BAL_LABEL = "begplanballabel";
    private static final String PMT_PLAN_START_DATE_LABEL = "pmtplanstartdatelabel";
    private static final String REMAINING_BAL_LABEL = "remainballabel";
    private static final String PMT_PLAN_DETAILS_DESC_LABEL = "pmtplandetailsdesc";

    private static final String JSON_COMP_NAME = "compname"; 
    private static final String JSON_ACCOUNT_LABEL_ATTR = "accountlabel";
    private static final String JSON_HOSPITAL_BILL_PMT_PLAN_LABEL_ATTR = "hospbillpmtplanlabel";
    private static final String JSON_PROFESIONAL_BILL_PMT_PLAN_LABEL_ATTR = "profbillpmtplanlabel";
    private static final String JSON_HOSPITAL_PROFESIONAL_BILL_PMT_PLAN_LABEL_ATTR = "hospprofbillpmtplanlabel";
    private static final String JSON_RECURRING_BILL_PMT_PLAN_LABEL_ATTR = "recurringbillpmtplanlabel";
    private static final String JSON_NEXT_PMT_PLAN_LABEL_ATTR = "nextpmtplanlabel";
    private static final String JSON_BEG_PLAN_BAL_LABEL_ATTR = "begplanballabel";
    private static final String JSON_PMT_PLAN_START_DATE_LABEL_ATTR = "pmtplanstartdatelabe";
    private static final String JSON_REMAINING_BAL_LABEL_ATTR = "remainballabel";
    private static final String JSON_PMT_PLAN_DETAILS_DESC_LABEL_ATTR = "pmtplandetailsdesc";
    
    private  static String compName="";
    private  static String accountLabel="";
    private  static String hospBillPMTPlanLabel="";
    private  static String profBillPMTPlanLabel="";
    private  static String hospProfBillPMTPlanLabel="";
    private  static String recurringBillPMTPlanLabel="";
    private  static String nextPMTPlanLabel="";
    private  static String begPlanBalLabel="";  
    private  static String pmtPlanStartDateLabel="";  
    private  static String remainBalLabel="";  
    private  static String pmtPlanDetailsDesc=""; 
    private  static String toString="";
    
	private PaymentPlanDetailUse classUnderTest = null;

		
	@Before
	public void setup() throws RepositoryException {
		super.setup();
		resource=mock(Resource.class);
		when(classUnderTest.getResource()).thenReturn(resource);
		when (resource.getName()).thenReturn(compName);		
	}
	
	@Override
	protected WCMUsePojo getClassUnderTest() {
		if (classUnderTest == null) {
			classUnderTest =PowerMockito.spy(new PaymentPlanDetailUse());
		}
		return classUnderTest;
	}

	@Test
	public void testGettersWithoutValues() throws Exception {
		  accountLabel="";
		  hospBillPMTPlanLabel="";
		  profBillPMTPlanLabel="";
		  hospProfBillPMTPlanLabel="";
		  recurringBillPMTPlanLabel="R";
		  nextPMTPlanLabel="";
		  begPlanBalLabel="l";  
		  pmtPlanStartDateLabel="";  
		  remainBalLabel="";  
		  pmtPlanDetailsDesc=""; 
		  toString="{"+JSON_COMP_NAME +":"+ compName + ", "+JSON_ACCOUNT_LABEL_ATTR+":" + accountLabel + ", "+JSON_HOSPITAL_BILL_PMT_PLAN_LABEL_ATTR+":" + hospBillPMTPlanLabel
					+ ", "+JSON_PROFESIONAL_BILL_PMT_PLAN_LABEL_ATTR+":" + profBillPMTPlanLabel + ", "+JSON_HOSPITAL_PROFESIONAL_BILL_PMT_PLAN_LABEL_ATTR+":" + hospProfBillPMTPlanLabel + ", "+JSON_RECURRING_BILL_PMT_PLAN_LABEL_ATTR+":" + recurringBillPMTPlanLabel
					+ ", "+JSON_NEXT_PMT_PLAN_LABEL_ATTR+":" + nextPMTPlanLabel + ", "+JSON_BEG_PLAN_BAL_LABEL_ATTR+":" + begPlanBalLabel + ", "+JSON_PMT_PLAN_START_DATE_LABEL_ATTR+":" + pmtPlanStartDateLabel
					+ ", "+JSON_REMAINING_BAL_LABEL_ATTR+":"+ remainBalLabel +", "+JSON_PMT_PLAN_DETAILS_DESC_LABEL_ATTR+":"+ pmtPlanDetailsDesc + "}";
		

		  	ValueMap properties = new ValueMapDecorator(new HashMap<String, Object>());
			properties.put(ACCOUNT_LABEL, accountLabel);
			properties.put(HOSPITAL_BILL_PMT_PLAN_LABEL, hospBillPMTPlanLabel);
			properties.put(PROFESIONAL_BILL_PMT_PLAN_LABEL, profBillPMTPlanLabel);
			properties.put(HOSPITAL_PROFESIONAL_BILL_PMT_PLAN_LABEL, hospProfBillPMTPlanLabel);		
			properties.put(RECURRING_BILL_PMT_PLAN_LABEL, recurringBillPMTPlanLabel);
			properties.put(NEXT_PMT_PLAN_LABEL, nextPMTPlanLabel);
			properties.put(BEG_PLAN_BAL_LABEL, begPlanBalLabel);
			properties.put(PMT_PLAN_START_DATE_LABEL, pmtPlanStartDateLabel);
			properties.put(REMAINING_BAL_LABEL, remainBalLabel);		
			properties.put(PMT_PLAN_DETAILS_DESC_LABEL, pmtPlanDetailsDesc);			
 
	        when(classUnderTest.getProperties()).thenReturn(properties);

			classUnderTest.activate();
			
		assertEquals(classUnderTest.getAccountLabel(),accountLabel );
		assertEquals(classUnderTest.getHospBillPMTPlanLabel(),hospBillPMTPlanLabel );	
		assertEquals(classUnderTest.getProfBillPMTPlanLabel(),profBillPMTPlanLabel );
		assertEquals(classUnderTest.getHospProfBillPMTPlanLabel(),hospProfBillPMTPlanLabel );
		assertEquals(classUnderTest.getRecurringBillPMTPlanLabel(),recurringBillPMTPlanLabel );
		assertEquals(classUnderTest.getNextPMTPlanLabel(),nextPMTPlanLabel );
		assertEquals(classUnderTest.getBegPlanBalLabel(),begPlanBalLabel );
		
		assertEquals(classUnderTest.getPmtPlanStartDateLabel(),pmtPlanStartDateLabel );
		assertEquals(classUnderTest.getRemainBalLabel(),remainBalLabel );
		assertEquals(classUnderTest.getPmtPlanDetailsDesc(),pmtPlanDetailsDesc );
		assertEquals(classUnderTest.getComponentText(),"" );
		
		assertEquals(classUnderTest.getJSON().replace(" ", "").replace("\n", "").replace("\"", ""),toString.replace(" ", ""));	
	}
	
	@Test
	public void testGettersWithValues() throws Exception {
		  accountLabel="Account";
		  hospBillPMTPlanLabel="Hospital Bill";
		  profBillPMTPlanLabel="Prof Bill";
		  hospProfBillPMTPlanLabel="Hosp/Prof Bill";
		  recurringBillPMTPlanLabel="Recurring";
		  nextPMTPlanLabel="Next Payment";
		  begPlanBalLabel="Beg Bal";  
		  pmtPlanStartDateLabel="Start Date";  
		  remainBalLabel="Remaining Amt:";  
		  pmtPlanDetailsDesc="Plan Details"; 
		  toString="{"+JSON_COMP_NAME +":"+ compName + ", "+JSON_ACCOUNT_LABEL_ATTR+":" + accountLabel + ", "+JSON_HOSPITAL_BILL_PMT_PLAN_LABEL_ATTR+":" + hospBillPMTPlanLabel
					+ ", "+JSON_PROFESIONAL_BILL_PMT_PLAN_LABEL_ATTR+":" + profBillPMTPlanLabel + ", "+JSON_HOSPITAL_PROFESIONAL_BILL_PMT_PLAN_LABEL_ATTR+":" + hospProfBillPMTPlanLabel + ", "+JSON_RECURRING_BILL_PMT_PLAN_LABEL_ATTR+":" + recurringBillPMTPlanLabel
					+ ", "+JSON_NEXT_PMT_PLAN_LABEL_ATTR+":" + nextPMTPlanLabel + ", "+JSON_BEG_PLAN_BAL_LABEL_ATTR+":" + begPlanBalLabel + ", "+JSON_PMT_PLAN_START_DATE_LABEL_ATTR+":" + pmtPlanStartDateLabel
					+ ", "+JSON_REMAINING_BAL_LABEL_ATTR+":"+ remainBalLabel +", "+JSON_PMT_PLAN_DETAILS_DESC_LABEL_ATTR+":"+ pmtPlanDetailsDesc + "}";
		

		  	ValueMap properties = new ValueMapDecorator(new HashMap<String, Object>());
			properties.put(ACCOUNT_LABEL, accountLabel);
			properties.put(HOSPITAL_BILL_PMT_PLAN_LABEL, hospBillPMTPlanLabel);
			properties.put(PROFESIONAL_BILL_PMT_PLAN_LABEL, profBillPMTPlanLabel);
			properties.put(HOSPITAL_PROFESIONAL_BILL_PMT_PLAN_LABEL, hospProfBillPMTPlanLabel);		
			properties.put(RECURRING_BILL_PMT_PLAN_LABEL, recurringBillPMTPlanLabel);
			properties.put(NEXT_PMT_PLAN_LABEL, nextPMTPlanLabel);
			properties.put(BEG_PLAN_BAL_LABEL, begPlanBalLabel);
			properties.put(PMT_PLAN_START_DATE_LABEL, pmtPlanStartDateLabel);
			properties.put(REMAINING_BAL_LABEL, remainBalLabel);		
			properties.put(PMT_PLAN_DETAILS_DESC_LABEL, pmtPlanDetailsDesc);			
			
 
	        when(classUnderTest.getProperties()).thenReturn(properties);

			classUnderTest.activate();
			
		assertEquals(classUnderTest.getAccountLabel(),accountLabel );
		assertEquals(classUnderTest.getHospBillPMTPlanLabel(),hospBillPMTPlanLabel );	
		assertEquals(classUnderTest.getProfBillPMTPlanLabel(),profBillPMTPlanLabel );
		assertEquals(classUnderTest.getHospProfBillPMTPlanLabel(),hospProfBillPMTPlanLabel );
		assertEquals(classUnderTest.getRecurringBillPMTPlanLabel(),recurringBillPMTPlanLabel );
		assertEquals(classUnderTest.getNextPMTPlanLabel(),nextPMTPlanLabel );
		assertEquals(classUnderTest.getBegPlanBalLabel(),begPlanBalLabel );
		
		assertEquals(classUnderTest.getPmtPlanStartDateLabel(),pmtPlanStartDateLabel );
		assertEquals(classUnderTest.getRemainBalLabel(),remainBalLabel );
		assertEquals(classUnderTest.getPmtPlanDetailsDesc(),pmtPlanDetailsDesc );
		assertEquals(classUnderTest.getComponentText(),"" );
		
		
		assertEquals(classUnderTest.getJSON().replace(" ", "").replace("\n", "").replace("\"", ""),toString.replace(" ", ""));	
	}

}

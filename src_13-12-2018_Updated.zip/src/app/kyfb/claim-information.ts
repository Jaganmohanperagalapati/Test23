interface AutoPolicies {
    autoPolicies?: PolicyDTO[];
}

interface PropertyPolicies {
    propertyPolicies?: PolicyDTO[];
}

interface PolicyDTO {
    policyNumber: string;
    lineOfBusiness: string;
    unitInfo: UnitType[];
    address: string;
    city: string;
    state: string;
    zip: string;
    type: string;
    status: string;
    policyHolderNames: PolicyHolderName[];
}

interface UnitType {
    unitNumber: string;
    unitDescription: string;
    vehicle: Vehicle;
}

interface PolicyHolderName {
    lastName: string;
    firstName: string;
    middleName: string;
    relationship: string;
}

interface Vehicle {
    year: string;
    make: string;
    model: string;
    vin: string;
}

interface ClaimHistoryInfo {
    policyNumber: string;
    claimNumber: string;
    policyTypeDesc: string;
    renewalAgencyNbr: string;
    agentPreferredNm: string;
    claimBranchNbr: string;
    assignedAdjusterNm: string;
    adjusterPhoneNbr: string;
    lossDt: string;
    lossReportedDt: string;
    claimDesc: string;
    membershipNbr: string;
    claimStatusDesc: string;
    claimSourceNm: string;
}

export class ClaimInformation {
    clientName: string;
    eBusinessId: string;
    portalEmailId: string;
    message: string;
    policyNum: string;
    lob: string;
    policyType: string;
    autoPolicies: AutoPolicies[];
    propertyPolicies: PropertyPolicies[];
    firstName: string;
    lastName: string;
    country: string;
    city: string;
    state: string;
    zip: string;
    otherCountry: string;
    otherState: string;
    policyNumForFNOL: string;
    rows: string;
    moreRows: string;
    claimHistoryInfoList: ClaimHistoryInfo[];

    /**
     * @todo Not in the schema yet, will build interfaces later.
     */

    constructor(
        clientName: string,
        eBusinessId: string,
        portalEmailId: string,
        message: string,
        policyNum: string,
        lob: string,
        policyType: string,
        autoPolicies: AutoPolicies[],
        propertyPolicies: PropertyPolicies[],
        firstName: string,
        lastName: string,
        country: string,
        city: string,
        state: string,
        zip: string,
        otherCountry: string,
        otherState: string,
        policyNumForFNOL: string,
        rows: string,
        moreRows: string,
        claimHistoryInfoList: ClaimHistoryInfo[]
    ) {
        this.clientName = clientName;
        this.eBusinessId = eBusinessId;
        this.portalEmailId = portalEmailId;
        this.message = message;
        this.policyNum = policyNum;
        this.lob = lob;
        this.policyType = policyType;
        this.autoPolicies = autoPolicies;
        this.propertyPolicies = propertyPolicies;
        this.firstName = firstName;
        this.lastName = lastName;
        this.country = country;
        this.city = city;
        this.state = state;
        this.zip = zip;
        this.otherCountry = otherCountry;
        this.otherState = otherState;
        this.policyNumForFNOL = policyNumForFNOL;
        this.rows = rows;
        this.moreRows = moreRows;
        this.claimHistoryInfoList = claimHistoryInfoList;
    }
}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kyfb-report-claim-landing',
  templateUrl: './report-claim-landing.component.html',
  styleUrls: ['./report-claim-landing.component.scss']
})
export class ReportClaimLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

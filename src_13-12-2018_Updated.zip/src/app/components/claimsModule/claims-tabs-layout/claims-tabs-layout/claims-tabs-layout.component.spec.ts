import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimsTabsLayoutComponent } from './claims-tabs-layout.component';

describe('ClaimsTabsLayoutComponent', () => {
  let component: ClaimsTabsLayoutComponent;
  let fixture: ComponentFixture<ClaimsTabsLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClaimsTabsLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimsTabsLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

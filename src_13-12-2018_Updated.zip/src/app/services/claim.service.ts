import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';
import { ClaimInformation } from '../kyfb/claim-information';

@Injectable({
    providedIn: 'root'
})
export class ClaimService {
    policesInfo: any[] = [];
    defaultDetails:any[]=[];
    vehicleInfo: any[] = [];
    private dueDateDetials = new BehaviorSubject(this.defaultDetails);
    currentDueDateDetails = this.dueDateDetials.asObservable();

    setDuedateDetials(dueDateDetials: any) {
        this.dueDateDetials.next(dueDateDetials)
    }


    constructor(private http: HttpClient) { }

    getClaimInformation(): Observable<ClaimInformation> {
        //https://api.myjson.com/bins/s1lpm
        //https://kyfb.crosby.work/api/account.json
        return this.http.get<ClaimInformation>('https://api.myjson.com/bins/6c0ze')
            .pipe(
                map((response: any) => {
                    return new ClaimInformation(
                        response.clientName,
                        response.eBusinessId,
                        response.portalEmailId,
                        response.message,
                        response.policyNum,
                        response.lob,
                        response.policyType,
                        response.autoPolicies,
                        response.propertyPolicies,
                        response.firstName,
                        response.lastName,
                        response.country,
                        response.city,
                        response.state,
                        response.zip,
                        response.otherCountry,
                        response.otherState,
                        response.policyNumForFNOL,
                        response.rows,
                        response.moreRows,
                        response.claimHistoryInfoList
                    );
                }),
                // catchError(this.handleError('getClaimInformation', []))
            );
    }
/*https://api.myjson.com/bins/bn1lq*/
    getClaimsInfo(): Observable<any> {
  // return this.http.get<any>('https://api.myjson.com/bins/bn1lq')
//return this.http.get<any>('http://lst1s34.kfbdom1.kyfb.pri:9082/EBusinessPortal/account/4F23D8DA-D53E-5BD6-66F50EF71CCF3045')
 // return this.http.get<any>('http://lst1s34.kfbdom1.kyfb.pri:9082/EBusinessPortal/account/8541C0CE-B321-E6E8-EFEB96595C1BCD30')
     //  EBusinessID 1 json
 //return this.http.get<any>('https://api.myjson.com/bins/nonxy')
     // EBusinessID 1 service
    // return this.http.get<any>('http://lst1s34.kfbdom1.kyfb.pri:9082/EBusinessPortal/account/3207D8A9-A91C-1603-702C7E6003497F9C')
       // EBusinessID 2 service
       //return this.http.get<any>('http://lst1s34.kfbdom1.kyfb.pri:9082/EBusinessPortal/account/7D05B412-D1C0-17B4-B3B7C7B7C390D62B')
       //Ebusiness Id 2 json  
      //  return this.http.get<any>('https://api.myjson.com/bins/1g1qik')
    // return this.http.get<any>('https://api.myjson.com/bins/bn1lq') 
    //morethan 7 policies json 
    return this.http.get<any>('https://api.myjson.com/bins/92o2k')
   //more than 1 agent service
  // return this.http.get<any>(' http://lst1s34.kfbdom1.kyfb.pri:9082/EBusinessPortal/account/FCBFE481-F491-FC51-7A557877A95B6778')
   //morethan 1 agent json
   //return this.http.get<any>('https://api.myjson.com/bins/kdwkc')
     //morethan 7 polies service
  //return this.http.get<any>('http://lst1s34.kfbdom1.kyfb.pri:9082/EBusinessPortal/account/8541C0CE-B321-E6E8-EFEB96595C1BCD30')
            .pipe(map((response: any) => response)
            );
    }
    selectPolicy(data): Observable<any> {
        // return this.http.get<any>('https://api.myjson.com/bins/bn1lq')
      //return this.http.get<any>('http://lst1s34.kfbdom1.kyfb.pri:9082/EBusinessPortal/account/4F23D8DA-D53E-5BD6-66F50EF71CCF3045')
       // return this.http.get<any>('http://lst1s34.kfbdom1.kyfb.pri:9082/EBusinessPortal/account/8541C0CE-B321-E6E8-EFEB96595C1BCD30')
           //  EBusinessID 1 json
       //return this.http.get<any>('https://api.myjson.com/bins/nonxy')
           // EBusinessID 1 service
            //return this.http.get<any>('http://lst1s34.kfbdom1.kyfb.pri:9082/EBusinessPortal/account/3207D8A9-A91C-1603-702C7E6003497F9C')
          // return this.http.get<any>('https://api.myjson.com/bins/bn1lq') 
          //morethan 7 policies  
         return this.http.post<any>('https://api.myjson.com/bins/z97ba',data)
         //more than 1 agent service
        // return this.http.get<any>(' http://lst1s34.kfbdom1.kyfb.pri:9082/EBusinessPortal/account/FCBFE481-F491-FC51-7A557877A95B6778')
         //morethan 1 agent json
         //return this.http.get<any>('https://api.myjson.com/bins/pgtcu')
           //morethan 7 polies service
        //return this.http.get<any>('http://lst1s34.kfbdom1.kyfb.pri:9082/EBusinessPortal/account/8541C0CE-B321-E6E8-EFEB96595C1BCD30')
                  .pipe(map((response: any) => response)
                  );
          }

          getPolicyInfo():  Observable<any>  {
            //   return this.http.get<any>('http://lst1s34.kfbdom1.kyfb.pri:9082/EBusinessPortal/reportClaim?policyNumber=0020174009')
            return this.http.get<any>('https://api.myjson.com/bins/xrwby')
                  .pipe(map((response: any) => response)
                  );
             
          }
}

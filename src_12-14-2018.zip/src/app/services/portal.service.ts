import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { AccountInformation } from '../kyfb/account-information';
import { JsonConvert, OperationMode, ValueCheckingMode } from 'json2typescript';
import { SnotifyService } from 'ng-snotify';
import { environment } from '../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class PortalService {
    public accountInformation: AccountInformation = null;

    constructor(private http: HttpClient, private messageService: SnotifyService) {
        this.http.get<AccountInformation>('https://api.myjson.com/bins/s1lpm')
            .pipe(
                map((response: any) => {
                    const jsonConvert: JsonConvert = new JsonConvert();
                    let accountInformation: AccountInformation;
                    if (!environment.production) {
                        jsonConvert.operationMode = OperationMode.LOGGING; // print some debug data
                    }

                    try {
                        accountInformation = (<any>jsonConvert).deserialize(response, AccountInformation);
                    } catch (e) {
                        this.messageService.error(
                            'There was an error parsing the response from the server.',
                            'Error!',
                            {showProgressBar: false, timeout: 0}
                        );

                        if (!environment.production) {
                            console.log((<Error>e));
                        }
                    }

                    return accountInformation;
                }),
            ).subscribe(
                accountInformation => this.accountInformation = accountInformation,
                error => this.messageService.error(error.message, 'Error!', {showProgressBar: false, timeout: 0})
            );
    }

}

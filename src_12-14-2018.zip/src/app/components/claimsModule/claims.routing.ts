import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PoliciesMainComponent } from './policies-main/policies-main.component';
import { ReportClaimLandingComponent } from './report-claim-landing/report-claim-landing.component';
import { ReportClaimComponent } from './report-claim/report-claim.component';
import { ClaimsTabsLayoutComponent } from './claims-tabs-layout/claims-tabs-layout/claims-tabs-layout.component';
import { CompleteComponent } from './complete/complete.component';

const routes: Routes = [
    { path: '', component: PoliciesMainComponent },
    { path:'policies-main',component:PoliciesMainComponent },
    { path:'report-claim',component:ReportClaimComponent },
    { path:'report-claim-landing',component:ReportClaimLandingComponent },
    { path: 'complete', component:CompleteComponent },
    {
        path: '',
        component: ClaimsTabsLayoutComponent,
        children: [
            {
                path: 'claims-tabs',
                loadChildren: 'src/app/components/claimsModule/claims-tabs-layout/claims-tabs-layout.module#ClaimsTabsLayoutModule'
            }
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ClaimsRoutingModule { }

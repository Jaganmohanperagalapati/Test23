import { objectify } from 'tslint/lib/utils';
import { Component, OnInit, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';


@Component({
  selector: 'kyfb-report-type-auto',
  templateUrl: './report-type-auto.component.html',
  styleUrls: ['./report-type-auto.component.scss']
})
export class ReportTypeAutoComponent implements OnInit {
  reportModalRef: BsModalRef;
  public claimType: any;
  public submitted: boolean = false;
  public ClaimTypeOptions = {
    'animal': false,
    'weather': false,
    'glassBreakage': false,
    'theftVandalism': false
  };

  public claimTypes = [
    {
      'DisplayLabel': 'Animal',
      'field': 'animal',
    },
    {
      'DisplayLabel': 'weather',
      'field': 'weather',
    },
    {
      'DisplayLabel': 'Glass Breakage',
      'field': 'glassBreakage',
      'policyType': 'A'
    },
    {
      'DisplayLabel': 'Theft/Vandalism',
      'field': 'theftVandalism',
    }
  ];
  selectedPolicyDetails: {
    policyNumber: number,
    type: string,
    dueDate: string
  };


  constructor(private router: Router, private modalService: BsModalService) { }

  ngOnInit() {
    this.selectedPolicyDetails = JSON.parse(localStorage.getItem('selectedPolicy'));
  }

  goToNext() {
    console.log(this.claimType);
    this.submitted = true;
    if (this.claimType && this.isRadioButtonChecked()) {
      this.router.navigate(['/claims/claims-tabs/user-location-info']);
    }
  }

  isRadioButtonChecked() {
    const field = this.getField(this.claimType);
    if (!field) {
      return true;
    }
    const flag = (this.ClaimTypeOptions[field]) ? true : false;
    return flag;
  }

  setClaimType(claimType){
    this.claimType = claimType;
  }

  getField(label) {
    const obj = this.getObj(this.claimTypes, label);
    if (obj && this.checkForPolicyType(obj)) {
      return obj.field;
    } else {
      return undefined;
    }

  }

  checkForPolicyType(obj) {
    if (obj.policyType) {
      return (obj.policyType === this.selectedPolicyDetails.type);
    } else {
      return true;
    }
  }

  getObj(list, label) {
    const obj = list.find(this.isExist, label);
    return obj;
  }

  isExist(value, index, arr) {
    const selectedValue = this;
    return (value.DisplayLabel === selectedValue);
  }


  openModalConfirmation(template2: TemplateRef<any>) {
    this.reportModalRef = this.modalService.show(template2);
  }

  goBackToDashboard(template2: TemplateRef<any>) {
    this.reportModalRef.hide();
    this.router.navigate(['/claims']);
  }

}

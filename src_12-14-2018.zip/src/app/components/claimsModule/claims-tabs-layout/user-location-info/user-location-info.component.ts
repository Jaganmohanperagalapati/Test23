import { Component, OnInit } from '@angular/core';
import { ClaimService } from 'src/app/services/claim.service';
import { Router } from '@angular/router';

@Component({
  selector: 'kyfb-user-location-info',
  templateUrl: './user-location-info.component.html',
  styleUrls: ['./user-location-info.component.scss']
})
export class UserLocationInfoComponent implements OnInit {
 // public time = new Date();
 // public date = new Date();

  public steps: any = { hour: 1, minute: 15 };
  //public value: Date = new Date(2000, 2, 10, 10, 30, 0);
  //public values: Date = new Date(2000, 2, 10);
  public min: Date = new Date();
  public maxDate: Date = new Date();
 // public maxDate: Date = new Date();s
  public maxTime: Date = null;
  address: any ="";
//  options = ["Kentucky", "Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "District of Columbia", "Florida", "Georgia", "Hawaii", "Idaho",  "Illinois", "Indiana", "Iowa", "Kansas"," Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi"," Missouri", "Montana", "Nebraska", "Nevada"," New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah","Vermont", "Virginia", "Washington"," West Virginia","Wisconsin", "Wyoming"];
 states = {
   "USA": {
     "stateTitle": 'State',
     "statesList": ["Kentucky", "Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "District of Columbia", "Florida", "Georgia", "Hawaii", "Idaho",  "Illinois", "Indiana", "Iowa", "Kansas"," Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi"," Missouri", "Montana", "Nebraska", "Nevada"," New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah","Vermont", "Virginia", "Washington"," West Virginia","Wisconsin", "Wyoming"]
   },
   "CAN": {
    "stateTitle": 'Province',
    "statesList": ["Alberta", "British Columbia", "Manitoba", "New Brunswick", "Newfoundland", "Northwest Territories", "Nova Scotia", "Nunavut", "Ontario", "Prince Edward Island", "Quebec", "Saskatchewan", "Yukon Territory"]
   },
   "MEX": {
    "stateTitle": 'Province',
    "statesList": ["Aguascalientes","Baja California","Baja California Sur","Campeche","Chiapas","Chihuahua","Coahuila de Zaragoza","Colima","Distrito Federal","Durango|Guanajuato","Guerrero|Hidalgo","Jalisco","Mexico|Michoacan de Ocampo","Morelos","Nayarit","Nuevo Leon","Oaxaca","Puebla","Queretaro de Arteaga","Quintana Roo","San Luis Potosi","Sinaloa","Sonora","Tabasco","Tamaulipas","Tlaxcala","Veracruz-Llave","Yucatan","Zacatecas"]    
   }
 } 
 optionSelected: any;
 public country: string = 'USA';
  onOptionSelected(event){
   console.log(event); //option value will be sent as event
  }



  datedd: any = "";
  selectedPolicyData: any[]=[];
  formSubmitted: boolean = false;
  constructor(private claimService: ClaimService, private router: Router) {}

  ngOnInit() {
    this.selectedPolicyData = JSON.parse(localStorage.getItem('selectedPolicy'));
  }

  goToPrevious() {
    if (this.selectedPolicyData['type'] == "A" || this.selectedPolicyData['type'] == "B") {
      this.router.navigate(['/claims/claims-tabs/report-type-auto']);
    } else {
      this.router.navigate(['/claims/claims-tabs/report-type-property']);
    }
  }
  getPolicyDetailsInfo(){
    this.claimService.getPolicyInfo().subscribe((policy) =>
    {
       this.address = policy.vehicleInfoDTOList;
    },
    
      error => { }
    );
  }

  goToNext(isValid) {
    this.formSubmitted = true;
    console.log(isValid);
    if(isValid) {
      if (this.selectedPolicyData['type'] == "A" || this.selectedPolicyData['type'] == "B") {
        this.router.navigate(['/claims/claims-tabs/auto-claim-details']);
      } else {
        this.router.navigate(['/claims/claims-tabs/property-claim-detail']);
      }
    }  
  }

  dateChange(event) {
  //  this.value = null;
    this.maxTime = null;
    if (this.getFormattedDate(event) == this.getFormattedDate(new Date())) {
      this.maxTime = new Date();
    }
  }

  getFormattedDate(date) {
    let year = date.getFullYear();

    let month = (1 + date.getMonth()).toString();
    month = month.length > 1 ? month : '0' + month;

    let day = date.getDate().toString();
    day = day.length > 1 ? day : '0' + day;

    return month + '/' + day + '/' + year;
  }



}

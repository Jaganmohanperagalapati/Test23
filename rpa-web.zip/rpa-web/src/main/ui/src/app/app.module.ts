import { ContourAgGridModule } from './shared-components/contour-ag-grid/contour.aggrid.module';
import { ChildCellRendererComponent } from './shared-components/contour-ag-grid/child-cell-renderer.component';
// Angular Modules
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


// third party
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { AngularFontAwesomeModule } from 'angular-font-awesome';

// KENDO
import { IntlModule } from '@progress/kendo-angular-intl';
// import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
// import { GridModule, ExcelModule } from '@progress/kendo-angular-grid';
// import { LayoutModule } from '@progress/kendo-angular-layout';
// import { PopupModule } from '@progress/kendo-angular-popup';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import * as $ from 'jquery';

// App Modules
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SharedComponentsModule } from './shared-components/shared-components.module';
import { PocessViewComponent } from './pocess-view/pocess-view.component';
import { ProcessStatusDetailsComponent } from './process-status-details/process-status-details.component';
import { UsersConfigComponent } from './users-config/users-config.component';
import { EditHandlerComponent } from './users-config/edit-user/edit-user.component';
import { AlertComponent } from './alert/alert.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    PocessViewComponent,
    ProcessStatusDetailsComponent,
    UsersConfigComponent,
    EditHandlerComponent,
    AlertComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AngularFontAwesomeModule,
    AppRoutingModule,
    SharedComponentsModule,
    HttpClientModule,
    HttpModule,
    Ng4LoadingSpinnerModule.forRoot(),
    ContourAgGridModule,
    IntlModule,
    DropDownsModule,
    BrowserAnimationsModule
  ],
  entryComponents: [ChildCellRendererComponent],

  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

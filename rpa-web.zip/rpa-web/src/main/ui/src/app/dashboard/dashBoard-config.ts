export const dashBoardconfig = {
    'statusConfig': [
        {
            'image': 'assets/img/process.png',
            'title': 'PROCESSES',
            'subTitle': 'ACTIVE',
            'statusColor': 'Green',
            'value': 1

        },
        {
            'image': 'assets/img/robot.png',
            'title': 'BOTS',
            'subTitle': 'RUNNING',
            'statusColor': 'Green',
            'value': 1
        },
        {
            'image': 'assets/img/requests.png',
            'title': 'TOTAL',
            'subTitle': 'REQUESTS',
            'statusColor': 'Red',
            'value': 0
        },
        {
            'image': 'assets/img/manual.png',
            'title': 'NEED',
            'subTitle': 'INTERVENTION',
            'statusColor': 'Red',
            'value': 0
        }
    ],
    'columns': [
        {
            'field': 'displayName',
            'displayName': 'Process Name',
            'hasLink': true,
            'hasActionButton': false,
            'max-width': '250px',
            'query': {
                'url': 'totalcount?',
                'params': [{
                    'param': 'processname=',
                    'value': 'processName'
                }, {
                    'param': 'id=',
                    'value': 'clientId'
                }]
            }
        }, {
            'field': 'clientId',
            'max-width': '250px',
            'displayName': 'Client Id',
            'hasLink': false,
            'hasActionButton': false,
        },
        {
            'field': 'attended',
            'max-width': '250px',
            'displayName': 'Attended',
            'hasLink': false,
            'hasActionButton': false,
        },
        {
            'field': 'sla',
            'displayName': 'SLA',
            'max-width': '250px',
            'hasLink': false,
            'hasActionButton': false
        },
        {
            'field': 'status',
            'displayName': 'Status',
            'max-width': '250px',
            'hasActionButton': false,
            'hasLink': false
        },
        {
            'field': 'comments',
            'displayName': 'Comments',
            'max-width': '250px',
            'hasActionButton': false,
            'hasLink': false
        },
        {
            'field': 'rating',
            'displayName': 'Rating',
            'max-width': '250px',
            'hasActionButton': false,
            'hasLink': false,

        },
        {
            'field': '',
            'displayName': '',
            'hasLink': false,
            'hasActionButton': true,
            'actions': [{
                type: 'button',
                displayName: 'Submit'
            }]
        }
    ],
    'dropDownConfig': {
        'value': {},
        'type': 'icon',
        'className': 'fa-bars-list',
        'itemsList': [{
            'displayLabel': 'User Config',
            'id': 'userConfig',
            'modalRef': 'userConfigRef'
        }, {
            'displayLabel': 'Sign Out',
            'id': 'signOut',
            'modalRef': ''
        }]
    },
    'generationDropDownConfig': {
        'value': {
            'displayLabel': 'Today',
            'id': 'today'
        },
        'type': 'button',
        'hasIcon': true,
        'iconClass': 'fa fa-calendar-o',
        'className': '',
        'itemsList': [{
            'displayLabel': 'Today',
            'id': 'today'
        }]
    }

};

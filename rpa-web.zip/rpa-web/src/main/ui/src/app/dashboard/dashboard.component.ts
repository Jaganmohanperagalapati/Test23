import { UsersConfigComponent } from './../users-config/users-config.component';

import { AppQueryService } from './../services/app-query.service';
import { PocessViewComponent } from './../pocess-view/pocess-view.component';
import { ModalComponent } from './../shared-components/modal/modal.component';
import { ConfigService } from './../config/config.service';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { dashBoardconfig } from './dashBoard-config';
import { ApiService } from './../services/app-http-api.service';
import { TableComponent } from '../shared-components/table/table.component';
import * as _ from 'Lodash';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  public statusData = dashBoardconfig.statusConfig;
  public processTableMetaData = dashBoardconfig.columns;
  public headerDropDownConfig = dashBoardconfig.dropDownConfig;
  public generationDropDownConfig = dashBoardconfig.generationDropDownConfig;
  public processList = [];
  public tableQuery = '';
  public showProcessView = false;
  public isTableDataLoaded = false;

  @ViewChild('processView') processView: PocessViewComponent;
  @ViewChild('tableRef') tableRef: TableComponent;
  @ViewChild('userConfigRef') userConfigRef: UsersConfigComponent;



  constructor(private config: ConfigService, private queryService: AppQueryService) { }

  ngOnInit() {
    this.tableQuery = this.prepareQuery();
  }



  clickedOnMenuItem(event) {
    if (event && event.modalRef) {
      this[event.modalRef].openModal();
    }
  }

  prepareQuery() {
    const urlConfig = this.config.getConfigUrls();
    const user = JSON.parse(localStorage.getItem('user'));
    const query = urlConfig.baseUrl + 'userprocess?id=' + user['userId'];
    return query;
  }

  clickEventOnTable(obj: boolean) {
    if (obj) {
      this.showProcessView = true;
      const data = obj['data'];
      const column = obj['column'];
      const query = this.queryService.prepareQuery(column['query'], data);
      setTimeout(() => {
        this.processView.openModal(data, query);
      }, 1);
    }

  }
  closeProcessViewModal(obj) {
    this.showProcessView = obj['isModalOpen'];
    this.refreshTableGrid(obj['isWorkFlowTriggerd']);
  }

  refreshTableGrid(flag) {
    if (flag) {
      this.tableRef.isTableDataLoaded = !flag;
      this.tableRef.tableData = [];
      this.tableQuery = this.prepareQuery();
      this.tableRef.getDataList();
    }
  }
  onGenerationSelect(event) {
    console.log('value :', event);
  }

}

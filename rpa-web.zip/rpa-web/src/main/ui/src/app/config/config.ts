export const config = {
    'localConfig': {
        'baseUrl': 'http://10.158.3.105:8080/rpa-dataservice/v1/process/',
        'isSSOEnabled': false
    },
    'devConfig': {
        'baseUrl': '/rpa-dataservice/v1/process/',
        'isSSOEnabled': true
    },
    'qaConfig': {
        'baseUrl': '/rpa-dataservice/v1/process/',
        'isSSOEnabled': true
    },
    'uatConfig': {
        'baseUrl': '/rpa-dataservice/v1/process/',
        'isSSOEnabled': true
    }

};

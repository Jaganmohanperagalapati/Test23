import { config } from './config';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ConfigService {
  constructor() { }

  getConfigUrls() {
    return config.localConfig;
  }
}


export interface Alert {
    type: string;
    message: string;
    id: string;
}


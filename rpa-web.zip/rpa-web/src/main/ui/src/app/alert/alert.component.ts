import { element } from 'protractor';
import { Component, OnInit } from '@angular/core';
import { Alert } from './alert.config';
import * as _ from 'Lodash';
import { AlertService } from './alert.service';

@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.css']
})
export class AlertComponent implements OnInit {
  public alerts = [];

  public classes = {
    'success': 'alert alert-success',
    'error': 'alert alert-danger',
    'info': 'alert alert-info',
    'warning': 'alert alert-warning'
  };

  constructor(private alert: AlertService) { }

  ngOnInit() {
    this.subscribeAlert();
  }

  cssClass(alert: Alert) {
    if (!alert) {
      return;
    }
    return this.classes[alert.type];

  }
  subscribeAlert() {
    this.alert.onSetAlert.subscribe((msg) => {
      if (typeof msg === 'object') {
        this.alerts.push(msg);
        msg.elementId = this.getElementId(msg);
        this.setDelayOnHide(msg);
      }

    });
  }

  setDelayOnHide(msg) {
    setTimeout(() => {
      this.removeAlert(msg);
    }, 5000);
  }

  removeAlert(msg) {
    const index = this.getIndex(this.alerts, 'id', msg);
    if (index !== -1) {
        this.alerts.splice(index, 1);
    }
  }

  getIndex(array, attribute, obj) {
    const index = _.findIndex(array, (alert) => {
      return (alert[attribute] === obj[attribute]);
    });
    return index;
  }
  getTopOfNotification(alert, index) {
    let positionValue = 20;
    if (index > 0) {
      for (let i = 0; i < index; i++) {
        positionValue = positionValue + 55;
      }
    }
    return positionValue + 'px';
  }

  getElementId(msg) {
    const postion = (this.alerts.length - 1 < 0) ? this.alerts.length : this.alerts.length - 1;
    const elementId = `#alert${postion}`;
    return elementId;
  }
}

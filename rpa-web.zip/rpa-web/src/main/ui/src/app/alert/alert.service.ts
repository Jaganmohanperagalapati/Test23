import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AlertService {
  public setAlert = new BehaviorSubject<any>('any');
  public onSetAlert = this.setAlert.asObservable();
  constructor() { }

  successMsg(msg) {
    this.setAlertMsg('success', msg);
  }

  errorMsg(msg) {
    this.setAlertMsg('error', msg);
  }

  warningMsg(msg) {
    this.setAlertMsg('warning', msg);
  }

  infoMsg(msg) {
    this.setAlertMsg('info', msg);
  }

  setAlertMsg(type, msg) {
    const obj = this.getMessageConfig(type, msg);
    this.setAlert.next(obj);
  }

  getMessageConfig(type, msg) {
    const obj = {
      'type': type,
      'message': msg,
      'id': this.getUUID()
    };
    return obj;
  }

  getUUID() {
    const uuid = this.s4() + this.s4() + '-' + this.s4() + '-' + this.s4() + '-' + this.s4() + '-' + this.s4() + this.s4() + this.s4();
    return uuid;
  }

  s4() {
    return Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .substring(1);
  }

}

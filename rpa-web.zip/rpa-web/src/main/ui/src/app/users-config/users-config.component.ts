import { UserCofigService } from './user-cofig.service';
import { AppQueryService } from './../services/app-query.service';
import { userConfigMetaData } from './user-config-metadata';
import { ApiService } from './../services/app-http-api.service';
import { ModalComponent } from './../shared-components/modal/modal.component';
import { Component, OnInit, ViewChild } from '@angular/core';
import { ConfigService } from '../config/config.service';
import { AlertService } from '../alert/alert.service';
import { EditHandlerComponent } from './edit-user/edit-user.component';




@Component({
    selector: 'app-users-config',
    templateUrl: './users-config.component.html',
    styleUrls: ['./users-config.component.css']
})
export class UsersConfigComponent implements OnInit {
    public gridHieght = '200px';
    public gridApi;
    public gridColumnApi;
    public showLoading = false;
    public query;
    public isGridVisible = false;
    public gridOptions = {
        'rowData': [],
        'columnDefs': userConfigMetaData.columns,
        'rowHeight': 40,
        'suppressNoRowsOverlay': true
    };
    private context;
    private frameworkComponents;
    public enableUserDetailsEntry = false;


    @ViewChild('modalContent') modalContent: ModalComponent;
    @ViewChild('editUser') editUser: EditHandlerComponent;
    constructor(private apiService: ApiService, private queryService: AppQueryService,
        private alertService: AlertService, private userCofigService: UserCofigService) {

        this.context = { componentParent: this };

    }

    ngOnInit() {
    }


    openModal() {
        this.query = this.userCofigService.prepareQuery('getDataQuery');
        this.isGridVisible = true;
        this.modalContent.openModal();
    }

    closeModal() {
        this.modalContent.closeModal();
        this.isGridVisible = false;
    }

    gridReadyCallBack(params) {
        this.getDataList();
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
        this.gridApi.refreshCells();
        this.gridApi.sizeColumnsToFit();
    }

    getDataList() {
        if (this.query) {
            this.showLoading = true;
            this.apiService.getApiData(this.query).subscribe(
                data => {
                    if (data.success) {
                        if (data.data && data.data.length > 0) {
                            this.gridOptions.rowData = data.data;
                            this.gridApi.setRowData(data.data);
                            this.gridHieght = this.getGridHeight();
                        } else {
                            this.gridOptions.suppressNoRowsOverlay = false;
                        }
                    } else {
                        if (data.errors.length > 0) {
                            console.log('errors :;', data.errors);
                            this.gridOptions.suppressNoRowsOverlay = false;
                        }
                    }
                    this.showLoading = false;
                },
                err => {
                    console.log('Error', err);
                    this.showLoading = false;
                    this.gridOptions.suppressNoRowsOverlay = false;
                }
            );
        }
    }

    getGridHeight() {
        const noOfReords = this.gridOptions.rowData.length;
        if (noOfReords < 13) {
            return noOfReords * this.gridOptions.rowHeight + 40 + 'px';
        } else {
            return '700px';
        }
    }

    editHandler(rowNo, data) {
        this.enableUserDetailsEntry = true;
        setTimeout(() => {
            this.editUser.openModal(true, data, rowNo);
        }, 1);

    }

    addHandler(rowNo, data) {
        this.enableUserDetailsEntry = true;
        setTimeout(() => {
            this.editUser.openModal(false);
        }, 1);
    }

    closeUserComponent({rowNo, record}) {
        this.enableUserDetailsEntry = false;
        if (typeof rowNo === 'number') {
            this.updateRecordData({ rowNo, record });
        } else {
            this.addNewRecord({ rowNo, record });
        }
    }

    updateRecordData({rowNo, record}) {
        const rowNode = this.gridApi.getRowNode(rowNo);
        rowNode.setData(record);
    }

    addNewRecord({rowNo, record}) {
        const newItem = record;
        this.gridApi.updateRowData({ add: [newItem] });
    }

}

export const userConfigMetaData = {
    'screenName': 'userConfig',
    'query': {
        'getDataQuery': 'userprofile',
        'updateDataQuery': 'userprofile',
        'addDataQuery': 'userprofile'
    },
    'columns': [{
        field: 'userId',
        'headerName': 'User ID'
    }, {
        field: 'userName',
        'headerName': 'User Name'
    }, {
        field: 'role',
        'headerName': 'Role'
    }, {
        field: 'emailId',
        'headerName': 'E-Mail ID'
    }, {
        field: 'location',
        'headerName': 'Location'
    }, {
        field: 'status',
        'headerName': 'Status'
    }, {
        field: 'supervisorId',
        'headerName': 'Supervisor'
    }, {
        field: 'createDate',
        'headerName': 'Created Date'
    }, {
        field: 'createdBy',
        'headerName': 'Created By'
    }, {
        field: 'lastUpdateDate',
        'headerName': 'Last updated on'
    }, {
        field: 'lastUpdateBy',
        'headerName': 'Last updated by'
    },
    {
        field: 'actions',
        'headerName': '',
        cellRenderer: 'childCellRendererComponent',

    }]
};

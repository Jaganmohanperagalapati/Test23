import { ConfigService } from './../config/config.service';
import { Injectable } from '@angular/core';
import { userConfigMetaData } from './user-config-metadata';

@Injectable({
  providedIn: 'root'
})
export class UserCofigService {

  constructor(private config: ConfigService) { }

  prepareQuery(url) {
    const urlConfig = this.config.getConfigUrls();
    const query = urlConfig.baseUrl + userConfigMetaData.query[url];
    return query;
  }

}

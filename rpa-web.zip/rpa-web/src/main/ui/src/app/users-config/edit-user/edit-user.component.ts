import { AlertService } from './../../alert/alert.service';
import { UserCofigService } from './../user-cofig.service';
import { EventEmitter } from '@angular/core';
import { Output } from '@angular/core';
import { ApiService } from './../../services/app-http-api.service';
import { ViewChild } from '@angular/core';
import { ModalComponent } from './../../shared-components/modal/modal.component';
import { Component, OnInit } from '@angular/core';
import { userConfigMetaData } from '../user-config-metadata';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
@Component({
  selector: 'edit-user-details',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditHandlerComponent implements OnInit {
  public isUpdateMode;
  public Roles = ['SUPERVISOR', 'ANALYST'];
  public locations = ['BANGALORE', 'DELHI', 'EDGEWOOD', 'HYDERABAD', 'NEWARK'];
  public statusList = ['ACTIVE', 'INACTIVE'];
  public Supervisors = [{ 'displayName': 'Vinay', 'value': 999992 },
  { 'displayName': 'Jagan', 'value': 999800 }, { 'displayName': 'Mahesh', 'value': 999990 },
  { 'displayName': 'Venkat', 'value': 999991 }];
  public rowNo;

  @ViewChild('modalContent') modalContent: ModalComponent;
  @Output() closeUserComponent = new EventEmitter();

  user: FormGroup;
  userProfile = this.nullifyUserProfile();
  logedInUser;


  constructor(private fb: FormBuilder, private apiService: ApiService, private userCofigService: UserCofigService,
    private alertService: AlertService) { }

  setRecordValues(value) {
    if (this.isUpdateMode) {
      this.userProfile = value;
      this.user.controls['userId'].setValue(value.userId);
      this.user.controls['userName'].setValue(value.userName);
      this.user.controls['role'].setValue(value.role);
      this.user.controls['emailId'].setValue(value.emailId);
      this.user.controls['location'].setValue(value.location);
      this.user.controls['status'].setValue(value.status);
      this.user.controls['supervisorId'].setValue(value.supervisorId);
    }
  }

  nullifyUserProfile() {
    const obj = {
      'userId': undefined, 'userName': undefined, 'role': undefined, 'emailId': undefined,
      'location': undefined, 'status': undefined, 'supervisorId': undefined
    };
    return obj;
  }



  ngOnInit() {
    this.initializeFormGroup();
    this.logedInUser = JSON.parse(localStorage.getItem('user'));
  }

  initializeFormGroup() {
    this.user = this.fb.group({
      userId: ['', Validators.required],
      userName: ['', Validators.required],
      role: ['', Validators.required],
      emailId: ['', Validators.required],
      location: ['', Validators.required],
      status: ['', Validators.required],
      supervisorId: ['', Validators.required]
    });
  }


  get f() { return this.user.controls; }

  openModal(flag, data?: any, rowNo?: any) {
    this.rowNo = rowNo;
    this.isUpdateMode = flag;
    this.setRecordValues(data);
    this.modalContent.openModal();
  }

  closeModal(hasChanges?: any) {
    if (hasChanges) {
      this.closeUserComponent.emit({ rowNo: this.rowNo, record: this.userProfile });
    }
    this.rowNo = '';
    this.userProfile = this.nullifyUserProfile();
    this.modalContent.closeModal();
  }

  update() {
    const query = this.userCofigService.prepareQuery('updateDataQuery');
    this.userProfile['lastUpdateBy'] = this.logedInUser.userName;
    this.userProfile['lastUpdateDate'] = new Date();
    this.apiService.updateData(query, this.userProfile).subscribe(success => {
      this.alertService.successMsg('Updated successfully');
      this.userProfile['id'] = success.data.id;
      this.closeModal(true);
    }, error => { });
  }

}

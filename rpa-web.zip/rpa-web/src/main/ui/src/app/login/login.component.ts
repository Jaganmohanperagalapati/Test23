import { ApiService } from './../Services/app-http-api.service';
import { ConfigService } from './../config/config.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { AlertService } from '../alert/alert.service';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
    user: any = {};
    returnUrl: string;
    loginFail = false;
       public listItems: Array<string> = [ 'Small', 'Medium', 'Large' ];
    public selectedValue = 'Medium';

    public invalidentry;
    constructor(private config: ConfigService, private router: Router, private apiService: ApiService,
        private spinnerService: Ng4LoadingSpinnerService, private alertService: AlertService) { }

    ngOnInit() {
        localStorage.removeItem('user');
    }

    login() {
        this.showLoader();
        const query = this.prepareQuery();
        this.apiService.getApiData(query).subscribe(
            data => {
                if (data.success) {
                    localStorage.setItem('user', JSON.stringify(data.data[0]));
                    this.router.navigate(['/dashboard']);
                    this.hideLoader();
                } else {
                    if (data.errors.length > 0) {
                        this.loginFail = true;
                        this.hideLoader();
                    }
                }

            },
            err => {
                console.log('Error', err);
                this.loginFail = true;
                this.hideLoader();
            }
        );
    }



    prepareQuery() {
        const urlConfig = this.config.getConfigUrls();
        const query = urlConfig.baseUrl + 'user?id=' + this.user.name + '&password=' + this.user.password;
        return query;
    }

    showLoader() {
        this.spinnerService.show();
    }
    hideLoader() {
        this.spinnerService.hide();
    }
}

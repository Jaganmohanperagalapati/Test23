import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PocessViewComponent } from './pocess-view.component';

describe('PocessViewComponent', () => {
  let component: PocessViewComponent;
  let fixture: ComponentFixture<PocessViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PocessViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PocessViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

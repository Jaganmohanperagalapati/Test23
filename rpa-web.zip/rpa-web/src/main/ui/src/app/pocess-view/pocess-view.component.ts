import { AlertService } from './../alert/alert.service';
import { EventEmitter } from '@angular/core';
import { AppQueryService } from './../services/app-query.service';
import { ApiService } from './../services/app-http-api.service';
import { query } from '@angular/animations';
import { Component, ElementRef, OnInit, ViewChild, Output } from '@angular/core';

import { ModalComponent } from './../shared-components/modal/modal.component';
import { ProcessStatusDetailsComponent } from './../process-status-details/process-status-details.component';
import { ConfigService } from './../config/config.service';
import { tilesConfig } from './tiles-config';

@Component({
  selector: 'app-pocess-view',
  templateUrl: './pocess-view.component.html',
  styleUrls: ['./pocess-view.component.css']
})
export class PocessViewComponent implements OnInit {
  @ViewChild('processStatusWindow') processStatusWindow: ProcessStatusDetailsComponent;
  @ViewChild('modalContent') modalContent: ModalComponent;

  @Output() eventOnCloseModal = new EventEmitter();
  public recordData;
  public selectedInfo;
  public processViewData = [];
  public showStatusDetails = false;
  public chartFields = [];
  public isWorkFlowTriggerd = false;
  public tiles = tilesConfig;
  public isLoading;
  constructor(private queryService: AppQueryService, private apiService: ApiService, private alertService: AlertService) { }
  ngOnInit() {
  }

  openModal(data?: any, URL?: any) {
    this.isLoading = true;
    this.recordData = data;
    this.setChartFields();
    this.getProcessInfo(URL);
    this.modalContent.openModal();
  }

  triggerWorkFlow() {
    this.isWorkFlowTriggerd = true;
    const URL = this.queryService.prepareQuery(this.getQueryConfig('startjob?'), this.recordData);
    this.apiService.getApiData(URL).subscribe(data => {
      console.log('data :; ', data);
      this.alertService.successMsg('Job started successfully');
    },
      err => {
        console.log(err);
        this.alertService.errorMsg('Job failed');
      });
  }

  getQueryConfig(queryUrl) {
    const obj = {
      'url': queryUrl,
      'params': [{
        'param': 'name=',
        'value': 'processName'
      }, {
        'param': 'id=',
        'value': 'clientId'
      }]
    };
    return obj;
  }

  closeModal() {
    this.eventOnCloseModal.emit({ 'isModalOpen': false, 'isWorkFlowTriggerd': this.isWorkFlowTriggerd });
    this.modalContent.closeModal();
  }

  openProcessDetails(tileInfo, index) {
    this.showStatusDetails = true;
    this.selectedInfo = tileInfo;
    if (tileInfo.query) {
      const apiQuery = this.queryService.prepareQuery(tileInfo['query'], this.recordData);
      setTimeout(() => {
        this.processStatusWindow.openModal(apiQuery);
      }, 1);

    }
  }
  closeProcessDetails(value) {
    this.showStatusDetails = value;
  }


  getProcessInfo(URL) {
    if (URL) {
      this.apiService.getApiData(URL).subscribe(
        data => {
          if (data.success) {
            this.processViewData = data.data[0];
            this.isLoading = false;
          } else {
            if (data.errors.length > 0) {
              this.isLoading = false;
            }
          }
          this.setChartFields();

        },
        err => {
          console.log('Error', err);
          this.isLoading = false;
          this.setChartFields();
        }
      );
    }
  }

  setChartFields() {
    this.chartFields = this.tiles.filter((field) => {
      return (field['highChartOptions']);
    });
  }

}

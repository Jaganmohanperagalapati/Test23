export const tilesConfig = [
  {
    'image': 'assets/img/requests.png',
    'mappingKey': 'totalRequests',
    'title': 'TOTAL',
    'subTitle': 'REQUESTS',

    'statusColor': 'Red',
    'field': 'totalRecCount',
    'processDetailsTitle': 'Total Requests',
    'query': {
      'url': 'record?',
      'params': [{
        'param': 'processname=',
        'value': 'processName'
      }, {
        'param': 'id=',
        'value': 'clientId'
      }]
    },
    'highChartOptions': {
      'name': 'Success',
      'substractionField': 'totalfaildCount',
      'color': '#227b22'
    }
  },
  {
    'image': 'assets/img/manual.png',
    'mappingKey': 'needIntervention',
    'title': 'NEED',
    'subTitle': 'INTERVENTION',
    'nameOnHighChart': 'Failure',
    'processDetailsTitle': 'Failure Requests',
    'statusColor': 'Red',
    'field': 'totalfaildCount',
    'query': {
      'url': 'failurerecords?',
      'params': [{
        'param': 'processname=',
        'value': 'processName'
      }, {
        'param': 'id=',
        'value': 'clientId'
      }]
    },
    'highChartOptions': {
      'name': 'Failure',
      'substractionField': '',
      'color': '#a72626'
    }
  },
  {
    'image': 'assets/img/process.png',
    'mappingKey': 'averageRequests',
    'title': 'AVERAGE',
    'processDetailsTitle': 'Average of Process',
    'subTitle': 'REQUESTS',
    'statusColor': 'Green',
    'field': 'avgTime',
    'query': ''

  },
  {
    'image': 'assets/img/robot.png',
    'mappingKey': 'history',
    'title': 'PROCESS HISTORY',
    'processDetailsTitle': 'Bots Running on process',
    'subTitle': '',
    'statusColor': 'Green',
    'field': 'robot',
    'query': ''
  }
];

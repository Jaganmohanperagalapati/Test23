import { Component, OnDestroy, Output, EventEmitter } from "@angular/core";
import { ICellRendererAngularComp } from "ag-grid-angular";
import { HyperLinkRendererService } from './hyperlink.formatter.service';

@Component({
    selector: 'link-format',
    template: `
    <a href="javascript:void(0)" *ngIf="params?.type === 'modal'"  href="javascript:void(0)" data-toggle="modal" [attr.data-target]="'#' + params.modalId" (click)="onClick($event)">{{params?.value}}</a>
    <a href="javascript:void(0)" *ngIf="params?.type !== 'modal'" (click)="onClick($event)">{{params?.value}} {{params.type}}</a>
    `,
    styles: []
})
export class HyperLinkRendererComponent implements ICellRendererAngularComp, OnDestroy {
    public params: any;


    constructor(private service: HyperLinkRendererService) {
    }

    agInit(params: any): void {
        this.params = params;
    }

    ngOnDestroy() {
    }

    onClick(event) {
        let obj: any = {};
        obj.cellDef = this.params.colDef;
        obj.data = this.params.data;
        if(this.params.type === 'modal'){
            obj.modalId = this.params.modalId;
        }
        this.params.context.componentName[this.params.methodName](obj);
        //this.service.createGridLinkServiceObj(obj);
    }

    refresh(): boolean {
        return false;
    }
}
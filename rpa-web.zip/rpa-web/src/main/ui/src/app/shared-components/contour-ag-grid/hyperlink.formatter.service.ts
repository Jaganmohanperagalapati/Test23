
import { Injectable, Inject } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class HyperLinkRendererService {

    private linkClickObj = new BehaviorSubject<any>('any');
    GridLinkClickService = this.linkClickObj.asObservable();
    createGridLinkServiceObj(value: any) {
        this.linkClickObj.next(value);
    }

    constructor() {
    }
}

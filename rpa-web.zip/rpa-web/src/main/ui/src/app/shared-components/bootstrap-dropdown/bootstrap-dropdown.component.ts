import { Component, OnInit , Input, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'app-bootstrap-dropdown',
  templateUrl: './bootstrap-dropdown.component.html',
  styleUrls: ['./bootstrap-dropdown.component.css']
})
export class BootstrapDropdownComponent implements OnInit {
  @Input() dropDownConfig;
  @Output() valueChangeEvent = new EventEmitter<any>();
  constructor() { }

  ngOnInit() {
  }

  onChange(item) {
    this.valueChangeEvent.emit(item);
  }

}

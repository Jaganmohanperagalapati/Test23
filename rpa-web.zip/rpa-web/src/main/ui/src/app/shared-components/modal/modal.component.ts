import { Component, ElementRef, OnDestroy, OnInit, Renderer2, ViewChild, Input } from '@angular/core';


@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss']
})
export class ModalComponent implements OnInit, OnDestroy {
  public isModalOpen = false;
  @Input()modalType;

  constructor(private renderer: Renderer2) {
  }

  ngOnInit() {
  }

  public openModal() {
    this.isModalOpen = true;
    this.renderer.addClass(document.body, 'modal-open');
  }

  public closeModal() {
    this.removeClass();
    this.isModalOpen = false;
  }
  public modalOpen() {
    return this.isModalOpen;
  }


  ngOnDestroy() {
    this.removeClass();
  }

  private removeClass() {
    setTimeout(() => {
      const openedModals = document.querySelectorAll('.action-modal.in');
      if (!openedModals || openedModals.length === 0) {
        this.renderer.removeClass(document.body, 'modal-open');
      }
    }, 0);
  }
}

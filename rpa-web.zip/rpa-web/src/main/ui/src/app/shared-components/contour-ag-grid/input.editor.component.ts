import { AfterViewInit, Component, ViewChild, ViewContainerRef } from "@angular/core";

import { ICellEditorAngularComp } from "ag-grid-angular";
import * as moment from 'moment';

@Component({
    selector: 'date-editor',
    template: `
       <input #input [(ngModel)]="value" (keyup)="performValidations($event)"/>
    `
})
export class InputEditor implements ICellEditorAngularComp, AfterViewInit {
    private params: any;
    public value: any;
    public oldValue: any;


    @ViewChild('input', { read: ViewContainerRef }) public input;

    // dont use afterGuiAttached for post gui events - hook into ngAfterViewInit instead for this
    ngAfterViewInit() {

    }

    agInit(params: any): void {
        this.params = params;
        this.value = params.value;
        this.oldValue = params.value;

    }

    performValidations(event) {
        if (this.params.pattern) {
            this.validateInput();
        }
        if (this.params.hasDependent) {
            this.params.valueChanged(this.value, this.params.rowIndex, this.params.column.colId, this.params.node.data);
        }
    }

    validateInput() {
        let elm: any = $(this.input.element.nativeElement);
        var currentValue = elm.val();
        var flag = currentValue.match(this.params.pattern);
        if (flag == null) {
            this.value = this.oldValue;
            elm.val(this.oldValue);
        } else {
            this.value = currentValue;
            this.oldValue = currentValue;
            elm.val(currentValue);
        }
    }

    getValue(): any {
        let elm = $(this.input.element.nativeElement);
        return elm.val()
    }

    setValue(value1): any {
        let elm: any = $(this.input.element.nativeElement);
        elm.val(value1);
        //this.eInput.value = this.value;
    }

    isPopup(): boolean {
        return false;
    }


}
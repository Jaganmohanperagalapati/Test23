import { Component, OnInit, Input } from '@angular/core';
import * as _ from 'Lodash';

@Component({
  selector: 'app-process-status',
  templateUrl: './process-status.component.html',
  styleUrls: ['./process-status.component.css']
})
export class ProcessStatusComponent implements OnInit {

  @Input() tileInfo;
  @Input() value;

  constructor() { }

  ngOnInit() {
    this.value = (!_.isUndefined(this.value)) ? this.value : this.tileInfo.value;
  }

}

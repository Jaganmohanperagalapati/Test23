import { Component, OnDestroy } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { BehaviorSubject } from 'rxjs';
import { GridActionsService } from './rowEdit.service';
import * as _ from 'lodash';

@Component({
    selector: 'row-edit',
    template: `
    <div *ngIf="params.node.group !== true">
            <button type="button" *ngIf="isNew == true && params?.isEdit && cloneStart && !unDelete" [disabled]="disableEdit"
             [ngClass]="{'disableClass': disableEdit==true}" (click) = "onEditClick()" data-action-type="view"
              class="btn btn-default btn-grid-action">
               <i class="fa fa-pencil"></i>
             </button>

             <button type="button"  *ngIf="isNew == false && !unDelete" (click) = "onUpdateClick()" data-action-type="view" 
             class="btn btn-default btn-grid-action">
               Update
             </button>

             <button type="button" *ngIf="isNew == false && !unDelete" (click) = "onCancelClick()" data-action-type="view" 
             class="btn btn-default btn-grid-action">
               Cancel
             </button>

            <button type="button"  *ngIf="isNew == true && params?.isClone && !cloneUpdate && !unDelete" [disabled]="disableClone" 
            [ngClass]="{'disableClass': disableClone==true}" (click) = "cloneRow()" data-action-type="clone" 
            class="btn btn-default btn-grid-action">
                <i class="fa fa-clone"></i>
            </button>

             <button type="button"  *ngIf="isNew == true && params?.isDownload && ! cloneUpdate && !unDelete" (click) = "onDownloadClick()"
              data-action-type="download" class="btn btn-default btn-grid-action">
                <i class="fa fa-download"></i>
            </button>

            <button type="button"  *ngIf="isNew == true && params?.isDelete && !cloneUpdate && !unDelete" [disabled]="disableDelete"  
            [ngClass]="{'disableClass': disableDelete==true}"(click) = "onDeleteClick()" data-action-type="remove" 
            class="btn btn-default btn-grid-action"  >
               <i class="fa fa-trash"></i>
            </button>

            <button type="button" placement="left" *ngIf="isNew == true && (params?.isMessage) && !cloneUpdate && !unDelete" 
            (click) = "onCommentsClick($event)"  [ngClass]="{'disableCommentClass': disableCommentClass==true}" data-action-type="comment" 
            class="btn btn-default btn-grid-action cmtBtn">
                <i class="fa fa-comment"></i>
            </button>

            <button type="button"  *ngIf="params?.isClone && cloneUpdate == true && !unDelete" (click) = "onCloneAndUpdate()"
             data-action-type="view" class="btn btn-default btn-grid-action">
               Update
             </button>

              <button type="button" *ngIf="params?.isClone && cloneUpdate == true && !unDelete" (click) = "revokeCloning()"
               data-action-type="view" class="btn btn-default btn-grid-action">
               Cancel
             </button>
             
             
              <button type="button" *ngIf="unDelete == true" (click) = "undeleteRow()" data-action-type="view" 
              class="btn btn-default btn-grid-action">
               Undelete
             </button>  
             
           
    </div>
            `,
    styles: [`
            .btn {
                padding: 2px 9px;
            }
            .btn-grid-action {
                background: #00A3D6;
                color: #fff !important;
                padding: 0px 8px !important;
                border-radius: 6px !important;
                border: none;
                font-size: 16px;
                margin-top: 0px !important;
                outline: none !important;
            }
            .customClass{
                left:100 rem;
                background-color:#515967;
            }
    `]
})
export class RowEditComponent implements ICellRendererAngularComp, OnDestroy {
    public params: any;
    public isNew: any;
    public previousData: any;
    public cloneUpdate: any;
    public unDelete: any;
    public cloneStart: any;
    public disableCommentClass: any;
    public disableEdit: any;
    public disableClone: any;
    public disableDelete: any;

    agInit(params: any): void {
        this.params = params;
        if (this.params.isUndelete) {
            const field = this.params.undeleteParams.field;
            const value = this.params.undeleteParams.value;
            if (this.params.node.data && this.params.node.data[field] === value) {
                this.unDelete = true;
            }
        }
        //check for comments

        if (this.params.isMessage && this.params.messageParams) {
            const field = this.params.messageParams.field;
            if (this.params.node.data && !_.isUndefined(this.params.node.data[field])
                && this.params.node.data[field] !== this.params.messageParams.value) {
                this.disableCommentClass = true;
            }
        }

        //check for  edit button disable condition
        if (this.params.isEdit && this.params.editParams) {
            const field = this.params.editParams.field;
            const value = this.params.editParams.value;
            if (this.params.node.data && this.params.node.data[field] === value) {
                this.disableEdit = true;
            }
        }

        //check for clone button button disable condition
        if (this.params.isEdit && this.params.cloneParams) {
            const field = this.params.cloneParams.field;
            const value = this.params.cloneParams.value;
            if (this.params.node.data && this.params.node.data[field] === value) {
                this.disableClone = true;
            }
        }


        //check for delete disable condition
        if (this.params.isDelete && this.params.deleteParams) {
            const field = this.params.deleteParams.field;
            const value = this.params.deleteParams.value;
            if (this.params.node.data && this.params.node.data[field] === value) {
                this.disableDelete = true;
            }
        }




    }

    constructor(private gridService: GridActionsService) {
        this.isNew = true;
        this.cloneUpdate = false;
        this.unDelete = false;
        this.cloneStart = true;
        this.disableCommentClass = false;
        this.disableEdit = false;
        this.disableDelete = false;
    }

    ngOnDestroy() {
    }

    refresh(): boolean {
        return false;
    }

    onEditClick() {
        const index = this.params.node.rowIndex;
        this.params.cancelOtherRowEditors(index);
        this.isNew = false;
        this.previousData = JSON.parse(JSON.stringify(this.params.data));
        const data = this.params.data;
        const cols = this.params.columnApi.getAllGridColumns();
        let column = {};
        cols.forEach(function (item) {
            if (item.colId === 'actionsColumn') {
                column = item;
            }
            // console.log(item.colId, " = ", item.colDef.displaySign);
            // if (!(item.colDef.displaySign === undefined || item.colDef.displaySign === true)) {
            //     if (data[item.colDef.field] < 0)
            //         data[item.colDef.field] = (data[item.colDef.field] * (-1));
            // }
        });
        this.params.data = data;
        let firstCol: any = {
            'colId': ''
        };

        if (column) {
            firstCol = column;
        }

        const rowIndex = this.params.node.rowIndex;
        this.params.api.setFocusedCell(rowIndex, firstCol.colId);
        this.params.api.startEditingCell({
            rowIndex: rowIndex,
            colKey: firstCol.colId
        });
    }

    onUpdateClick() {
        this.isNew = true;
        const cols = this.params.columnApi.getAllGridColumns();
        let column = {};
        cols.forEach(function (item) {
            if (item.colId === 'actionsColumn') {
                column = item;
            }
        });
        let firstCol: any = {
            'colId': ''
        };
        if (column) {
            firstCol = column;
        }
        const obj: any = {};
        obj.type = 'update';
        this.params.api.stopEditing();
        obj.upDatedData = this.params.data;
        obj.oldData = this.previousData;
        obj.gridName = this.params.gridName;
        obj.rowIndex = this.params.node.rowIndex;
        obj.firstCol = firstCol;
        this.gridService.createGridActionsServiceObj(obj);
    }

    onCloneAndUpdate() {
        const cols = this.params.columnApi.getAllGridColumns();
        let column = {};
        cols.forEach(function (item) {
            if (item.colId == "actionsColumn") {
                column = item;
            }
        });
        this.isNew = true;
        const obj: any = {};
        obj.type = 'clone';
        this.params.api.stopEditing();
        obj.upDatedData = this.params.data;
        obj.oldData = this.previousData;
        obj.rowIndex = this.params.node.rowIndex;
        obj.firstCol = column;
        obj.gridName = this.params.gridName;
        this.gridService.createGridActionsServiceObj(obj);
    }

    onCommentsClick(e: any) {
        const obj: any = {};
        obj.type = 'Comments';
        obj.selectedData = this.params.data;
        obj.gridName = this.params.gridName;
        obj.rowIndex = this.params.node.rowIndex;
        obj.el = e;
        this.gridService.createGridActionsServiceObj(obj);

    }

    onDownloadClick() {
        const obj: any = {};
        obj.type = 'download';
        obj.selectedData = this.params.data;
        obj.gridName = this.params.gridName;
        this.gridService.createGridActionsServiceObj(obj);
    }

    onCancelClick() {
        //let rowIndex = this.params.node.rowIndex;
        const previousData = JSON.parse(JSON.stringify(this.previousData));
        this.isNew = true;
        this.params.api.stopEditing(true);
        setTimeout(() => {
            const rowNode1 = this.params.api.getRowNode(this.params.node.id);
            const rowNode = this.params.api.getRowNode(this.params.rowIndex);
            rowNode1.setData(previousData);
            this.params.data = previousData;
        }, 50);
    }

    onDeleteClick() {
        const obj: any = {};
        obj.type = 'delete';
        obj.selectedData = this.params.data;
        obj.gridName = this.params.gridName;
        this.gridService.createGridActionsServiceObj(obj);
    }

    undeleteRow() {
        const obj: any = {};
        obj.type = 'undelete';
        obj.selectedData = this.params.data;
        obj.gridName = this.params.gridName;
        this.gridService.createGridActionsServiceObj(obj);
    }

    cloneRow() {

        const cols = this.params.columnApi.getAllGridColumns();
        const data = JSON.parse(JSON.stringify(this.params.data));
        let column = {};
        cols.forEach(function (item) {
            if (item.colId === 'actionsColumn') {
                column = item;
            }
            // console.log(item.colId, " = ", item.colDef.displaySign);
            // if (!(item.colDef.displaySign === undefined || item.colDef.displaySign === true)) {
            //     if(data[item.colDef.field] < 0)
            //     data[item.colDef.field] = (data[item.colDef.field] * (-1));
            // }
        });
        const currentIndex = this.params.node.rowIndex;
        let firstCol: any = {
            'colId': ''
        };
        if (cols) {
            firstCol = column;
        }
        const res = this.params.api.updateRowData({
            add: [data],
            addIndex: currentIndex + 1
        });

        // making new row as edtible
        setTimeout(() => {
            this.params.api.setFocusedCell(currentIndex + 1, firstCol.colId);
            this.params.api.startEditingCell({
                rowIndex: currentIndex + 1,
                colKey: firstCol.colId
            });
        }, 1);

        //getting renderere instance and enabling buttons
        const rowNode = this.params.api.getDisplayedRowAtIndex(currentIndex + 1);
        const colParams = { columns: ['actionsColumn'], rowNodes: [rowNode] };
        const renderInstance = this.params.api.getCellRendererInstances(colParams);
        if (renderInstance && renderInstance.length === 1) {
            renderInstance[0]._agAwareComponent.cloneUpdate = true;
            if (this.params.isClone && this.params.isEdit) {
                renderInstance[0]._agAwareComponent.cloneStart = false;
            }
        }
    }

    revokeCloning() {
        const selectedData = this.params.data;
        this.params.api.updateRowData({ remove: [selectedData] });
        this.cloneStart = true;
    }
}

import { Component, OnInit, Input } from '@angular/core';
import { Chart } from 'angular-highcharts';
import * as _ from 'Lodash';

@Component({
  selector: 'app-pie-chart',
  templateUrl: './app-pie-chart.component.html',
  styleUrls: ['./app-pie-chart.component.css']
})
export class AppPieChartComponent implements OnInit {
  public chart: Chart;
  @Input() data;
  @Input() fields;
  @Input() size;
  constructor() { }


  ngOnInit() {
    this.init();
  }

  init() {
    const chart = new Chart({
      chart: {
        plotBackgroundColor: null,
        plotBorderWidth: 0,
        plotShadow: false,
        type: 'pie',

      },
      title: {
        text: 'Process Status'
      },
      tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
      },
      credits: {
        enabled: false
      },
      plotOptions: {
        pie: {
          allowPointSelect: true,
          cursor: 'pointer',
          dataLabels: {
            enabled: false
          },
          showInLegend: true,
          size: this.size
        }
      },
      series: this.prepareSeries()
    });

    this.chart = chart;
  }

  prepareSeries() {
    const array = [];
    const obj = {
      name: 'records',
      colorByPoint: true,
      data: this.prepareDataSeries()
    };
    array.push(obj);
    return array;
  }

  prepareDataSeries() {
    const seriesData = [];
    _.each(this.fields, (item) => {
      const obj = {};
      const key = item['field'];
      const chartInfo = item['highChartOptions'];
      const subStractionField = chartInfo['substractionField'];
      obj['name'] = chartInfo['name'];
      obj['y'] = (subStractionField !== '') ? this.data[key] - this.data[subStractionField] : this.data[key];
      obj['color'] = chartInfo['color'];
      seriesData.push(obj);
    });
    return seriesData;
  }

}



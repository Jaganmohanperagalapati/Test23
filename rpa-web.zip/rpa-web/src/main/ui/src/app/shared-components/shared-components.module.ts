
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header/header.component';
import { ClockTileComponent } from './clock-tile/clock-tile.component';
import { ProcessStatusComponent } from './process-status/process-status.component';
import { ProfileComponent } from './profile/profile.component';
import { TableComponent } from './table/table.component';
import { ModalComponent } from './modal/modal.component';
import { AgGridModule } from 'ag-grid-angular/main';
import { LoadingComponent } from './loading/loading.component';
import { ChartModule } from 'angular-highcharts';
import { AppPieChartComponent } from './app-pie-chart/app-pie-chart.component';
import { BootstrapDropdownComponent } from './bootstrap-dropdown/bootstrap-dropdown.component';

@NgModule({
  declarations: [HeaderComponent, ClockTileComponent, ProcessStatusComponent,
    ProfileComponent, TableComponent, ModalComponent, LoadingComponent,
    AppPieChartComponent, BootstrapDropdownComponent],
  imports: [
    CommonModule,
    ChartModule,
    AgGridModule.withComponents(
      []
    )
  ],
  exports: [
    CommonModule,
    AgGridModule,
    ChartModule,
    HeaderComponent,
    ClockTileComponent,
    ProcessStatusComponent,
    ProfileComponent,
    TableComponent,
    ModalComponent,

    LoadingComponent,
    AppPieChartComponent,
    BootstrapDropdownComponent
  ]
})
export class SharedComponentsModule { }

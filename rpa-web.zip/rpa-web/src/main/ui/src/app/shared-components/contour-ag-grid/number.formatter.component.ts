import { Component, OnDestroy } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
    selector: 'number-format',
    template: `
            <span *ngIf="params?.enclosedBraces && params?.value!=0">({{params?.value | number: params?.digitFormat }})</span>
            <span *ngIf="params?.enclosedBraces && params?.value==0">{{params?.value | number: params?.digitFormat }}</span> 
            <span *ngIf="!params?.enclosedBraces">{{params?.value | number: params?.digitFormat }}</span> 
    `,
    styles: []
})
export class NumberFormatterComponent implements ICellRendererAngularComp, OnDestroy {
    public params: any;

    agInit(params: any): void {
        this.params = params;
    }

    ngOnDestroy() {
    }

    refresh(): boolean {
        return false;
    }
}
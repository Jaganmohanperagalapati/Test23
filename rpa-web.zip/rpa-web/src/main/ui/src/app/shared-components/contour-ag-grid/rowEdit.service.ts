
import { Injectable, Inject } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class GridActionsService {
    private gridActionsServiceObj = new BehaviorSubject<any>('any');
    GridActionsService = this.gridActionsServiceObj.asObservable();

    createGridActionsServiceObj(value: any) {
        this.gridActionsServiceObj.next(value);
    }

    constructor() {
    }
}

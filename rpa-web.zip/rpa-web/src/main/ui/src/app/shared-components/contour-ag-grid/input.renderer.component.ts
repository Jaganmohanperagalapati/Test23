import { Component, ViewChild, ViewContainerRef } from '@angular/core';

import { ICellRendererAngularComp } from 'ag-grid-angular';
declare var $: any;

@Component({
    selector: 'date-editor',
    template: `
       <input *ngIf="params.node.group !== true" #input [(ngModel)]="value" [ngClass]="params.cellClass" 
       (blur)="performValidations($event)" />
       <span *ngIf="params.node.group === true" style='font-size:16px;font-weight:bold'>{{value}}</span>
    `
})
export class InputRenderer implements ICellRendererAngularComp {
    public params: any;
    public value: any;
    public oldValue: any;
    @ViewChild('input', { read: ViewContainerRef }) public input;

    agInit(params: any): void {
        this.params = params;
        this.value = params.value;
      
        this.oldValue = params.value;

    }

    performValidations(event) {
        if (this.params.pattern) {
            this.validateInput();
        }
        if (this.params.hasDependent) {
            this.params.valueChanged(this.value, this.params.rowIndex, this.params.column.colId, this.params.node.data,this.params.node.id);
        }
    }

    validateInput() {
        let elm: any = $(this.input.element.nativeElement);
        const currentValue = elm.val();
        const flag = currentValue.match(this.params.pattern);
        if (flag == null) {
            this.value = this.oldValue;
            elm.val(this.oldValue);
        } else {
            this.value = currentValue;
            this.oldValue = currentValue;
            elm.val(currentValue);
        }
    }

    getValue(): any {
        let elm = $(this.input.element.nativeElement);
        return elm.val()
    }

    setValue(value1): any {
        let elm: any = $(this.input.element.nativeElement);
        elm.val(value1);
        //this.eInput.value = this.value;
    }

    isPopup(): boolean {
        return false;
    }


    refresh(): boolean {
        return false;
    }


}

import { EventEmitter } from '@angular/core';
import { ViewChild, Input, Output } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import * as _ from 'lodash';



@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  @Input() dropDownConfig;
  @Output() clickedOnMenuItem = new EventEmitter<any>();

  constructor() { }

  ngOnInit() {
  }

  onSelect(event) {
    console.log('event ::', event);
    this.handleModalRef(event);
  }

  handleModalRef(event) {
    if (event.modalRef) {
      this.clickedOnMenuItem.emit(event);
    }
  }



}

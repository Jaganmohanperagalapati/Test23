import { ChildCellRendererComponent } from './child-cell-renderer.component';
import { InputRenderer } from './input.renderer.component';
import { NgModule, ModuleWithProviders } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { ContourAgGridComponent } from './contour.aggrid.component';
import { AgGridModule } from 'ag-grid-angular/main';
import { DateFormatterComponent } from './date.formatter.component';
import { NumberFormatterComponent } from './number.formatter.component';
import { HyperLinkRendererComponent } from './hyperlink.formatter.component';
import { CommonModule } from '@angular/common';
import { LicenseManager } from 'ag-grid-enterprise/main';
import { HyperLinkRendererService } from './hyperlink.formatter.service';
import { RowEditComponent } from './rowEdit.component';
import { GridActionsService } from './rowEdit.service';
import { DateEditor } from './date.editor.component';
import { InputEditor } from './input.editor.component';


//LicenseManager.setLicenseKey("Broadridge_Financial_Solutions_MultiApp_3Devs4_SaaS_3_May_2018__MTUyNTMwMjAwMDAwMA==774a65a28104fce80456ae126447381c");
LicenseManager.setLicenseKey("Broadridge_Financial_Solutions_MultiApp_3Devs4_SaaS_3_May_2019__MTU1NjgzODAwMDAwMA==e2c56c10948e9779b06eda5e4ef5bfba");

@NgModule({
    imports: [
        FormsModule,
        HttpClientModule,
        CommonModule,
        AgGridModule.withComponents([DateFormatterComponent, NumberFormatterComponent, HyperLinkRendererComponent,
            RowEditComponent, DateEditor, InputEditor, InputRenderer])
    ],
    declarations: [
        DateFormatterComponent,
        NumberFormatterComponent,
        HyperLinkRendererComponent,
        ContourAgGridComponent,
        RowEditComponent,
        DateEditor,
        InputEditor,
        InputRenderer,
        ChildCellRendererComponent
    ],
    providers: [],
    exports: [
        ContourAgGridComponent
    ]
})
export class ContourAgGridModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: ContourAgGridModule,
            providers: [
            ]
        };
    }
}

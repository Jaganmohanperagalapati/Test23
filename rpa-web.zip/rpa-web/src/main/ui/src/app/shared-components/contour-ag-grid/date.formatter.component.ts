import { Component, OnDestroy } from "@angular/core";
import { ICellRendererAngularComp } from "ag-grid-angular";
import { DatePipe } from '@angular/common';

@Component({
    selector: 'date-format',
    template: `
    {{getDateValue() }}
    `,
    styles: []
})
export class DateFormatterComponent implements ICellRendererAngularComp, OnDestroy {
    public params: any;
    public fixedTimezone: any;

    constructor(private datepipe: DatePipe) {

    }

    agInit(params: any): void {
        this.params = params;
    }

    ngOnDestroy() {

    }

    getDateValue() {
        return this.datepipe.transform(this.params.value, this.params.dateFormat);
    }

    refresh(): boolean {
        return false;
    }
}
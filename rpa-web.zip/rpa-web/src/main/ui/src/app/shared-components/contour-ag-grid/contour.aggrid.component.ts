import { InputRenderer } from './input.renderer.component';
import {
    Component, OnInit, OnChanges, Input, ViewChild, EventEmitter, Output, ElementRef,
    Renderer2, ChangeDetectionStrategy, OnDestroy
} from '@angular/core';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { GridOptions } from 'ag-grid/main';
import * as moment from 'moment';
import { DateFormatterComponent } from './date.formatter.component';
import { NumberFormatterComponent } from './number.formatter.component';
import { HyperLinkRendererComponent } from './hyperlink.formatter.component';
import { HyperLinkRendererService } from './hyperlink.formatter.service';
import { RowEditComponent } from './rowEdit.component';
import { GridActionsService } from './rowEdit.service';
import { DateEditor } from './date.editor.component';
import { InputEditor } from './input.editor.component';
import { ChildCellRendererComponent } from './child-cell-renderer.component';



@Component({
    moduleId: module.id,
    selector: 'contour-ag-grid',
    templateUrl: 'contour.aggrid.component.html',
    styleUrls: ['contour.aggrid.component.scss']
})

export class ContourAgGridComponent implements OnInit, OnChanges, OnDestroy {
    @Input() gridOptions: GridOptions;
    @Input() gridSettings: any;
    @Input() gridRecordsCount: any;
    @Output() gridActionsEvent = new EventEmitter<boolean>();
    @Output() gridReady = new EventEmitter<boolean>();
    @Input() components: any;
    @Output() toolbarAction = new EventEmitter<boolean>();
    @Output() onCellClck = new EventEmitter<boolean>();
    @Input() context ;
    @Input() gridHieght;
    showingTotalsResultsTemplate: any;

    frameworkComponents: any;
    linkSubscription: any;
    actionsSubscription: any;
    defaultColDef: any;
    getContextMenuItems: any;
    getMainMenuItems: any;
    public result = ['copy'];

    constructor(private linkService: HyperLinkRendererService, private actionsService: GridActionsService) {
        this.gridRecordsCount = 0;
        this.frameworkComponents = {
            dateFormatRenderer: DateFormatterComponent,
            numberFormatRenderer: NumberFormatterComponent,
            hyperLinkRenderer: HyperLinkRendererComponent,
            rowEditFrameWorkRenderer: RowEditComponent,
            dateEditor: DateEditor,
            inputEditor: InputEditor,
            inputRenderer: InputRenderer,
            childCellRendererComponent : ChildCellRendererComponent

        };

        this.actionsSubscription = this.actionsService.GridActionsService.subscribe(
            response => {
                if (response.type) {
                    this.gridActionsEvent.emit(response);
                }
            }
        );
    }


    ngOnInit() {
        if (this.checkForTotalRecors()) {
            this.showingTotalsResultsTemplate = this.gridSettings.gridtoolbaroptions.gridtoolbarmessage;
        }

        this.defaultColDef = {
            'enableRowGroup': true,
            'stopEditingWhenGridLosesFocus': false,
            'suppressKeyboardEvent': function (event) {
                if (event.editing) {
                    return true;
                }
            }
        };

        this.getMainMenuItems = function getMainMenuItems(params) {
            return ['pinSubMenu', 'separator', 'autoSizeThis', 'autoSizeAll', 'separator', 'resetColumns'];
        };

    }

    ngOnChanges() {
        this.showToolBarMessage();
        this.gridOptions = this.gridOptions;
    }

    ngOnDestroy() {
        this.actionsSubscription.unsubscribe();
    }

    checkForTotalRecors() {
        let flag = false;
        if (this.gridSettings && this.gridSettings.gridtoolbaroptions && this.gridSettings.gridtoolbaroptions.showgridtoolbarmessage) {
            flag = true;
        }
        return flag;
    }

    showToolBarMessage() {
        if (this.checkForTotalRecors() && this.showingTotalsResultsTemplate) {
            this.gridSettings.gridtoolbaroptions.gridtoolbarmessage =
                this.showingTotalsResultsTemplate.replace('{count}', this.gridRecordsCount);
        }
    }

    exportToExcel() {
        const params: any = {};
        params.fileName = 'hello';
        this.gridOptions.api.exportDataAsExcel(params);
    }

    onToolbarAction(event) {
        this.toolbarAction.emit(event);
    }

    onGridReady = (evnt) => {
        this.gridReady.emit(evnt);
    }

    onCellClicked(params) {
        if (params.node.field !== 'action') {
            this.onCellClck.emit(params);
        }
    }
}

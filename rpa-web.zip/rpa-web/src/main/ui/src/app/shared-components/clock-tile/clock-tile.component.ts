import {
  Component, OnInit, Input
} from '@angular/core';
import { Router } from '@angular/router';
import * as momenttimezone from 'moment-timezone';

@Component({
  selector: 'app-clock-tile',
  templateUrl: './clock-tile.component.html',
  styleUrls: ['./clock-tile.component.scss']
})
export class ClockTileComponent implements OnInit {
  public defaultTimeZone;
  public myDate;
  public timeZones = ['IST', 'EST', 'GMT'];
  public CurrentTime;
  public CurrentTimeAMPM;
  public interval;

  constructor() { }

  ngOnInit() {
    this.defaultTimeZone = 'IST';
    this.utcTime(this.defaultTimeZone);
  }

  utcTime(timeZone: any): void {
    this.getDateTime(timeZone);
    this.interval = setInterval(() => {
      this.getDateTime(timeZone);
    }, 10000);
  }

  // get date object based on selected time zone
  getDateTime(timeZone: any) {
    this.myDate = new Date(new Date().toString());
    switch (timeZone) {
      case 'GMT': {
        const timezoneTime = this.toTimeZone(this.myDate, 'Atlantic/Reykjavik');
        this.CurrentTime = timezoneTime.toString().split(' ')[0];
        this.CurrentTimeAMPM = timezoneTime.toString().split(' ')[1];
        break;
      } case 'EST': {
        const timezoneTime = this.toTimeZone(this.myDate, 'America/New_York');
        this.CurrentTime = timezoneTime.toString().split(' ')[0];
        this.CurrentTimeAMPM = timezoneTime.toString().split(' ')[1];
        break;
      } case 'IST': {
        const timezoneTime = this.toTimeZone(this.myDate, 'Asia/Kolkata');
        this.CurrentTime = timezoneTime.toString().split(' ')[0];
        this.CurrentTimeAMPM = timezoneTime.toString().split(' ')[1];
        break;
      }
      default: {
        const timezoneTime = this.toTimeZone(this.myDate, 'Asia/Kolkata');
        this.CurrentTime = timezoneTime.toString().split(' ')[0];
        this.CurrentTimeAMPM = timezoneTime.toString().split(' ')[1];
        break;
      }
    }
  }
  toTimeZone(time: any, zone: any) {
    const format = 'h:mm a';
    return momenttimezone(time, format).tz(zone).format(format);
  }

  // Time zone change
  timeZoneChange(Obj: any) {
    clearInterval(this.interval);
    this.utcTime(Obj);
  }

}

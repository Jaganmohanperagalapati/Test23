import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';

import { ApiService } from '../../services/app-http-api.service';
import { AppQueryService } from './../../services/app-query.service';

@Component({
    selector: 'app-table',
    templateUrl: './table.component.html',
    styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnInit {
    @Input() columns;
    @Input() query;
    @Input()maxheight;
    public tableData = [];
    public isTableDataLoaded;
    @Input() noRecordsMsg;
    @Output() clickEventOnRecord = new EventEmitter();
    constructor(private apiService: ApiService, private queryService: AppQueryService) { }

    ngOnInit() {
        this.isTableDataLoaded = false;
        this.getDataList();
    }

    getDataList() {
        if (this.query) {
            this.apiService.getApiData(this.query).subscribe(
                data => {
                    if (data.success) {
                        this.tableData = data.data;
                    } else {
                        if (data.errors.length > 0) {
                        }
                    }
                    this.isTableDataLoaded = true;

                },
                err => {
                    console.log('Error', err);
                    this.isTableDataLoaded = true;
                }
            );
        }
    }

    openModal(data, column) {
        this.clickEventOnRecord.emit({ data: data, column: column  });
    }

}

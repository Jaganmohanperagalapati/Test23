import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
  selector: 'app-child-cell',
  template: `<span><span><button  (click)="clickedOnEdit()" class="btn btn-default">Edit</button></span></span>`,
  styles: [
    `.btn {
            line-height: 0.5;
            height: 75%;
            border: 1px solid gray;
            width: 75%;
            margin-top: 5%;
        }`
  ]
})
export class ChildCellRendererComponent implements ICellRendererAngularComp {
  public params: any;
  constructor() { }
  agInit(params: any): void {
    this.params = params;
  }

  public clickedOnEdit() {
    console.log(this.params.node);
    this.params.context.componentParent.editHandler(this.params.node.rowIndex, this.params.node.data);
  }

  refresh(): boolean {
    return false;
  }
}

import { AfterViewInit, Component, ViewChild, ViewContainerRef } from '@angular/core';

import { ICellEditorAngularComp } from 'ag-grid-angular';
import * as moment from 'moment';

@Component({
    selector: 'date-editor',
    template: `
       <input #input [(ngModel)]="value" readOnly/>
    `
})
export class DateEditor implements ICellEditorAngularComp, AfterViewInit {
    private params: any;
    public value: any;

    @ViewChild('input', { read: ViewContainerRef }) public input;
    // dont use afterGuiAttached for post gui events - hook into ngAfterViewInit instead for this
    ngAfterViewInit() {
        setTimeout(() => {
            const elm: any = $(this.input.element.nativeElement);
            const options: any = {
                dateFormat: this.params.datePickerFormat ? this.params.datePickerFormat : 'yy-M-dd',
                changeMonth: true,
                changeYear: true
            };
            if (this.params.minDate) {
                options.minDate = this.params.minDate;
            }
            elm.datepicker(options);
        });
    }

    agInit(params: any): void {
        this.params = params;
        if (!this.params.currentFormat) {
            this.params.currentFormat = params.dateFormat;
        }
        this.value = this.params.dateFormat ?
            moment(moment(this.params.value, this.params.currentFormat)).format(this.params.dateFormat) : this.params.value;
    }

    getValue(): any {
        let elm = $(this.input.element.nativeElement);
        //return 
        if (elm.val()) {
            return moment(moment(elm.val(), this.params.dateFormat)).format(this.params.currentFormat);
        } else {
            return elm.val();
        }
    }

    isPopup(): boolean {
        return false;
    }


}

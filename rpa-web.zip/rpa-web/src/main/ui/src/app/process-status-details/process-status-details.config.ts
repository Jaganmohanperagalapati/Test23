export const statusConfig = {
    'totalRequests': [
        { headerName: 'Process Name', field: 'processName' },
        { headerName: 'Instance Id', field: 'instanceId' },
        { headerName: 'Status', field: 'success' },
        { headerName: 'reason', field: 'reason' },
        {headerName: 'Start Time', field: 'startTime' },
        { headerName: 'End Time', field: 'endTime' }
    ],
    'needIntervention': [
        { headerName: 'Process Name', field: 'processName' },
        { headerName: 'Instance Id', field: 'instanceId' },
        { headerName: 'Status', field: 'success' },
        { headerName: 'reason', field: 'reason' },
        { headerName: 'Start Time', field: 'startTime' },
        { headerName: 'End Time', field: 'endTime' }
    ],
    'averageRequests': [],
    'botsRunning': [],

};

import { ChangeDetectorRef, EventEmitter, Output } from '@angular/core';
import { ApiService } from './../services/app-http-api.service';
import { Component, OnInit, ViewChild, Input } from '@angular/core';

import { ModalComponent } from './../shared-components/modal/modal.component';
import { statusConfig } from './process-status-details.config';
import * as _ from 'lodash';

@Component({
  selector: 'app-process-status-details',
  templateUrl: './process-status-details.component.html',
  styleUrls: ['./process-status-details.component.css']
})
export class ProcessStatusDetailsComponent implements OnInit {
  @Input() tileInfo;
  @ViewChild('modalContent') modalContent: ModalComponent;
  @Output() eventOnCloseModal = new EventEmitter();
  public gridHieght = '200px';
  public gridApi;
  public gridColumnApi;
  public showLoading = false;
  public gridOptions = {
    'rowData': [],
    'columnDefs': [],
    'rowHeight': 40,
    'suppressNoRowsOverlay': true
  };

  public isGridVisible = false;
  public config = statusConfig;
  public query;
  public title;
  constructor(private apiService: ApiService, private cdr: ChangeDetectorRef) {
  }

  ngOnInit() { }

  gridReadyCallBack(params) {
    this.getDataList();
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.refreshCells();
    this.gridApi.sizeColumnsToFit();
  }

  getDataList() {
    if (this.query) {
      this.apiService.getApiData(this.query).subscribe(
        data => {
          if (data.success) {
            if (data.data && data.data.length > 0) {
              this.gridOptions.rowData = data.data;
              this.gridApi.setRowData(data.data);
              this.gridHieght = this.getGridHeight();
            } else {
              this.gridOptions.suppressNoRowsOverlay = false;
              this.gridApi.showNoRowsOverlay();
            }
          } else {
            if (data.errors.length > 0) {
              console.log('errors :;', data.errors);
              this.gridOptions.suppressNoRowsOverlay = false;
              this.gridApi.showNoRowsOverlay();
            }
          }
          this.showLoading = false;
        },
        err => {
          console.log('Error', err);
          this.showLoading = false;
          this.gridOptions.suppressNoRowsOverlay = false;
          this.gridApi.showNoRowsOverlay();
        }
      );
    }
  }

  getGridHeight() {
    const noOfReords = this.gridOptions.rowData.length;
    if (noOfReords < 13) {
      return noOfReords * this.gridOptions.rowHeight + 80 + 'px';
    } else {
      return '700px';
    }
  }

  openModal(query) {
    this.query = query;
    this.modalContent.openModal();
    this.getGridMetaData();
    // this.getDataList();
  }

  closeModal() {
    this.modalContent.closeModal();
    this.eventOnCloseModal.emit(false);
    this.query = '';
    this.isGridVisible = false;
  }

  getGridMetaData() {
    if (this.tileInfo) {
      const mappingKey = this.tileInfo.mappingKey;
      this.title = this.tileInfo.processDetailsTitle;
      this.gridOptions.columnDefs = this.config[mappingKey];
      setTimeout(() => {
        this.isGridVisible = true;
        this.showLoading = true;
      }, 1);
    }
  }
}

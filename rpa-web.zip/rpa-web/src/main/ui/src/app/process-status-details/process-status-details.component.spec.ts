import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProcessStatusDetailsComponent } from './process-status-details.component';

describe('ProcessStatusDetailsComponent', () => {
  let component: ProcessStatusDetailsComponent;
  let fixture: ComponentFixture<ProcessStatusDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProcessStatusDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProcessStatusDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ConfigService } from './../config/config.service';
import { Injectable } from '@angular/core';
import * as _ from 'lodash';


@Injectable({
  providedIn: 'root'
})
export class AppQueryService {

  constructor(private config: ConfigService) { }



  prepareQuery(query, data) {
    const urlConfig = this.config.getConfigUrls();
    let apiQuery = urlConfig.baseUrl + query['url'];
    _.each(query.params, (obj, index) => {
      if (index === 0) {
        apiQuery = apiQuery + obj['param'] + data[obj['value']];
      } else {
        apiQuery = apiQuery + '&' + obj['param'] + data[obj['value']];
      }
    });
    return apiQuery;
  }
}

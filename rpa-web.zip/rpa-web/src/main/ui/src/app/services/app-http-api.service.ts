import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { map, filter, tap } from 'rxjs/operators';
import { Http, Headers, Response, RequestOptions } from '@angular/http';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http: HttpClient) { }

  getApiData(Url): Observable<any> {
    return this.http
      .get(Url)
      .map((res: Response) => res)
      .catch((error: any) => Observable.throw(error || 'Server error'));
  }

  updateData(Url, body: any): Observable<any> {
    return this.http
      .post(Url, body)
      .map(res => {
        return res;
      })
      .catch((error: any) => Observable.throw(error || 'Server error'));
  }

}

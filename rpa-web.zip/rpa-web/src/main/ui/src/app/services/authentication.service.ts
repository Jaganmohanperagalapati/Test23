import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import { ConfigService } from '../config/config.service';
import { ApiService } from './app-http-api.service';



@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  public config;


  constructor(private configService: ConfigService, private apiService: ApiService) {
    this.config = this.configService.getConfigUrls();
  }


  // Login from SSO
  readSSOHeaders(): Observable<any> {
    if (!this.config.isSSOEnabled) {
      return Observable.of('');
    } else {
      localStorage.removeItem('user');
      return (this.apiService.getApiData('api/auth/' + this.generateRandomString()).
        map(response => {
          const result: any = response.json();
          console.log('response from SSO ', result);
          const user = {
            userId: result.userId,
            userCode: result.userId,
            firstName: result.firstName,
            lastName: result.lastName,
            name: result.name,
            department: result.department,
            role: result.role,
            designation: result.role.trim().toLowerCase()
          };
          return Observable.of('/dashboard');
        }).catch((error: any) => Observable.throw(error.json().error || 'Server error')));
    }
  }



  // Generating random number for logging
  generateRandomString(): string {
    let text = '';
    const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    for (let i = 0; i < 5; i++) {
      text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
  }

}

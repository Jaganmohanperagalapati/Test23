package com.broadridge.rpa.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.ws.rs.container.ContainerRequestContext;

public class HeaderUtil {

    // TODO: Soft code these names somewhere
    private static final String SSO_ROLE_HEADER = "BRSMINT_ROLES";
    private static final String SSO_USER_ID_HEADER = "BRSMINT_USERID";
    private static final String SSO_USER_FNAME_HEADER = "BRSMINT_FIRSTNAME";
    private static final String SSO_USER_LNAME_HEADER = "BRSMINT_LASTNAME";
    private static final String SSO_USER_CODE = "BRSMINT_CLIENTNO";
    private static final String SSO_APPROLE_NAME = "BRSMINT_APPROLENAME";
    private static final String SSO_USER_EMAIL = "BRSMINT_EMAIL";

    public static List<String> getRoles(ContainerRequestContext ctx) {
        String roles = getAsString(ctx, SSO_ROLE_HEADER);
        if (roles.isEmpty()) {
            return new ArrayList<String>();
        }

        return Arrays.asList(roles.split("\\^"));
    }

    public static String getUserCode(ContainerRequestContext ctx) {
        return getAsString(ctx, SSO_USER_CODE);
    }
    
    public static String getRole(ContainerRequestContext ctx) {
        return getAsString(ctx, SSO_ROLE_HEADER);
    }

    public static String getAppRoleName(ContainerRequestContext ctx) {
        return getAsString(ctx, SSO_APPROLE_NAME);
    }

    public static String getEmail(ContainerRequestContext ctx) {
        return getAsString(ctx, SSO_USER_EMAIL);
    }

    public static String getUserID(ContainerRequestContext ctx) {
        return getAsString(ctx, SSO_USER_ID_HEADER);
    }

    public static String getName(ContainerRequestContext ctx) {
        return getAsString(ctx, SSO_USER_FNAME_HEADER) + " " + getAsString(ctx, SSO_USER_LNAME_HEADER);
    }

    private static String getAsString(ContainerRequestContext ctx, String type) {
        List<String> values = ctx.getHeaders().get(type);
        if (values == null || values.isEmpty()) {
            return "";
        }
        return values.get(0);
    }

}
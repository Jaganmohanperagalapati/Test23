package com.broadridge.rpa.controller;

/*
import java.io.IOException;
import java.text.ParseException;*/
import java.util.List;

import javax.json.Json;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriInfo;

import com.broadridge.rpa.util.HeaderUtil;


@Path("/auth")
public class AuthController {

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("{path}")
	public String find(@DefaultValue("/") @PathParam("path") String path, @Context ContainerRequestContext ctx,
			@Context UriInfo uriInfo) {
		try {
			List<String> roles = HeaderUtil.getRoles(ctx);
			String userID = HeaderUtil.getUserID(ctx);
			String userCode = HeaderUtil.getUserCode(ctx);
			String name = HeaderUtil.getName(ctx);
			String email = HeaderUtil.getEmail(ctx);
			String roletext = HeaderUtil.getRole(ctx);

			JsonObjectBuilder builder = Json.createObjectBuilder();
			JsonArrayBuilder roleArr = Json.createArrayBuilder();
			for (String role : roles) {
				roleArr.add(role);
			}
			builder.add("userId", userID);
			builder.add("userCode", userCode);
			builder.add("name", name);
			builder.add("roles", roleArr);
			builder.add("role", roletext);
			builder.add("email", email);
			builder.add("entitlements", Json.createArrayBuilder());

			JsonObject resp = builder.build();
			return resp.toString();
		} catch (Exception ex) {
			// TODO: Use logger
			ex.printStackTrace();
			return ex.getMessage();
		}
	}

}

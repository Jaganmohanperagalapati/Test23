import { angularCoreEnv } from '@angular/core/src/render3/jit/environment';
// import { Component, OnInit, TemplateRef } from '@angular/core';
// import { ClaimService } from 'src/app/services/claim.service';
// import { ClaimInformation } from 'src/app/kyfb/claim-information';
// import { Router } from '@angular/router';
// import { BsModalRef, BsModalService } from 'ngx-bootstrap';
// import { ConstantPool } from '@angular/compiler';

// @Component({
//   selector: 'kyfb-policies-main',
//   templateUrl: './policies-main.component.html',
//   styleUrls: ['./policies-main.component.scss']
// })
// export class PoliciesMainComponent implements OnInit {
//   claimInformation?: ClaimInformation;
//   policiesInfo: any;
//   dueDateDetails: any[];
//   policesAllmodalRef: BsModalRef;
//   clientName: any = "";
//   mobileView: boolean=false;
//   constructor(private claimService: ClaimService, private router: Router, private modalService: BsModalService) { }

//   ngOnInit() {
//     this.getInfo();
//     if (window.screen.width < 600) { // 768px portrait
//       this.mobileView = true;
//     }
//     console.log(this.mobileView)
//     this.claimService.currentDueDateDetails.subscribe(dueDateDetails => this.dueDateDetails = dueDateDetails)
//   }

//   openPoliciesAllModal(template: TemplateRef<any>) {
//     this.policesAllmodalRef = this.modalService.show(template);
//   }

//   getInfo() {
//     this.claimService.getClaimsInfo().subscribe((claims) => {
//       this.policiesInfo = claims.eBusAccountResponseType.policies.policyInfo;
//       this.clientName = claims.eBusAccountResponseType.clientInfo.firstName;

//     },
//       error => { }
//     );
//   }

//   policyClick(policy, type, isModalOpened = false) {
//     let dueDate = "";
//     if (policy.inetPayInd != null && policy.inetPayInd.trim() != "" && policy.inetPayInd.trim().toLowerCase() == "y" &&
//       policy.unprocPayInd != null && policy.unprocPayInd.trim() != "" && policy.unprocPayInd.trim().toLowerCase() == "n" &&
//       policy.accountBillInd != null && policy.accountBillInd.trim() != "" && policy.accountBillInd.trim().toLowerCase() == "n" &&
//       policy.dueDate != null && policy.dueDate.trim() != "" && policy.dueDate != "0001-01-01") {
//       dueDate = this.convertDate(policy.dueDate);
//     }
//     let tempArr = { 'policyNumber': policy.policyNumber, 'type': type, "dueDate": dueDate };
//     localStorage.setItem('selectedPolicy', JSON.stringify(tempArr));
//     if (isModalOpened) {
//       this.policesAllmodalRef.hide();
//     }
//     this.router.navigate(['/claims/report-claim']);
//   }


//   convertDate(inputFormat) {
//     inputFormat = new Date(inputFormat);
//     function pad(s) { return (s < 10) ? '0' + s : s; }
//     var d = new Date(inputFormat);
//     return [pad(d.getDate()), pad(d.getMonth() + 1), d.getFullYear()].join('/');
//   }

// }


import { Component, OnInit, TemplateRef } from '@angular/core';
import { ClaimService } from 'src/app/services/claim.service';
import { ClaimInformation } from 'src/app/kyfb/claim-information';
import { Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { ConstantPool } from '@angular/compiler';

@Component({
  selector: 'kyfb-policies-main',
  templateUrl: './policies-main.component.html',
  styleUrls: ['./policies-main.component.scss']
})
export class PoliciesMainComponent implements OnInit {
  claimInformation?: ClaimInformation;
  policiesInfo: any;
  dueDateDetails: any[];
  policesAllmodalRef: BsModalRef;
  clientName: any = "";
  mobileView: boolean = false;
  agentInfo: any[] = [];
  policyType: any[];


  vehicleInfo: any;
  constructor(private claimService: ClaimService, private router: Router, private modalService: BsModalService) { }

  ngOnInit() {
    this.getInfo();
    this.getDetailsInfo();
    if (window.screen.width < 600) { // 768px portrait
      this.mobileView = true;
    }
    console.log(this.mobileView)
    this.claimService.currentDueDateDetails.subscribe(dueDateDetails => this.dueDateDetails = dueDateDetails)
  }

  openPoliciesAllModal(template: TemplateRef<any>) {
    this.policesAllmodalRef = this.modalService.show(template);
  }
  public clientInfo: any;
  getInfo() {
    this.claimService.getClaimsInfo().subscribe((claims) => {
      // console.log(claims,'claims');
      this.policiesInfo = this.getValidPolicies(claims);
      this.clientName = claims.eBusAccountResponseType.clientInfo.firstName;
      this.agentInfo = claims.agentInfo;
      this.clientInfo = claims.eBusAccountResponseType.clientInfo;
      // this.agentInfo=[];
      console.log(this.agentInfo);
    },
      error => { }
    );
  }


  getValidPolicies(claims) {
    const policyLineCodes = ['01', '19', '08', '09', '11', '15', '02'];
    let policiesInfo = claims.eBusAccountResponseType.policies.policyInfo;
    const array = this.getFilteredInfo(policiesInfo, 'lineCode', policyLineCodes);
    policiesInfo = array || [];
    return policiesInfo;
  }

  getFilteredInfo(list, attribute, listOfValues) {
    const array = list.filter((item) => {
      const index = this.getPositionOfValue(listOfValues, item[attribute]);
      return (index !== -1);
    });
    return array;
  }

  getPositionOfValue(list, value) {
    const index = list.indexOf(value);
    return index;
  }

  getDetailsInfo() {
    console.log("hello sriiiiiiiii");

    this.claimService.getClaimsInfo().subscribe((pol) => {
      this.vehicleInfo = pol.vehicleInfoDTOList;
      console.log(pol.vechileIndoDTOList);
    },
      error => { }
    );
  }

  policyClick(policy, type, isModalOpened = false, policyNumber) {

    if (policyNumber) {
      const data = {
        'clientName': this.clientInfo.firstName + ' ' + this.clientInfo.lastNameOrCompanyName,
        'clientRefNum': this.clientInfo.clientUID,
        'policyNumForFNDL': policyNumber,
        'policyType': JSON.parse(window.localStorage.getItem('selectedPolicy')).type
      };
      this.claimService.selectPolicy(data).subscribe((response) => {
        console.log(response, 'response');
        // this.agentInfo=[];

      },
        error => { }
      );
    }
    let dueDate = "";
    let policyType = type;
    console.log(policyType);
    if (policy.inetPayInd != null && policy.inetPayInd.trim() != "" && policy.inetPayInd.trim().toLowerCase() == "y" &&
      policy.unprocPayInd != null && policy.unprocPayInd.trim() != "" && policy.unprocPayInd.trim().toLowerCase() == "n" &&
      policy.accountBillInd != null && policy.accountBillInd.trim() != "" && policy.accountBillInd.trim().toLowerCase() == "n" &&
      policy.dueDate != null && policy.dueDate.trim() != "" && policy.dueDate != "0001-01-01") {
      dueDate = this.convertDate(policy.dueDate);
    }
    let tempArr = { 'policyNumber': policy.policyNumber, 'type': type, "dueDate": dueDate };
    localStorage.setItem('selectedPolicy', JSON.stringify(tempArr));
    if (isModalOpened) {
      this.policesAllmodalRef.hide();
    }
    this.router.navigate(['/claims/report-claim']);
  }



  convertDate(inputFormat) {
    inputFormat = new Date(inputFormat);
    function pad(s) { return (s < 10) ? '0' + s : s; }
    var d = new Date(inputFormat);
    return [pad(d.getDate()), pad(d.getMonth() + 1), d.getFullYear()].join('/');
  }

}


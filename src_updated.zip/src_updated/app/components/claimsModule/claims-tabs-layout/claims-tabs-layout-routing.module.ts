import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ReportTypeAutoComponent } from './report-type-auto/report-type-auto.component';
import { UserLocationInfoComponent } from './user-location-info/user-location-info.component';
import { AutoClaimDetailsComponent } from './auto-claim-details/auto-claim-details.component';
import { ContactInfoComponent } from './contact-info/contact-info.component';
import { ConfirmationAutoComponent } from './confirmation-auto/confirmation-auto.component';
import { ReportTypePropertyComponent } from './report-type-property/report-type-property.component';
import { PropertyClaimDetailsComponent } from './property-claim-details/property-claim-details.component';
import { ConfirmationPropertyComponent } from './confirmation-property/confirmation-property.component';

const routes: Routes = [
    {path:'report-type-auto',component:ReportTypeAutoComponent},
    {path:'user-location-info',component:UserLocationInfoComponent},
    {path:'auto-claim-details',component:AutoClaimDetailsComponent},
    {path:'contact-info',component:ContactInfoComponent},
    {path:'confirmation-auto',component:ConfirmationAutoComponent},
    {path:'report-type-property',component:ReportTypePropertyComponent},
    {path:'property-claim-detail',component:PropertyClaimDetailsComponent},
    {path:'confirmation-property',component:ConfirmationPropertyComponent},
    
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ClaimsTabsLayoutRoutingModule { }

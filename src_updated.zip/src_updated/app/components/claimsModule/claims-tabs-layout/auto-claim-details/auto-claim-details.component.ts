import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ClaimService } from 'src/app/services/claim.service';




@Component({
  selector: 'kyfb-auto-claim-details',
  templateUrl: './auto-claim-details.component.html',
  styleUrls: ['./auto-claim-details.component.scss']
})
export class AutoClaimDetailsComponent implements OnInit {
  vehicleInfo: any;
  constructor(private claimService: ClaimService,private router:Router) { }

  ngOnInit() {
  }
 


  getDetailsInfo(){
    console.log("hello sriiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
      
    this.claimService.getPolicyInfo().subscribe((pol) => {
      this.vehicleInfo = pol.contactNameNumbersDTOList;
      console.log("hiiiiiiiiiiii");
      console.log(pol.contactNameNumbersDTOList)
    }, 
    error => {
      console.log("Failed");
    } 
    );
  }


  goToPrevious(){
    this.router.navigate(['/claims/claims-tabs/user-location-info']);
  }

  goToNext(){
    this.router.navigate(['/claims/claims-tabs/contact-info']);
  }

}

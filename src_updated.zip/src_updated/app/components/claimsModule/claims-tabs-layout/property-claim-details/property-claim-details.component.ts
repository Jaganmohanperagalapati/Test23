import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'kyfb-property-claim-details',
  templateUrl: './property-claim-details.component.html',
  styleUrls: ['./property-claim-details.component.scss']
})
export class PropertyClaimDetailsComponent implements OnInit {
  selectedPolicyData: any[] = [];
  constructor(private router: Router) { }

  ngOnInit() {
  }

  goToPrevious() {
    this.router.navigate(['/claims/claims-tabs/user-location-info']);
  }

  goToNext() {
    this.router.navigate(['/claims/claims-tabs/contact-info']);
  }

}

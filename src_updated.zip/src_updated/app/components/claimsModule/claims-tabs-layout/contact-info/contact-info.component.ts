import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { ClaimService } from 'src/app/services/claim.service';
import { Router } from '@angular/router';

@Component({
  selector: 'kyfb-contact-info',
  templateUrl: './contact-info.component.html',
  styleUrls: ['./contact-info.component.scss']
})
export class ContactInfoComponent implements OnInit {
  selectedPolicyData: any[] = [];
  constructor(private router: Router) { }

  ngOnInit() {
  }

  goToPrevious() {
    if (this.selectedPolicyData['type'] == "A" || this.selectedPolicyData['type'] == "B") {
      this.router.navigate(['/claims/claims-tabs/auto-claim-details']);
    } else {
      this.router.navigate(['/claims/claims-tabs/property-claim-detail']);
    }
  }

  goToNext() {
    if (this.selectedPolicyData['type'] == "A" || this.selectedPolicyData['type'] == "B") {
      this.router.navigate(['/claims/claims-tabs/confirmation-auto']);
    } else {
      this.router.navigate(['/claims/claims-tabs/confirmation-property']);
    }
  }


  /*goToPrevious() {
    if (this.selectedPolicyData['type'] == "A" || this.selectedPolicyData['type'] == "B") {
      this.router.navigate(['/claims/claims-tabs/report-type-auto']);
    } else {
      this.router.navigate(['/claims/claims-tabs/report-type-property']);
    }
  }

  goToNext() {
    if (this.selectedPolicyData['type'] == "A" || this.selectedPolicyData['type'] == "B") {
      this.router.navigate(['/claims/claims-tabs/auto-claim-details']);
    } else {
      this.router.navigate(['/claims/claims-tabs/property-claim-detail']);
    }
  }*/


}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportTypePropertyComponent } from './report-type-property.component';

describe('ReportTypePropertyComponent', () => {
  let component: ReportTypePropertyComponent;
  let fixture: ComponentFixture<ReportTypePropertyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportTypePropertyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportTypePropertyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

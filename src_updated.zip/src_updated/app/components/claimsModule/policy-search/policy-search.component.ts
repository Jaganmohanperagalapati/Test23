import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kyfb-policy-search',
  templateUrl: './policy-search.component.html',
  styleUrls: ['./policy-search.component.scss']
})
export class PolicySearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

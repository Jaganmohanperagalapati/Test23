import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kyfb-preferences',
  templateUrl: './preferences.component.html',
  styleUrls: ['./preferences.component.scss']
})
export class PreferencesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

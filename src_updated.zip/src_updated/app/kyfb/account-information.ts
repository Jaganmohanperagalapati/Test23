import { JsonObject, JsonProperty } from 'json2typescript';
import { Status, Address, DateTime } from './common';
import * as _ from 'lodash';
import * as moment from 'moment';

@JsonObject('ClientName')
export class ClientName {
    @JsonProperty('name', String, true)
    name?: string = null;
    @JsonProperty('enrollmentStatus', String, true)
    enrollmentStatus?: string = null;
    @JsonProperty('enrollmentDate', DateTime, true)
    enrollmentDate?: DateTime | null = null;
    @JsonProperty('designationStatus', String, true)
    designationStatus?: string = null;
    @JsonProperty('emailAddress', String, true)
    emailAddress?: string = null;
}

@JsonObject('ClientInfo')
export class ClientInfo {
    @JsonProperty('clientUID', String)
    clientUID: string = null;
    @JsonProperty('clientType', String)
    clientType: string = null;
    @JsonProperty('membershipNumber', String, true)
    membershipNumber?: string = null;
    @JsonProperty('membershipRelationship', String, true)
    membershipRelationship?: string = null;
    @JsonProperty('title', String, true)
    title?: string = null;
    @JsonProperty('suffix', String, true)
    suffix?: string = null;
    @JsonProperty('firstName', String, true)
    firstName?: string = null;
    @JsonProperty('lastNameOrCompanyName', String)
    lastNameOrCompanyName: string = null;
    @JsonProperty('address', Address, true)
    address?: Address = null;
    @JsonProperty('homePhoneNumber', String, true)
    homePhoneNumber?: string = null;
    @JsonProperty('workPhoneNumber', String, true)
    workPhoneNumber: string = null;
    @JsonProperty('cellPhoneNumber', String, true)
    cellPhoneNumber?: string = null;
    @JsonProperty('pagerPhoneNumber', String, true)
    pagerPhoneNumber?: string = null;
    @JsonProperty('faxNumber', String, true)
    faxNumber?: string = null;
    @JsonProperty('faxNumber2', String, true)
    faxNumber2?: string = null;
    @JsonProperty('homeEMailAddress', String, true)
    homeEMailAddress?: string = null;
    @JsonProperty('workEMailAddress', String)
    workEMailAddress: string = null;
    @JsonProperty('birthDateOrDateEstablished', String, true)
    birthDateOrDateEstablished?: string = null;
    @JsonProperty('businessContactName', String, true)
    businessContactName?: string = null;
    @JsonProperty('businessContactPhone', String, true)
    businessContactPhone?: string = null;
    @JsonProperty('notificationSentTmStmp', String, true)
    notificationSentTmStmp?: string = null;
    @JsonProperty('notificationStatusCode', String, true)
    notificationStatusCode?: string = null;

    getFullName(): string {
        return this.firstName + ' ' + this.lastNameOrCompanyName;
    }
}

@JsonObject('MembershipInfo')
export class MembershipInfo implements Payable {
    @JsonProperty('membershipNumber', String)
    membershipNumber: string = null;
    @JsonProperty('type', String, true)
    type?: string = null;
    @JsonProperty('county', String, true)
    county?: string = null;
    @JsonProperty('agencyNumber', String, true)
    agencyNumber?: string = null;
    @JsonProperty('status', String, true)
    status: string = null;
    @JsonProperty('paidYear', String, true)
    paidYear?: string = null;
    @JsonProperty('dueDate', String, true)
    dueDate?: string = null;
    @JsonProperty('dueAmount', String, true)
    dueAmount?: string = null;
    @JsonProperty('inetPayInd', String, true)
    inetPayInd?: string = null;
    @JsonProperty('unprocPayInd', String, true)
    unprocPayInd?: string = null;
    @JsonProperty('duesEarlyPayDt', String, true)
    duesEarlyPayDt?: string = null;
    @JsonProperty('duesEarlyPayAmt', String, true)
    duesEarlyPayAmt?: string = null;
    @JsonProperty('primaryHolderName', ClientName, true)
    primaryHolderName?: ClientName = null;
    @JsonProperty('secondaryHolderName', ClientName, true)
    secondaryHolderName?: ClientName = null;
    @JsonProperty('otherHolderName', [ClientName], true)
    otherHolderName?: ClientName[] = [];
    @JsonProperty('eDeliveryEligibility', String, true)
    eDeliveryEligibility?: string = null;
    @JsonProperty('address', Address, true)
    address?: Address = null;
    @JsonProperty('paymentIndicator', String, true)
    paymentIndicator?: string = null;
    @JsonProperty('farmingDesignation', String, true)
    farmingDesignation?: string = null;
    @JsonProperty('effectiveDate', String, true)
    effectiveDate?: string = null;
    @JsonProperty('expirationDate', String, true)
    expirationDate?: string = null;

    getType(): PayableType {
        return PayableType.MEMBERSHIP;
    }

    isDue(): boolean {
        return this.inetPayInd === 'Y'
            && this.unprocPayInd === 'N'
            && (this.paymentIndicator !== 'AE' && this.paymentIndicator !== 'NE')
            && (this.dueDate !== '01/01/1900' && this.dueDate !== '01/01/2077');
    }

    getLabel(): string {
        return this.membershipNumber;
    }

    getMinimumAmountDue(): string {
        return this.dueAmount;
    }

    getDueDate(): moment.Moment {
        return moment(this.dueDate);
    }
}

@JsonObject('PendInfo')
export class PendInfo {
    @JsonProperty('pendType', String, true)
    pendType?: string = null;
    @JsonProperty('pendCode', String, true)
    pendCode?: string = null;
    @JsonProperty('pendDate', String, true)
    pendDate?: string = null;
    @JsonProperty('nextPendActCode', String, true)
    nextPendActCode?: string = null;
}

@JsonObject('PendInfoDetails')
export class PendInfoDetails {
    @JsonProperty('pendInfo', [PendInfo], true)
    pendInfo?: PendInfo[] = [];
}

@JsonObject('UnitInfo')
export class UnitInfo {
    @JsonProperty('unitNumber', String, true)
    unitNumber?: string = null;
    @JsonProperty('unitDescription', String, true)
    unitDescription?: string = null;
}

@JsonObject('Units')
export class Units {
    @JsonProperty('unitInfo', [UnitInfo], true)
    unitInfo?: UnitInfo[] = [];
}

@JsonObject('PolicyInfo')
export class PolicyInfo implements Payable {
    @JsonProperty('policyNumber', String)
    policyNumber: string = null;
    @JsonProperty('lineCode', String)
    lineCode: string = null;
    @JsonProperty('companyNumber', String)
    companyNumber: string = null;
    @JsonProperty('inetPayInd', String, true)
    inetPayInd?: string = null;
    @JsonProperty('agentNo', String, true)
    agentNo?: string = null;
    @JsonProperty('accountBillNumber', String, true)
    accountBillNumber?: string = null;
    @JsonProperty('billPlan', String, true)
    billPlan?: string = null;
    @JsonProperty('policyStatus', String, true)
    policyStatus?: string = null;
    @JsonProperty('primaryHolderName', ClientName, true)
    primaryHolderName?: ClientName = null;
    @JsonProperty('secondaryHolderName', ClientName, true)
    secondaryHolderName?: ClientName = null;
    @JsonProperty('otherHolderName', [ClientName], true)
    otherHolderName?: ClientName[] = [];
    @JsonProperty('eDeliveryEligibility', String, true)
    eDeliveryEligibility?: string = null;
    @JsonProperty('address', Address, true)
    address?: Address = null;
    @JsonProperty('locationCounty', String, true)
    locationCounty?: string = null;
    @JsonProperty('insuredPhone', String, true)
    insuredPhone?: string = null;
    @JsonProperty('membershipNumber', String, true)
    membershipNumber?: string = null;
    @JsonProperty('agentName', String, true)
    agentName?: string = null;
    @JsonProperty('terminationReason', String, true)
    terminationReason?: string = null;
    @JsonProperty('dueReason', String, true)
    dueReason?: string = null;
    @JsonProperty('totalDueAmount', String, true)
    totalDueAmount?: string = null;
    @JsonProperty('dueDate', String, true)
    dueDate?: string = null;
    @JsonProperty('installDueAmount', String, true)
    installDueAmount?: string = null;
    @JsonProperty('totalBillAmount', String, true)
    totalBillAmount?: string = null;
    @JsonProperty('due02MonthAmount', String, true)
    due02MonthAmount?: string = null;
    @JsonProperty('due03MonthAmount', String, true)
    due03MonthAmount?: string = null;
    @JsonProperty('carryDate', String, true)
    carryDate?: string = null;
    @JsonProperty('cancellationDate', String, true)
    cancellationDate?: string = null;
    @JsonProperty('accountBillInd', String, true)
    accountBillInd?: string = null;
    @JsonProperty('canBeViewed', String, true)
    canBeViewed?: string = null;
    @JsonProperty('unprocPayInd', String, true)
    unprocPayInd?: string = null;
    @JsonProperty('pendInfoDetails', PendInfoDetails, true)
    pendInfoDetails?: PendInfoDetails = null;
    @JsonProperty('units', Units, true)
    units?: Units = null;
    @JsonProperty('systemOfRecord', String, true)
    systemOfRecord?: string = null;
    @JsonProperty('nsfFeesAmt', String, true)
    nsfFeesAmt?: string = null;
    @JsonProperty('lateFeesAmt', String, true)
    lateFeesAmt?: string = null;
    @JsonProperty('latePayCount', String, true)
    latePayCount?: string = null;
    @JsonProperty('eqPolicyInd', String, true)
    eqPolicyInd?: string = null;
    @JsonProperty('eqPolicyEffectiveDt', String, true)
    eqPolicyEffectiveDt?: string = null;
    @JsonProperty('eqPolicyExpiryDt', String, true)
    eqPolicyExpiryDt?: string = null;
    @JsonProperty('scheduledPaymentInd', String, true)
    scheduledPaymentInd?: Boolean = null;
    
    getType(): PayableType {
        return PayableType.POLICY;
    }

    isDue(): boolean {
        return this.inetPayInd === 'Y'
            && this.unprocPayInd === 'N'
            && this.accountBillInd === 'N'
            && (this.dueDate !== '01/01/1900' && this.dueDate !== '01/01/2077');
    }

    isCurrentlyDue(): boolean {
        return this.inetPayInd === 'Y'
            && this.unprocPayInd === 'N'
            && this.accountBillInd === 'N'
            && (this.dueDate !== '01/01/1900' && this.dueDate !== '01/01/2077');
    }

    isBalanceDue(): boolean {
        return this.inetPayInd === 'Y'
            && this.unprocPayInd === 'N'
            && this.accountBillInd === 'N'
            && (this.dueDate == '01/01/1900' || this.dueDate == '01/01/2077');
    }

    isNoBalanceDue(): boolean {
        return this.inetPayInd === 'N'
            && this.unprocPayInd === 'N'
            && this.accountBillInd === 'N';
    }

    getLabel(): string {
        return this.policyNumber;
    }

    getDescription(): string {
        return this.units.unitInfo.map(unit => unit.unitDescription).join(', ');
    }

    getMinimumAmountDue(): string {
        if (Number(this.installDueAmount) > Number(this.totalDueAmount)) {
            if (Number(this.due03MonthAmount) < Number(this.totalDueAmount)) {
                return this.due03MonthAmount;
            }

            if (Number(this.due02MonthAmount) < Number(this.totalDueAmount)) {
                return this.due02MonthAmount;
            }

            if (Number(this.installDueAmount) < Number(this.totalDueAmount)) {
                return this.installDueAmount;
            }
        }

        return this.totalDueAmount;
    }

    getDueDate(): moment.Moment {
        return moment(this.dueDate);
    }
}

@JsonObject('Policies')
export class Policies {
    @JsonProperty('policyInfo', [PolicyInfo], true)
    policyInfo?: PolicyInfo[] = [];

    getPoliciesDue(): PolicyInfo[] {
        return _.filter(this.policyInfo, function (policyInfo) {
            return policyInfo.isDue();
        });
    }

    getAgentNumbers(): string[] {
        return _.uniq(this.policyInfo.map(policy => policy.agentNo));
    }
}

@JsonObject('AccountBillInfo')
export class AccountBillInfo implements Payable {
    @JsonProperty('accountBillNumber', String, true)
    accountBillNumber?: string = null;
    @JsonProperty('type', String, true)
    type?: string = null;
    @JsonProperty('status', String, true)
    status?: string = null;
    @JsonProperty('dateOpened', String, true)
    dateOpened?: string = null;
    @JsonProperty('dateClosed', String, true)
    dateClosed?: string = null;
    @JsonProperty('nextStatementDueDate', String, true)
    nextStatementDueDate?: string = null;
    @JsonProperty('lastStatementDate', String, true)
    lastStatementDate?: string = null;
    @JsonProperty('lastEFTDate', String, true)
    lastEFTDate?: string = null;
    @JsonProperty('estNextStatementDueAmt', String, true)
    estNextStatementDueAmt?: string = null;
    @JsonProperty('primaryHolderName', ClientName, true)
    primaryHolderName?: ClientName = null;
    @JsonProperty('secondaryHolderName', ClientName, true)
    secondaryHolderName?: ClientName = null;
    @JsonProperty('otherHolderName', [ClientName], true)
    otherHolderName?: ClientName[] = [];
    @JsonProperty('eDeliveryEligibility', String, true)
    eDeliveryEligibility?: string = null;
    @JsonProperty('totalDueAmount', String, true)
    totalDueAmount?: string = null;
    @JsonProperty('dueDate', String, true)
    dueDate?: string = null;
    @JsonProperty('inetPayInd', String, true)
    inetPayInd?: string = null;
    @JsonProperty('unprocPayInd', String, true)
    unprocPayInd?: string = null;
    @JsonProperty('address', Address, true)
    address?: Address = null;
    @JsonProperty('agencyNumber', String, true)
    agencyNumber?: string = null;
    @JsonProperty('branchNumber', String, true)
    branchNumber?: string = null;
    @JsonProperty('estimatedMonthlyAmount', String, true)
    estimatedMonthlyAmount?: string = null;
    @JsonProperty('billingMethod', String, true)
    billingMethod?: string = null;
    @JsonProperty('canBeViewed', String, true)
    canBeViewed?: string = null;

    getType(): PayableType {
        return PayableType.ACCOUNT_BILL;
    }

    isDue(): boolean {
        return this.inetPayInd === 'Y'
            && this.unprocPayInd === 'N'
            && (this.dueDate !== '01/01/1900' && this.dueDate !== '01/01/2077');
    }

    getLabel(): string {
        return this.accountBillNumber;
    }

    getDescription(): string {
        return 'Account Bill';
    }

    getMinimumAmountDue(): string {
        return this.totalDueAmount;
    }

    getDueDate(): moment.Moment {
        return moment(this.dueDate);
    }
}

@JsonObject('AccountBills')
export class AccountBills {
    @JsonProperty('accountBillInfo', [AccountBillInfo], true)
    accountBillInfo?: AccountBillInfo[] = [];

    getAccountBillsDue(): AccountBillInfo[] {
        return _.filter(this.accountBillInfo, function (accountBillInfo) {
            return accountBillInfo.isDue();
        });
    }
}

@JsonObject('PortalProfile')
export class PortalProfile {
    @JsonProperty('eBusinessId', String, true)
    eBusinessId?: string = null;
    @JsonProperty('portalEmailId', String, true)
    portalEmailId?: string = null;
}

@JsonObject('MultipleProfiles')
export class MultipleProfiles {
    @JsonProperty('portalProfiles', [PortalProfile], true)
    portalProfiles?: PortalProfile[] = [];
}

@JsonObject('EntitiesScheduledPaymentInfo')
export class EntitiesScheduledPaymentInfo {
    @JsonProperty('entityNbr', String)
    entityNbr: string = null;
    @JsonProperty('entityTypeCd', String)
    entityTypeCd: string = null;
    @JsonProperty('scheduledPaymentAmt', String)
    scheduledPaymentAmt: string = null;
}

@JsonObject('ScheduledPayment')
export class ScheduledPayment {
    @JsonProperty('scheduledDate', String)
    scheduledDate: string = null;
    @JsonProperty('orderNbr', String)
    orderNbr: string = null;
    @JsonProperty('totalAmout', String)
    totalAmout: string = null;
    @JsonProperty('entitiesScheduledPaymentInfo', EntitiesScheduledPaymentInfo)
    entitiesScheduledPaymentInfo: EntitiesScheduledPaymentInfo = null;
    @JsonProperty('settlementType', String)
    settlementType: string = null;
    @JsonProperty('currentStatus', String)
    currentStatus: string = null;
}

@JsonObject('ScheduledPaymentsList')
export class ScheduledPaymentsList {
    @JsonProperty('scheduledPayment', [ScheduledPayment], true)
    scheduledPayment?: ScheduledPayment[] = [];
}

export enum PayableType {
    MEMBERSHIP,
    POLICY,
    ACCOUNT_BILL
}

export interface Payable {
    getType(): PayableType;
    isDue(): boolean;
    getLabel(): string;
    getMinimumAmountDue(): string;
    getDueDate(): moment.Moment;
}

@JsonObject('AccountInformation')
export class AccountInformation {
    @JsonProperty('status', Status)
    status: Status = null;
    @JsonProperty('clientInfo', ClientInfo)
    clientInfo: ClientInfo = null;
    @JsonProperty('membershipInfo', MembershipInfo)
    membershipInfo: MembershipInfo = null;
    @JsonProperty('policies', Policies)
    policies: Policies = null;
    @JsonProperty('accountBills', AccountBills)
    accountBills: AccountBills = null;
    @JsonProperty('multipleProfiles', MultipleProfiles)
    multipleProfiles: MultipleProfiles;
    @JsonProperty('scheduledPaymentsList', ScheduledPaymentsList)
    scheduledPaymentsList: ScheduledPaymentsList;

    constructor(
        status: Status,
        clientInfo: ClientInfo,
        membershipInfo: MembershipInfo,
        policies: Policies,
        accountBills: AccountBills,
        multipleProfiles: MultipleProfiles,
        scheduledPaymentsList: ScheduledPaymentsList
    ) {
        this.status = status;
        this.clientInfo = clientInfo;
        this.membershipInfo = membershipInfo;
        this.policies = policies;
        this.accountBills = accountBills;
        this.multipleProfiles = multipleProfiles;
        this.scheduledPaymentsList = scheduledPaymentsList;
    }

    getPayables(): Payable[] {
        const payables: Payable[] = [];

        payables.push(this.membershipInfo);
        this.policies.policyInfo.forEach(item => payables.push(item));
        this.accountBills.accountBillInfo.forEach(item => payables.push(item));

        return payables;
    }

    getPayablesDue(limit = 3): Payable[] {
        let payables: Payable[] = [];

        payables = _.filter(this.getPayables(), payable => payable.isDue());

        return payables.slice(0, limit);
    }
}

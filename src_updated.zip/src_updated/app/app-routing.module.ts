import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { PaymentsComponent } from './components/payments/payments.component';
import { DocumentsComponent } from './components/documents/documents.component';
import { ClaimsComponent } from './components/claims/claims.component';
import { FileComponent as FileClaimComponent } from './components/claims/file/file.component';
import { PreferencesComponent } from './components/preferences/preferences.component';
import { AccountComponent } from './components/account/account.component';
import { MembershipComponent } from './components/membership/membership.component';
import { QuoteComponent } from './components/quote/quote.component';
import { SupportComponent } from './components/support/support.component';
import { PaymentSummaryComponent } from './components/payment-summary/payment-summary.component';
import { ClaimsLayoutComponent } from './components/claimsModule/claims-layout/claims-layout.component';

const routes: Routes = [
    { path: '', component: DashboardComponent },
    { path: 'dashboard', component: DashboardComponent },
    { path: 'payments', component: PaymentsComponent },
    { path: 'payment-summary', component: PaymentSummaryComponent },
    { path: 'documents', component: DocumentsComponent },
  /*  { path: 'claims/file/:policyNumber', component: FileClaimComponent },*/
    { path: 'preferences', component: PreferencesComponent },
    { path: 'account', component: AccountComponent },
    { path: 'membership', component: MembershipComponent },
    { path: 'quote', component: QuoteComponent },
    { path: 'support', component: SupportComponent },
    {
        path: '',
        component: ClaimsLayoutComponent,
        children: [
            {
                path: 'claims',
                loadChildren: 'src/app/components/claimsModule/claims.module#ClaimsModule'
            }
        ],
    },
];

@NgModule({
    imports: [RouterModule.forRoot(routes, {scrollPositionRestoration: 'enabled'})],
    exports: [RouterModule]
})
export class AppRoutingModule { }

$(function() {
    // Remove splash screen after load
    $('.splash').css('display', 'none');
});


interface PaymentsSummaryInfo {
    policyNumber: string;
    description: string;
    dueDate: string;
}

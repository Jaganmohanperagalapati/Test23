import { JsonObject, JsonProperty } from 'json2typescript';

@JsonObject('Status')
export class Status {
    @JsonProperty('statusCode', String)
    statusCode: string = null;
    @JsonProperty('statusMessage', String)
    statusMessage: string = null;
}

@JsonObject('Address')
export class Address {
    @JsonProperty('addressCategory', String, true)
    addressCategory?: string = null;
    @JsonProperty('addresse', String, true)
    addresse?: string = null;
    @JsonProperty('streetAddress', String, true)
    streetAddress?: string = null;
    @JsonProperty('townSuburb', String, true)
    townSuburb?: string = null;
    @JsonProperty('city', String, true)
    city?: string = null;
    @JsonProperty('stateProvince', String, true)
    stateProvince?: string = null;
    @JsonProperty('postalCode', String, true)
    postalCode?: string = null;
    @JsonProperty('county', String, true)
    county?: string = null;
    @JsonProperty('country', String, true)
    country?: string = null;
    @JsonProperty('boxNumber', String, true)
    boxNumber?: string = null;
    @JsonProperty('boxType', String, true)
    boxType?: string = null;
}

@JsonObject('DateTime')
export class DateTime {
    @JsonProperty('year', Number)
    year?: number = null;
    @JsonProperty('month', Number)
    month?: number = null;
    @JsonProperty('day', Number)
    day?: number = null;
    @JsonProperty('hour', Number)
    hour?: number = null;
    @JsonProperty('minute', Number)
    minute?: number = null;
    @JsonProperty('second', Number)
    second?: number = null;
    @JsonProperty('fractionalSecond', Number)
    fractionalSecond?: number = null;
    @JsonProperty('timezone', Number)
    timezone?: number = null;
}

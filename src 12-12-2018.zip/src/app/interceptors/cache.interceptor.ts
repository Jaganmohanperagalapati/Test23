import { Injectable } from '@angular/core';
import { CacheService } from '../services/cache.service';
import { Observable, of } from 'rxjs';
import { tap } from 'rxjs/operators';
import {
    HttpRequest,
    HttpResponse,
    HttpEvent,
    HttpHandler,
    HttpInterceptor
} from '@angular/common/http';

@Injectable()
export class CacheInterceptor implements HttpInterceptor {
    private defaultTtl = 60;

    constructor(private cache: CacheService) { }

    public intercept(req: HttpRequest<any>, next: HttpHandler) {
        if (!this.isCacheable(req)) {
            this.sendRequest(req, next);
        }

        const cachedResponse = this.cache.get(req.url);
        return cachedResponse ? of(cachedResponse) : this.sendRequest(req, next);
    }

    protected isCacheable(req: HttpRequest<any>): boolean {
        return req.method === 'GET';
    }

    protected sendRequest(
        req: HttpRequest<any>,
        next: HttpHandler
    ): Observable<HttpEvent<any>> {
        return next.handle(req).pipe(
            tap(event => {
                if (event instanceof HttpResponse) {
                    this.cache.set(req.url, event, this.defaultTtl);
                }
            })
        );
    }
}

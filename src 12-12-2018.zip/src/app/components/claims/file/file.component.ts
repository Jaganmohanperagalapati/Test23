import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';

@Component({
    selector: 'kyfb-file-claim',
    templateUrl: './file.component.html',
    styleUrls: ['./file.component.scss']
})
export class FileComponent implements OnInit {
    public policyNumber: string;

    constructor(
        private route: ActivatedRoute
    ) { }

    ngOnInit() {
        this.policyNumber = this.route.snapshot.paramMap.get('policyNumber');
    }

}

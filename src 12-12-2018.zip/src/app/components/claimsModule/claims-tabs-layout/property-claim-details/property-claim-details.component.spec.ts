import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PropertyClaimDetailsComponent } from './property-claim-details.component';

describe('PropertyClaimDetailsComponent', () => {
  let component: PropertyClaimDetailsComponent;
  let fixture: ComponentFixture<PropertyClaimDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PropertyClaimDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PropertyClaimDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

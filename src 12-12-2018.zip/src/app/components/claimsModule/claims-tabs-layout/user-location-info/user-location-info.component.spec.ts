import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserLocationInfoComponent } from './user-location-info.component';

describe('UserLocationInfoComponent', () => {
  let component: UserLocationInfoComponent;
  let fixture: ComponentFixture<UserLocationInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserLocationInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserLocationInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

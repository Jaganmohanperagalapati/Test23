import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { ClaimService } from 'src/app/services/claim.service';

@Component({
  selector: 'kyfb-claims-layout',
  templateUrl: './claims-layout.component.html',
  styleUrls: ['./claims-layout.component.scss']
})
export class ClaimsLayoutComponent implements OnInit {

  constructor(private claimsService: ClaimService,private cdRef : ChangeDetectorRef) { }

  ngOnInit() {
  }


}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportClaimLandingComponent } from './report-claim-landing.component';

describe('ReportClaimLandingComponent', () => {
  let component: ReportClaimLandingComponent;
  let fixture: ComponentFixture<ReportClaimLandingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportClaimLandingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportClaimLandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

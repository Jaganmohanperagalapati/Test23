export class TokenModel {
    constructor(
        public id: string,
        public model: string,
        public created: string,
        public value: string,
        public lifetimeInMinutes: number
    ) {
    }
}

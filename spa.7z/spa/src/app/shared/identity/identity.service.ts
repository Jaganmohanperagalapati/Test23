// import { Injectable } from '@angular/core';
// import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
// import { Observable } from 'rxjs/Observable';

// import { TokenModel } from './token.model';
// import { IdentityModel } from './identity.model';
// import { StorageService } from '../storage/storage.service';
// import { ApiService } from '../api/api.service';

// @Injectable()
// export class IdentityService {
//     constructor(private storage: StorageService, private api: ApiService, private router: Router) {
//     }

//     canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
//         let token = this.storage.getToken();
//         if (token) {
//             return true;
//         }

//         // Redirect to the login page
//         this.router.navigate(['/login']);
//         return false;
//     }

//     login(userName: string, password: string): Observable<IdentityModel> {
//         // Clear any prior sessions
//         this.storage.clear();

//         return this.api.post('/tokens', JSON.stringify({ userName: userName, password: password }))
//             .map(response => {
//                 let data = response.json();
//                 const token = new TokenModel(data.id, data.model, data.created, data.value, data.lifetimeInMinutes);
//                 const identity = data.identity as IdentityModel;

//                 // Put the data into storage
//                 this.storage.setToken(token);
//                 this.storage.setIdentity(identity);

//                 return identity;
//             });
//     }

//     logout(): void {
//         var token = this.storage.getToken();
//         if (token) {
//             let url = `/tokens/${token.id}`;
//             this.api.delete(url).subscribe(); // We don't actually care about the response

//             // Clear any session
//             this.storage.clear();

//             // Redirect to login
//             this.router.navigate(['/login']);
//         }
//     }
// }

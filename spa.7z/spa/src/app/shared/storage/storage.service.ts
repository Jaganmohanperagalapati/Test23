import { Injectable } from '@angular/core';
import { IdentityModel } from '../identity/identity.model';
import { TokenModel } from '../identity/token.model';
import { parse, addMinutes, isBefore } from 'date-fns';

const tokenStorageKey: string = '::token::';
const identityStorageKey: string = '::identity::';

@Injectable()
export class StorageService {

    constructor() {
    }

    getItem(key: string): string {
        // TODO Sometime sessionStorage doesn't exist in Safari Incognito Mode
        return sessionStorage.getItem(key);
    }

    setItem(key: string, data: string): void {
        sessionStorage.setItem(key, data);
    }

    removeItem(key: string): void {
        sessionStorage.removeItem(key);
    }

    clear(): void {
        sessionStorage.clear();
    }

    //
    // Identity
    //

    getIdentity(): IdentityModel {
        let str: string = this.getItem(identityStorageKey);
        if (!str) {
            return null;
        }

        let identity = JSON.parse(str) as IdentityModel;
        return identity;
    }

    setIdentity(identity: IdentityModel): void {
        let str = JSON.stringify(identity);
        this.setItem(identityStorageKey, str);
    }

    //
    // Token
    //

    getToken(): TokenModel {
        let str = this.getItem(tokenStorageKey);
        if (!str) {
            return null;
        }

        let token = JSON.parse(str) as TokenModel;
        let created = parse(token.created);
        let expires = addMinutes(created, token.lifetimeInMinutes);
        if (isBefore(expires, new Date())) {
            // The token has expired.
            // Remove it from storage and return null;
            this.removeItem(tokenStorageKey);
            token = null;
        }

        return token;
    }

    setToken(token: TokenModel): void {
        let str = JSON.stringify(token);
        this.setItem(tokenStorageKey, str);
    }
}

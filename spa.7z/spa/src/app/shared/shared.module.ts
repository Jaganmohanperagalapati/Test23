import { NgModule, ModuleWithProviders } from '@angular/core';
import { HttpClientModule } from '@angular/common/http'
import { ApiService } from './api/api.service';
import { StorageService } from './storage/storage.service';
import { EmployeeService } from '../test/employee.service';
import { SearchCriteriaService } from '../services/search-criteria.service';
import { LdpDataService } from '../services/ldp-data.service';

@NgModule({
    declarations: [],
    imports: [
        HttpClientModule
    ],
    exports: []
})
export class SharedModule {
    public static forRoot(): ModuleWithProviders {
        return {
            ngModule: SharedModule,
            providers: [
                ApiService,
                EmployeeService,
                StorageService,
                SearchCriteriaService,
                LdpDataService
            ]
        };
    }
}

export interface IListingAuctionRun {
    listingId: string;
    startDate: string;
    endDate: string;
}

export interface IAuctionRun {
    number: string;
    name: string;
    method: string;
    startDate: string;
    endDate: string;
    websiteDescription: string;
    listingAuctionRuns: IListingAuctionRun[];
}
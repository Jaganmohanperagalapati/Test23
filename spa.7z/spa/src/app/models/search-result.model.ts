import { IListing } from "./listing.model";

export interface ISearchResult {
    totalCount: number;
    listings: IListing[];
}
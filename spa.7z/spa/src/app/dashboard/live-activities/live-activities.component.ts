import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-live-activities',
  templateUrl: './live-activities.component.html',
  styleUrls: ['./live-activities.component.css']
})
export class LiveActivitiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

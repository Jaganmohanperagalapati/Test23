import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LiveActivitiesComponent } from './live-activities.component';

describe('LiveActivitiesComponent', () => {
  let component: LiveActivitiesComponent;
  let fixture: ComponentFixture<LiveActivitiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LiveActivitiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LiveActivitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardRoutingModule } from './dashboard-routing.module';

import { DashboardComponent } from './dashboard.component';
import { FavoritesComponent } from './favorites/favorites.component';
import { LiveActivitiesComponent } from './live-activities/live-activities.component';
import { AccountComponent } from './account/account.component';

@NgModule({
    imports: [
        CommonModule,
        DashboardRoutingModule
    ],
    declarations: [
        DashboardComponent,
        FavoritesComponent,
        LiveActivitiesComponent,
        AccountComponent
    ]
})
export class DashboardModule { }

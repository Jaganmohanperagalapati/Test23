import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AuctionEventsComponent } from './auction-events.component';

describe('AuctionEventsComponent', () => {
  let component: AuctionEventsComponent;
  let fixture: ComponentFixture<AuctionEventsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AuctionEventsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuctionEventsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

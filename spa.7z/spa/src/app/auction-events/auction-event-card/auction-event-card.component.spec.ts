import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AuctionEventCardComponent } from './auction-event-card.component';

describe('AuctionEventCardComponent', () => {
  let component: AuctionEventCardComponent;
  let fixture: ComponentFixture<AuctionEventCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AuctionEventCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuctionEventCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

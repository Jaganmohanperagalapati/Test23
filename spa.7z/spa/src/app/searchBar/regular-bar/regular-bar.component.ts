///<reference types="@types/googlemaps" />
import { Component, OnInit, NgZone } from '@angular/core';
import {SearchCriteriaService} from "../../services/search-criteria.service";
import { FormGroup, FormControl, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { Router } from "@angular/router";

@Component({
    selector: 'app-regular-bar',
    templateUrl: './regular-bar.component.html',
    styleUrls: ['./regular-bar.component.css']
})
export class RegularBarComponent implements OnInit {
  
  searchForm: FormGroup;
  public addrKeys: string[];
  public addr: object;
  geoCoder=new google.maps.Geocoder();
  constructor(private _fb:FormBuilder,private router:Router,private zone: NgZone,private _searchCriteriaService:SearchCriteriaService) { }
  
  setAddress(addrObj) {
    this.zone.run(() => {
        this.addr = addrObj;
        this.addrKeys = Object.keys(addrObj);
        console.log("addr",this.addr)
        console.log("addrKeys",this.addrKeys)
    });
}
    geoCodeInput(address){
      let search_obj={};
this.geoCoder.geocode({address:address},function(results,status){
    if(status===google.maps.GeocoderStatus.OK){
      const R = results[0];
      search_obj["type"] = R.types[0];
      console.log("r",R)
      console.log("type",search_obj["type"])
      // let stateCode;
      if (R.address_components[0].types[0] == 'administrative_area_level_1') {
        search_obj['stateCode'] = R.address_components[0].short_name;
      } else if (R.address_components[1] && R.address_components[1].types[0] == 'administrative_area_level_1') {
        search_obj['stateCode'] = R.address_components[1].short_name;
      } else if (R.address_components[2] && R.address_components[2].types[0] == 'administrative_area_level_1') {
        search_obj['stateCode'] = R.address_components[2].short_name;
      } else if (R.address_components[3] && R.address_components[3].types[0] == 'administrative_area_level_1') {
        search_obj['stateCode'] = R.address_components[3].short_name;
      } else if (R.address_components[4] && R.address_components[4].types[0] == 'administrative_area_level_1') {
        search_obj['stateCode'] = R.address_components[4].short_name;
      } else if (R.address_components[5] && R.address_components[5].types[0] == 'administrative_area_level_1') {
        search_obj['stateCode'] = R.address_components[5].short_name;
      }
      console.log("state=",search_obj['stateCode']);
      for(let i in R.address_components){
        if(R.address_components[i].types[0]=="postal_code"){
          search_obj['postal_code']=R.address_components[i].short_name;
          console.log("postalCode=",search_obj['postal_code']);
        }
        else{
          console.log("no code")
        }
        
      }
      //extracting the city 
  // let city;
					if (R.address_components.length > 3) {
						for (let i = 0; i < R.address_components.length; i++) {
							if (R.address_components[i].types[0] == 'locality') {
								search_obj["city"] = R.address_components[i].long_name.toLowerCase();
							}
						}
					}

      //extracting the state
    // let street = address
     search_obj["street"] = address
      .toLowerCase()
      .split(' ')
      .join('');
      console.log("street=",search_obj["street"]);

      // Street exception for New York
      if (R.address_components[0].long_name == 'New York' && (search_obj["type"] == 'locality' || search_obj["type"] == 'text')) {
        if (search_obj["street"].includes('city')) {
          console.log('logic for new york city');
          // If they select New York city, then do logic for city
          search_obj["type"] = 'locality';
        } else {
          console.log('NEW YORK STATE');
          // If they select New York state, then create new stateCode using [1].short_name
          search_obj["type"] = 'administrative_area_level_1';
          search_obj['stateCode'] = R.address_components[1].short_name;
        }
      }

      //coordinates
          const latitude = R.geometry.location.lat();
          console.log("lat",latitude)
          const longitude = R.geometry.location.lng();
          console.log("long",longitude)
					const location = new google.maps.LatLng(latitude, longitude);

					const center = {
						lat: latitude,
						lng: longitude
					};
          console.log("loc",location);
          console.log("cen",center)






    }

})
// console.log("sobj",search_obj);
this._searchCriteriaService.setAddressEntity(search_obj);
    }


  ngOnInit() {
    this.searchForm=this._fb.group({
      searchData:""
    })
    
  }

onSearch():void{
  // console.log("sVal="+this.searchForm.controls.searchData.value);
  if(this.searchForm.controls.searchData.value==""){
this.router.navigate(["/properties"])
  }
  else{
    console.log("sVal="+this.searchForm.controls.searchData.value)
    this.geoCodeInput(this.searchForm.controls.searchData.value)
    
  }

    
   
}
}


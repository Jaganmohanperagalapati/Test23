import { Component } from '@angular/core';
import{ NgxSpinnerService} from 'ngx-spinner';
import { LoginComponent } from './Users/login/login.component';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})
export class AppComponent {
    title = 'AuctionSpa';
    constructor(private spinner: NgxSpinnerService) { }

    ngOnInit(){
        /**spinner starts on init */
        this.spinner.show();

        setTimeout(() => {
            /**spinner ends after 3 seconds */
            this.spinner.hide();
        }, 3000);
    }
}

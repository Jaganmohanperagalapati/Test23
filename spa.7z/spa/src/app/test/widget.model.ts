export interface IWidget {
    id: number;
    widgetId: number;
    model: string;
    name: string;
    description: string;
    currentPrice: number;
    startDTTM: string;
    endDTTM: string;
    currentDTTM: string;
}
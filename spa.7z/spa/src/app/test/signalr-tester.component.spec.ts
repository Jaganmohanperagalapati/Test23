import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SignalrTesterComponent } from './signalr-tester.component';

describe('SignalrTesterComponent', () => {
  let component: SignalrTesterComponent;
  let fixture: ComponentFixture<SignalrTesterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SignalrTesterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SignalrTesterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

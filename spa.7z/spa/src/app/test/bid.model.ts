export interface IBid {
    id: number;
    bidTime: string;
    amount: number;
    endTime: string;
    widgetId: number;
    userId: number;
    currentPrice: number;
    currentDTTM: string;
}
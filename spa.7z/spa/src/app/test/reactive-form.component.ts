import { Component, OnInit, NgZone } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators, AbstractControl } from '@angular/forms'
import { EmployeeService } from './employee.service';
import { ApiService } from "../shared/api/api.service";
import { IEmployee } from './employee.model';

@Component({
    selector: 'app-reactive-form',
    templateUrl: './reactive-form.component.html',
    styleUrls: ['./reactive-form.component.css']
})
export class ReactiveFormComponent implements OnInit {
    public employees = [];
    public employees2 = [];
    public employees3 = [];
    employeeForm: FormGroup;
    fullNameLength = 0;
    public addrKeys: string[];
    public addr: object;

    constructor(private _api: ApiService, private _employeeService: EmployeeService, private _fb: FormBuilder, private zone: NgZone) { }

    setAddress(addrObj) {
        console.log("addr",addrObj)
        this.zone.run(() => {
            this.addr = addrObj;
            console.log("adr",this.addr)
            this.addrKeys = Object.keys(addrObj);
            console.log("ak",this.addrKeys)
        });
    }

    // This object will hold the messages to be displayed to the user
    // Notice, each key in this object has the same name as the
    // corresponding form control
    formErrors = {
        'fullName': '',
        'email': '',
        'phone': '',
        'skillName': '',
        'experienceInYears': '',
        'proficiency': ''
    };

    // This object contains all the validation messages for this form
    validationMessages = {
        'fullName': {
            'required': 'Full Name is required.',
            'minlength': 'Full Name must be greater than 2 characters.',
            'maxlength': 'Full Name must be less than 10 characters.'
        },
        'email': {
            'required': 'Email is required.',
            'emailDomain': 'Email domain should be svclnk.com'
        },
        'phone': {
            'required': 'Phone is required.'
        },
        'skillName': {
            'required': 'Skill Name is required.',
        },
        'experienceInYears': {
            'required': 'Experience is required.',
        },
        'proficiency': {
            'required': 'Proficiency is required.',
        },
    };

    async ngOnInit() {
        // this.employeeForm = new FormGroup({
        //     fullName: new FormControl(),
        //     email: new FormControl(),
        //     skills: new FormGroup({
        //         skillName: new FormControl(),
        //         experienceInYears: new FormControl(),
        //         proficiency: new FormControl()
        //     })
        // });

        // Use FormBuilder to reduce code
        this.employeeForm = this._fb.group({
            fullName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(10)]],
            contactPreference: ['email'],
            email: ['', [Validators.required, emailDomain]],
            phone: [''],
            skills: this._fb.group({
                skillName: ['', Validators.required],
                experienceInYears: ['', Validators.required],
                proficiency: ['', Validators.required]
            }),
        });

        // Subscribe to valueChanges observable
        this.employeeForm.get('fullName').valueChanges.subscribe(
            (value: string) => {
                this.fullNameLength = value.length;
            }
        );

        // Subscribe to FormGroup valueChanges observable
        this.employeeForm.valueChanges.subscribe(
            (value: any) => {
                // console.log(JSON.stringify(value));
                this.logValidationErrors(this.employeeForm);
            }
        );

        // Subscribe to nested FormGroup skills
        this.employeeForm.get('skills').valueChanges.subscribe(
            (value: any) => {
                console.log(JSON.stringify(value));
                this.fullNameLength = value.length;
            }
        );

        this.employeeForm.get('contactPreference').valueChanges.subscribe(
            (data: string) => {
                this.onContactPreferenceChange(data);
            }
        );

        this._employeeService.getEmployees().subscribe(data => this.employees = data);
        this.employees2 = await this._employeeService.getEmployeesAsync();
        this.employees3 = await this._api.getEndPoint<IEmployee[]>('/assets/data/employees.json');
    }

    // If the Selected Radio Button value is "phone", then add the
    // required validator function otherwise remove it
    onContactPreferenceChange(selectedValue: string) {
        const phoneFormControl = this.employeeForm.get('phone');
        const emailFormControl = this.employeeForm.get('email');
        if (selectedValue === 'phone') {
            phoneFormControl.setValidators(Validators.required);
            emailFormControl.clearValidators();
        } else {
            emailFormControl.setValidators([Validators.required, emailDomain]);
            phoneFormControl.clearValidators();
        }
        emailFormControl.updateValueAndValidity();
        phoneFormControl.updateValueAndValidity();
    }

    logKeyValuePairs(group: FormGroup): void {
        // loop through each key in the FormGroup
        Object.keys(group.controls).forEach((key: string) => {
            // Get a reference to the control using the FormGroup.get() method
            const abstractControl = group.get(key);
            // If the control is an instance of FormGroup i.e a nested FormGroup
            // then recursively call this same method (logKeyValuePairs) passing it
            // the FormGroup so we can get to the form controls in it
            if (abstractControl instanceof FormGroup) {
                // abstractControl.disable();                
                this.logKeyValuePairs(abstractControl);
                // If the control is not a FormGroup then we know it's a FormControl
            } else {
                console.log('Key = ' + key + ' && Value = ' + abstractControl.value);
                abstractControl.disable();
            }
        });
    }

    logValidationErrors(group: FormGroup = this.employeeForm): void {
        Object.keys(group.controls).forEach((key: string) => {
            const abstractControl = group.get(key);
            if (abstractControl instanceof FormGroup) {
                this.logValidationErrors(abstractControl);
            } else {
                this.formErrors[key] = '';
                if (abstractControl && !abstractControl.valid && (abstractControl.touched || abstractControl.dirty)) {
                    const messages = this.validationMessages[key];

                    for (const errorKey in abstractControl.errors) {
                        if (errorKey) {
                            this.formErrors[key] += messages[errorKey] + ' ';
                        }
                    }
                }
            }
        });
    }

    onLogKeyValuePairsClick(): void {
        // this.logKeyValuePairs(this.employeeForm);
        this.logValidationErrors(this.employeeForm);
        console.log(this.formErrors);
    }

    onLoadDataClick(): void {
        this.employeeForm.setValue({
            fullName: 'Super Man',
            email: 'super.man@svclnk.com',
            skills: {
                skillName: 'C#',
                experienceInYears: 25,
                proficiency: 'advanced'
            }
        });
    }

    onLoadDataPatchClick(): void {
        this.employeeForm.patchValue({
            fullName: 'Bat Man',
            email: 'bat.man@svclnk.com'
        });
    }

    onSubmit(): void {
        console.log('this.employeeForm.value', this.employeeForm.value);
        console.log('this.employeeForm.dirty', this.employeeForm.dirty);
        console.log('this.employeeForm.touched', this.employeeForm.touched);
        console.log('JSON.stringify(this.employeeForm.value)', JSON.stringify(this.employeeForm.value));
        console.log('this.employeeForm.controls.fullName.value', this.employeeForm.controls.fullName.value);
        console.log('this.employeeForm.get("fullName").value', this.employeeForm.get('fullName').value);
        console.log('this.employeeForm.controls.fullName.dirty', this.employeeForm.controls.fullName.dirty);
        console.log('this.employeeForm.controls.fullName.touched', this.employeeForm.controls.fullName.touched);
        console.log('this.employeeForm.controls.fullName.valid', this.employeeForm.controls.fullName.valid);
    }
}

function emailDomain(control: AbstractControl): { [key: string]: any } | null {
    const email: string = control.value;
    const domain = email.substring(email.lastIndexOf('@') + 1);
    if (email === '' || domain.toLowerCase() === 'svclnk.com') {
        return null;
    } else {
        return { 'emailDomain': true };
    }
}
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {
  public next:boolean=false;
  public step2:boolean=true;

  constructor() { }

  ngOnInit() {
  }
  onNext(){
    this.next=true;
    this.step2=false;
  }
  onBack(){
    this.next=false;
    this.step2=true;
  }


}

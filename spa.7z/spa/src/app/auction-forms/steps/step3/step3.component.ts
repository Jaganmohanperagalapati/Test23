import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-step3',
  templateUrl: './step3.component.html',
  styleUrls: ['./step3.component.scss']
})
export class Step3Component implements OnInit {
public showAgentForm:boolean=false;
  constructor() { }

  ngOnInit() {
  }
  
  onAgent(e){
    if(e.target.id=="agentInfo" && e.target.checked){
      console.log("id",e.target.id)
      this.showAgentForm=true;
      console.log("ainfo",this.showAgentForm)
    }
    else if(e.target.id=="noAgent" &&e.target.checked){
      console.log("info",e.target.id)
      this.showAgentForm=false;
      console.log("usInfo",this.showAgentForm)
    }
  }

}

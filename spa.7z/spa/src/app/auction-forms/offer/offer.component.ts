import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offer',
  templateUrl: './offer.component.html',
  styleUrls: ['./offer.component.scss']
})
export class OfferComponent implements OnInit {
  public step1:boolean=true;
  public step2:boolean=false;
  public step3:boolean=false;

  constructor() { }

  ngOnInit() {
  }
  onNextStep(){
    if(this.step1==true){
      this.step2=true;
      this.step1=false;
      this.step3=false;
    }
    else if(this.step2==true){
      this.step3=true;
      this.step2=false;
      this.step1=false
    }
    else if(this.step3==true){
      this.step1=false;
      this.step2=false;

    }

  }

}

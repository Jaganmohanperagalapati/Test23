import { Component, OnInit, Input,AfterViewInit } from '@angular/core';
import { IListing } from '../../models/listing.model';

@Component({
    selector: 'app-listing-card',
    templateUrl: './listing-card.component.html',
    styleUrls: ['./listing-card.component.css']
})
export class ListingCardComponent implements OnInit {
    @Input() listing: IListing;
    public propertyDetailsURL: string;
    public favClicked: boolean = false;
    
    constructor() { 
    }

    ngOnInit() {
        const index = this.listing.websiteURL.lastIndexOf("/");
        const urlPart = this.listing.websiteURL.substring(index + 1);
        this.propertyDetailsURL = `/property-details/${urlPart}`;

    }
    
    onFavorites() {
        this.favClicked = !this.favClicked;
    }
}
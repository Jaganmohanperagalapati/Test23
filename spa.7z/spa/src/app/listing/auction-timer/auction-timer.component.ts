import { Component, OnInit, Input } from '@angular/core';
import { IListing } from '../../models/listing.model';

@Component({
    selector: 'app-auction-timer',
    templateUrl: './auction-timer.component.html',
    styleUrls: ['./auction-timer.component.scss']
})
export class AuctionTimerComponent implements OnInit {
    @Input() listing: IListing;

    constructor() { }

    ngOnInit() {
    }
}

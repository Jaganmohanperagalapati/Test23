import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auction-form',
  templateUrl: './auction-form.component.html',
  styleUrls: ['./auction-form.component.scss']
})
export class AuctionFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

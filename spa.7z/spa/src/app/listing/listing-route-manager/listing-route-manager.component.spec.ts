import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListingRouteManagerComponent } from './listing-route-manager.component';

describe('ListingRouteManagerComponent', () => {
  let component: ListingRouteManagerComponent;
  let fixture: ComponentFixture<ListingRouteManagerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListingRouteManagerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListingRouteManagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

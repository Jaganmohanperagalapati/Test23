import { Component, OnInit, Input } from '@angular/core';
import { ISearchResult } from '../../models/search-result.model';

@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.scss']
})
export class MapComponent implements OnInit {
@Input() searchResult:ISearchResult;
latitude:number=37.090240;
longitude:number=-95.712891;
zoom:number=4;
previous;
markerUrl:string='/assets/images/map-pin-2-copy-5.svg';
  constructor() { }

  ngOnInit() {
    console.log("search",this.searchResult)
  }

  // OnMarkerClick(cardInfoWindow):void{
  //   console.log("info",cardInfoWindow)
  //   if (this.previous) {
  //      this.previous.close();
  //  }
  //  this.previous = cardInfoWindow;  
  //  }
  

  
}

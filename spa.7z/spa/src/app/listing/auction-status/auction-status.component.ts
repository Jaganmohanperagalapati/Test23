import { Component, OnInit, Input } from '@angular/core';
import { IListing } from '../../models/listing.model';

@Component({
    selector: 'app-auction-status',
    templateUrl: './auction-status.component.html',
    styleUrls: ['./auction-status.component.scss']
})
export class AuctionStatusComponent implements OnInit {
    @Input() listing: IListing;

    constructor() { }

    ngOnInit() {
    }

    getListingMethod(): string {
        if (this.listing.auctionProgram == "TPS")
            return "Foreclosure";

        return this.listing.auctionProgram;
    }

    getListingSaleStatus(): string {
        return this.listing.foreclosureSaleStatusWebsite;
    }

    getListingOpeningBid(): number {
        return this.listing.openingBid;
    }

    getListingSaleDate(): string {
        return this.listing.tpsSaleTime;
    }

    getListingSaleLocation(): string {
        return this.listing.tpsSaleLocation;
    }
}

import { Component, OnInit, Input } from '@angular/core';
import { IListing } from '../../../models/listing.model';

@Component({
    selector: 'app-ldp-property-details',
    templateUrl: './ldp-property-details.component.html',
    styleUrls: ['./ldp-property-details.component.scss']
})
export class LdpPropertyDetailsComponent implements OnInit {
    @Input() listing: IListing;

    constructor() { }

    ngOnInit() {
    }
}

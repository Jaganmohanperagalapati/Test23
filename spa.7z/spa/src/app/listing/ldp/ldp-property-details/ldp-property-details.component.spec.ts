import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpPropertyDetailsComponent } from './ldp-property-details.component';

describe('LdpPropertyDetailsComponent', () => {
  let component: LdpPropertyDetailsComponent;
  let fixture: ComponentFixture<LdpPropertyDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpPropertyDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpPropertyDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

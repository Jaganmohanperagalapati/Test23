import { Component, OnInit } from '@angular/core';
import { IListing } from '../../../models/listing.model';
import { LdpDataService } from '../../../services/ldp-data.service';

@Component({
    selector: 'app-ldp-coming-soon',
    templateUrl: './ldp-coming-soon.component.html',
    styleUrls: ['./ldp-coming-soon.component.scss']
})
export class LdpComingSoonComponent implements OnInit {
    listing: IListing;

    constructor(private _ldpDataService: LdpDataService) { }

    ngOnInit() {
        this.listing = this._ldpDataService.getListing();
    }
}

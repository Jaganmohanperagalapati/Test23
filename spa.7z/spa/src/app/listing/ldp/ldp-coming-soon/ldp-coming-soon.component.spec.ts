import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpComingSoonComponent } from './ldp-coming-soon.component';

describe('LdpComingSoonComponent', () => {
  let component: LdpComingSoonComponent;
  let fixture: ComponentFixture<LdpComingSoonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpComingSoonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpComingSoonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

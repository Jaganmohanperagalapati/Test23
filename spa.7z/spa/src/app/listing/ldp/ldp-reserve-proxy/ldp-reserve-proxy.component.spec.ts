import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpReserveProxyComponent } from './ldp-reserve-proxy.component';

describe('LdpReserveProxyComponent', () => {
  let component: LdpReserveProxyComponent;
  let fixture: ComponentFixture<LdpReserveProxyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpReserveProxyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpReserveProxyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ldp-reserve-proxy',
  templateUrl: './ldp-reserve-proxy.component.html',
  styleUrls: ['./ldp-reserve-proxy.component.scss']
})
export class LdpReserveProxyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

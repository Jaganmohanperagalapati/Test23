import { Component, OnInit, ViewChild, ViewContainerRef, ComponentRef, ComponentFactoryResolver } from '@angular/core';
import { IListing } from '../../../models/listing.model';
import { LdpBiddingHistoryComponent } from '../ldp-bidding-history/ldp-bidding-history.component'
import { LdpPropertyDetailsComponent } from '../ldp-property-details/ldp-property-details.component'
import { LdpContactUsComponent } from '../ldp-contact-us/ldp-contact-us.component'
import { LdpDataService } from '../../../services/ldp-data.service';

@Component({
    selector: 'app-ldp-property-tabs',
    templateUrl: './ldp-property-tabs.component.html',
    styleUrls: ['./ldp-property-tabs.component.scss']
})
export class LdpPropertyTabsComponent implements OnInit {
    @ViewChild('activeComponent', { read: ViewContainerRef }) activeComponent;
    listing: IListing;
    cmpRef: ComponentRef<Component>;
    public tabs = ['Bidding History', 'Property Details', 'Contact Us'];
    public activeIndex = 1;

    constructor(private componentFactoryResolver: ComponentFactoryResolver, private _ldpDataService: LdpDataService) { }

    ngOnInit() {
        this.listing = this._ldpDataService.getListing();
        this.onTabClick(1);
    }

    ngOnDestroy() {
        if (this.cmpRef) {
            this.cmpRef.destroy();
        }
    }

    updateActiveComponent(component: any) {
        if (this.cmpRef) {
            this.cmpRef.destroy();
        }

        this.activeComponent.clear();
        const factory = this.componentFactoryResolver.resolveComponentFactory(component);
        this.cmpRef = this.activeComponent.createComponent(factory);
        (<any>this.cmpRef.instance).listing = this.listing;
        console.log(this.cmpRef)
        console.log((<any>this.cmpRef.instance).listing)
    }

    onTabClick(index: number): void {
        this.activeIndex = index;
        let component = LdpPropertyDetailsComponent;
        switch (index) {
            case 0:
                component = LdpBiddingHistoryComponent;
                break;
            case 1:
                component = LdpPropertyDetailsComponent;
                break;
            case 2:
                component = LdpContactUsComponent;
                break;
        }

        this.updateActiveComponent(component);
    }

    displayTestStyles(index: number) {
        let styles = {
            'cursor': 'pointer',
            'font-weight': this.activeIndex === index ? 'bold' : 'normal'
        };
        return styles;
    }
}

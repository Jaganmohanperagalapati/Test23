import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpPropertyTabsComponent } from './ldp-property-tabs.component';

describe('LdpPropertyTabsComponent', () => {
  let component: LdpPropertyTabsComponent;
  let fixture: ComponentFixture<LdpPropertyTabsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpPropertyTabsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpPropertyTabsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ldp-share',
  templateUrl: './ldp-share.component.html',
  styleUrls: ['./ldp-share.component.scss']
})
export class LdpShareComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

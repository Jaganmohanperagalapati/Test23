import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpShareComponent } from './ldp-share.component';

describe('LdpShareComponent', () => {
  let component: LdpShareComponent;
  let fixture: ComponentFixture<LdpShareComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpShareComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpShareComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

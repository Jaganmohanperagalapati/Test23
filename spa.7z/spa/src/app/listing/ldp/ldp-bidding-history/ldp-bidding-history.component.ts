import { Component, OnInit, Input } from '@angular/core';
import { IListing } from '../../../models/listing.model';

@Component({
    selector: 'app-ldp-bidding-history',
    templateUrl: './ldp-bidding-history.component.html',
    styleUrls: ['./ldp-bidding-history.component.scss']
})
export class LdpBiddingHistoryComponent implements OnInit {
    @Input() listing: IListing;

    constructor() { }

    ngOnInit() {
    }
}

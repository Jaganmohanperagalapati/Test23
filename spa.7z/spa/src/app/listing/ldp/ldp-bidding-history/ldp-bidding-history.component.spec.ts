import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpBiddingHistoryComponent } from './ldp-bidding-history.component';

describe('LdpBiddingHistoryComponent', () => {
  let component: LdpBiddingHistoryComponent;
  let fixture: ComponentFixture<LdpBiddingHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpBiddingHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpBiddingHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

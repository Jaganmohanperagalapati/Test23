import { Component, OnInit, Input } from '@angular/core';
import { IListing } from '../../../models/listing.model';

@Component({
    selector: 'app-ldp-contact-us',
    templateUrl: './ldp-contact-us.component.html',
    styleUrls: ['./ldp-contact-us.component.scss']
})
export class LdpContactUsComponent implements OnInit {
    @Input() listing: IListing;

    constructor() { }

    ngOnInit() {
    }
}

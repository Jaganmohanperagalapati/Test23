import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpContactUsComponent } from './ldp-contact-us.component';

describe('LdpContactUsComponent', () => {
  let component: LdpContactUsComponent;
  let fixture: ComponentFixture<LdpContactUsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpContactUsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpContactUsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

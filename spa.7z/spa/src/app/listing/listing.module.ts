import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListingRoutingModule } from './listing-routing.module';
import{AgmCoreModule} from "@agm/core";
import { AgmSnazzyInfoWindowModule } from '@agm/snazzy-info-window';

import { SrpComponent } from './srp/srp.component';
import { LdpComponent } from './ldp/ldp.component';
import { ListingCardComponent } from './listing-card/listing-card.component';
import { ListingRouteManagerComponent } from './listing-route-manager/listing-route-manager.component';
import { LdpHeaderComponent } from './ldp/ldp-header/ldp-header.component';
import { LdpShareComponent } from './ldp/ldp-share/ldp-share.component';
import { LdpReserveProxyComponent } from './ldp/ldp-reserve-proxy/ldp-reserve-proxy.component';
import { ImageGalleryComponent } from './image-gallery/image-gallery.component';
import { LdpComingSoonComponent } from './ldp/ldp-coming-soon/ldp-coming-soon.component';
import { AuctionTimerComponent } from './auction-timer/auction-timer.component';
import { AuctionStatusComponent } from './auction-status/auction-status.component';
import { AuctionFormComponent } from './auction-form/auction-form.component';
import { LdpPropertyIconsComponent } from './ldp/ldp-property-icons/ldp-property-icons.component';
import { LdpMapComponent } from './ldp/ldp-map/ldp-map.component';
import { LdpPropertyTabsComponent } from './ldp/ldp-property-tabs/ldp-property-tabs.component';
import { LdpBiddingHistoryComponent } from './ldp/ldp-bidding-history/ldp-bidding-history.component';
import { LdpPropertyDetailsComponent } from './ldp/ldp-property-details/ldp-property-details.component';
import { LdpContactUsComponent } from './ldp/ldp-contact-us/ldp-contact-us.component';
import { PaginationComponent } from './pagination/pagination.component';
import { BreadcrumbsComponent } from './breadcrumbs/breadcrumbs.component';
import { PaginationBottomComponent } from './pagination-bottom/pagination-bottom.component';
import { MapComponent } from './map/map.component';

@NgModule({
    imports: [
        CommonModule,
        ListingRoutingModule,
        AgmCoreModule.forRoot({
            apiKey:'AIzaSyARw-XELZPGKXVbucz9dDAtqjXKh-uoTME'
        }),
        AgmSnazzyInfoWindowModule
    ],
    declarations: [
        SrpComponent,
        LdpComponent,
        ListingCardComponent,
        ListingRouteManagerComponent,
        LdpHeaderComponent,
        LdpShareComponent,
        LdpReserveProxyComponent,
        ImageGalleryComponent,
        LdpComingSoonComponent,
        AuctionTimerComponent,
        AuctionStatusComponent,
        AuctionFormComponent,
        LdpPropertyIconsComponent,
        LdpMapComponent,
        LdpPropertyTabsComponent,
        LdpBiddingHistoryComponent,
        LdpPropertyDetailsComponent,
        LdpContactUsComponent,
        PaginationComponent,
        BreadcrumbsComponent,
        PaginationBottomComponent,
        MapComponent
    ],
    entryComponents: [
        SrpComponent,
        LdpComponent,
        LdpBiddingHistoryComponent,
        LdpPropertyDetailsComponent,
        LdpContactUsComponent,
        ListingCardComponent

    ]
})
export class ListingModule { }

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgxSpinnerModule } from 'ngx-spinner';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { HttpClientModule } from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { SharedModule } from './shared/shared.module';
import { AppComponent } from './app.component';
import { ReactiveFormComponent } from './test/reactive-form.component';
import { HomeComponent } from './home/home.component';
import { FooterComponent } from './layout/footer/footer.component';
import { QuoteCarouselComponent } from './quote-carousel/quote-carousel.component';
import { NotFoundComponent } from './notfound/not-found.component';
import { GooglePlacesDirective } from './directives/google-places.directive';
import { HeaderComponent } from './layout/header/header.component';
import { SearchBarComponent } from './search-bar/search-bar.component';
import { BuyMenuComponent } from './buy-menu/buy-menu.component';
import { RegularBarComponent } from './searchBar/regular-bar/regular-bar.component';
import { ForeclosureComponent } from './auction-program/foreclosure/foreclosure.component';
import { ShortSaleComponent } from './auction-program/short-sale/short-sale.component';
import { NewlyForeclosedComponent } from './auction-program/newly-foreclosed/newly-foreclosed.component';
import { BankOwnedHomesComponent } from './auction-program/bank-owned-homes/bank-owned-homes.component';
import { BrokerCoopAvailableComponent } from './auction-program/broker-coop-available/broker-coop-available.component';
// import { LoginComponent } from './login/login.component';
import { LoginComponent } from './Users/login/login.component';
import { RegisterComponent } from './Users/register/register.component';
import { AuctionEventsComponent } from './auction-events/auction-events.component';
import { AuctionEventCardComponent } from './auction-events/auction-event-card/auction-event-card.component';
import { from } from 'rxjs';
import { RegistrationComponent } from './auction-forms/registration/registration.component';
import { Step2Component } from './auction-forms/steps/step2/step2.component';
import { Info1Component } from './auction-forms/steps/info1/info1.component';
import { NotificationsComponent } from './layout/notifications/notifications.component';
import { BreadcrumbsComponent } from './layout/breadcrumbs/breadcrumbs.component';
import { MainComponent } from './auction-forms/main/main.component';
import { OfferComponent } from './auction-forms/offer/offer.component';
import { Step1Component } from './auction-forms/steps/step1/step1.component';
import { Step3Component } from './auction-forms/steps/step3/step3.component';
import { Info2Component } from './auction-forms/steps/info2/info2.component';

import { SignalrTesterComponent } from './test/signalr-tester.component';
import { CountdownComponent } from './countdown/countdown.component';

@NgModule({
    declarations: [
        AppComponent,
        ReactiveFormComponent,
        HomeComponent,
        FooterComponent,
        QuoteCarouselComponent,
        NotFoundComponent,
        GooglePlacesDirective,
        HeaderComponent,
        SearchBarComponent,
        BuyMenuComponent,
        RegularBarComponent,
        ForeclosureComponent,
        ShortSaleComponent,
        NewlyForeclosedComponent,
        BankOwnedHomesComponent,
        BrokerCoopAvailableComponent,
        // LoginComponent
        LoginComponent,
        RegisterComponent,
        AuctionEventsComponent,
        AuctionEventCardComponent,
        RegistrationComponent,
        Step2Component,
        Info1Component,
        NotificationsComponent,
        BreadcrumbsComponent,
        MainComponent,
        OfferComponent,
        Step1Component,
        Step3Component,
        Info2Component,
        SignalrTesterComponent,
        CountdownComponent
    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        NgxSpinnerModule,
        SharedModule.forRoot()
    ],
    providers: [],
    bootstrap: [AppComponent]
})
export class AppModule { }

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-foreclosure',
  templateUrl: './foreclosure.component.html',
  styleUrls: ['./foreclosure.component.css']
})
export class ForeclosureComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewlyForeclosedComponent } from './newly-foreclosed.component';

describe('NewlyForeclosedComponent', () => {
  let component: NewlyForeclosedComponent;
  let fixture: ComponentFixture<NewlyForeclosedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewlyForeclosedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewlyForeclosedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newly-foreclosed',
  templateUrl: './newly-foreclosed.component.html',
  styleUrls: ['./newly-foreclosed.component.css']
})
export class NewlyForeclosedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

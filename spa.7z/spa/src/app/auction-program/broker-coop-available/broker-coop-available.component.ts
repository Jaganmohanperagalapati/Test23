import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-broker-coop-available',
  templateUrl: './broker-coop-available.component.html',
  styleUrls: ['./broker-coop-available.component.css']
})
export class BrokerCoopAvailableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

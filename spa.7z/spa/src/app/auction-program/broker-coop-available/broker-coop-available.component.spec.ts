import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BrokerCoopAvailableComponent } from './broker-coop-available.component';

describe('BrokerCoopAvailableComponent', () => {
  let component: BrokerCoopAvailableComponent;
  let fixture: ComponentFixture<BrokerCoopAvailableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BrokerCoopAvailableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BrokerCoopAvailableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

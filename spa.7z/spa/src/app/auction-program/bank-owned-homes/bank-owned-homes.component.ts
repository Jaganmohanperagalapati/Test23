import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bank-owned-homes',
  templateUrl: './bank-owned-homes.component.html',
  styleUrls: ['./bank-owned-homes.component.css']
})
export class BankOwnedHomesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

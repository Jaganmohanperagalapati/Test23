import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankOwnedHomesComponent } from './bank-owned-homes.component';

describe('BankOwnedHomesComponent', () => {
  let component: BankOwnedHomesComponent;
  let fixture: ComponentFixture<BankOwnedHomesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankOwnedHomesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankOwnedHomesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

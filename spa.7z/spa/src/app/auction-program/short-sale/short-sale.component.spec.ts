import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShortSaleComponent } from './short-sale.component';

describe('ShortSaleComponent', () => {
  let component: ShortSaleComponent;
  let fixture: ComponentFixture<ShortSaleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShortSaleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShortSaleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-short-sale',
  templateUrl: './short-sale.component.html',
  styleUrls: ['./short-sale.component.css']
})
export class ShortSaleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

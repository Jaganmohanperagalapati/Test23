import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { NotFoundComponent } from './notfound/not-found.component';
import { ReactiveFormComponent } from './test/reactive-form.component';
import { ForeclosureComponent } from "./auction-program/foreclosure/foreclosure.component";
import { SignalrTesterComponent } from './test/signalr-tester.component';
import { AuctionEventsComponent } from './auction-events/auction-events.component';
// import { LoginComponent } from './login/login.component';

const routes: Routes = [
    // { path: 'login', component: LoginComponent },
    // { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: '', component: HomeComponent },
    { path: 'content', loadChildren: './content/content.module#ContentModule' },
    { path: 'properties', loadChildren: './listing/listing.module#ListingModule' },
    { path: 'property-details', loadChildren: './listing/listing.module#ListingModule' },
    { path: 'foreclosures', loadChildren: './listing/listing.module#ListingModule' },
    { path: 'short-sale-properties', loadChildren: './listing/listing.module#ListingModule' },
    { path: 'occupied', loadChildren: './listing/listing.module#ListingModule' },
    { path: 'retail-properties', loadChildren: './listing/listing.module#ListingModule' },
    { path: 'dashboard', loadChildren: './dashboard/dashboard.module#DashboardModule' },
    { path: 'test', component: ReactiveFormComponent },
    { path: 'signalr', component: SignalrTesterComponent },
    { path: "foreclosures", component: ForeclosureComponent },
    { path: "upcoming-auctions", component: AuctionEventsComponent },
    { path: '**', component: NotFoundComponent }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }

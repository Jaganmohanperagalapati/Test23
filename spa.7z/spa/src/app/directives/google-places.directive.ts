/// <reference types="@types/googlemaps" />
import { Directive, ElementRef, OnInit, Output, EventEmitter } from '@angular/core';

@Directive({
    selector: '[google-place]'
})
export class GooglePlacesDirective implements OnInit {
    @Output() onSelect: EventEmitter<any> = new EventEmitter();
    private element: HTMLInputElement;
    geoCoder=new google.maps.Geocoder();
    constructor(elRef: ElementRef) {
        this.element = elRef.nativeElement;
    }

    getFormattedAddress(place) {
        console.log("pl",place)
        let location_obj = {};
        for (let i in place.address_components) {
            let item = place.address_components[i];
            console.log("it",item)
            location_obj['formatted_address'] = place.formatted_address;
            if (item['types'].indexOf("locality") > -1) {
                location_obj['locality'] = item['long_name']
            } else if (item['types'].indexOf("administrative_area_level_1") > -1) {
                location_obj['admin_area_l1'] = item['short_name']
            } else if (item['types'].indexOf("street_number") > -1) {
                location_obj['street_number'] = item['short_name']
            } else if (item['types'].indexOf("route") > -1) {
                location_obj['route'] = item['long_name']
            } else if (item['types'].indexOf("country") > -1) {
                location_obj['country'] = item['long_name']
            } else if (item['types'].indexOf("postal_code") > -1) {
                location_obj['postal_code'] = item['short_name']
            }
        }

        console.log("mo",location_obj)
        return location_obj;
        
    }

//     geoCodeInput(address){
// this.geoCoder.geocode({address:address},function(results,status){
//     if(status===google.maps.GeocoderStatus.OK){
//         console.log("res",results[0])
//         // console.log()
//     }

// })

//     }

    ngOnInit() {
        const autocomplete = new google.maps.places.Autocomplete(this.element, {
            types: ['(regions)'],
            componentRestrictions: { country: 'us' },
        });
        google.maps.event.addListener(autocomplete, 'place_changed', () => {
            this.onSelect.emit(this.getFormattedAddress(autocomplete.getPlace()));
            // this.onSelect.emit(this.geoCodeInput(autocomplete.getPlace()));
        });
    }
}
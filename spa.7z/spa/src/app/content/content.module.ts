import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContentRoutingModule } from './content-routing.module';

import { ContactUsComponent } from './contact-us/contact-us.component';
import { HowToBidComponent } from './how-to-bid/how-to-bid.component';
import { FinancingComponent } from './financing/financing.component';
import { AboutComponent } from './about/about.component';
import { PrivacyComponent } from './privacy/privacy.component';
import { TermsComponent } from './terms/terms.component';

@NgModule({
    imports: [
        CommonModule,
        ContentRoutingModule
    ],
    declarations: [
        ContactUsComponent,
        HowToBidComponent,
        FinancingComponent,
        AboutComponent,
        PrivacyComponent,
        TermsComponent,
    ]
})
export class ContentModule { }

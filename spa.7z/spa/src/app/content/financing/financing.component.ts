import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-financing',
  templateUrl: './financing.component.html',
  styleUrls: ['./financing.component.css']
})
export class FinancingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

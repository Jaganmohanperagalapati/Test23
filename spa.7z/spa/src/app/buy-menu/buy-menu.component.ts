import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buy-menu',
  templateUrl: './buy-menu.component.html',
  styleUrls: ['./buy-menu.component.css']
})
export class BuyMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
onForeclosure():void{
  
}
}

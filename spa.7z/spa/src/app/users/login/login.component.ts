import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { IdentityModel } from '../../shared/identity/identity.model';
//import { IdentityService } from '../../shared/identity/identity.service'

class LoginModel {
    userName: string = '';
    password: string = '';
}

@Component({
    selector: 'login-cmp',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
    model = new LoginModel();
    invalidCredentials = false;
    networkError = false;

    constructor(private router: Router) {
    }

    ngOnInit() {
    }

    //   onSubmit() {
    //     // Reset
    //     this.invalidCredentials = false;
    //     this.networkError = false;

    //     this.identityService.login(this.model.userName, this.model.password)
    //       .subscribe(identity => {
    //         // Authenticated
    //         this.router.navigate(['/vendors']);
    //       }, err => {
    //         let response = err as Response;
    //         if (response.status === 401) {
    //           this.invalidCredentials = true;
    //         } else {
    //           this.networkError = true;
    //         }
    //       });
    //   }
}

import { JsonObject, JsonProperty } from 'json2typescript';
import * as _ from 'lodash';

@JsonObject('Agent')
export class Agent {
    @JsonProperty('number', Number)
    number: number = null;
    @JsonProperty('agencyBranchNumber', Number)
    agencyBranchNumber: number = null;
    @JsonProperty('agencyName', String)
    agencyName: string = null;
    @JsonProperty('agencyMisc', [Object], true)
    agencyMisc: object[] = [];
    @JsonProperty('firstName', String)
    firstName: string = null;
    @JsonProperty('agencyPhoto', String)
    agencyPhoto: string = null;
    @JsonProperty('email', String)
    email: string = null;
    @JsonProperty('faceBookURL', String)
    facebookUrl: string = null;
    @JsonProperty('agencyAddress', [Object])
    agencyAddress: object[] = [];
    @JsonProperty('url', String)
    url: string = null;
    @JsonProperty('agencyPhone', [Object])
    agencyPhone: object[] = [];
    @JsonProperty('role', String)
    role: string = null;
    @JsonProperty('contractDate', String)
    contractDate: string = null;
    @JsonProperty('sfbNumber', Number)
    sfbNumber: number = null;
    @JsonProperty('agencyHours', [Object])
    agencyHours: object[] = [];
    @JsonProperty('prefName', String)
    prefName: string = null;
    @JsonProperty('lastName', String)
    lastName: string = null;
    @JsonProperty('countyName', String)
    countyName: string = null;
    @JsonProperty('userName', String)
    userName: string = null;
    @JsonProperty('error', String)
    error: string = null;
    @JsonProperty('photo', String)
    photo: string = null;
    @JsonProperty('agencyNumber', Number)
    agencyNumber: number = null;
    @JsonProperty('agencyURL', String)
    agencyUrl: string = null;
    @JsonProperty('designators', String, true)
    designators?: string = null;

    getPhoneNumber(type = 'Main'): string {
        const phone = _.find(this.agencyPhone, { 'type': type });
        return phone ? (<any>phone).number : '';
    }
}

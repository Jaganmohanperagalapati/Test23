import { Component, OnInit, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';


@Component({
  selector: 'kyfb-report-type-auto',
  templateUrl: './report-type-auto.component.html',
  styleUrls: ['./report-type-auto.component.scss']
})
export class ReportTypeAutoComponent implements OnInit {
  reportModalRef: BsModalRef;
  public claimType: any;
  public submitted: boolean = false;
  selectedPolicyDetails: {
    policyNumber: number,
    type: string,
    dueDate: string
  };

  constructor(private router:Router, private modalService: BsModalService) { }

  ngOnInit() {
    this.selectedPolicyDetails = JSON.parse(localStorage.getItem('selectedPolicy'));
  }

  goToNext(){
   
    console.log(this.claimType);
    this.submitted = true;
    if (this.claimType) {
      this.router.navigate(['/claims/claims-tabs/user-location-info']);
    }
  }

  openModalConfirmation(template2:  TemplateRef<any>){
    this.reportModalRef = this.modalService.show(template2);
  }

  goBackToDashboard(template2:  TemplateRef<any>){
    this.reportModalRef.hide();
    this.router.navigate(['/claims']);
  }

}

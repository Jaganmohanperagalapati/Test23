import { Component, OnInit } from '@angular/core';
import { ClaimService } from '../../services/claim.service';
import { ClaimInformation } from '../../kyfb/claim-information';

@Component({
    selector: 'kyfb-claims',
    templateUrl: './claims.component.html',
    styleUrls: ['./claims.component.scss']
})
export class ClaimsComponent implements OnInit {
    claimInformation?: ClaimInformation;

    constructor(private claimService: ClaimService) { }

    ngOnInit() {
        this.claimService.getClaimInformation().subscribe(claimInformation => this.claimInformation = claimInformation);
    }

}

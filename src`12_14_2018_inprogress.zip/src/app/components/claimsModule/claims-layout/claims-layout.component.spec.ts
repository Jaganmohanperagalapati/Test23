import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimsLayoutComponent } from './claims-layout.component';

describe('ClaimsLayoutComponent', () => {
  let component: ClaimsLayoutComponent;
  let fixture: ComponentFixture<ClaimsLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClaimsLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimsLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

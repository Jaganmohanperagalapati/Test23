import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ClaimService } from 'src/app/services/claim.service';




@Component({
  selector: 'kyfb-auto-claim-details',
  templateUrl: './auto-claim-details.component.html',
  styleUrls: ['./auto-claim-details.component.scss']
})
export class AutoClaimDetailsComponent implements OnInit {
  selectedPolicyData: any[] = [];
 
  vehicleInfoData: any[];
  selectedVehicle : string ='';
  vehicleInfo: any;
  formSubmitted: boolean = false;
  selectedVehicleInvolved: string = '';
  vehiclesInvolved: any[] =[];
  constructor(private claimService: ClaimService,private router:Router) { }

  ngOnInit() {
  }
 


  getDetailsInfo(){
    console.log("hello sriiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
      
    this.claimService.getPolicyInfo().subscribe((pol) => {
      this.vehicleInfo = pol.contactNameNumbersDTOList;
      console.log("hiiiiiiiiiiii");
      console.log(pol.contactNameNumbersDTOList)
    }, 
    error => {
      console.log("Failed");
    } 
    );
  }


  goToPrevious(){
    this.router.navigate(['/claims/claims-tabs/user-location-info']);
  }

  goToNext(isValid){
    this.formSubmitted = true;
    console.log(isValid);
   
    this.router.navigate(['/claims/claims-tabs/contact-info']);
 



  }










  // getPolicyDetailsInfo(){
  //   this.claimService.getPolicyInfoData(this.selectedPolicyData['policyNumber']).subscribe((policy) =>
  //   {
  //      this.contactInfoData = policy.contactNameNumbersDTOList;
  //      if(this.contactInfoData) {
  //       this.selectedVehicle = this.contactInfoData[0].clientReferenceNo;
  //       this.prepareContactNumbers();
  //      }
  //   },    
  //   error => { }
  //   );
  // }


  getVehicleDetailsInfo(){
    this.claimService.getPolicyInfoData(this.selectedPolicyData['policyNumber']).subscribe((veh) =>
    {
      this.vehicleInfoData = veh.vehicleInfoDTOList;
      if(this.vehicleInfoData){
        this.selectedVehicle  = this.vehicleInfoData [0].clientReferenceNo;
        this. prepareVehicleInvolved();
      }
    },
    error => { }
    );
  }

  // prepareContactNumbers() {
  //   this.contactNumbers = [];
  //   const index = this.contactInfoData.findIndex(c => c.clientReferenceNo==this.selectedVehicle);
  //   if (index >= 0) {
  //     if (this.contactInfoData[index].workPhoneNumber) {
  //       this.contactNumbers.push({"label": `Work: ${this.contactInfoData[index].workPhoneNumber}`});
  //     }
  //     if (this.contactInfoData[index].cellPhoneNumber) {
  //       this.contactNumbers.push({"label": `Cell: ${this.contactInfoData[index].cellPhoneNumber}`});
  //     }
  //     if (this.contactInfoData[index].homePhoneNumber) {
  //       this.contactNumbers.push({"label": `Home: ${this.contactInfoData[index].homePhoneNumber}`});
  //     }  
  //   }
  //   if(this.selectedVehicle === 'other') {
  //     this.selectedContactNumber = 'other';
  //   }
  // }

  prepareVehicleInvolved(){
    this.vehiclesInvolved = [];
    const index = this.vehicleInfoData.findIndex(c => c.clientReferenceNo==this.selectedVehicle);

    if (index >= 0) {
      if(this.vehicleInfoData[index].vehicleDesc){
        this.vehiclesInvolved.push(this.vehicleInfoData[index].vehicleDesc);
      }
    }
    if(this.selectedVehicle =='other'){
      this. selectedVehicleInvolved ='other';
    }

  }



}

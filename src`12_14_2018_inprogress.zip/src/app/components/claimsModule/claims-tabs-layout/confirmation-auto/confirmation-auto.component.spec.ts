import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmationAutoComponent } from './confirmation-auto.component';

describe('ConfirmationAutoComponent', () => {
  let component: ConfirmationAutoComponent;
  let fixture: ComponentFixture<ConfirmationAutoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfirmationAutoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmationAutoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { StorageService } from '../../shared/storage/storage.service';
import { ShareDataService } from "../../services/share-data/share-data.service";

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html'
})
export class NotificationsComponent implements OnInit {
  public isLoggedIn = false;
  public loginObj:any;
  private auctionProgramValue;

  constructor(private storageService: StorageService,private _shareData: ShareDataService) {
    this.storageService.loginSession$.subscribe((data) => {
      this.loginObj=data;
      this.isLoggedIn = data.isLoggedIn;
    }
    );
  }

  ngOnInit() {
  }
  logOut(){
    this.loginObj.isLoggedIn=false;
    this.storageService.loginSession(this.loginObj);
  }
  onAuctionProgramChange(e): void {
    console.log("drop event:", e.target.innerText)
    let listingObject={};
    if(e.target.innerText=="All Homes for Sale"){
        this.auctionProgramValue=e.target.innerText;
        console.log("");
    }
    else if(e.target.innerText=="Bank-Owned Homes"){
        console.log("auctionProgram")
        listingObject["auctionProgram"]=e.target.innerText;
        this.auctionProgramValue=e.target.innerText;
    }
    else if(e.target.innerText=="Foreclosures"){
        console.log("auctionProgram");
        listingObject["auctionProgram"]=e.target.innerText;
        this.auctionProgramValue=e.target.innerText;
    }
    else if(e.target.innerText=="Newly Foreclosed"){
        console.log("auctionProgram");
        listingObject["auctionProgram"]=e.target.innerText;
        this.auctionProgramValue=e.target.innerText;
    }
    else if(e.target.innerText=="Banker Co-op Available"){
        console.log("show Only");
        listingObject["showOnly"]=e.target.innerText;
        this.auctionProgramValue=e.target.innerText;
    }
    else if(e.target.innerText=="Short Sale"){
        listingObject["auctionProgram"]=e.target.innerText;
        this.auctionProgramValue=e.target.innerText;
    }

    // this.dropDownValue = e.target.innerText;
    console.log("listing Object",listingObject);
    this._shareData.getFilterResp(listingObject);
    this._shareData.changeAuctionProgram2(this.auctionProgramValue)


}
}

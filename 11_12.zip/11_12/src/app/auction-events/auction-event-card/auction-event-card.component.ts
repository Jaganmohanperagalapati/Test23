import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { IAuctionRun } from '../../models/auction-run.model';
import { ExportService } from 'src/app/services/export.service';
import * as moment from "moment";

@Component({
    selector: 'app-auction-event-card',
    templateUrl: './auction-event-card.component.html',
    styleUrls: ['./auction-event-card.component.scss']
})
export class AuctionEventCardComponent implements OnInit {
    @Input() auctionRun: IAuctionRun;
    constructor(private _router: Router, private _exportService: ExportService) { }

    ngOnInit() {
    }

    onViewAllClick(auctionNumber: string): void {
        this._router.navigate([`/upcoming-auctions/${this.auctionRun.auctionNumber}`]);
    }

    //FIXME - update missing fields once service is updated
    onDownloadResults(auctionRun: IAuctionRun): void {
        var itemsFormatted = [];
        auctionRun.listings.forEach((item) => {
            itemsFormatted.push({
                auctionProgram: item.listingProgramWebsite ? item.listingProgramWebsite : "",
                address: item.propertyInfo.address ? item.propertyInfo.address : "",
                city: item.propertyInfo.city ? item.propertyInfo.city : "",
                state: item.propertyInfo.state ? item.propertyInfo.state : "",
                zip: item.propertyInfo.postalCode ? item.propertyInfo.postalCode : "",
                county: item.propertyInfo.county ? item.propertyInfo.county : "",
                propertyType: item.propertyInfo.propertyType ? item.propertyInfo.propertyType : "",
                bedrooms: item.propertyInfo.bedrooms ? item.propertyInfo.bedrooms : "",
                bathrooms: item.propertyInfo.fullBathrooms ? item.propertyInfo.fullBathrooms : "",
                squareFeet: item.propertyInfo.interiorSqFt ? item.propertyInfo.interiorSqFt : "",
                lotSizeValue: item.propertyInfo.lotSize ? item.propertyInfo.lotSize : "",
                lotSizeType: item.propertyInfo.lotSizeAcreageDescription ? item.propertyInfo.lotSizeAcreageDescription : "",
                yearBuilt: item.propertyInfo.yearBuilt ? item.propertyInfo.yearBuilt : "",
                occupancyStatus: item.propertyInfo.occupancyStatus ? item.propertyInfo.occupancyStatus : "",
                preAuctionStartDate: "",
                preAuctionEndDate: "",
                // preAuctionStartDate: (item.auctionRunInfo && item.auctionRunInfo.preAuctionStartDate) ? item.auctionRunInfo.preAuctionStartDate : "",
                // preAuctionEndDate: (item.auctionRunInfo && item.auctionRunInfo.preAuctionEndDate) ? item.auctionRunInfo.preAuctionEndDate : "",
                auctionStartDate: (item.auctionRunInfo && item.auctionRunInfo.startDate) ? moment(item.auctionRunInfo.startDate).format('MM/DD/YYYY h:mm A') : "",
                auctionEndDate: (item.auctionRunInfo && item.auctionRunInfo.endDate) ? moment(item.auctionRunInfo.endDate).format('MM/DD/YYYY h:mm A') : "",
                foreclosureSaleStatus: item.foreclosureSaleStatus ? item.foreclosureSaleStatus : "",
                foreclosureSaleDate: item.foreclosureSaleDate ? moment(item.foreclosureSaleDate).format('MM/DD/YYYY') : "",
                // listingAgent: (item.auctionRunInfo && item.auctionRunInfo.listingAgent) ? item.auctionRunInfo.listingAgent : "",
                // agentEmail: (item.auctionRunInfo && item.auctionRunInfo.agentEmail) ? item.auctionRunInfo.agentEmail : "",
                // agentPhone: (item.auctionRunInfo && item.auctionRunInfo.agentPhone) ? item.auctionRunInfo.agentPhone : "",
                // brokerCoopPercent: (item.auctionRunInfo && item.auctionRunInfo.brokerCoopPercent) ? item.auctionRunInfo.brokerCoopPercent : "",
                listingAgent: "",
                agentEmail: "",
                agentPhone: "",
                brokerCoopPercent: "",
                websiteUrl: item.propertyInfo.websiteUrl ? item.propertyInfo.websiteUrl : ""
            });
        });
        this._exportService.exportCSVFile(this._exportService.getDefaultHeader(), itemsFormatted, 'SearchResults');
    }
}
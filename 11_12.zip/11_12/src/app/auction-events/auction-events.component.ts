import { Component, OnInit } from '@angular/core';
import { ApiService } from '../shared/api/api.service';
import { IAuctionRun } from '../models/auction-run.model';
import { IAuctionRunResult } from '../models/auction-run-result.model';

@Component({
    selector: 'app-auction-events',
    templateUrl: './auction-events.component.html',
    styleUrls: ['./auction-events.component.scss']
})
export class AuctionEventsComponent implements OnInit {
    public auctionRuns: IAuctionRun[];
    public isEndingSoonestSort: boolean;

    constructor(private _api: ApiService) { }

    async ngOnInit() {
        this.isEndingSoonestSort = true;

        //FIXME - update URL once gateway configured
        const result = await this._api.getEndPoint<IAuctionRunResult>('https://auctionrunsvc-s1-v1.dev.exostechnology.local/api/v1/auctionruns?limit=100', true);
        this.auctionRuns = result.data;
    }

    onEndingSoonestClick(): void {
        this.isEndingSoonestSort = true;
        this.auctionRuns = this.auctionRuns.sort((a1, a2) => new Date(a1.endDate).getTime() - new Date(a2.endDate).getTime());
    }

    onEndingLatestClick(): void {
        this.isEndingSoonestSort = false;
        this.auctionRuns = this.auctionRuns.sort((a1, a2) => new Date(a2.endDate).getTime() - new Date(a1.endDate).getTime());
    }
}
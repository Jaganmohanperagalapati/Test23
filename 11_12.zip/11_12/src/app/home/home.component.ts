import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute, Params } from '@angular/router';


@Component({ 
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
public isCheckHome;
  constructor(private router: Router, private activatedRoute: ActivatedRoute) {}

  ngOnInit() {
    this.isCheckHome=this.isHome(this.activatedRoute.snapshot.url.length);
    //console.log('this.isHome(this.activatedRoute.snapshot.url.length)', this.isCheckHome);
  }


isHome(isLength){
if(isLength ==0){
return false;
}else{
return true;
}
}
}

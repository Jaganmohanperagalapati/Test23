import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-alerts',
  templateUrl: './dashboard-alerts.component.html',
  styleUrls: ['./dashboard-alerts.component.scss']
})
export class DashboardAlertsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

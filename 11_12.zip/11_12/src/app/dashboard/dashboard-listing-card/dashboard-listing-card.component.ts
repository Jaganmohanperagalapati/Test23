import { Component, OnInit, Input } from '@angular/core';
import { IListingView } from '../../models/listing-view.model';
import { ApiService } from "../../shared/api/api.service";
import { CountdownService } from '../../services/countdown.service';

@Component({
    selector: 'app-dashboard-listing-card',
    templateUrl: './dashboard-listing-card.component.html',
    styleUrls: ['./dashboard-listing-card.component.scss']
})
export class DashboardListingCardComponent implements OnInit {
    @Input() listingView: IListingView;

    constructor(private _api: ApiService, private _countdownService: CountdownService) { }

    ngOnInit() { }

    async onSubmitBidClick() {
        this._countdownService.handleOnSubmitBidClick(this.listingView);
    }

    async onCountdownComplete() {
        this._countdownService.handleOnCountdownComplete(this.listingView);
    }

    isUserPartOfBidding(): boolean {
        return this._countdownService.isUserPartOfBidding(this.listingView);
    }

    isUserHighestBidder(): boolean {
        return this._countdownService.isUserHighestBidder(this.listingView);
    }

    isAuctionEnded(): boolean {
        return this._countdownService.isAuctionEnded(this.listingView);
    }
}
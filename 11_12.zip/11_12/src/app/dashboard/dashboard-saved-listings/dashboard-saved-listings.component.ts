import { Component, OnInit } from '@angular/core';
import { CountdownService } from '../../services/countdown.service';
import { IListingView } from '../../models/listing-view.model';

@Component({
    selector: 'app-dashboard-saved-listings',
    templateUrl: './dashboard-saved-listings.component.html',
    styleUrls: ['./dashboard-saved-listings.component.scss']
})
export class DashboardSavedListingsComponent implements OnInit {
    listingViews: IListingView[];

    constructor(private _countdownService: CountdownService) {
    }

    ngOnInit() {
        this.listingViews = this._countdownService.getListingViews();
    }
}
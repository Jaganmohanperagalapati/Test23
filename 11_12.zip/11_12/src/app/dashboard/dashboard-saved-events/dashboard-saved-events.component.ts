import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-saved-events',
  templateUrl: './dashboard-saved-events.component.html',
  styleUrls: ['./dashboard-saved-events.component.scss']
})
export class DashboardSavedEventsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

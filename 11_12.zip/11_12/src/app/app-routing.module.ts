import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { NotFoundComponent } from './notfound/not-found.component';
import { ReactiveFormComponent } from './test/reactive-form.component';
import { AccountComponent } from './account/account.component';
import { AuctionEventsComponent } from './auction-events/auction-events.component';
// import { LoginComponent } from './login/login.component';

const routes: Routes = [
    // { path: 'login', component: LoginComponent, data:{title:"Log in to Servicelink Auction | Hudson and Marshall", description:"Log in to your account to get personalized property recommendations from Servicelink Auction. Find and save your favorite properties to your watchlist."} },
    // { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: '', component: HomeComponent, data: { title: "Home Auctions |Real Estate Auctions | Service Link Auction", description: 'Service Link Auctions the easy way to find and buy Home auctions. Browse thounds of properties through our secure online real estate auctions. Find your perfect property today!' } },
    { path: 'content', loadChildren: './content/content.module#ContentModule' },
    { path: 'properties', loadChildren: './listing/listing.module#ListingModule' },
    { path: 'property-details', loadChildren: './listing/listing.module#ListingModule' },
    { path: 'foreclosures', loadChildren: './listing/listing.module#ListingModule', data: { title: "Foreclosed Homes For Sale - Foreclosure Listings | Hudson & Marshall ", description: "Find foreclosed homes for sale. Visit our foreclosures resource center to find out more about foreclosures and newly foreclosed homes in your area." } },
    { path: 'short-sale-properties', loadChildren: './listing/listing.module#ListingModule' },
    { path: 'occupied', loadChildren: './listing/listing.module#ListingModule', data: { title: "Buying Tenant Occupied Property | Hudson and Marshall", description: "Occupied properties are bank owned properties but are not vacant when they are offered for sale. These properties provide an excellent opportunity to earn additional income." } },
    { path: 'retail-properties', loadChildren: './listing/listing.module#ListingModule', data: { title: "Retail Property for Sale | Hudson and Marshall", description: "Retail property listings will be added shortly. Sign up to be the first to receive updates about our retail property listings." } },
    { path: 'upcoming-auctions/:id', loadChildren: './listing/listing.module#ListingModule' },
    { path: 'dashboard', loadChildren: './dashboard/dashboard.module#DashboardModule' },
    { path: 'test', component: ReactiveFormComponent },
    { path: "upcoming-auctions", component: AuctionEventsComponent, data: { title: "Upcoming Property Auctions | Auction Calendar | Hudson & Marshall ", description: "Real estate auction calendar. View the calendar of upcoming property auctions, foreclosure and bank-owned auctions. Sign up and bid now!" } },
    { path: "account", component: AccountComponent },
    { path: '**', component: NotFoundComponent }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
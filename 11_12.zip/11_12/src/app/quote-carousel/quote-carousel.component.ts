import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quote-carousel',
  templateUrl: './quote-carousel.component.html',
  styleUrls: ['./quote-carousel.component.css']
})
export class QuoteCarouselComponent implements OnInit {
   quotes = [
    {
      quote:
        "ServiceLink Auction's communication excels in facilitating information in all aspects of the transaction, they make it a seamless process from start to finish.",
      author: 'Luis Gonzalez',
      occupation: 'Home Investor',
    },
    {
      quote:
        'I would rate my experience working with ServiceLink Auction a 10 out of 10.',
      author: 'Jason Sirounis',
      occupation: 'Real Estate Agent',
    },
    {
      quote:
        'ServiceLink Auction provides everything I need to sell at market value, clear communication and transparent offer management every step along the way.',
      author: 'Robert Jayne',
      occupation: 'Home Seller',
    },
    {
      quote:
        'I really loved the upfront disclosures. The process was smooth and stress free. I love ServiceLink Auction! Thank you!',
      author: 'Jennifer Longmore',
      occupation: 'Buyer',
    },
  ];

  constructor() { }

  ngOnInit() {
  }

}

import { IAuctionRun } from "./auction-run.model";

export interface IAuctionRunResult {
    searchResultCount: number;
    model: string,
    continuationToken: string;
    data: IAuctionRun[];
}
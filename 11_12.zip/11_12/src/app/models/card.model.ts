export interface CardModel {
    method: string;
    propertyInfo:string;
    url: string;
}
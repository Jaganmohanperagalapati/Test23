export interface IPropertyMedia{
    model:string;
    mediaUrl:string;
    thumbnailUrl:string;
    url:string;
    externalLink:string;
    title:string;
    tags:string;
}
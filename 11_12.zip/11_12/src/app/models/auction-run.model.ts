import { IListing } from "./listing.model";

export interface IAuctionRun {
    id: string;
    model: string;
    awxId: string;
    auctionName: string;
    auctionNumber: string;
    auctionProgram: string;
    auctionMethod: string;
    websiteDescription: string;
    websiteName: string;
    startDate: string;
    endDate: any;
    earnestMoneyDepositPercentage: number;
    earnestMoneyDepositMin: number;
    startingBid: number;
    coopComissionMinimum: number;
    coopComissionPercentage: number;
    buyersPremiumPercentage: number;
    buyersPremiumMinimum: number;
    termsAndConditions: string;
    listings: IListing[];
}
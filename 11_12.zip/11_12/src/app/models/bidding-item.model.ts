export interface Category {
    id: number;
    name: string;
    displayOrder: number;
    mvcAction: string;
    type: string;
    enabledCustomProperty: string;
}

export interface PrimaryCategory {
    id: number;
    name: string;
    parentCategoryID: number;
    displayOrder: number;
    mvcAction: string;
    type: string;
    enabledCustomProperty: string;
}

export interface Field {
    id: number;
    name: string;
    type: number;
    defaultValue: string;
    group: string;
    required: boolean;
    deferred: boolean;
    displayOrder: number;
    visibility: number;
    mutability: number;
    includeOnInvoice: boolean;
    encrypted: boolean;
}

export interface Property {
    id: number;
    field: Field;
}

export interface IBiddingItem {
    model: string;
    categories: Category[];
    currencyCode: string;
    winningUser: string;
    currentPrice: number;
    currentQuantity: number;
    decorations: any[];
    description: string;
    endDTTM: string;
    hits: number;
    id: number;
    increment: number;
    actionCount: number;
    locations: any[];
    media: any[];
    ownerUserName: string;
    primaryCategory: PrimaryCategory;
    properties: Property[];
    shippingOptions: any[];
    startDTTM: string;
    status: string;
    title: string;
    subtitle: string;
    version: number;
    typeName: string;
    currentDTTM: string;
    secsToEndDTTM: string;
}
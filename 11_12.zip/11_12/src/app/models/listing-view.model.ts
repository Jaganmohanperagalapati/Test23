import { IBidHistoryData } from './bidding-history.model';
import { IBiddingItem } from './bidding-item.model';
// import { IImage } from './listing.model';
import {IPropertyMedia} from "./property-media.model";

export interface IListingView {
    id: number;
    listingId: string;
    model: string;
    address: string;
    description: string;
    price: number;
    bidAmount: number;
    startDTTM: string;
    endDate: string;
    currentDTTM: string;
    ctaButtonText: string;
    biddingItem: IBiddingItem;
    bidHistoryData: IBidHistoryData[];
    // images: IImage[];
    images:IPropertyMedia[];
}
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HowToBidComponent } from './how-to-bid.component';

describe('HowToBidComponent', () => {
  let component: HowToBidComponent;
  let fixture: ComponentFixture<HowToBidComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HowToBidComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HowToBidComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

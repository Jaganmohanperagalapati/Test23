import { Injectable } from '@angular/core';

@Injectable()
export class ExportService {
    constructor() { }

    exportCSVFile(headers, items, fileTitle) {
        if (headers) {
            items.unshift(headers);
        }
        var jsonObject = JSON.stringify(items);
        var csv = this.convertToCSV(jsonObject);
        var exportedFileName = fileTitle + '.csv' || 'export.csv';
        var blob = new Blob([csv], {
            type: 'text/csv;charset=utf-8;'
        });
        if (navigator.msSaveBlob) {
            navigator.msSaveBlob(blob, exportedFileName);
        } else {
            var link = document.createElement("a");
            if (link.download !== undefined) {
                var url = URL.createObjectURL(blob);
                link.setAttribute("href", url);
                link.setAttribute("download", exportedFileName);
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
        }
    }

    convertToCSV(objArray) {
        var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
        var str = '';
        for (var i = 0; i < array.length; i++) {
            var line = '';
            for (var index in array[i]) {
                if (line != '') line += ','
                line += array[i][index];
            }
            str += line + '\r\n';
        }
        return str;
    }

    getDefaultHeader(): any {
        return {
            auctionProgram: "Auction Program",
            address: "Address",
            city: "City",
            state: "State",
            zip: "Zip",
            county: "County",
            propertyType: "Property Type",
            bedrooms: "Bedrooms",
            bathrooms: "Bathrooms",
            squareFeet: "Square Feet",
            lotSizeValue: "Lot Size Value",
            lotSizeType: "Lot Size Type",
            yearBuilt: "Year Built",
            occupancyStatus: "Occupancy Status",
            preAuctionStartDate: "Pre-Auction Start Date",
            preAuctionEndDate: "Pre-Auction Start Date",
            auctionStartDate: "Auction Start Date",
            auctionEndDate: "Auction End Date",
            foreclosureSaleStatus: "Foreclosure Sale Status",
            foreclosureSaleDate: "Foreclosure Sale Date",
            listingAgent: "Listing Agent",
            agentEmail: "Agent Email",
            agentPhone: "Agent Phone",
            brokerCoopPercent: "Broker Co-op Percent",
            websiteUrl: "Property URL",
        };
    }
}
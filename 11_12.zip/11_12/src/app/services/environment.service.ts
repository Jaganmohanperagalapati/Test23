import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment'

@Injectable({
    providedIn: 'root'
})
export class EnvironmentService {
    public production: boolean = environment.production;
    public apiRoot: string = environment.apiRoot;
    public apiPath: string = environment.apiPath;

    constructor() { }
}
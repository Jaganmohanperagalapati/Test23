import { TestBed } from '@angular/core/testing';

import { LdpDataService } from './ldp-data.service';

describe('LdpDataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LdpDataService = TestBed.get(LdpDataService);
    expect(service).toBeTruthy();
  });
});

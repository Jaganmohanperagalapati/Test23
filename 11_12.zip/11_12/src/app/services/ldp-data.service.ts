import { Injectable } from '@angular/core';
import { IListing } from '../models/listing.model';
import {ReplaySubject} from 'rxjs';

@Injectable()
export class LdpDataService {
    _listing= new ReplaySubject<IListing>();

    constructor() { }

    setListing(listing: IListing): void {
        this._listing.next(listing)
    }

    getListing() {
        return this._listing.asObservable();
    }
}

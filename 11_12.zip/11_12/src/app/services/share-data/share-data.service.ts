import { Injectable, EventEmitter } from '@angular/core';
import { BehaviorSubject, Observable } from "rxjs";
import { HttpClient, HttpParams } from "@angular/common/http";
import { ISearchResult } from '../../models/search-result.model';
import { shareReplay } from 'rxjs/operators';
import { SearchCriteriaService } from '../../services/search-criteria.service';

@Injectable({
    providedIn: 'root'
})
export class ShareDataService {
    private resultValue: ISearchResult;
    public urlParameters: string;
    // public sr1 = new BehaviorSubject<object>({});

    share = new EventEmitter();
    public searchClick = new BehaviorSubject<boolean>(false);
    searchClickValue = this.searchClick.asObservable();
    public searchObject: any = {};
    private auctionProgram = new BehaviorSubject<string>("All Homes for Sale");
    currentAuctionProgram = this.auctionProgram.asObservable();
    private auctionProgram2 = new BehaviorSubject<string>("");
    currentAuctionProgram2 = this.auctionProgram2.asObservable();
    private location = new BehaviorSubject<object>({});
    currentLocation = this.location.asObservable();
    private _searched: boolean = false;
    
    constructor(private _http: HttpClient, private _searchCriteriaService: SearchCriteriaService) {
    }

  




    private sr1 = new BehaviorSubject<object>({});
    listenData(): Observable<any> {
        return this.sr1.asObservable();
    }




    //example
    shareResult(data: string) {
        this.share.emit(data);
    }
    //example end
    /**
     * 
     */
    private filterMessageTitle = new BehaviorSubject('split');
    listenTitle(): Observable<any> {
        return this.filterMessageTitle.asObservable();
    }
    filterTitle(message: any) {
        console.log('this.message---', message);
        this.filterMessageTitle.next(message)
    }






    async setSearchParams(searchResult) {
        console.log("check speed -3", searchResult)
        console.log('searchResult', searchResult);
        let result;
        let filterSearchObject: any = {};

        console.log("result text", result);
        if (searchResult.city && searchResult.stateCode && searchResult.postal_code) {
            console.log("there");
            filterSearchObject.city = searchResult.city;
            filterSearchObject.state = searchResult.stateCode;
            filterSearchObject.postalCode = searchResult.postal_code;

        } else if (searchResult.city && searchResult.stateCode) {
            console.log("2")
            filterSearchObject.city = searchResult.city;
            filterSearchObject.state = searchResult.stateCode;
        }
        else if (searchResult.county) {
            console.log("3")
            filterSearchObject.county = searchResult.county;
            filterSearchObject.state = searchResult.stateCode;

        }
        else if (searchResult.city) {
            filterSearchObject.city = searchResult.city;
        } else if (searchResult.stateCode) {
            console.log("state 4");
            filterSearchObject.state = searchResult.stateCode;
        }
        else if (searchResult.postal_code) {
            filterSearchObject.postalCode = searchResult.postal_code
        }
        else if (searchResult.text) {
            filterSearchObject.text = searchResult.text;
        }


        var querystring = this.getQueryString(filterSearchObject);
        console.log("check speed part", filterSearchObject);

        return await this._searchCriteriaService.search('/listings?limit=100', filterSearchObject);

    }


    getQueryString(search): string {
        console.log("ssr", search)
        return Object.keys(search).map(key => key + '=' + search[key]).join('&');
    }

    alreadySearched(): boolean {
        return this._searched;
    }

    //sam
    async getSResp(sResp: object) {
        this._searched = true;

        console.log("check speed -2", sResp)
        this.resultValue = await this.setSearchParams(sResp);
        if (this.resultValue != undefined) {
            console.log("check speed -4", this.resultValue)
        }
        this.sr1.next(this.resultValue);
    }

    async getFilterResp(filter: object) {
        this.resultValue = await this.setFilterParams(filter)
        console.log("result", this.resultValue);
        this.sr1.next(this.resultValue);
    }

    async setFilterParams(searchResult) {
        console.log("filter params", searchResult);
        return await this._searchCriteriaService.search('/listings?limit=100', searchResult);
    }




    setAuctionProgram(data: any) {
        this.auctionProgram = data;
        console.log("auctionProgram", this.auctionProgram);
        this.changeAuctionProgram(data)
    }

    getAuctionProgram(): any {
        return this.auctionProgram;
    }
    changeAuctionProgram(message: string) {
        this.auctionProgram.next(message)
        console.log("cap", this.auctionProgram)
    }
    changeAuctionProgram2(auctionProgramValue: string) {
        this.auctionProgram2.next(auctionProgramValue);
        // console.log("cap2",this.auctionProgram2);
    }
    onChangeLocation(currLocation: object) {
        console.log("currl", currLocation)
        this.location.next(currLocation)

    }
    // onSearchClick(searchClick: boolean) {
    //   console.log("search click value", searchClick);
    //   this.searchClick.next(searchClick)

    // }
}

import { Injectable } from '@angular/core';
import {Meta, Title} from '@angular/platform-browser';

@Injectable({
  providedIn: 'root'
})
export class MetaService {

  constructor(private title:Title, private meta:Meta) { }
auth
  updateTitle(title:string){
    this.title.setTitle(title);
    console.log("Title: "+this.title.getTitle())
  }

  updateDescription(desc:string){
    this.meta.updateTag({name:'description', content: desc})
    console.log("Description: "+this.meta.getTag("name = 'description'").content)
  }
} 

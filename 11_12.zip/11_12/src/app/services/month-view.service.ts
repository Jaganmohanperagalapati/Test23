import { Injectable } from '@angular/core';
import { CalendarDateFormatter, DateFormatterParams } from 'angular-calendar';
import { formatDate } from '@angular/common';
import {ReplaySubject} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MonthViewService extends CalendarDateFormatter {
date=new ReplaySubject;
  public monthViewColumnHeader({date, locale}: DateFormatterParams): string {
       return formatDate(date, 'EEE', locale).slice(0,1); // use short week days
   }

   getDates(range): void{
    this.date.next(range.shift());
   }

   sendDate(){
     return this.date.asObservable();;
   }
}

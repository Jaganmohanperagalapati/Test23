import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { BehaviorSubject } from "rxjs";
import { ApiService } from "../shared/api/api.service";
import { ISearchResult } from '../models/search-result.model';
import { IAuctionRunResult } from '../models/auction-run-result.model';
import { IAuctionRun } from "../models/auction-run.model";

@Injectable({
    providedIn: 'root'
})
export class SearchCriteriaService {
    private _searchContext: string;
    private _auctionNumber: string;
    private _auctionRun: IAuctionRun;
    private _addressObj: any;
    public searchResp = new BehaviorSubject<object>({});
    searchRespValue = this.searchResp.asObservable();
    public city: any;
    public county: any;
    public formattedAddress: any;
    public stateCode: any;
    public street: any;
    public type: any;
    public searchObject: any;
    public params: any = "empty";
    public searchResultResponse: any;

    constructor(private _api: ApiService, private _http: HttpClient) { }

    setSearchContext(searchContext: string): void {
        this._searchContext = searchContext;
        console.log("service st", this._searchContext)
    }

    setAuctionNumber(auctionNumber: string): void {
        this._auctionNumber = auctionNumber;
        console.log("auction number", this._auctionNumber)
    }

    setSearchObject(searchResult): void {
        console.log("searchResult in service", searchResult);
        this.searchObject = searchResult;
    }

    getSearchResp(searchObj: object) {
        console.log("searchObj in search criteria service", searchObj)
        this.searchResp.next(searchObj);
    }

    getSearchResponse() {
        console.log("sresp", this.searchResultResponse)
        return this.searchResultResponse;
    }

    getCriteria(): any {
        //TODO - ensure we whitelist incoming URL values (e.g., bank-owned-homes, foreclosures, occupied, etc.)
        return {
            searchContext: this._searchContext,
            // city: this._addressObj['city'],
            // county: this._addressObj['city'],
            // postal_code:this._addressObj['postal_code'],
            // stateCode:this._addressObj['stateCode'],
            // street:this._addressObj['street']

        };
    }

    getAuctionRun(): IAuctionRun {
        return this._auctionRun;
    }

    async search(url: string, paramObject: object = null) {
        if (paramObject != null) {
            var query = this.getQueryString(paramObject);
            url += url.indexOf('?') < 0 ? "?" + query : "&" + query;
        }

        if (this.isAuctionCalendarSearch()) {
            return await this.getAuctionCalendarResult();
        }

        return await this._api.getEndPoint<ISearchResult>(url);
    }

    getQueryString(search: object): string {
        return Object.keys(search).map(key => key + '=' + search[key]).join('&');
    }

    isAuctionCalendarSearch(): boolean {
        return this._searchContext === 'upcoming-auctions';
    }

    async getAuctionCalendarResult(): Promise<ISearchResult> {
        //FIXME - fix endpoint once we iron out gateway details for services
        const auctionRunResult = await this._api.getEndPoint<IAuctionRunResult>(`https://auctionrunsvc-s1-v1.dev.exostechnology.local/api/v1/auctionruns?AuctionNumber=${this._auctionNumber}&limit=100`, true);
        this._auctionRun = auctionRunResult.data[0];

        let result: ISearchResult = {
            totalCount: 9,
            data: this._auctionRun.listings,
            continuationToken: '',
            searchResultCount:9
        };

        return result;
    }

    restoreDefaults(): void {
        this._searchContext = null;
        this._auctionNumber = null;
        this._auctionRun = null;
    }
}
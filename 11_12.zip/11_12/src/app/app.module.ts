import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgxSpinnerModule } from 'ngx-spinner';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { HttpClientModule } from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { SharedModule } from './shared/shared.module';
import { AppComponent } from './app.component';
import { ReactiveFormComponent } from './test/reactive-form.component';
import { HomeComponent } from './home/home.component';
import { FooterComponent } from './layout/footer/footer.component';
import { QuoteCarouselComponent } from './quote-carousel/quote-carousel.component';
import { NotFoundComponent } from './notfound/not-found.component';
import { GooglePlacesDirective } from './directives/google-places.directive';
import { HeaderComponent } from './layout/header/header.component';
import { BuyMenuComponent } from './buy-menu/buy-menu.component';
import { RegularBarComponent } from './search-bar/regular-bar/regular-bar.component';
import { LoginComponent } from './Users/login/login.component';
import { RegisterComponent } from './Users/register/register.component';
import { AuctionEventsComponent } from './auction-events/auction-events.component';
import { AuctionEventCardComponent } from './auction-events/auction-event-card/auction-event-card.component';
import { RegistrationComponent } from './auction-forms/registration/registration.component';
import { Step2Component } from './auction-forms/steps/step2/step2.component';
import { Info1Component } from './auction-forms/steps/info1/info1.component';
import { NotificationsComponent } from './layout/notifications/notifications.component';
import { MainComponent } from './auction-forms/main/main.component';
import { OfferComponent } from './auction-forms/offer/offer.component';
import { Step1Component } from './auction-forms/steps/step1/step1.component';
import { Step3Component } from './auction-forms/steps/step3/step3.component';
import { Info2Component } from './auction-forms/steps/info2/info2.component';

import { SignalrTesterComponent } from './test/signalr-tester.component';
import { PaginationModule } from 'ngx-bootstrap';
import { StateImagesComponent } from './state-images/state-images.component';
// import { SplitScreenComponent } from './split-screen/split-screen.component';
//import { CardPaginationComponent } from './card-pagination/card-pagination.component';
import { AccountComponent } from './account/account.component';//
//import { SplitButtonsComponent } from './split-buttons/split-buttons.component';
import {CalendarComponent} from './test/calendar/calendar.component';
import {CommonModule} from '@angular/common';
import {CalendarModule, DateAdapter} from 'angular-calendar';
import {adapterFactory} from 'angular-calendar/date-adapters/date-fns';
import {ComModule} from './test/calendar-header/com.module';
// import { ListingsDropdownComponent } from './listings-dropdown/listings-dropdown.component';


@NgModule({
    declarations: [
        AppComponent,
        ReactiveFormComponent,
        HomeComponent,
        FooterComponent,
        QuoteCarouselComponent,
        NotFoundComponent,
        GooglePlacesDirective,
        HeaderComponent,
        BuyMenuComponent,
        RegularBarComponent,
        LoginComponent,
        RegisterComponent,
        AuctionEventsComponent,
        AuctionEventCardComponent,
        RegistrationComponent,
        Step2Component,
        Info1Component,
        NotificationsComponent,
        MainComponent,
        OfferComponent,
        Step1Component,
        Step3Component,
        Info2Component,
        SignalrTesterComponent,
        StateImagesComponent,
        // SplitScreenComponent,
       // CardPaginationComponent,
        AccountComponent,
        //SplitButtonsComponent,
        CalendarComponent,
        // ListingsDropdownComponent,
    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        NgxSpinnerModule,
        SharedModule.forRoot(),
        PaginationModule.forRoot(),
        CommonModule,
        CalendarModule.forRoot({
            provide: DateAdapter,
            useFactory: adapterFactory
        }),
        ComModule

    ],
    providers: [],
    bootstrap: [AppComponent],
    exports:[CalendarComponent]
})
export class AppModule { }

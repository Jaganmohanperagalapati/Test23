import { Component } from '@angular/core';
import{ NgxSpinnerService} from 'ngx-spinner';
import { LoginComponent } from './Users/login/login.component';
import { Router, NavigationEnd, ActivatedRoute, Params } from '@angular/router';
import {MetaService} from './services/meta.service';
import {filter, map, mergeMap} from 'rxjs/operators';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})
export class AppComponent {
    title = 'AuctionSpa';
    constructor(private spinner: NgxSpinnerService,private router: Router, private activatedRoute: ActivatedRoute, private service:MetaService) { }

    ngOnInit(){
        /**spinner starts on init */
        this.spinner.show();

        setTimeout(() => {
            /**spinner ends after 3 seconds */
            this.spinner.hide();
        }, 3000);


    //Changing meta and title tags dynamically
    this.router.events.pipe(
        filter((event) => event instanceof NavigationEnd),
        map(() => this.activatedRoute),
        map((route) => {
          while (route.firstChild) route = route.firstChild;
          return route;
        }),
        filter((route) => route.outlet === 'primary'),
        mergeMap((route) => route.data)
       )
       .subscribe((event) => {
         this.service.updateTitle(event['title']);
         //Updating Description tag dynamically with title and desc
         this.service.updateDescription(event['description'])
       }); 
    }

    
}

export class IdentityModel {
    id: string;
    model: string;
    created: string;
    name: string;
    emailAddress: string;
}

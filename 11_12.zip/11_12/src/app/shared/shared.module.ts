import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http'
import { ApiService } from './api/api.service';
import { StorageService } from './storage/storage.service';
import { EmployeeService } from '../test/employee.service';
import { LdpDataService } from '../services/ldp-data.service';
import { CountdownService } from '../services/countdown.service';
import { CountdownComponent } from '../countdown/countdown.component';
import { MetaService } from '../services/meta.service';
import { MonthViewService } from '../services/month-view.service';
import { ExportService } from '../services/export.service';
// import { CardPaginationComponent } from '../card-pagination/card-pagination.component';
// import { SplitButtonsComponent } from '../split-buttons/split-buttons.component';
import { PaginationModule } from 'ngx-bootstrap';

@NgModule({
    declarations: [
        CountdownComponent,
        // CardPaginationComponent,
        // SplitButtonsComponent
    ],
    imports: [
        CommonModule,
        HttpClientModule,
        // PaginationModule
    ],
    exports: [
        CountdownComponent,
        // CardPaginationComponent,
        // SplitButtonsComponent
    ]
})
export class SharedModule {
    public static forRoot(): ModuleWithProviders {
        return {
            ngModule: SharedModule,
            providers: [
                ApiService,
                EmployeeService,
                StorageService,
                LdpDataService,
                CountdownService,
                MetaService,
                MonthViewService,
                ExportService
            ]
        };
    }
}

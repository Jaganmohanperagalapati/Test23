import { Injectable } from '@angular/core';
import { throwError as observableThrowError, Observable, Subject } from "rxjs";
import { HttpClient, HttpResponse, HttpParams } from "@angular/common/http";
import { catchError } from "rxjs/operators";
import { StorageService } from '../storage/storage.service';
import { environment } from '../../../environments/environment';

@Injectable()
export class ApiService {
    private onSuccessSubject = new Subject<any>();

    constructor(
        private http: HttpClient,
        private storage: StorageService) {
    }

    public onSuccess(): Observable<any> {
        return this.onSuccessSubject.asObservable();
    }

    private updateUrl(url: string): string {
        return environment.apiRoot + environment.apiPath + url;
    }

    private updateToken(response: HttpResponse<any>): void {
        if (response.status >= 200 && response.status < 400) {
            // Notify listeners
            this.onSuccessSubject.next();

            // Look for a returned token
            const tokenValue = response.headers.get("Set-Authentication");
            if (tokenValue) {
                const token = this.storage.getToken();
                if (token) {
                    token.value = tokenValue;
                    this.storage.setToken(token);
                }
            }
        }
    }

    private getHeaders(hasBody: boolean) {
        const headers: any = {};

        if (hasBody) {
            headers["Content-Type"] = "application/json";
            headers['Authorization'] = 'Basic ' + btoa('systemapiuser:Pa$$word1/2');
        }

        /*
        // Include auth token
        let token = this.storage.getToken();
        if (token) {
            headers["Authorization"] = "Bearer " + token.value;
        }*/

        return headers;
    }

    //--params 
    public param(val) {

    }
    //params end

    public async postEndPoint<T>(url: string, body: any, isTest: boolean = false): Promise<T> {
        if (!isTest) { url = this.updateUrl(url); }

        const response = await this.http
            .post<T>(url, body, { headers: this.getHeaders(true), withCredentials: true, observe: "response" })
            .pipe(
                catchError((res) => {
                    return observableThrowError(res);
                })
            )
            .toPromise();

        this.updateToken(response);

        return response.body;
    }

    public async getEndPoint<T>(url: string, isTest: boolean = false): Promise<T> {
        if (!isTest) { url = this.updateUrl(url); }

        const response = await this.http
            .get<T>(url, { headers: this.getHeaders(true), withCredentials: true, observe: "response" })
            .pipe(
                catchError((res) => {
                    return observableThrowError(res);
                })
            )
            .toPromise();

        this.updateToken(response);

        return response.body;
    }

    //------get end point v2
    public async getListingSearch<T>(url: string): Promise<T> {
        const response = await this.http
            .get<T>(url, { headers: this.getHeaders(false), withCredentials: true, observe: "response" })
            .pipe(
                catchError((res) => {
                    return observableThrowError(res);
                })
            )
            .toPromise();

        this.updateToken(response);

        return response.body;
    }
    //------v2 get end point--end

    public async putEndPoint<T>(url: string, body: any): Promise<T> {
        const response = await this.http
            .put<T>(this.updateUrl(url), body, { headers: this.getHeaders(true), withCredentials: true, observe: "response" })
            .pipe(
                catchError((res) => {
                    return observableThrowError(res);
                })
            )
            .toPromise();

        this.updateToken(response);

        return response.body;
    }

    public async deleteEndPoint<T>(url: string): Promise<T> {
        const response = await this.http
            .delete<T>(this.updateUrl(url), { headers: this.getHeaders(true), withCredentials: true, observe: "response" })
            .pipe(
                catchError((res) => {
                    return observableThrowError(res);
                })
            )
            .toPromise();

        this.updateToken(response);

        return response.body;
    }
}

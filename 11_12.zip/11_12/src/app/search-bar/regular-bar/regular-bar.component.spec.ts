import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegularBarComponent } from './regular-bar.component';

describe('RegularBarComponent', () => {
  let component: RegularBarComponent;
  let fixture: ComponentFixture<RegularBarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegularBarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegularBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

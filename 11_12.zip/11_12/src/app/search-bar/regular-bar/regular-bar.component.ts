///<reference types="@types/googlemaps" />
import { Component, OnInit, NgZone } from '@angular/core';
import { SearchCriteriaService } from "../../services/search-criteria.service";
import { ShareDataService } from "../../services/share-data/share-data.service";
import { FormGroup, FormControl, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { Router, NavigationEnd, ActivatedRoute, Params } from '@angular/router';
import * as moment from "moment";
import { StorageService } from '../../shared/storage/storage.service';
import { Observer, Observable , Subject} from 'rxjs';
import { of, timer } from 'rxjs';
// import { debounce } from 'rxjs/operators';
import { debounce } from "debounce";
import { ExportService } from 'src/app/services/export.service';

@Component({
    selector: 'app-regular-bar',
    templateUrl: './regular-bar.component.html'
})
export class RegularBarComponent implements OnInit {
    //sample filters
    public auctionProgram = [{
        id: 100,
        name: 'Any',
        key: "auctionProgram",
        isCheck: true
    },
    {
        id: 200,
        name: 'Trustee - Foreclosure',
        key: "auctionProgram",
        isCheck: false
    },
    {
        id: 300,
        name: 'Newly Foreclosures ',
        key: "auctionProgram",
        isCheck: false
    },
    {
        id: 400,
        name: 'Banked-Owned - REO',
        key: "auctionProgram",
        isCheck: false
    },
    {
        id: 500,
        name: 'Short Sale',
        key: "auctionProgram",
        isCheck: false
    }
    ];
    public showOnly = [{
        id: 100,
        name: 'Any',
        key: "showOnly",
        isCheck: true
    },
    {
        id: 200,
        name: 'Last Chance to Bid',
        key: "showOnly",
        isCheck: false
    },
    {
        id: 300,
        name: 'Absolute Auction',
        key: "showOnly",
        isCheck: false
    },
    {
        id: 400,
        name: 'Financing Available',
        key: "showOnly",
        isCheck: false
    },
    {
        id: 500,
        name: "No Buyer's Premium",
        key: "showOnly",
        isCheck: false
    },
    {
        id: 600,
        name: "Broker Co-Op Available",
        key: "showOnly",
        isCheck: false
    }
    ]
    public propertyType = [{
      id: 100,
      name: 'Any',
      key: "propertyType",
      isCheck: true
  },
  {
      id: 200,
      name: 'Single Family Home',
      key: "propertyType",
      isCheck: false
  },
  {
      id: 300,
      name: 'Condo/Town Home',
      key: "propertyType",
      isCheck: false
  },
  {
      id: 400,
      name: 'Multi-Family',
      key: "propertyType",
      isCheck: false
  },
  {
      id: 500,
      name: "Manufactured/Mobile",
      key: "propertyType",
      isCheck: false
  },
  {
      id: 600,
      name: "Land",
      key: "propertyType",
      isCheck: false
  },
  {
    id: 700,
    name: "Commercial",
    key: "propertyType",
    isCheck: false
},
{
  id: 800,
  name: "Planned Unit Development",
  key: "propertyType",
  isCheck: false
},
{
  id: 900,
  name: "Special Purpose",
  key: "propertyType",
  isCheck: false
}
  ]
    public occupancy = [{
        id: 100,
        name: 'Any',
        key: 'occupancyStatus'
    },
    {
        id: 200,
        name: 'Occupied',
        key: "occupancyStatus"
    },
    {
        id: 300,
        name: 'vacant',
        key: "occupancyStatus"
    }
    ];

    // sample filters end
    public downloadSearchData: any;
    public dropDownValue: string = "All Homes for Sale";
    private auctionProgramValue;
    private auctionProgramValue2;
    searchInfo: any;
    breadcrumbLocation: any = {};
    searchForm: FormGroup;
    public addrKeys: string[];
    public addr: any;
    public isLoggedIn = false;
    public searchResp: any;
    // public isCheckHome;
    geoCoder = new google.maps.Geocoder();

    constructor(private _fb: FormBuilder, private router: Router, private zone: NgZone, private _searchCriteriaService: SearchCriteriaService,
        private _shareData: ShareDataService, private activatedRoute: ActivatedRoute, private storageService: StorageService,
        private _exportService: ExportService) {
        this.storageService.loginSession$.subscribe((data) => {
            this.isLoggedIn = data.isLoggedIn;
        });
    }

    ngOnInit() {
        this.searchForm = this._fb.group({
            searchData: ""
        });
        this._shareData.currentAuctionProgram.subscribe(auctionProgram => this.auctionProgramValue = auctionProgram);
        this._shareData.currentAuctionProgram2.subscribe(auctionProgram => this.auctionProgramValue2 = auctionProgram);
        this._shareData.listenData().subscribe(sr1 => this.searchResp = sr1);
        this._shareData.currentLocation.subscribe(location => this.breadcrumbLocation = location)
        // this.isCheckHome=this.isHome(this.activatedRoute.snapshot.url.length);
        // console.log('this.isHome(this.activatedRoute.snapshot.url.length)', this.isCheckHome);
        this.defaultChoice = this.occupancy[0].id;
    }

    /////sample filter testing


    public optionsChecked = [];
    public optionsChecked2 = [];
    public optionsChecked3 = [];
    currentMessage: any;
    results: any;
    public defaultChoice: any;
    public optionsRadioChecked: any;
    public objData: {} = {};
    public filteredData: any;

    onSelectionRadio(option, event) {
        let elementValue = event.target.value;  
        if(option.name == 'Any'){
            this.optionsRadioChecked='';
        }else{
            this.optionsRadioChecked=option.name;
        }
        this.checkAny(option.key, this.optionsRadioChecked);

    }
    updateCheckedOptions(option, event) {
        let index = this.optionsChecked.indexOf(event.target.value);
        let elementValue = event.target.value;
        if (elementValue == 'Any') {
            this.filteredMethod(this.auctionProgram);
            if (this.filteredData != undefined) {
                this.auctionProgram = this.filteredData;
                this.optionsChecked = [];
            }
        } else {
            // below is second methd
            if (index === -1) {
                // val not found, pushing onto array
                this.optionsChecked.push(elementValue);
                if (this.optionsChecked.length > 0) {
                    this.auctionProgram[0].isCheck = false;
                }
            } else {
                // val is found, removing from array
                this.optionsChecked.splice(index, 1);
                if (this.optionsChecked.length > 0) {
                    this.auctionProgram[0].isCheck = false;
                } else {
                    this.auctionProgram[0].isCheck = true;
                }
            }
        }

        this.checkAny(option.key, this.optionsChecked);
    }
    updateCheckedOptions2(option, event) {
        let index = this.optionsChecked2.indexOf(event.target.value);
        let elementValue = event.target.value;  
           if(elementValue == 'Any'){
            this.filteredMethod(this.propertyType);       
            if (this.filteredData != undefined) {
                this.propertyType =  this.filteredData;
                this.optionsChecked2 = [];
            }
           }else{
            if (index === -1) {
                // val not found, pushing onto array
                this.optionsChecked2.push(elementValue);
                if (this.optionsChecked2.length > 0) {
                    this.propertyType[0].isCheck = false;
                    }
                    } else {
                        // val is found, removing from array
                        this.optionsChecked2.splice(index, 1);
                        if (this.optionsChecked2.length > 0) {
                            this.propertyType[0].isCheck = false;
                            } else {
                                this.propertyType[0].isCheck = true;
                            }
                    } 
                } 
           this.checkAny(option.key, this.optionsChecked2);
    } 
    updateCheckedOptions3(option, event) {
      let index = this.optionsChecked3.indexOf(event.target.value);
      let elementValue = event.target.value;  
         if(elementValue == 'Any'){
          this.filteredMethod(this.showOnly);       
          if (this.filteredData != undefined) {
              this.showOnly =  this.filteredData;
              this.optionsChecked3 = [];
          }
         }else{
          if (index === -1) {
              // val not found, pushing onto array
              this.optionsChecked3.push(elementValue);
              if (this.optionsChecked3.length > 0) {
                  this.showOnly[0].isCheck = false;
                  }
                  } else {
                      // val is found, removing from array
                      this.optionsChecked3.splice(index, 1);
                      if (this.optionsChecked3.length > 0) {
                          this.showOnly[0].isCheck = false;
                          } else {
                              this.showOnly[0].isCheck = true;
                          }
                  } 
              } 
         this.checkAny(option.key, this.optionsChecked3);
  } 
    filteredMethod(checkValue) {
        this.filteredData = checkValue;
        if (this.filteredData != undefined) {
            this.filteredData[0].isCheck = true;
            this.filteredData.forEach((element, index) => {
                if (this.filteredData[index + 1] != undefined) {
                    this.filteredData[index + 1]['isCheck'] = false;
                }
            })
        }
    }
    checkAny(key, optionsChecked) {
        let checkedData;
        if (Array.isArray(optionsChecked)) {
            checkedData = optionsChecked.join(',');
        } else {
            checkedData = optionsChecked;
        }
        this.objData[key] = checkedData;
        console.log('checkedData---', this.objData);
        this.applyFilterData(this.objData);
    }

    applyFilterData(optionsChecked) {

        this._shareData.getFilterResp(optionsChecked);
    }
    checkReset() {
      for (let key in this.objData) {
          this.objData[key] ="";
      }
      console.log('this.objData====>>>', this.objData);
      this.filteredMethod( this.propertyType);
      this.filteredMethod( this.showOnly);
      this.filteredMethod( this.auctionProgram);
      this.applyFilterData(this.objData);
  }
  resetsAuction(objArray) {
    let keyData= objArray[0].key;
    for (let key in this.objData) {
      this.objData[key] ="";
      if(key == keyData){
        this.objData[key] ="";
      }
  }
    // this.filteredMethod( this.auctionProgram);
    if(keyData =='auctionProgram'){
      this.filteredMethod( this.auctionProgram);
    }else if(keyData =='showOnly'){
      this.filteredMethod( this.showOnly);
    }
    else if(keyData =='propertyType'){
      this.filteredMethod( this.propertyType);
    }
    this.applyFilterData(this.objData);
}
    //sample filter testing end

    setAddress(addrObj) {
      this.zone.run(() => {
        console.log("check speed setAddressObject----------------------------",addrObj);
        this.addr = addrObj;
        this.addrKeys = Object.keys(addrObj);
        this.router.navigate(["/properties"]);
        this.breadcrumbLocation={};
        let searchObject={};
        console.log("addr", this.addr);
        if(this.addr.locality && this.addr.state&&this.addr.postal_code){
          console.log("there")
          // this.breadcrumbLocation=this.addr.locality+","+this.addr.state;
          this.breadcrumbLocation["city"]=this.addr.locality;
          this.breadcrumbLocation["state"]=this.addr.state;
          this.breadcrumbLocation["postalCode"]=this.addr.postal_code;
          searchObject["postal_code"]=this.addr.postal_code;
          searchObject["city"]=this.addr.locality;
          searchObject["stateCode"]=this.addr.admin_area_l1;
        }
        else if (this.addr.locality&&this.addr.state){
          this.breadcrumbLocation["city"]=this.addr.locality;
          this.breadcrumbLocation["state"]=this.addr.state;
          searchObject["city"]=this.addr.locality;
          
        }
        else if(this.addr.county){
          this.breadcrumbLocation["county"]=this.addr.county;
          this.breadcrumbLocation["state"]=this.addr.state;
          searchObject["county"]=this.addr.county;
          searchObject["state"]=this.addr.state;
        }
        else if (this.addr.admin_area_l1) {
          console.log("state");
          this.breadcrumbLocation["state"] = this.addr.state;
          searchObject["stateCode"]=this.addr.admin_area_l1;
        }
        this._shareData.changeAuctionProgram2(this.auctionProgramValue);
        this._shareData.onChangeLocation(this.breadcrumbLocation)
        this._shareData.getSResp(searchObject);
       
      });
    }
     geoCodeInput(address){
       
      
      let search_obj = {};
      this.geoCoder.geocode({componentRestrictions: {country: 'USA'}, address: address },(results, status)=> {
        if (status === google.maps.GeocoderStatus.OK) {
          // if (results[0] != null) {
          const R = results[0];
          search_obj["type"] = R.types[0]; 
          search_obj["text"]=address;
          if (R.address_components[0].types[0] == 'administrative_area_level_1') {
            search_obj['stateCode'] = R.address_components[0].short_name;
            search_obj['state']=R.address_components[0].long_name;
          } else if (R.address_components[1] && R.address_components[1].types[0] == 'administrative_area_level_1') {
            search_obj['stateCode'] = R.address_components[1].short_name;
            search_obj['state']=R.address_components[1].long_name
          } else if (R.address_components[2] && R.address_components[2].types[0] == 'administrative_area_level_1') {
            search_obj['stateCode'] = R.address_components[2].short_name;
            search_obj['state']=R.address_components[2].long_name
          } else if (R.address_components[3] && R.address_components[3].types[0] == 'administrative_area_level_1') {
            search_obj['stateCode'] = R.address_components[3].short_name;
            search_obj['state']=R.address_components[3].long_name;
          } else if (R.address_components[4] && R.address_components[4].types[0] == 'administrative_area_level_1') {
            search_obj['stateCode'] = R.address_components[4].short_name;
            search_obj['state']=R.address_components[4].long_name;
          } else if (R.address_components[5] && R.address_components[5].types[0] == 'administrative_area_level_1') {
            search_obj['stateCode'] = R.address_components[5].short_name;
            search_obj['state']= R.address_components[5].long_name;
          }
          //console.log("state=", search_obj['stateCode']);
 
for (let i in R.address_components) {
  if (R.address_components[i].types[0] == "administrative_area_level_2") {
  search_obj["county"] = R.address_components[i].short_name;
  }
  if (R.address_components[i].types[0] == "postal_code") {
  search_obj['postal_code'] = R.address_components[i].short_name;
  console.log("postalCode=", search_obj['postal_code']);
  }
  }
  //extracting the city
  let city;
  if (R.address_components.length > 3) {
  for (let i = 0; i < R.address_components.length; i++) {
  if (R.address_components[i].types[0] == 'locality') {
  search_obj["city"] = R.address_components[i].long_name.toLowerCase();
   
  }
  }
  }
   
  //extracting the state
  let street = address
  search_obj["street"] = address
  .toLowerCase()
  .split(' ')
  .join('');
  // console.log("street=", search_obj["street"]);
  search_obj["formatted address"] = R.formatted_address;
   
  // Street exception for New York
  if (R.address_components[0].long_name == 'New York' && (search_obj["type"] == 'locality' || search_obj["type"] == 'text')) {
  if (search_obj["street"].includes('city')) {
  // console.log('logic for new york city');
  // If they select New York city, then do logic for city
  search_obj["type"] = 'locality';
  } else {
  // console.log('NEW YORK STATE');
  // If they select New York state, then create new stateCode using [1].short_name
  search_obj["type"] = 'administrative_area_level_1';
  search_obj['stateCode'] = R.address_components[1].short_name;
  search_obj['state']=R.address_components[1].long_name;
  }
  }
  // this._shareData.getSResp(search_obj);
  //coordinates
          const latitude = R.geometry.location.lat();
          console.log("lat", latitude)
          const longitude = R.geometry.location.lng();
          console.log("long", longitude)
          const location = new google.maps.LatLng(latitude, longitude);
          const center = {
            lat: latitude,
            lng: longitude
          };
          
          console.log("search_obj",search_obj)
          this._shareData.getSResp(search_obj);
          // this.breadcrumbLocation={};
        if(search_obj["city"] && search_obj["state"]&&search_obj["postal_code"]){
          console.log("there")
          this.breadcrumbLocation["city"]=search_obj["city"]
          this.breadcrumbLocation["state"]=search_obj["state"]
          this.breadcrumbLocation["postalCode"]=search_obj["postal_code"]
        }else if(search_obj["city"]&&search_obj["state"]){
          this.breadcrumbLocation["city"]=search_obj["city"];
          this.breadcrumbLocation["state"]=search_obj["state"];
        }
        else if(search_obj["county"]){
          this.breadcrumbLocation["county"]=search_obj["county"];
          this.breadcrumbLocation["state"]=search_obj["state"];
        }else if(search_obj["state"]){
          console.log("state");
          this.breadcrumbLocation["state"]=search_obj["state"];
        }
        
        console.log("breadcrumb location",)
        this._shareData.onChangeLocation(this.breadcrumbLocation);

        //  this._shareData.getSResp(search_obj);
        // }
        
      }
      else{
        search_obj["text"]=address;
        console.log("else in geocode");
        this._shareData.getSResp(search_obj);
      }
      });
      // this._searchCriteriaService.setAddressEntity(search_obj);
      // this._shareData.onChangeLocation(this.breadcrumbLocation);
    }
  



    onSearch(): void {

        this.router.navigate(["/properties"])
        if (this.searchForm.controls.searchData.value == "") {
            this._shareData.getSResp({});
            this._shareData.onChangeLocation({});
            console.log("check speed bread", this.breadcrumbLocation);
            console.log("getting data?", this.searchResp)
            this._shareData.changeAuctionProgram2(this.auctionProgramValue);
        }
        else {
            this._shareData.changeAuctionProgram2(this.auctionProgramValue)
            console.log("sVal=" + this.searchForm.controls.searchData.value);
            console.log("brcr", this.breadcrumbLocation)
            this.geoCodeInput(this.searchForm.controls.searchData.value);

        }
        event.stopPropagation();
    }
    onAuctionProgramChange(e): void {
        console.log("drop event:", e.target.innerText)
        let listingObject={};
        if(e.target.innerText=="All Homes for Sale"){
            this.auctionProgramValue=e.target.innerText;
            console.log("");
        }
        else if(e.target.innerText=="Bank-Owned Homes"){
            console.log("auctionProgram")
            listingObject["auctionProgram"]=e.target.innerText;
            this.auctionProgramValue=e.target.innerText;
        }
        else if(e.target.innerText=="Foreclosures"){
            console.log("auctionProgram");
            listingObject["auctionProgram"]=e.target.innerText;
            this.auctionProgramValue=e.target.innerText;
        }
        else if(e.target.innerText=="Newly Foreclosed"){
            console.log("auctionProgram");
            listingObject["auctionProgram"]=e.target.innerText;
            this.auctionProgramValue=e.target.innerText;
        }
        else if(e.target.innerText=="Banker Co-op Available"){
            console.log("show Only");
            listingObject["showOnly"]=e.target.innerText;
            this.auctionProgramValue=e.target.innerText;
        }
        else if(e.target.innerText=="Short Sale"){
            listingObject["auctionProgram"]=e.target.innerText;
            this.auctionProgramValue=e.target.innerText;
        }

        this.dropDownValue = e.target.innerText;
        console.log("listing Object",listingObject);
        this._shareData.getFilterResp(listingObject);
        this._shareData.changeAuctionProgram2(this.auctionProgramValue)


    }

    onDownloadResults() {
        console.log(" check speed on download", this.searchResp)

        this.downloadSearchData = this.searchResp
        if (this.downloadSearchData.data.length > 0) {
            var itemsFormatted = [];
            this.downloadSearchData.data.forEach((item) => {
                itemsFormatted.push({
                    auctionProgram: item.listingProgramWebsite ? item.listingProgramWebsite : "",
                    address: item.propertyInfo.address ? item.propertyInfo.address : "",
                    city: item.propertyInfo.city ? item.propertyInfo.city : "",
                    state: item.propertyInfo.state ? item.propertyInfo.state : "",
                    zip: item.propertyInfo.postalCode ? item.propertyInfo.postalCode : "",
                    county: item.propertyInfo.county ? item.propertyInfo.county : "",
                    propertyType: item.propertyInfo.propertyType ? item.propertyInfo.propertyType : "",
                    bedrooms: item.propertyInfo.bedrooms ? item.propertyInfo.bedrooms : "",
                    bathrooms: item.propertyInfo.fullBathrooms ? item.propertyInfo.fullBathrooms : "",
                    squareFeet: item.propertyInfo.interiorSqFt ? item.propertyInfo.interiorSqFt : "",
                    lotSizeValue: item.propertyInfo.lotSize ? item.propertyInfo.lotSize : "",
                    lotSizeType: item.propertyInfo.lotSizeAcreageDescription ? item.propertyInfo.lotSizeAcreageDescription : "",
                    yearBuilt: item.propertyInfo.yearBuilt ? item.propertyInfo.yearBuilt : "",
                    occupancyStatus: item.propertyInfo.occupancyStatus ? item.propertyInfo.occupancyStatus : "",
                    preAuctionStartDate: (item.auctionRunInfo && item.auctionRunInfo.preAuctionStartDate) ? item.auctionRunInfo.preAuctionStartDate : "",
                    preAuctionEndDate: (item.auctionRunInfo && item.auctionRunInfo.preAuctionEndDate) ? item.auctionRunInfo.preAuctionEndDate : "",
                    auctionStartDate: (item.auctionRunInfo && item.auctionRunInfo.startDate) ? moment(item.auctionRunInfo.startDate).format('MM/DD/YYYY h:mm A') : "",
                    auctionEndDate: (item.auctionRunInfo && item.auctionRunInfo.endDate) ? moment(item.auctionRunInfo.endDate).format('MM/DD/YYYY h:mm A') : "",
                    foreclosureSaleStatus: item.foreclosureSaleStatus ? item.foreclosureSaleStatus : "",
                    foreclosureSaleDate: item.foreclosureSaleDate ? moment(item.foreclosureSaleDate).format('MM/DD/YYYY') : "",
                    listingAgent: (item.auctionRunInfo && item.auctionRunInfo.listingAgent) ? item.auctionRunInfo.listingAgent : "",
                    agentEmail: (item.auctionRunInfo && item.auctionRunInfo.agentEmail) ? item.auctionRunInfo.agentEmail : "",
                    agentPhone: (item.auctionRunInfo && item.auctionRunInfo.agentPhone) ? item.auctionRunInfo.agentPhone : "",
                    brokerCoopPercent: (item.auctionRunInfo && item.auctionRunInfo.brokerCoopPercent) ? item.auctionRunInfo.brokerCoopPercent : "",
                    websiteUrl: item.propertyInfo.websiteUrl ? item.propertyInfo.websiteUrl : ""
                });
            });
            this._exportService.exportCSVFile(this._exportService.getDefaultHeader(), itemsFormatted, 'SearchResults');
        }
    }
}
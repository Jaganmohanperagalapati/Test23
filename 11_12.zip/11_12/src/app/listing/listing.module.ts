import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { ListingRoutingModule } from './listing-routing.module';
import {AgmCoreModule} from "@agm/core";
import { AgmOverlays } from "agm-overlays";
import { AgmSnazzyInfoWindowModule } from '@agm/snazzy-info-window';

import { SrpComponent } from './srp/srp.component';
import { LdpComponent } from './ldp/ldp.component';
import { ListingCardComponent } from './listing-card/listing-card.component';
import { ListingRouteManagerComponent } from './listing-route-manager/listing-route-manager.component';
import { LdpHeaderComponent } from './ldp/ldp-header/ldp-header.component';
import { LdpReserveProxyComponent } from './ldp/ldp-reserve-proxy/ldp-reserve-proxy.component';
import { ImageGalleryComponent } from './image-gallery/image-gallery.component';
import { LdpComingSoonComponent } from './ldp/ldp-coming-soon/ldp-coming-soon.component';
import { AuctionTimerComponent } from './auction-timer/auction-timer.component';
import { AuctionStatusComponent } from './auction-status/auction-status.component';
import { AuctionFormComponent } from './auction-form/auction-form.component';
import { LdpPropertyIconsComponent } from './ldp/ldp-property-icons/ldp-property-icons.component';
import { LdpMapComponent } from './ldp/ldp-map/ldp-map.component';
import { CardPaginationComponent } from './card-pagination/card-pagination.component';
import { LdpBiddingHistoryComponent } from './ldp/ldp-bidding-history/ldp-bidding-history.component';
import { LdpKeyFeaturesComponent } from './ldp/ldp-key-features/ldp-key-features.component';
// import { PaginationComponent } from './pagination/pagination.component';
import { BreadcrumbsComponent } from './breadcrumbs/breadcrumbs.component';
import { PaginationBottomComponent } from './pagination-bottom/pagination-bottom.component';
import { MapComponent } from './map/map.component';
import { SplitScreenComponent } from './split-screen/split-screen.component';
import { SplitButtonsComponent } from './split-buttons/split-buttons.component';
import { LdpPropertyDocumentsComponent } from './ldp/ldp-property-documents/ldp-property-documents.component';
import { LdpSellerInformationComponent } from './ldp/ldp-transaction-details/ldp-seller-information/ldp-seller-information.component';
import { LdpAgentInformationComponent } from './ldp/ldp-agent-information/ldp-agent-information.component';
import { LdpLicencingComponent } from './ldp/ldp-licencing/ldp-licencing.component';
import { LdpDisclaimerComponent } from './ldp/ldp-disclaimer/ldp-disclaimer.component';
import { LdpAdditionalInformationComponent } from './ldp/ldp-transaction-details/ldp-additional-information/ldp-additional-information.component';
import { LdpNearbyPropertiesComponent } from './ldp/ldp-nearby-properties/ldp-nearby-properties.component';
import { PaginationModule } from 'ngx-bootstrap';
import { ListingsDropdownComponent } from './listings-dropdown/listings-dropdown.component';
import { LdpOccupiedNotificationComponent } from './ldp/ldp-occupied-notification/ldp-occupied-notification.component';
import { LdpPropertyDnaComponent } from './ldp/ldp-property-dna/ldp-property-dna.component';
import { LdpTransactionDetailsComponent } from './ldp/ldp-transaction-details/ldp-transaction-details.component';
import { LdpEarnestMoneyDepositComponent } from './ldp/ldp-transaction-details/ldp-earnest-money-deposit/ldp-earnest-money-deposit.component';
import { LdpSpecialComponent } from './ldp/ldp-transaction-details/ldp-special/ldp-special.component';
import { LdpBuyersPremiumComponent } from './ldp/ldp-transaction-details/ldp-buyers-premium/ldp-buyers-premium.component';
import { LdpSecondChanceInteriorAccessComponent } from './ldp/ldp-transaction-details/ldp-second-chance-interior-access/ldp-second-chance-interior-access.component';
import { LdpDisclosuresComponent } from './ldp/ldp-disclosures/ldp-disclosures.component';
import { LdpValueInformationComponent } from './ldp/ldp-value-information/ldp-value-information.component';
import { AuctionRunDetailsComponent } from './auction-run-details/auction-run-details.component';
import { LdpAuctionInformationComponent } from './ldp/ldp-auction-information/ldp-auction-information.component';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ListingRoutingModule,
        PaginationModule.forRoot(),
        AgmOverlays,
        AgmCoreModule.forRoot({
            apiKey: 'AIzaSyARw-XELZPGKXVbucz9dDAtqjXKh-uoTME'
        }),
        AgmSnazzyInfoWindowModule,
        
        SharedModule.forRoot()
    ],
    declarations: [
        SrpComponent,
        LdpComponent,
        ListingCardComponent,
        ListingRouteManagerComponent,
        LdpHeaderComponent,
        LdpReserveProxyComponent,
        ImageGalleryComponent,
        LdpComingSoonComponent,
        AuctionTimerComponent,
        AuctionStatusComponent,
        AuctionFormComponent,
        LdpPropertyIconsComponent,
        LdpMapComponent,
        LdpBiddingHistoryComponent,
        LdpKeyFeaturesComponent,
        // PaginationComponent,
        BreadcrumbsComponent,
        PaginationBottomComponent,
        MapComponent,
        SplitScreenComponent,
        CardPaginationComponent,
        SplitButtonsComponent,
        LdpPropertyDocumentsComponent,
        LdpSellerInformationComponent,
        LdpAgentInformationComponent,
        LdpLicencingComponent,
        LdpDisclaimerComponent,
        LdpAdditionalInformationComponent,
        LdpNearbyPropertiesComponent,
        ListingsDropdownComponent,
        LdpOccupiedNotificationComponent,
        LdpPropertyDnaComponent,
        LdpTransactionDetailsComponent,
        LdpEarnestMoneyDepositComponent,
        LdpSpecialComponent,
        LdpBuyersPremiumComponent,
        LdpSecondChanceInteriorAccessComponent,
        LdpDisclosuresComponent,
        LdpValueInformationComponent,
        AuctionRunDetailsComponent,
        LdpAuctionInformationComponent,
    ],


    entryComponents: [
        SrpComponent,
        LdpComponent,
        LdpBiddingHistoryComponent,
        LdpKeyFeaturesComponent,
        ListingCardComponent,
        

    ]
})
export class ListingModule {

 }

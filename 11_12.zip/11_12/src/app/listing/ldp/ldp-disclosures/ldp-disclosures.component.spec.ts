import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpDisclosuresComponent } from './ldp-disclosures.component';

describe('LdpDisclosuresComponent', () => {
  let component: LdpDisclosuresComponent;
  let fixture: ComponentFixture<LdpDisclosuresComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpDisclosuresComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpDisclosuresComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

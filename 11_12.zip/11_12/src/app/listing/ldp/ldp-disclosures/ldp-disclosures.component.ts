import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ldp-disclosures',
  templateUrl: './ldp-disclosures.component.html',
  styleUrls: ['./ldp-disclosures.component.scss']
})
export class LdpDisclosuresComponent implements OnInit {
  clicked:boolean=true;
  toggleArrow:string="../../../../assets/images/up-arrow.png";
  constructor() { }

  ngOnInit() {
  }

  toggleFunc(){
    if(this.clicked===true){
        this.clicked=false;
        this.toggleArrow="../../../../assets/images/down-arrow.png"
        
    }else{
        this.clicked=true;
        this.toggleArrow="../../../../assets/images/up-arrow.png"        
    }
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ldp-value-information',
  templateUrl: './ldp-value-information.component.html',
  styleUrls: ['./ldp-value-information.component.scss']
})
export class LdpValueInformationComponent implements OnInit {
  clicked:boolean=false;
  toggleArrow:string="../../../../assets/images/down-arrow.png";
  constructor() { }

  ngOnInit() {
  }

  // toggleFunc(){
  //   if(this.clicked===true){
  //       this.clicked=false;
  //       this.toggleArrow="../../../../assets/images/down-arrow.png"
        
  //   }else{
  //       this.clicked=true;
  //       this.toggleArrow="../../../../assets/images/up-arrow.png"        
  //   }
  // }

}

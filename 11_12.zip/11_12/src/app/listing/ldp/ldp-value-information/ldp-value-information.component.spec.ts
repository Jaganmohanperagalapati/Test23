import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpValueInformationComponent } from './ldp-value-information.component';

describe('LdpValueInformationComponent', () => {
  let component: LdpValueInformationComponent;
  let fixture: ComponentFixture<LdpValueInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpValueInformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpValueInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit} from '@angular/core';
import { IListing } from '../../../models/listing.model';
import {LdpDataService} from '../../../services/ldp-data.service';
import { Subscription } from 'rxjs';
@Component({
    selector: 'app-ldp-property-documents',
    templateUrl: './ldp-property-documents.component.html',
    styleUrls: ['./ldp-property-documents.component.scss']
})
export class LdpPropertyDocumentsComponent implements OnInit {
    listing: IListing;
    toggleArrow:string="../../../../assets/images/up-arrow.png";
  clicked:boolean=true;
  sub:Subscription;
    constructor(private _ldpDataService: LdpDataService) { }

    ngOnInit() { 
        this.sub=this._ldpDataService.getListing().subscribe(res=>{this.listing=res;})
    }

    toggleFunc(){
        if(this.clicked===true){
            this.clicked=false;
            this.toggleArrow="../../../../assets/images/down-arrow.png"
            
        }else{
            this.clicked=true;
            this.toggleArrow="../../../../assets/images/up-arrow.png"        
        }
    }

    ngOnDestroy(){
        if(this.sub){
            this.sub.unsubscribe();
        }
    }
}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpAuctionInformationComponent } from './ldp-auction-information.component';

describe('LdpAuctionInformationComponent', () => {
  let component: LdpAuctionInformationComponent;
  let fixture: ComponentFixture<LdpAuctionInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpAuctionInformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpAuctionInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ldp-auction-information',
  templateUrl: './ldp-auction-information.component.html',
  styleUrls: ['./ldp-auction-information.component.scss']
})
export class LdpAuctionInformationComponent implements OnInit {
  toggleArrow:string="../../../../assets/images/up-arrow.png";
  clicked:boolean=true;
  constructor() { }

  ngOnInit() {
  }
  toggleFunc(){
    if(this.clicked===true){
        this.clicked=false;
        this.toggleArrow="../../../../assets/images/down-arrow.png"
        
    }else{
        this.clicked=true;
        this.toggleArrow="../../../../assets/images/up-arrow.png"        
    }
}

}
 
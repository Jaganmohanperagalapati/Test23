import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpMapComponent } from './ldp-map.component';

describe('LdpMapComponent', () => {
  let component: LdpMapComponent;
  let fixture: ComponentFixture<LdpMapComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpMapComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

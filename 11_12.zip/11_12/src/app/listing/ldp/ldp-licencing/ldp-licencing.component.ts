import { Component, OnInit} from '@angular/core';
import { IListing } from '../../../models/listing.model';

@Component({
  selector: 'app-ldp-licencing',
  templateUrl: './ldp-licencing.component.html',
  styleUrls: ['./ldp-licencing.component.scss']
})
export class LdpLicencingComponent implements OnInit {
listing:IListing;
toggleArrow:string="../../../../assets/images/up-arrow.png";
clicked:boolean=true;
  constructor() { }

  ngOnInit() {
  }

  toggleFunc(){
    if(this.clicked===true){
        this.clicked=false;
        this.toggleArrow="../../../../assets/images/down-arrow.png"
        
    }else{
        this.clicked=true;
        this.toggleArrow="../../../../assets/images/up-arrow.png"        
    }
  }   

}

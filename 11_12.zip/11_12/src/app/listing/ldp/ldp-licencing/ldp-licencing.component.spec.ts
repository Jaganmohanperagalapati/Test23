import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpLicencingComponent } from './ldp-licencing.component';

describe('LdpLicencingComponent', () => {
  let component: LdpLicencingComponent;
  let fixture: ComponentFixture<LdpLicencingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpLicencingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpLicencingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

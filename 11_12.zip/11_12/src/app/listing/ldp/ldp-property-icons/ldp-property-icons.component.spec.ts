import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpPropertyIconsComponent } from './ldp-property-icons.component';

describe('LdpPropertyIconsComponent', () => {
  let component: LdpPropertyIconsComponent;
  let fixture: ComponentFixture<LdpPropertyIconsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpPropertyIconsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpPropertyIconsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

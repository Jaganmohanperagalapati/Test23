import { Component, OnInit } from '@angular/core';
import { IListing } from '../../../models/listing.model';
import { LdpDataService } from '../../../services/ldp-data.service';

@Component({
    selector: 'app-ldp-property-icons',
    templateUrl: './ldp-property-icons.component.html',
    styleUrls: ['./ldp-property-icons.component.scss']
})
export class LdpPropertyIconsComponent implements OnInit {
    listing: IListing;

    constructor(private _ldpDataService: LdpDataService) { }

    ngOnInit() {
        // this.listing = this._ldpDataService.getListing();
    }
}

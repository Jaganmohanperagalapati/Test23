import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpTransactionDetailsComponent } from './ldp-transaction-details.component';

describe('LdpTransactionDetailsComponent', () => {
  let component: LdpTransactionDetailsComponent;
  let fixture: ComponentFixture<LdpTransactionDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpTransactionDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpTransactionDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit} from '@angular/core';
import { IListing } from '../../../../models/listing.model';

@Component({
  selector: 'app-ldp-seller-information',
  templateUrl: './ldp-seller-information.component.html',
  styleUrls: ['./ldp-seller-information.component.scss']
})
export class LdpSellerInformationComponent implements OnInit {
listing:IListing;
  constructor() { }

  ngOnInit() {
  }

}

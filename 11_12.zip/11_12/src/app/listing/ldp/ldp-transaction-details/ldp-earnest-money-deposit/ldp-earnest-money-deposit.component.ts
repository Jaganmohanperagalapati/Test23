import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ldp-earnest-money-deposit',
  templateUrl: './ldp-earnest-money-deposit.component.html',
  styleUrls: ['./ldp-earnest-money-deposit.component.scss']
})
export class LdpEarnestMoneyDepositComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpEarnestMoneyDepositComponent } from './ldp-earnest-money-deposit.component';

describe('LdpEarnestMoneyDepositComponent', () => {
  let component: LdpEarnestMoneyDepositComponent;
  let fixture: ComponentFixture<LdpEarnestMoneyDepositComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpEarnestMoneyDepositComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpEarnestMoneyDepositComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

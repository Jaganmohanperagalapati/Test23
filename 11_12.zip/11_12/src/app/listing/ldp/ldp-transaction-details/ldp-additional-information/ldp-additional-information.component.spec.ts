import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpAdditionalInformationComponent } from './ldp-additional-information.component';

describe('LdpAdditionalInformationComponent', () => {
  let component: LdpAdditionalInformationComponent;
  let fixture: ComponentFixture<LdpAdditionalInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpAdditionalInformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpAdditionalInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit} from '@angular/core';
import { IListing } from '../../../../models/listing.model';

@Component({
  selector: 'app-ldp-additional-information',
  templateUrl: './ldp-additional-information.component.html',
  styleUrls: ['./ldp-additional-information.component.scss']
})
export class LdpAdditionalInformationComponent implements OnInit {
listing:IListing;

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ldp-transaction-details',
  templateUrl: './ldp-transaction-details.component.html',
  styleUrls: ['./ldp-transaction-details.component.scss']
})
export class LdpTransactionDetailsComponent implements OnInit {

  clicked:boolean=true;
  toggleArrow:string="../../../../assets/images/up-arrow.png";
  constructor() { } 

  ngOnInit() {
  } 

  toggleFunc(){
    if(this.clicked===true){
        this.clicked=false;
        this.toggleArrow="../../../../assets/images/down-arrow.png"
        
    }else{
        this.clicked=true;
        this.toggleArrow="../../../../assets/images/up-arrow.png"        
    }
  }

}

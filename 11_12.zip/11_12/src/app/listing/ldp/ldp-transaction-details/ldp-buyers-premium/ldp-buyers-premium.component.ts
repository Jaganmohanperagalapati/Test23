import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ldp-buyers-premium',
  templateUrl: './ldp-buyers-premium.component.html',
  styleUrls: ['./ldp-buyers-premium.component.scss']
})
export class LdpBuyersPremiumComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

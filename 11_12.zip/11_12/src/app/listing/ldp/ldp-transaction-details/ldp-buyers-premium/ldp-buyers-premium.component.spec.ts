import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpBuyersPremiumComponent } from './ldp-buyers-premium.component';

describe('LdpBuyersPremiumComponent', () => {
  let component: LdpBuyersPremiumComponent;
  let fixture: ComponentFixture<LdpBuyersPremiumComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpBuyersPremiumComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpBuyersPremiumComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

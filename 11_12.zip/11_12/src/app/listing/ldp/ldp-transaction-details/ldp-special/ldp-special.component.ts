import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ldp-special',
  templateUrl: './ldp-special.component.html',
  styleUrls: ['./ldp-special.component.scss']
})
export class LdpSpecialComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

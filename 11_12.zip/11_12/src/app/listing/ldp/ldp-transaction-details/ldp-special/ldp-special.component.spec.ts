import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpSpecialComponent } from './ldp-special.component';

describe('LdpSpecialComponent', () => {
  let component: LdpSpecialComponent;
  let fixture: ComponentFixture<LdpSpecialComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpSpecialComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpSpecialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ldp-second-chance-interior-access',
  templateUrl: './ldp-second-chance-interior-access.component.html',
  styleUrls: ['./ldp-second-chance-interior-access.component.scss']
})
export class LdpSecondChanceInteriorAccessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

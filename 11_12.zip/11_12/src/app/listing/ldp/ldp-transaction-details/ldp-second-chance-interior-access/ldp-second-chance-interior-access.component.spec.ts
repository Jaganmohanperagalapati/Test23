import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpSecondChanceInteriorAccessComponent } from './ldp-second-chance-interior-access.component';

describe('LdpSecondChanceInteriorAccessComponent', () => {
  let component: LdpSecondChanceInteriorAccessComponent;
  let fixture: ComponentFixture<LdpSecondChanceInteriorAccessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpSecondChanceInteriorAccessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpSecondChanceInteriorAccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

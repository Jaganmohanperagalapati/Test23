import { Component, OnInit } from '@angular/core';
import {LdpDataService} from '../../../services/ldp-data.service';
import { Subscription } from 'rxjs';
import { IListing } from '../../../models/listing.model';

@Component({
  selector: 'app-ldp-occupied-notification',
  templateUrl: './ldp-occupied-notification.component.html',
  styleUrls: ['./ldp-occupied-notification.component.scss']
})
export class LdpOccupiedNotificationComponent implements OnInit {

  constructor(private _ldpDataService: LdpDataService) { }
listing:IListing;
sub:Subscription;
occupancyWarning:boolean=true;
  ngOnInit() {
    this.sub=this._ldpDataService.getListing().subscribe(res=>{this.listing=res;
      // if(this.listing.propertyInfo.occupancyStatus!=undefined){
      //   if(this.listing.propertyInfo.occupancyStatus!="Vacant"){
      //     this.occupancyWarning=true;
      //   };
      // };
    });
  }

  ngOnDestroy(){
    if(this.sub){
        this.sub.unsubscribe();
    }
}

}

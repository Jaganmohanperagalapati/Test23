import { Component, OnInit } from '@angular/core';
import { IListing } from '../../../models/listing.model';
import { LdpDataService } from '../../../services/ldp-data.service';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-ldp-header',
    templateUrl: './ldp-header.component.html',
    styleUrls: ['./ldp-header.component.scss']
})
export class LdpHeaderComponent implements OnInit {
    listing:IListing;
    sub:Subscription;

    constructor(private _ldpDataService: LdpDataService) { }

    ngOnInit(){
        this.sub=this._ldpDataService.getListing().subscribe(res=>{this.listing=res;})
    }

    ngOnDestroy(){
        if(this.sub){
            this.sub.unsubscribe();
        }
    } 
}

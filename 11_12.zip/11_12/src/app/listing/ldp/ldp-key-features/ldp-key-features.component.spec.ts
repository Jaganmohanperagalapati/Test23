import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpKeyFeaturesComponent } from './ldp-key-features.component';

describe('LdpPropertyDetailsComponent', () => {
  let component: LdpKeyFeaturesComponent;
  let fixture: ComponentFixture<LdpKeyFeaturesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpKeyFeaturesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpKeyFeaturesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

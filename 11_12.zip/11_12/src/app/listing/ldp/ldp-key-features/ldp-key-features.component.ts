import { Component, OnInit, NgModule} from '@angular/core';
import { IListing } from '../../../models/listing.model';
import { LdpDataService } from '../../../services/ldp-data.service';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-ldp-key-features',
    templateUrl: './ldp-key-features.component.html',
    styleUrls: ['./ldp-key-features.component.scss']
})
export class LdpKeyFeaturesComponent implements OnInit {
    listing: IListing;
    sub:Subscription;
    clicked:boolean=true;
    constructor(private _ldpDataService: LdpDataService) { }

    //add filtering through these, for now leave it 
 imgArr:Array<string>=["../../../../assets/images/interior-access.png", "../../../../assets/images/deny.png","../../../../assets/images/cash.png","../../../../assets/images/credit-card.png","../../../../assets/images/users.png"]
 contentArr:Array<string>=["Interior Access Available","No Buyer's Premium","Cash Only","Financing Available","Broker Co-Op Avail."]
 toggleArrow:string="../../../../assets/images/up-arrow.png";
    ngOnInit() {
        this.sub=this._ldpDataService.getListing().subscribe(res=>{this.listing=res;})
    }
 
    ngOnDestroy(){
        if(this.sub){
            this.sub.unsubscribe();
        }
    } 

    toggleFunc(){
        if(this.clicked===true){
            this.clicked=false;
            this.toggleArrow="../../../../assets/images/down-arrow.png"
            
        }else{
            this.clicked=true;
            this.toggleArrow="../../../../assets/images/up-arrow.png"        
        }
    }
}

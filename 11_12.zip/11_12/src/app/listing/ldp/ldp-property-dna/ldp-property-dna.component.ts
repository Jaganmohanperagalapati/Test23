import { Component, OnInit } from '@angular/core';
import { IListing } from '../../../models/listing.model';
import { LdpDataService } from '../../../services/ldp-data.service';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-ldp-property-dna',
  templateUrl: './ldp-property-dna.component.html',
  styleUrls: ['./ldp-property-dna.component.scss']
})
export class LdpPropertyDnaComponent implements OnInit {
  listing: IListing;
  sub:Subscription;
  clicked:boolean=true;
  toggleArrow:string="../../../../assets/images/up-arrow.png";
  constructor(private _ldpDataService: LdpDataService) { }
  
  ngOnInit() {
    this.sub=this._ldpDataService.getListing().subscribe(res=>{this.listing=res;})
  }

  ngOnDestroy(){
    if(this.sub){
        this.sub.unsubscribe();
    }
} 

toggleFunc(){
  if(this.clicked===true){
      this.clicked=false;
      this.toggleArrow="../../../../assets/images/down-arrow.png"
      
  }else{
      this.clicked=true;
      this.toggleArrow="../../../../assets/images/up-arrow.png"        
  }
}

}

import { Component, OnInit } from '@angular/core';
import {ShareDataService} from "../../services/share-data/share-data.service";

@Component({
  selector: 'app-breadcrumbs',
  templateUrl: './breadcrumbs.component.html'
})
export class BreadcrumbsComponent implements OnInit {
  public auctionProgramValue;
  public breadcrumbLocation;

  constructor(private _shareData:ShareDataService) { }

  ngOnInit() {
    this._shareData.currentAuctionProgram2.subscribe(auctionProgram=>this.auctionProgramValue=auctionProgram);
    this._shareData.currentLocation.subscribe(location=>
      { 
        this.breadcrumbLocation=location
        console.log("check",this.breadcrumbLocation)
    });

  }

}

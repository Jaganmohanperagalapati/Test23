import { Component, OnInit, OnChanges, Input, Output, EventEmitter } from '@angular/core';
import { IListing } from "../../models/listing.model";
import { PageChangedEvent } from 'ngx-bootstrap';
import { ISearchResult } from '../../models/search-result.model';

@Component({
  selector: 'app-card-pagination',
  templateUrl: './card-pagination.component.html'
})
export class CardPaginationComponent implements OnInit, OnChanges {

  @Input('searchResult') searchResult: ISearchResult;
  @Input('curPageSize') curPageSize: any;
  @Input('moreSearchResult') moreSearchResult: any[];
  @Output() onFilterChange: EventEmitter<any> = new EventEmitter<any>();
  @Output() getMoreListings: EventEmitter<any> = new EventEmitter<any>();
  @Output() getPreviousListings: EventEmitter<any> = new EventEmitter<any>();
  public previousClickCount = 1;
  public maxSize: any;
  returnedArray: IListing[];
  public curentPg = 1;
  public availableCount: any;
  constructor() { }

  ngOnInit() {
    console.log("curr", this.curPageSize.Value)
  }

  ngOnChanges() {
    if (this.searchResult) {
      console.log('this.searchResult', this.searchResult);
      this.filterData(0, this.curPageSize.Value);
      this.availableCount = this.moreSearchResult.length / 100;
      // this.maxSize=Math.round(this.moreSearchResult.length/this.curPageSize.Value);
      console.log('maxSize', this.maxSize);
    }
  }

  pageChanged(event: PageChangedEvent): void {
    console.log("page changed", event.page)
    const startItem = (event.page - 1) * event.itemsPerPage;
    const endItem = event.page * event.itemsPerPage;
    console.log("startItem-------", startItem);
    console.log("endItem---------", endItem)
    this.filterData(startItem, endItem);
  }

  // setPageSize(id: any): void {
  //   this.curPageSize = this.lPageSizes.filter(value => value.id === Number(id))[0];
  //   console.log(this.curPageSize);
  //   this.filterData(0, this.curPageSize.Value);
  // }

  filterData(startItem, endItem) {
    // this.moreSearchResult
   // this.returnedArray = this.moreSearchResult.slice(startItem, endItem);
     this.returnedArray = this.searchResult.data.slice(startItem, endItem);
    this.onFilterChange.emit(this.returnedArray);
  }
  getMoreItems() {
    if (this.curPageSize.Value === 48) {
      this.curentPg = this.curentPg + 3;
      this.maxSize = 3;
    } else {
      this.curentPg = this.curentPg + 5;
      this.maxSize = 5;
    }

    this.getMoreListings.emit(true);
  }

  getPreviousItems() {
    if (this.previousClickCount < this.availableCount)
      if (this.curPageSize.Value === 48) {
        this.curentPg = this.curentPg - 3;
        this.maxSize = 3;
      } else {
        this.curentPg = this.curentPg - 5;
        this.maxSize = 5;
      }
    // this.getPreviousListings.emit(this.previousClickCount);
    this.previousClickCount++;
  }

  isMoreItems() {
    // if(this.previousClickCount > this.availableCount){
    //   return false;
    // }
    if (this.moreSearchResult.length > 100 ) {
      return true;
    }
  
    return false;
  }
  isMoreItemsExist(){
    if (this.searchResult.searchResultCount <= this.moreSearchResult.length ) {
      return true;
    }
    return false;
  }
}

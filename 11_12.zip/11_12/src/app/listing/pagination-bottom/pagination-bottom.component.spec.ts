import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaginationBottomComponent } from './pagination-bottom.component';

describe('PaginationBottomComponent', () => {
  let component: PaginationBottomComponent;
  let fixture: ComponentFixture<PaginationBottomComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaginationBottomComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaginationBottomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

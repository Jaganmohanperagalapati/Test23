import { Component, OnInit, Input } from '@angular/core';
import { IListing } from '../../models/listing.model';
import { LdpDataService } from '../../services/ldp-data.service';
import { Subscription } from 'rxjs';
@Component({
    selector: 'app-image-gallery',
    templateUrl: './image-gallery.component.html',
    styleUrls: ['./image-gallery.component.scss']
})
export class ImageGalleryComponent implements OnInit {
    listing:IListing
    sub:Subscription

    constructor(private _ldpDataService: LdpDataService) { }

    ngOnInit() {
        this.sub=this._ldpDataService.getListing().subscribe(res=>{this.listing=res; console.log(this.listing);})
    }

    ngOnDestroy(){
        if(this.sub){
            this.sub.unsubscribe();
        }
    }  
}

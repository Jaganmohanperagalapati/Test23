/// <reference types="@types/googlemaps" />
import { ViewChild, Component, OnInit, OnDestroy } from '@angular/core';
import { Observable } from "rxjs";
import { ListingCardComponent } from "../listing-card/listing-card.component";
import { ISearchResult } from '../../models/search-result.model';
import { IListing } from "../../models/listing.model";
import { ApiService } from '../../shared/api/api.service';
import { SearchCriteriaService } from '../../services/search-criteria.service';
import { ShareDataService } from "../../services/share-data/share-data.service";
import { PageChangedEvent } from 'ngx-bootstrap';

@Component({
    selector: 'app-srp',
    templateUrl: './srp.component.html',
    styleUrls: ['./srp.component.css']
})
export class SrpComponent implements OnInit, OnDestroy {
    @ViewChild('googlemap') googlemapElement: any;
    map: google.maps.Map;
    infoWindow = new google.maps.InfoWindow();
    // public searchResult: ISearchResult;
    public returnedArray: IListing[];
    // public _view: string = "grid";
    private _view: string = "grid";
    latitude: number = 41.85003;
    longitude: number = -87.6500523;
    zoom: number = 5;
    public singleListingData: any;

    constructor(private _api: ApiService, private _searchCriteriaService: SearchCriteriaService) { }

    async ngOnInit() {
        //TODO - populate search criteria, post listing search
        // const searchCriteria = this._searchCriteriaService.getCriteria();
        // this.searchResult = await this._api.getEndPoint<ISearchResult>('/assets/data/search-result.json');                
        // this.searchResult = await this._searchCriteriaService.search('/listings?limit=100');
    }

    ngOnDestroy() {
        this._searchCriteriaService.restoreDefaults();
    }

    isGridView(): boolean {
        return this._view === "grid";
    }

    isMapView(): boolean {
        return this._view === "map";
    }

    loadView(view: string): void {
        this._view = view;
        console.log("load view", this._view);
    }

    getListingData(listingData) {
        console.log('this.singleListingData', listingData);
        this.singleListingData = listingData;
    }

    onFilterChange(event) {
        this.returnedArray = event;
    }

    async getMoreListings(event) {
        console.log('more is called', event)
    }
}
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SplitButtonsComponent } from './split-buttons.component';

describe('SplitButtonsComponent', () => {
  let component: SplitButtonsComponent;
  let fixture: ComponentFixture<SplitButtonsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SplitButtonsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SplitButtonsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

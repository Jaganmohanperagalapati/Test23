import { Component, OnInit,Output,EventEmitter } from '@angular/core';
import {ShareDataService} from "../../services/share-data/share-data.service";


@Component({
  selector: 'app-split-buttons',
  templateUrl: './split-buttons.component.html'
})
export class SplitButtonsComponent implements OnInit {
  public _view: string = "split";
  public view;
  @Output() _viewEvent= new EventEmitter<string>()

  constructor(private _shareData:ShareDataService) { }

  ngOnInit() {
    this._shareData.listenTitle().subscribe(shareTitle => this.view = shareTitle);
  }

  
//   isMapView(): boolean {
//     return this._view === "map";
//   }

//   isSplitView(): boolean {
//     return this._view === "split";
// }
//   isGridView(): boolean {
//     return this._view === "grid";
// }
//output the view
shareView(item:string){
  this._shareData.filterTitle(item);
  // this._view=view;
  // console.log("load view",this._view);
  // this._viewEvent.emit(this._view);
}

loadView(view: string): void {
    this._view = view;
    console.log("load view",this._view);
}

}

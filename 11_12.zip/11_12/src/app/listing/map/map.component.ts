import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';
import { ISearchResult } from '../../models/search-result.model';

@Component({
    selector: 'app-map',
    templateUrl: './map.component.html',
    styleUrls: ['./map.component.scss']
})
export class MapComponent implements OnInit, OnChanges {
    @Input() searchResult: ISearchResult;
    @Input() getMapListing: any;
    listing: any;
    latitude: number = 37.090240;
    longitude: number = -95.712891;
    zoom: number = 4;
    previous;
    markerUrl: string = './assets/images/map-pin-2-copy-5.svg';
    constructor() { }

    ngOnInit() {
    }

    ngOnChanges(changes: SimpleChanges) {
        this.listing = changes.getMapListing;
        if (changes.getMapListing && changes.getMapListing.currentValue) {
            this.toggleInfoWindow(changes.getMapListing.currentValue.latitude);
        }
    }

    toggleInfoWindow(data) {
        //this.listing = true;
        console.log('this.data--', data);
        console.log('this.isInfoWindowOpened--', this.searchResult.data);
        this.searchResult.data.map((el, i) => {
            if (el.propertyInfo.latitude == data) {
                this.searchResult.data[i]['isOpen'] = true;
                console.log(this.searchResult.data[i])
            } else {
                this.searchResult.data[i]['isOpen'] = false;
            }
        })
    }
    mapReady(e) {
        let sort = document.getElementById('mapSearch');
        e.controls[google.maps.ControlPosition.LEFT_TOP].push(sort);

    }
}

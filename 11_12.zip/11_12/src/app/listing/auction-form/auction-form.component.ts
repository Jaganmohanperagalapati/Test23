import { Component, OnInit, Input } from '@angular/core';
import { IListing } from '../../models/listing.model';
@Component({
  selector: 'app-auction-form',
  templateUrl: './auction-form.component.html',
  styleUrls: ['./auction-form.component.scss']
})
export class AuctionFormComponent implements OnInit {

  constructor() { }
  @Input() listing: IListing;
  ngOnInit() {
  }
 
}

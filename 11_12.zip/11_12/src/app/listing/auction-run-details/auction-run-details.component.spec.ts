import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AuctionRunDetailsComponent } from './auction-run-details.component';

describe('AuctionRunDetailsComponent', () => {
  let component: AuctionRunDetailsComponent;
  let fixture: ComponentFixture<AuctionRunDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AuctionRunDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuctionRunDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

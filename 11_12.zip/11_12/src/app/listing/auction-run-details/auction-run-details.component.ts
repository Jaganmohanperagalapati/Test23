import { Component, OnInit, Input } from '@angular/core';
import { IAuctionRun } from '../../models/auction-run.model';

@Component({
    selector: 'app-auction-run-details',
    templateUrl: './auction-run-details.component.html',
    styleUrls: ['./auction-run-details.component.scss']
})
export class AuctionRunDetailsComponent implements OnInit {
    @Input() auctionRun: IAuctionRun;

    constructor() { }

    ngOnInit() {
    }
}
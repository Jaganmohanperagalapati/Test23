import { Component, OnInit } from '@angular/core';
import { ISearchResult } from '../../models/search-result.model';
import { IListing } from "../../models/listing.model";
import { ApiService } from '../../shared/api/api.service';
import { SearchCriteriaService } from '../../services/search-criteria.service';
import { ShareDataService } from "../../services/share-data/share-data.service";
import { IAuctionRun } from '../../models/auction-run.model';

@Component({
    selector: 'app-split-screen',
    templateUrl: './split-screen.component.html'
})
export class SplitScreenComponent implements OnInit {
  public searchResult: ISearchResult;
  public searchResp: any;
  public moreSearchResult: any[];
  public returnedArray: IListing[];
  public continutionToken = '';
  title = 'Auction';
  flag_1: number;

  lPageSizes: any[] = [
    { id: 1, Value: '24' },
    { id: 2, Value: '48' }
  ];
  curPageSize: any = this.lPageSizes[0];
  public singleListingData: any
  public view: string;
  public auctionRun: IAuctionRun;

  constructor(private _api: ApiService, private _searchCriteriaService: SearchCriteriaService, private _shareData: ShareDataService) {
    this.flag_1 = 1;
  }


  async ngOnInit() {
   // We only initiate a search call if SRP is being loaded directly or if "View All" is clicked from Auction Calendar
        // Other areas of the site already call this._shareData.getSResp so we need to avoid duplicate call.
        if (!this._shareData.alreadySearched() || this._searchCriteriaService.isAuctionCalendarSearch()) {
          this._shareData.getSResp({});

          // blank out auction fields in case user triggers another search from SRP
          // if we don't, the search will be treated as if coming from auction calendar screen
          this._searchCriteriaService.restoreDefaults();
      }

    this._shareData.listenTitle().subscribe(shareTitle => this.view = shareTitle);
    //this._shareData.listenData().subscribe((sr1:ISearchResult) => this.searchResult = sr1);
    await this._shareData.listenData().subscribe((sr1: ISearchResult) => {
      this.searchResp = {};
      console.log("check speed -5", sr1)
      //this.searchResult=sr1;
      this.searchResp = sr1;
      if (sr1 != undefined) {
        console.log('data', sr1);
        this.searchResult = sr1;
        this.moreSearchResult = [];
        this.auctionRun = this._searchCriteriaService.getAuctionRun();
        if (this.searchResult.data) {
          console.log('(this.searchResult.data', this.searchResult.data);
          this.continutionToken = this.searchResult.continuationToken;
          this.moreSearchResult = this.moreSearchResult.concat(this.searchResult.data);
          console.log('data', sr1)
        }
        // console
      }

      console.log("check speed -6", this.searchResult);
    }
    );



    // this.searchResult = await this._searchCriteriaService.search('/listings?limit=100');
    //this.moreSearchResult.data = this.moreSearchResult.data.concat(this.searchResult.data);
    //this.moreSearchResult = this.searchResult.data;

  }

  receiveView($event) {
    this.view = $event
  }


  public switchCondition(): void {
    this.flag_1 += 1;
    if (this.flag_1 == 4)
      this.flag_1 = 1;
  }
  onFilterChange(event) {
    this.returnedArray = event;
  }

  onListingDropChange(event) {
    console.log('drop change', event);
    this.curPageSize = event;

  }
  getListingData(listingData) {
    console.log('this.singleListingData', listingData);
    this.singleListingData = listingData;
  }

  async getMoreListings(event) {
    console.log('Before listings', this.moreSearchResult);
    let moreListings: ISearchResult;
    moreListings = await this._searchCriteriaService.search('/listings?limit=100&ContinuationToken=' + this.continutionToken);
    this.continutionToken = moreListings.continuationToken;
    this.moreSearchResult = this.moreSearchResult.concat(moreListings.data);
    console.log('this.moreSearchResult', this.moreSearchResult);
  }

  getPreviousListings(previousCount) {
    let startIndex = previousCount * 100;
    let endIndex = startIndex + 100;
    this.searchResult.data = this.moreSearchResult.slice(startIndex, endIndex);
  }
}

import { Component, OnInit,EventEmitter,Output,Input } from '@angular/core';

@Component({
  selector: 'app-listings-dropdown',
  templateUrl: './listings-dropdown.component.html',
})
export class ListingsDropdownComponent implements OnInit {
  @Input('searchResultCount') searchResultCount: any;
  @Input('moreSearchResult') moreSearchResult: any[];
  @Input('lPageSizes') lPageSizes: any;
  curPageSize: any;
  @Output() onChange: EventEmitter<any> = new EventEmitter<any>();
  constructor() { }

  ngOnInit() {
    this.curPageSize=this.lPageSizes[0];
  }
  setPageSize(id: any): void {
    this.curPageSize = this.lPageSizes.filter(value => value.id === Number(id))[0];
    console.log(this.curPageSize);
    this.onChange.emit(this.curPageSize);
    // this.filterData(0, this.curPageSize.Value);
  }
}

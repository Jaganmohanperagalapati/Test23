import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListingsDropdownComponent } from './listings-dropdown.component';

describe('ListingsDropdownComponent', () => {
  let component: ListingsDropdownComponent;
  let fixture: ComponentFixture<ListingsDropdownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListingsDropdownComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListingsDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

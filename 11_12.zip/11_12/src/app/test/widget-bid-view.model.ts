export interface IWidgetBidView {
    id: number;
    widgetId: number;
    model: string;
    name: string;
    description: string;
    price: number;
    bidAmount: number;
    startDTTM: string;
    endDate: string;
    currentDTTM: string;
    ctaButtonText: string;
}
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-state-images',
  templateUrl: './state-images.component.html'
})
export class StateImagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

export const environment = {
    production: true,
    // Paths (not really, just placeholders)
    apiRoot: 'https://uidev.exostechnology.com/api/listingsvc',
    apiPath: '/v1'
};

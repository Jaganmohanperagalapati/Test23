import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { Agent } from '../kyfb/agent';
import { JsonConvert, OperationMode, ValueCheckingMode } from 'json2typescript';
import { SnotifyService } from 'ng-snotify';
import { environment } from '../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class AgentService {
    constructor(private http: HttpClient, private messageService: SnotifyService) { }

    getAgent(agentNumber: number): Observable<Agent> {
        const query = new HttpParams()
            .set('method', 'getAgentInfo')
            .set('agentNumber', agentNumber.toString());

        return this.http.get<Agent>(environment.agentApi.baseUrl, {params: query})
            .pipe(
                map((response: any) => {
                    const jsonConvert: JsonConvert = new JsonConvert();
                    let agent: Agent;

                    if (!environment.production) {
                        jsonConvert.operationMode = OperationMode.LOGGING; // print some debug data
                    }

                    try {
                        agent = (<any>jsonConvert).deserialize(response, Agent);
                    } catch (e) {
                        this.messageService.error(
                            'There was an error parsing the response from the server.',
                            'Error!',
                            {showProgressBar: false, timeout: 0}
                        );

                        if (!environment.production) {
                            console.log((<Error>e));
                        }
                    }

                    return agent;
                }),
            );
    }
}

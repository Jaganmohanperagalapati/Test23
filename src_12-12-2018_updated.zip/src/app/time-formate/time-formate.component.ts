import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kyfb-time-formate',
  templateUrl: './time-formate.component.html',
  styleUrls: ['./time-formate.component.scss']
})
export class TimeFormateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

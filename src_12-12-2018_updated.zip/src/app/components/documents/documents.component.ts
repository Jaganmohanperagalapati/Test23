import { Component, OnInit } from '@angular/core';
import { getToday } from '@progress/kendo-angular-dateinputs/dist/es2015/util';
// import { Time } from '@angular/common';

@Component({
  selector: 'kyfb-documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.scss']
})



export class DocumentsComponent implements OnInit {
  public time = new Date();
  public date = new Date();
  public today = new Date();
  // public value: Date = new Date(2000, 2, 10, 10, 30, 0);


  public steps: any = { hour: 1, minute: 15 };
  public value: Date = new Date(2000, 2, 10, 10, 30, 0);
  public values: Date = new Date(2000, 2, 10);
  public min: Date = new Date(2000, 2, 10);
  public maxDate: Date = new Date();
  public maxTime: Date = null;
  datedd: any = "";
  // public maxTime: Date = new Date();










  constructor() { }

  ngOnInit() {

  }

  dateChange(event) {
    this.value=null;
    this.maxTime=null;
    if (this.getFormattedDate(event) == this.getFormattedDate(new Date())) {
      this.maxTime = new Date();
    }
  }

  getFormattedDate(date) {
    let year = date.getFullYear();

    let month = (1 + date.getMonth()).toString();
    month = month.length > 1 ? month : '0' + month;

    let day = date.getDate().toString();
    day = day.length > 1 ? day : '0' + day;

    return month + '/' + day + '/' + year;
  }

}



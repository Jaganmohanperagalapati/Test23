import { Component, OnInit } from '@angular/core';
import { PortalService } from 'src/app/services/portal.service';
import { PaymentsService } from 'src/app/services/payments.service';
import { Router } from '@angular/router';

@Component({
  selector: 'kyfb-payments',
  templateUrl: './payments.component.html',
  styleUrls: ['./payments.component.scss']
})
export class PaymentsComponent implements OnInit {
  message: any[];
  selectedData: any[];
  public currentDate = new Date();
  public paymentsSummary;
  public totalAmount: number = 0;
  public portalService: PortalService;
  dateTime = new Date();
  selectedAmount: any[];
  constructor(portalService: PortalService, private data: PaymentsService, private router: Router) {
    this.portalService = portalService;
  }
  headings = ["Policy/Acct#", "Description", "Due Date"];
  acctheadings = ["Accounts Currently Due", " Balance Due", "No Balance Due at This Time"];
  pendings = ["Policy/Acct#", "Description", "Payment Date", "Payment Amount", "status"];
  scheduleds = ["Policy/Acct#", "Description", "Due Date", "Payment Amount", "Payment type", "Scheduled date", "Action"];
  ngOnInit() {
    this.selectedAmount = [];
    this.selectedData = [];
    this.data.currentMessage.subscribe(message => this.message = message)
    // this.paymentsInfo();
  }

  newMessage() {
    this.data.changeMessage(this.selectedData);
    this.router.navigate(['./payment-summary']);
  }

  public datediff(date1, currDate) {
    let date11 = new Date(date1);
    let date22 = new Date(currDate);
    var timeDiff1 = Math.abs(date22.getTime() - date11.getTime());
    var timeDiff2 = Math.abs(date11.getTime() - date22.getTime());
    var diffDays1 = Math.ceil(timeDiff1 / (1000 * 3600 * 24));
    var diffDays2 = Math.ceil(timeDiff2 / (1000 * 3600 * 24));
    return diffDays1 <= 5 || diffDays2 <= 5;
  }

  public sumAmount(event, i, pnumber,description): void {  // event will give you full breif of action
    //console.log(pnumber)
    let tempArr=[];
    const newVal = event.target.value;
    this.totalAmount = Number(newVal) + Number(this.totalAmount);
    this.selectedAmount[i] = newVal;
    tempArr['policyNumber']=pnumber;
    tempArr['description']=description;
    tempArr['amount']=newVal;
    this.selectedData[i] = tempArr;
    this.totalAmount = this.selectedAmount.reduce(function (a, b) { return Number(a) + Number(b); }, 0);
  }

  checkSummaryIndStatus(policyNum, purpose) {
    if (purpose == "isExists") {
      let status = false;
      this.portalService.accountInformation.policies.policyInfo.forEach((element, key) => {
        if (policyNum == element.policyNumber && element.scheduledPaymentInd) {
          status = true;
        }
      });
      return status;
    } else {
      let description = "";
      this.portalService.accountInformation.policies.policyInfo.forEach((element, key) => {
        if (policyNum == element.policyNumber) {
          description = element.getDescription();
        }
      });
      return description;
    }
  }

  /* private paymentsInfo() {
     this.paymentsService.getPaymentsInformation()
       .subscribe((candidates) => {
         if(candidates.status.statusCode=="00"){
           if(candidates.policies.policyInfo){
             this.paymentsSummary=candidates.policies.policyInfo;
           }
         }
       },
         error => { }
       );
   }*/


}

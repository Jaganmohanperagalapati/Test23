import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'kyfb-confirmation-auto',
  templateUrl: './confirmation-auto.component.html',
  styleUrls: ['./confirmation-auto.component.scss']
})
export class ConfirmationAutoComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }

  goToPrevious(){
    this.router.navigate(['/claims/claims-tabs/contact-info']);
  }

  submitClaim(){
    this.router.navigate(['/claims/complete']);
  }

}

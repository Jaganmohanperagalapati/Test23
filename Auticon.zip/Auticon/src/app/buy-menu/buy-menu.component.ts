import { Component, OnInit } from '@angular/core';
import {ShareDataService} from "../services/share-data/share-data.service";

@Component({
  selector: 'app-buy-menu',
  templateUrl: './buy-menu.component.html',
  styleUrls: ['./buy-menu.component.css']
})
export class BuyMenuComponent implements OnInit {
  auctionProgramValue:string;
  auctionProgramData:string[]=[
    "All Homes for Sale",
    "Bank-Owned Homes",
    "Foreclosures",
    "Newly Foreclosed",
    "Broker Co-op Available",
    "Short Sale"
  ];

  constructor(private _shareData:ShareDataService) { }

  ngOnInit() {
    
    //if the search box is empty, then the default value should be "All homes for sale!"
    this.auctionProgramValue="All Homes for Sale";
    this._shareData.currentAuctionProgram.subscribe(auctionProgram=>this.auctionProgramValue=auctionProgram);
    this._shareData.changeAuctionProgram(this.auctionProgramValue);
  }
  

onAuctionProgramChange(val:string):void{
  console.log("val",val)
  this._shareData.changeAuctionProgram(val)

  
}
}

import { Injectable } from '@angular/core';

@Injectable()
export class SearchCriteriaService {
    private _searchContext: string;
    private _addressObj: any;
    constructor() { }

    setSearchContext(searchContext: string): void {
        this._searchContext = searchContext;
        console.log("service st", this._searchContext)
    }

    setAddressEntity(addressEntity: any): void {
        this._addressObj = addressEntity;
        // console.log("service",this._addressObj)
    }

    getCriteria(): any {
        //TODO - ensure we whitelist incoming URL values (e.g., bank-owned-homes, foreclosures, occupied, etc.)
        return {
            searchContext: this._searchContext,
            // city: this._addressObj['city'],
            // county: this._addressObj['city'],
            // postal_code:this._addressObj['postal_code'],
            // stateCode:this._addressObj['stateCode'],
            // street:this._addressObj['street']

        };
    }
}

import { Injectable } from '@angular/core';
import {BehaviorSubject} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class ShareDataService {
  private auctionProgram=new BehaviorSubject<string>("All Homes for Sale");
  currentAuctionProgram=this.auctionProgram.asObservable();
  private auctionProgram2=new BehaviorSubject<string>("");
  currentAuctionProgram2=this.auctionProgram2.asObservable();
  private location=new BehaviorSubject<string>("");
  currentLocation=this.location.asObservable();

  constructor() { 
    // console.log("service constructor",this.currentAuctionProgram)
  }
  setAuctionProgram(data:any){
    this.auctionProgram = data;
    console.log("auctionProgram",this.auctionProgram);
    this.changeAuctionProgram(data)
}

getAuctionProgram():any{
    return this.auctionProgram;
}
changeAuctionProgram(message:string){
  this.auctionProgram.next(message)
  console.log("cap",this.auctionProgram)
}
changeAuctionProgram2(auctionProgramValue:string){
  this.auctionProgram2.next(auctionProgramValue);
  console.log("cap2",this.auctionProgram2);
}
onChangeLocation(currLocation:string){
  console.log("currl",currLocation)
  this.location.next(currLocation)
  
}
}

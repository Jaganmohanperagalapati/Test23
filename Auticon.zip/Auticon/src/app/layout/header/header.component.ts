import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute, Params } from '@angular/router';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
  export class HeaderComponent implements OnInit {
    advanceFilters={
      dateFilter:false,
      occupancyFilter:false,
      propertyTypeFilter:false,
      showOnly:false,
      moreFilters:false

    }
    filterObj={
      startDate:"",
      endDate:"",
      occupancyStatus:"",
      propertyType:"",
      showOnly:"",
      auctionPeriod:"",
      auctionProgram:"",
      bidType:"",
      // minPriceRange:"",
      // maxPriceRange:"",
      minSqft:"",
      maxSqft:"",
      minYear:"",
      maxYear:""
      
    };
    occupancyData:any[]=["Any","Occupied","Vacant"];
    propertyTypeData:any=[
      {name:"Any",isChecked:true},
      {name:"Single Family Home",isChecked:false},
      {name:"Multi Family Home",isChecked:false},
      {name:"Condo",isChecked:false},
      {name:"Manufactured - Mobile",isChecked:false},
      {name:"Land",isChecked:false},
      {name:"Commercial",isChecked:false},
      {name:"Planned Unit Development",isChecked:false},
      {name:"Special Purpose",isChecked:false}
    ];
    

    showOnlyData:any=[
      {name:"Any",isChecked:true},
      {name:"Last Chance to Bid",isChecked:false},
      {name:"Absolute Auction",isChecked:false},
      {name:"Financing Available",isChecked:false},
      {name:"No Buyer's Premium",isChecked:false},
      {name:"Broker Co-Op Available",isChecked:false}];
   
    auctionPeriodData:any=[
      {name:"Any",isChecked:true},
      {name:"Pre-Auction",isChecked:false},
      {name:"Auction",isChecked:false},
      {name:"Post-Auction",isChecked:false},
      ];
    auctionProgramData:any=[
      {name:"Any",isChecked:true},
      {name:"Trustee - Foreclosure",isChecked:false},
      {name:"Newly Foreclosed",isChecked:false},
      {name:"Bank-Owned REO",isChecked:false},
      {name:"Short-Sale",isChecked:false}
    ];
 
  bidTypeData:any=[
    {name:"Any",isChecked:true},
    {name:"Online Auction",isChecked:false},
    {name:"Onsite Auction",isChecked:false},
    ];

    bedData:any[]=[
     {name:"Any",isChecked:true},
     {name:1,isChecked:false},
     {name:2,isChecked:false},
     {name:3,isChecked:false},
     {name:4,isChecked:false}];
  
  bathData:any[]=[
    {name:"Any",isChecked:true},
    {name:1,isChecked:false},
    {name:2,isChecked:false},
    {name:3,isChecked:false},
    {name:4,isChecked:false}];
  

  propertyType:string[]=[];
  showOnly:string[]=[];
  auctionPeriod:string[]=[];
  auctionProgram:string[]=[];
  bidType:string[]=[];
  a:boolean=true;
  public isCheckHome;
    constructor(private activatedRoute: ActivatedRoute, private router:Router) { }

    ngOnInit() {
this.propertyType.push("Any");
this.showOnly.push("Any");
this.auctionPeriod.push("Any");
this.auctionProgram.push("Any");
this.bidType.push("Any");
this.isCheckHome=this.isHome(this.activatedRoute.snapshot.url.length);
console.log('this.isHome(this.activatedRoute.snapshot.url.length-hetdd)', this.isCheckHome); 
      
    }
    
    isHome(isLength){
      if(isLength ==0){
      return false;
      }else{
      return true;
      }
      }
// toggle filters
  onDateFilter():void{
this.advanceFilters.dateFilter=!this.advanceFilters.dateFilter;
  }  
  onOccupancyFilter():void{
    this.advanceFilters.occupancyFilter=!this.advanceFilters.occupancyFilter;
  }
  onPropertyTypeFilter():void{
    this.advanceFilters.propertyTypeFilter=!this.advanceFilters.propertyTypeFilter; 
  }
  onShowOnly():void{
    this.advanceFilters.showOnly=!this.advanceFilters.showOnly
  }
  onMoreFilters():void{
    this.advanceFilters.moreFilters=!this.advanceFilters.moreFilters;
  }

  //Filters
  
  onOccupancyOption(e:any):void{
    console.log("occupancy event",e) 
    this.filterObj.occupancyStatus=e.target.value; 
    console.log("val",this.filterObj.occupancyStatus)
  }

  onPropertyTypeCheck(e:any):void{
    this.checkboxArrayUpdate(e,this.propertyType,this.propertyTypeData);
  }

  onShowOnlyCheck(e:any):void{
    this.checkboxArrayUpdate(e,this.showOnly,this.showOnlyData);
  }

  onAuctionPeriodCheck(e:any):void{
    this.checkboxArrayUpdate(e,this.auctionPeriod,this.auctionPeriodData);
  }

onAuctionProgramCheck(e:any):void{
  console.log("name-----------",e.target.name);
  this.checkboxArrayUpdate(e,this.auctionProgram,this.auctionProgramData)
}

onBidTypeCheck(e:any):void{
  this.checkboxArrayUpdate(e,this.bidType,this.bidTypeData);
}
onBedOption(e:any):void{
  console.log("bed",e.target.id)
  // this.filterObj.beds=e.target.value;
  this.filterObj["beds"]=Number(e.target.value); 
}

onBathOption(e:any):void{
  this.filterObj["baths"]=Number(e.target.value); 
}

  // apply buttons:
  onApply():void{
    if(!this.propertyType.includes("Any")){
      this.filterObj.propertyType=this.propertyType.join()
    }
    // console.log("filterObj property join",this.filterObj.propertyType)
    if(!this.showOnly.includes("Any")){
      this.filterObj.showOnly=this.showOnly.join();
    }
    if(!this.auctionPeriod.includes("Any")){
      this.filterObj.auctionPeriod=this.auctionPeriod.join()
    }
    if(!this.auctionProgram.includes("Any")){
      this.filterObj.auctionProgram=this.auctionProgram.join()
    }
    if(!this.bidType.includes("Any")){
      this.filterObj.bidType=this.bidType.join()
    }
    
    console.log("filterObj",this.filterObj)
  }

  onDateApply():void{
    console.log("sd",this.filterObj.startDate);
    console.log("ed",this.filterObj.endDate);
    console.log(this.filterObj)
  }
  onOccupancyApply():void{
    console.log("----Make Occupancy filter service call----")
    console.log("occFil",this.filterObj)
  }
  onOccupancyReset(){
    this.filterObj.occupancyStatus="";
    console.log("reset",this.filterObj)
  }

  onPropertyTypeApply():void{
    this.filterObj.propertyType=this.propertyType.join()
    console.log("filterObj property join",this.filterObj.propertyType)
    console.log("finale",this.filterObj);
  }
  onPropertyTypeReset(){
    this.onCheckboxReset(this.propertyType,this.propertyTypeData);
  }
  onShowOnlyApply():void{
    this.filterObj.showOnly=this.showOnly.join()
    console.log("filterObj show only join",this.filterObj.showOnly)
    console.log("finale",this.filterObj);
  }
  onShowOnlyReset(){
    this.onCheckboxReset(this.showOnly,this.showOnlyData);
  }
  onMoreFiltersApply():void{
    this.filterObj.auctionPeriod=this.auctionPeriod.join()
    this.filterObj.auctionProgram=this.auctionProgram.join()
    this.filterObj.bidType=this.bidType.join()
    
    console.log("filterObj",this.filterObj)
    }
    onMoreFiltersReset(){
      this.onCheckboxReset(this.auctionPeriod,this.auctionPeriodData);
      this.onCheckboxReset(this.auctionProgram,this.auctionProgramData);
      this.onCheckboxReset(this.bidType,this.bidTypeData);
      this.filterObj.auctionPeriod="";
      this.filterObj.auctionProgram="";
      this.filterObj.bidType="";
      // this.filterObj.minPriceRange="";
      // this.filterObj.maxPriceRange="";
      this.filterObj.minSqft="";
      this.filterObj.maxSqft="";
      this.filterObj.minYear="";
      this.filterObj.maxYear="";
      console.log("filter obj reset",this.filterObj)
    }


    checkboxArrayUpdate(val:any,arr:string[],arrData:Array<any>):void{
      console.log("property type value",val.target.value)
      if(val.target.value=="Any" && val.target.checked==true){
        if(arr.length>0) arr.splice(0,arr.length);
        console.log("removed array",arr)
        console.log("any?",val.target.value)
        arr.push(val.target.value)
        console.log("property",arr); 
        arrData.forEach(el => {
          if(el.name!="Any"){
            el.isChecked=false;
          }
        });
      }
      else if(val.target.value!="Any" && val.target.checked==true){
        if(arr.includes("Any")){
          arrData.forEach(el=>{
            if(el.name=="Any"){
              el.isChecked=false;
            } 
          })
          arr.splice(arr.indexOf("Any"),1);
          console.log("rem any",arr)
        }
        arr.push(val.target.value)
        console.log("property",arr)
      }
      else if(val.target.checked==false){
        if(arr.includes(val.target.value)){
          arr.splice(arr.indexOf(val.target.value),1)
        }
        console.log("property false",arr)
      }
    }

    onCheckboxReset(arr,arrData){
      arrData.forEach(el=>{
        if(el.isChecked==true){
          el.isChecked=false
        }
        console.log("checked",el.isChecked)
      })
      if(arr.length>0) arr.splice(0,arr.length);
      console.log("reset arr",arr)
    }

    onRadioButtonReset(arr:any[]){
      arr.forEach(el=>{
        if(el.isChecked=true){

          el.isChecked=false
          console.log("radio el",el);
        }
      })
    }
   
      
  }

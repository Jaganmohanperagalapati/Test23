import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html'
})
export class NotificationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

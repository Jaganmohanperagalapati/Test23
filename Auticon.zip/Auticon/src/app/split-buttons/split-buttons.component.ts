import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-split-buttons',
  templateUrl: './split-buttons.component.html'
})
export class SplitButtonsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { FormGroup } from '@angular/forms'

export abstract class BaseFormComponent {
    // This object will hold the messages to be displayed to the user
    // Each key in this object has the same name as the corresponding form control
    formErrors: any = {};

    // This object contains all the validation messages for the form
    validationMessages: any = {};

    constructor() { }

    logValidationErrors(group: FormGroup): void {
        Object.keys(group.controls).forEach((key: string) => {
            const abstractControl = group.get(key);
            if (abstractControl instanceof FormGroup) {
                this.logValidationErrors(abstractControl);
            } else {
                this.formErrors[key] = '';
                if (abstractControl && !abstractControl.valid && (abstractControl.touched || abstractControl.dirty)) {
                    const messages = this.validationMessages[key];

                    for (const errorKey in abstractControl.errors) {
                        if (errorKey) {
                            this.formErrors[key] += messages[errorKey] + ' ';
                        }
                    }
                }
            }
        });
    }
}
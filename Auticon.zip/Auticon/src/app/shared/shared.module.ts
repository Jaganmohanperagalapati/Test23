import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http'
import { ApiService } from './api/api.service';
import { StorageService } from './storage/storage.service';
import { EmployeeService } from '../test/employee.service';
import { SearchCriteriaService } from '../services/search-criteria.service';
import { LdpDataService } from '../services/ldp-data.service';
import { CountdownService } from '../services/countdown.service';
import { CountdownComponent } from '../countdown/countdown.component';

@NgModule({
    declarations: [
        CountdownComponent
    ],
    imports: [
        CommonModule,
        HttpClientModule
    ],
    exports: [
        CountdownComponent
    ]
})
export class SharedModule {
    public static forRoot(): ModuleWithProviders {
        return {
            ngModule: SharedModule,
            providers: [
                ApiService,
                EmployeeService,
                StorageService,
                SearchCriteriaService,
                LdpDataService,
                CountdownService
            ]
        };
    }
}

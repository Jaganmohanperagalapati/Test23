import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpPropertyDocumentsComponent } from './ldp-property-documents.component';

describe('LdpPropertyDocumentsComponent', () => {
  let component: LdpPropertyDocumentsComponent;
  let fixture: ComponentFixture<LdpPropertyDocumentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpPropertyDocumentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpPropertyDocumentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

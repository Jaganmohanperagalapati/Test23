import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpSellerInformationComponent } from './ldp-seller-information.component';

describe('LdpSellerInformationComponent', () => {
  let component: LdpSellerInformationComponent;
  let fixture: ComponentFixture<LdpSellerInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpSellerInformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpSellerInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

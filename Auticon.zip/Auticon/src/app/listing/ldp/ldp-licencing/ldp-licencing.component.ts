import { Component, OnInit, Input } from '@angular/core';
import { IListing } from '../../../models/listing.model';

@Component({
  selector: 'app-ldp-licencing',
  templateUrl: './ldp-licencing.component.html',
  styleUrls: ['./ldp-licencing.component.scss']
})
export class LdpLicencingComponent implements OnInit {
@Input() listing:IListing;
  constructor() { }

  ngOnInit() {
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpDisclaimerComponent } from './ldp-disclaimer.component';

describe('LdpDisclaimerComponent', () => {
  let component: LdpDisclaimerComponent;
  let fixture: ComponentFixture<LdpDisclaimerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpDisclaimerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpDisclaimerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

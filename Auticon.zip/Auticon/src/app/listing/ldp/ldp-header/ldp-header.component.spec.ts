import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpHeaderComponent } from './ldp-header.component';

describe('LdpHeaderComponent', () => {
  let component: LdpHeaderComponent;
  let fixture: ComponentFixture<LdpHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

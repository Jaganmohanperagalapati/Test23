import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../../shared/api/api.service';
import { IListing } from '../../models/listing.model';
import { ISearchResult } from '../../models/search-result.model';
import { LdpDataService } from '../../services/ldp-data.service';

@Component({
    selector: 'app-ldp',
    templateUrl: './ldp.component.html',
    styleUrls: ['./ldp.component.css']
})
export class LdpComponent implements OnInit {
    public listing: IListing;

    constructor(private route: ActivatedRoute, private _api: ApiService, private _ldpDataService: LdpDataService) { }

    async ngOnInit() {
        const address = this.route.snapshot.url[0].path;
        // const searchResult = await this._api.getEndPoint<ISearchResult>('/assets/data/search-result.json');
        const searchResult = await this._api.getEndPoint<ISearchResult>("http://listingsvc-s1-v1.dev.exostechnology.local/api/v1/listings?propertyType=Mobile");
        // this.listing = searchResult.listings.filter(l => l.websiteURL.indexOf(address) > -1)[0];
        this.listing = searchResult.data.filter(l => l.propertyInfo.websiteUrl.indexOf(address) > -1)[0];
        this._ldpDataService.setListing(this.listing);
    }

    isComingSoon(): boolean {
        return false;
    }

    isAuctionReady(): boolean {
        return true;
    }
}

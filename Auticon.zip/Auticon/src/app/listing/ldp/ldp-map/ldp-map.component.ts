import { Component, OnInit } from '@angular/core';
import { IListing } from '../../../models/listing.model';
import { LdpDataService } from '../../../services/ldp-data.service';

@Component({
    selector: 'app-ldp-map',
    templateUrl: './ldp-map.component.html',
    styleUrls: ['./ldp-map.component.scss']
})
export class LdpMapComponent implements OnInit {
    listing: IListing;

    constructor(private _ldpDataService: LdpDataService) { }

    ngOnInit() {
        this.listing = this._ldpDataService.getListing();
    }
}

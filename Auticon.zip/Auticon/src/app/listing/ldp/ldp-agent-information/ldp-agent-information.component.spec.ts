import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpAgentInformationComponent } from './ldp-agent-information.component';

describe('LdpAgentInformationComponent', () => {
  let component: LdpAgentInformationComponent;
  let fixture: ComponentFixture<LdpAgentInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpAgentInformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpAgentInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

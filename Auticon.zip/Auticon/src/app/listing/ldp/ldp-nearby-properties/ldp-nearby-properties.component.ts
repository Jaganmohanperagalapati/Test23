import { Component, OnInit, Input } from '@angular/core';
import { IListing } from '../../../models/listing.model';

@Component({
  selector: 'app-ldp-nearby-properties',
  templateUrl: './ldp-nearby-properties.component.html',
  styleUrls: ['./ldp-nearby-properties.component.scss']
})
export class LdpNearbyPropertiesComponent implements OnInit {
  @Input() listing:IListing;
  constructor() { }
arr
  
ngOnInit() {
    // this.arr=[this.listing.propertyType, this.listing.occupancyStatus, this.listing.bedrooms+" BD", this.listing.fullBathrooms+" BA", this.listing.interiorSqFt+" SF"]
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LdpNearbyPropertiesComponent } from './ldp-nearby-properties.component';

describe('LdpNearbyPropertiesComponent', () => {
  let component: LdpNearbyPropertiesComponent;
  let fixture: ComponentFixture<LdpNearbyPropertiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LdpNearbyPropertiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LdpNearbyPropertiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

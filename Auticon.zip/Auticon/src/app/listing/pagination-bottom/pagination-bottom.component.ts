import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagination-bottom',
  templateUrl: './pagination-bottom.component.html'
})
export class PaginationBottomComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

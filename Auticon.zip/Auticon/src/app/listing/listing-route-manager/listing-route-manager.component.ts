import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

import { SrpComponent } from '../srp/srp.component'
import { LdpComponent } from '../ldp/ldp.component'
import { SearchCriteriaService } from '../../services/search-criteria.service';

@Component({
    selector: 'app-listing-route-manager',
    templateUrl: './listing-route-manager.component.html',
    styleUrls: ['./listing-route-manager.component.scss']
})
export class ListingRouteManagerComponent implements OnInit {
    public currentComponent;

    constructor(private router: Router, private activatedRoute: ActivatedRoute,
        private location: Location, private _searchCriteriaService: SearchCriteriaService) { }

    ngOnInit() {
        if (this.router.url.indexOf('/property-details') > -1) {
            this.currentComponent = LdpComponent;
        } else {
            if (!this.urlEndsWithProperties()) {
                this._searchCriteriaService.setSearchContext(this.getSearchContext());
                this.location.replaceState('/properties');
            }

            this.currentComponent = SrpComponent;
        }
    }

    urlEndsWithProperties(): boolean {
        let result = false;

        const urlPart = '/properties';
        const index = this.router.url.lastIndexOf(urlPart);
        if (index + urlPart.length === this.router.url.length) {
            result = true;
        }

        return result;
    }

    getSearchContext(): string {
        if (this.router.url.indexOf('/foreclosures/all') > -1) {
            return 'foreclosures';
        }

        const index = this.router.url.lastIndexOf('/');
        return this.router.url.substring(index + 1);;
    }
}

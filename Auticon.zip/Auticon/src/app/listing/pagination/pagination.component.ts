
import { Component, OnInit, OnChanges, Input, Output, EventEmitter } from '@angular/core';
import { IListing } from "../../models/listing.model";
import { PageChangedEvent } from 'ngx-bootstrap';
import { ISearchResult } from '../../models/search-result.model';

@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.scss']
})
export class PaginationComponent implements OnInit, OnChanges {
  lPageSizes: any[] = [
    { id: 1, Value: '12' },
    { id: 2, Value: '24' }
  ];
  curPageSize: any = this.lPageSizes[0];
  @Input('searchResult') searchResult: ISearchResult;
  @Output() onFilterChange: EventEmitter<any> = new EventEmitter<any>();

  returnedArray: IListing[];
  constructor() { }

  ngOnInit() {
  }

  ngOnChanges() {
    if (this.searchResult) {
      this.filterData(0, this.curPageSize.Value);
    }
  }

  pageChanged(event: PageChangedEvent): void {
    const startItem = (event.page - 1) * event.itemsPerPage;
    const endItem = event.page * event.itemsPerPage;
    this.filterData(startItem, endItem);
  }

  setPageSize(id: any): void {
    this.curPageSize = this.lPageSizes.filter(value => value.id === Number(id))[0];
    console.log(this.curPageSize);
    this.filterData(0, this.curPageSize.Value);
  }

  filterData(startItem, endItem) {
    this.returnedArray = this.searchResult.data.slice(startItem, endItem);
    this.onFilterChange.emit(this.returnedArray);
  }

}

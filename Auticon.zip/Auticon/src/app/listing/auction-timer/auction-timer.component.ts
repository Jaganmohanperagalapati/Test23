import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { ApiService } from '../../shared/api/api.service';
import { CountdownService } from '../../services/countdown.service';
import { IListing } from '../../models/listing.model';
import { IListingView } from '../../models/listing-view.model';
import { ISearchResult } from '../../models/search-result.model';

@Component({
    selector: 'app-auction-timer',
    templateUrl: './auction-timer.component.html',
    styleUrls: ['./auction-timer.component.scss']
})
export class AuctionTimerComponent implements OnInit {
    @Input() listing: IListing;
    listingView: IListingView;

    constructor(private _api: ApiService, private _countdownService: CountdownService) { }

    async ngOnInit() {
        const searchResult = await this._api.getEndPoint<ISearchResult>('/assets/data/dashboard-result.json');
        // await this._countdownService.initialize(searchResult.listings.slice(0, 1));
        this.listingView = this._countdownService.getListingViews()[0];
    }

    async onSubmitBidClick() {
        this._countdownService.handleOnSubmitBidClick(this.listingView);
    }

    async onCountdownComplete() {
        this._countdownService.handleOnCountdownComplete(this.listingView);
    }

    isUserPartOfBidding(): boolean {
        return this._countdownService.isUserPartOfBidding(this.listingView);
    }

    isUserHighestBidder(): boolean {
        return this._countdownService.isUserHighestBidder(this.listingView);
    }

    isAuctionEnded(): boolean {
        return this._countdownService.isAuctionEnded(this.listingView);
    }

    ngOnDestroy() {
        this._countdownService.terminate();
    }
}
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-how-to-bid',
  templateUrl: './how-to-bid.component.html',
  styleUrls: ['./how-to-bid.component.css']
})
export class HowToBidComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

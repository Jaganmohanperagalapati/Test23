import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-step2',
  templateUrl: './step2.component.html',
  styleUrls: ['./step2.component.scss']
})
export class Step2Component implements OnInit {
  public userInfoUpdate:boolean=false;

  constructor() { }

  ngOnInit() {
  }


  onUserInfoUpdate(e){
    if(e.target.id=="userInfoUpdate" && e.target.checked){
      console.log("id",e.target.id)
      this.userInfoUpdate=true;
      console.log("uinfo",this.userInfoUpdate)
    }
    else if(e.target.id=="userInfo" &&e.target.checked){
      console.log("info",e.target.id)
      this.userInfoUpdate=false;
      console.log("usInfo",this.userInfoUpdate)
    }

  }

}

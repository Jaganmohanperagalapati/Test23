import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})
export class MainComponent implements OnInit {
  public submitOffer:boolean=false;
  public register:boolean=false;
  constructor() { }

  ngOnInit() {
  }
  onSubmitOffer():void{
    this.submitOffer=true;
    this.register=false;

  }
  onRegister():void{
    this.submitOffer=false;
    this.register=true;
  }

}

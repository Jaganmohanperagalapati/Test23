///<reference types="@types/googlemaps" />
import { Component, OnInit, NgZone } from '@angular/core';
import { SearchCriteriaService } from "../../services/search-criteria.service";
import { ShareDataService } from "../../services/share-data/share-data.service";
import { FormGroup, FormControl, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { Router, NavigationEnd, ActivatedRoute, Params } from '@angular/router';
import { StorageService } from '../../shared/storage/storage.service';

@Component({
  selector: 'app-regular-bar',
  templateUrl: './regular-bar.component.html'
})
export class RegularBarComponent implements OnInit {
  public dropDownValue: string = "All Homes for Sale";
  private auctionProgramValue;
  private auctionProgramValue2;
  searchInfo: any;
  breadcrumbLocation: string;
  searchForm: FormGroup;
  public addrKeys: string[];
  public addr: any;
  public isLoggedIn = false;
  // public isCheckHome;
  geoCoder = new google.maps.Geocoder();
  constructor(private _fb: FormBuilder, private router: Router, private zone: NgZone, private _searchCriteriaService: SearchCriteriaService,
    private _shareData: ShareDataService, private activatedRoute: ActivatedRoute, private storageService: StorageService) {
      this.storageService.loginSession$.subscribe((data) => {
        this.isLoggedIn = data; 
      }
      );

    }

    setAddress(addrObj) {
      this.zone.run(() => {
        this.addr = addrObj;
        this.addrKeys = Object.keys(addrObj);
        this.router.navigate(["/properties"])
        console.log("addr", this.addr)
        if (this.addr.locality && this.addr.admin_area_l1) {
          console.log("there")
          this.breadcrumbLocation = this.addr.locality + "," + this.addr.admin_area_l1
        }
        else if (this.addr.admin_area_l1) {
          console.log("state");
          this.breadcrumbLocation = this.addr.state;
        }
        this._shareData.changeAuctionProgram2(this.auctionProgramValue);
        this._shareData.onChangeLocation(this.breadcrumbLocation)
        console.log("bclocation", this.breadcrumbLocation);
        console.log("addrKeys", this.addrKeys);
      });
    }
    geoCodeInput(address){
      let search_obj = {};
      this.geoCoder.geocode({ address: address }, function (results, status) {
        if (status === google.maps.GeocoderStatus.OK) {
          const R = results[0];
          search_obj["type"] = R.types[0];
          console.log("r", R)
          console.log("type", search_obj["type"])
          // let stateCode;
          if (R.address_components[0].types[0] == 'administrative_area_level_1') {
            search_obj['stateCode'] = R.address_components[0].short_name;

          } else if (R.address_components[1] && R.address_components[1].types[0] == 'administrative_area_level_1') {
            search_obj['stateCode'] = R.address_components[1].short_name;

          } else if (R.address_components[2] && R.address_components[2].types[0] == 'administrative_area_level_1') {
            search_obj['stateCode'] = R.address_components[2].short_name;

          } else if (R.address_components[3] && R.address_components[3].types[0] == 'administrative_area_level_1') {
            search_obj['stateCode'] = R.address_components[3].short_name;

          } else if (R.address_components[4] && R.address_components[4].types[0] == 'administrative_area_level_1') {
            search_obj['stateCode'] = R.address_components[4].short_name;

          } else if (R.address_components[5] && R.address_components[5].types[0] == 'administrative_area_level_1') {
            search_obj['stateCode'] = R.address_components[5].short_name;

          }
          console.log("state=", search_obj['stateCode']);
          for (let i in R.address_components) {
            if (R.address_components[i].types[0] == "administrative_area_level_2") {
              search_obj["county"] = R.address_components[i].short_name;
              console.log("county name", search_obj["county"])
            }
            else {
              console.log("no code");
            }
            if (R.address_components[i].types[0] == "postal_code") {
              search_obj['postal_code'] = R.address_components[i].short_name;
              console.log("postalCode=", search_obj['postal_code']);
            }
            else {
              console.log("no code")
            }

          }
          //extracting the city 
          // let city;
          if (R.address_components.length > 3) {
            for (let i = 0; i < R.address_components.length; i++) {
              if (R.address_components[i].types[0] == 'locality') {
                search_obj["city"] = R.address_components[i].long_name.toLowerCase();

              }
            }
          }

          //extracting the state
          // let street = address
          search_obj["street"] = address
            .toLowerCase()
            .split(' ')
            .join('');
          console.log("street=", search_obj["street"]);
          search_obj["formatted address"] = R.formatted_address;

          // Street exception for New York
          if (R.address_components[0].long_name == 'New York' && (search_obj["type"] == 'locality' || search_obj["type"] == 'text')) {
            if (search_obj["street"].includes('city')) {
              console.log('logic for new york city');
              // If they select New York city, then do logic for city
              search_obj["type"] = 'locality';
            } else {
              console.log('NEW YORK STATE');
              // If they select New York state, then create new stateCode using [1].short_name
              search_obj["type"] = 'administrative_area_level_1';
              search_obj['stateCode'] = R.address_components[1].short_name;
            }
          }

          //coordinates
          const latitude = R.geometry.location.lat();
          console.log("lat", latitude)
          const longitude = R.geometry.location.lng();
          console.log("long", longitude)
          const location = new google.maps.LatLng(latitude, longitude);
          //sessionStorage.setItem('dataKey', json.strin(latitude));
          const center = {
            lat: latitude,
            lng: longitude
          };
          console.log("loc", location);
          console.log("cen", center);
        }

      })

      this._searchCriteriaService.setAddressEntity(search_obj);
      this._shareData.onChangeLocation(this.breadcrumbLocation);
    }


    ngOnInit() {


      this.searchForm = this._fb.group({
        searchData: ""
      });
      this._shareData.currentAuctionProgram.subscribe(auctionProgram => this.auctionProgramValue = auctionProgram);
      this._shareData.currentAuctionProgram2.subscribe(auctionProgram => this.auctionProgramValue2 = auctionProgram);
      this._shareData.currentLocation.subscribe(location => this.breadcrumbLocation = location)
      // this.isCheckHome=this.isHome(this.activatedRoute.snapshot.url.length);
      // console.log('this.isHome(this.activatedRoute.snapshot.url.length)', this.isCheckHome);

    }
    // isHome(isLength){
    // if(isLength ==0){
    // return false;
    // }else{
    // return true;
    // }
    // }
    onSearch(): void {
      // console.log("sVal="+this.searchForm.controls.searchData.value);
      if(this.searchForm.controls.searchData.value== "") {
      this._shareData.changeAuctionProgram2(this.auctionProgramValue)
      // this.getUserLocation()
      this.router.navigate(["/properties"])
    }
  else {
      this._shareData.changeAuctionProgram2(this.auctionProgramValue)
      console.log("sVal=" + this.searchForm.controls.searchData.value);
      console.log("search Obj", this.addr)
      console.log("brcr", this.breadcrumbLocation)
      this.geoCodeInput(this.searchForm.controls.searchData.value);

    }
  }
  onAuctionProgramChange(e): void {
    console.log("drop event:", e.target.innerText)
    this.dropDownValue = e.target.innerText;


  }

}






import { Component, OnInit } from '@angular/core';
import { HubConnection } from '@aspnet/signalr';
import * as signalR from '@aspnet/signalr';
import { ApiService } from "../shared/api/api.service";
import { IWidget } from './widget.model';
import { IBid } from '../models/bid.model';
import { IWidgetBidView } from './widget-bid-view.model';

@Component({
    selector: 'app-signalr-tester',
    templateUrl: './signalr-tester.component.html',
    styleUrls: ['./signalr-tester.component.scss']
})
export class SignalrTesterComponent implements OnInit {
    private _hubConnection: HubConnection;
    groupName: string;
    message = '';
    messages: string[] = [];
    widget: IWidget;
    widgetBidViewModel: IWidgetBidView;
    widgets = [];
    bids = [];
    latestBid: IBid;
    userId: number;

    constructor(private _api: ApiService) {
        this.userId = Math.floor(Math.random() * Math.floor(9999));
    }

    public sendMessage(): void {
        const data = `Sent: ${this.message}`;

        if (this._hubConnection) {
            this._hubConnection.invoke('Send', this.groupName, data);
        }
        this.messages.push(data);
    }

    public joinGroup(groupName: string): void {
        this.groupName = groupName;
        this._hubConnection.invoke('JoinGroup', groupName);
    }

    async ngOnInit() {
        this.widgets = await this._api.getEndPoint<IWidget[]>('http://localhost:5000/api/v1/widgets');

        this._hubConnection = new signalR.HubConnectionBuilder()
            .withUrl('http://localhost:5000/notify')
            .configureLogging(signalR.LogLevel.Information)
            .build();

        this._hubConnection.start().catch(err => console.error(err.toString()));

        this._hubConnection.on('Send', (data: any) => {
            const received = `Received: ${data}`;
            this.messages.push(received);
        });

        this._hubConnection.on('SendBidHistory', (data: any) => {
            this.handleOnReceiveSendBidHistoryMessage(data);
        });
    }

    async onJoinAuctionClick(widgetId: number) {
        this._hubConnection.invoke('JoinGroup', widgetId);
        this.widget = await this._api.getEndPoint<IWidget>(`http://localhost:5000/api/v1/widgets/${widgetId}`);
        this.bids = await this._api.getEndPoint<IBid[]>(`http://localhost:5000/api/v1/widgets/bids/${widgetId}`);
        if (this.bids && this.bids.length > 0)
            this.latestBid = this.bids[0];

        this.populateWidgetBidViewModel();
    }

    async onSubmitBidClick() {
        await this._api.postEndPoint('http://localhost:5000/api/v1/widgets/bids', {
            amount: this.widgetBidViewModel.bidAmount,
            widgetId: this.widget.id,
            userId: this.userId
        });
    }

    async onCountdownComplete() {
        this.widget = await this._api.getEndPoint<IWidget>(`http://localhost:5000/api/v1/widgets/${this.widget.id}`);
        this.bids = await this._api.getEndPoint<IBid[]>(`http://localhost:5000/api/v1/widgets/bids/${this.widget.id}`);
        this.latestBid = this.bids[0];

        let ctaButtonText = 'Auction Ended'
        if (this.isUserHighestBidder())
            ctaButtonText = 'Auction Ended, you won champ!';
        else if (this.isUserPartOfBidding())
            ctaButtonText = 'Auction Ended, you lost ya bum';

        this.widgetBidViewModel.ctaButtonText = ctaButtonText;
    }

    populateWidgetBidViewModel() {
        const amount = this.latestBid ? this.latestBid.amount : this.widget.currentPrice;

        this.widgetBidViewModel = <IWidgetBidView>{
            name: this.widget.name,
            endDate: this.widget.endDTTM,
            price: amount,
            bidAmount: amount,
            ctaButtonText: this.getCtaButtonText()
        };
    }

    handleOnReceiveSendBidHistoryMessage(data: any) {
        this.bids = data;
        this.latestBid = this.bids[0];
        this.widgetBidViewModel.ctaButtonText = this.getCtaButtonText();
        this.widgetBidViewModel.price = this.latestBid.amount;
        this.widgetBidViewModel.bidAmount = this.latestBid.amount;

        // Update countdown due to sniping
        if (this.latestBid.endTime != this.widget.endDTTM) {
            this.widget.endDTTM = this.latestBid.endTime;
            this.widgetBidViewModel.endDate = this.latestBid.endTime;
        }
    }

    getCtaButtonText(): string {
        if (this.isUserHighestBidder())
            return 'You are the highest bidder'

        return 'Submit Bid';
    }

    isUserPartOfBidding(): boolean {
        return this.bids.some(b => b.userId == this.userId);
    }

    isUserHighestBidder(): boolean {
        return this.latestBid && this.userId == this.latestBid.userId;
    }

    isAuctionEnded(): boolean {
        const endDate = new Date(this.widget.endDTTM);
        const now = new Date();
        return now > endDate;
    }
}

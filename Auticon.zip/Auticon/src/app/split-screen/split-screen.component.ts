import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-split-screen',
  templateUrl: './split-screen.component.html'
})
export class SplitScreenComponent {
  title = 'Auction';
  flag_1: number;
  constructor(){
    this.flag_1 = 1;
  }

  public switchCondition(): void {
    this.flag_1 += 1;
    if(this.flag_1 == 4)
      this.flag_1 = 1;
  }
}

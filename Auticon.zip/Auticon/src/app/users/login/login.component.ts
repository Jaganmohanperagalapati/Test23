import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { } from '../../shared/identity/identity.model';
import { first } from 'rxjs/operators';
//import { IdentityService } from '../../shared/identity/identity.service'
import { StorageService } from '../../shared/storage/storage.service';

class LoginModel {
    email: string = '';
    password: string = '';
}

@Component({
    selector: 'login-cmp',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
    model = new LoginModel();
    invalidCredentials = false;
    networkError = false;
    loginForm: FormGroup;
    loading = false;
    submitted = false;
    returnUrl: string;
    isLoggedIn:any;
    constructor(private router: Router, private formBuilder: FormBuilder, private storageService: StorageService) {
    }

    ngOnInit() {
        this.model = { email: 'admin@svclnk.com', password: 'admin123' };
        this.loginForm = this.formBuilder.group({
            email: ['', Validators.required],
            password: ['', Validators.required]
        });
    }

    get fetchContolrs() { return this.loginForm.controls; }

    onSubmit() {
        this.submitted = true;
        // stop here if form is invalid
        if (this.loginForm.invalid) {
            return;
        }

        // this.loading = true;
        else {
            if (this.fetchContolrs.email.value === this.model.email && this.fetchContolrs.password.value === this.model.password) {
                console.log('logged in successful');
                localStorage.setItem('isloggedIn', 'true');
                this.isLoggedIn = true;
                this.storageService.loginSession(this.isLoggedIn);
            } else {
                console.log('Invalid user');
                this.storageService.loginSession(this.isLoggedIn); 
            }
        }

        // // Reset
        // this.invalidCredentials = false;
        // this.networkError = false;

        // this.identityService.login(this.model.userName, this.model.password)
        //   .subscribe(identity => {
        //     // Authenticated
        //     this.router.navigate(['/vendors']);
        //   }, err => {
        //     let response = err as Response;
        //     if (response.status === 401) {
        //       this.invalidCredentials = true;
        //     } else {
        //       this.networkError = true;
        //     }
        //   });
    }
}

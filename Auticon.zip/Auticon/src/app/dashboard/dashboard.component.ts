import { Component, OnInit, OnDestroy } from '@angular/core';
import { ApiService } from '../shared/api/api.service';
import { CountdownService } from '../services/countdown.service';
import { ISearchResult } from '../models/search-result.model';

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, OnDestroy {
    constructor(private _api: ApiService, private _countdownService: CountdownService) { }

    async ngOnInit() {
        const searchResult = await this._api.getEndPoint<ISearchResult>('/assets/data/dashboard-result.json');
        // await this._countdownService.initialize(searchResult.listings);
    }

    ngOnDestroy() {
        this._countdownService.terminate();
    }
}
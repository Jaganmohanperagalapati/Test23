import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardSavedEventsComponent } from './dashboard-saved-events.component';

describe('DashboardSavedEventsComponent', () => {
  let component: DashboardSavedEventsComponent;
  let fixture: ComponentFixture<DashboardSavedEventsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardSavedEventsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardSavedEventsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardListingCardComponent } from './dashboard-listing-card.component';

describe('DashboardListingCardComponent', () => {
  let component: DashboardListingCardComponent;
  let fixture: ComponentFixture<DashboardListingCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardListingCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardListingCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-marketing',
  templateUrl: './dashboard-marketing.component.html',
  styleUrls: ['./dashboard-marketing.component.scss']
})
export class DashboardMarketingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { DashboardRoutingModule } from './dashboard-routing.module';

import { DashboardComponent } from './dashboard.component';
import { DashboardNavigationComponent } from './dashboard-navigation/dashboard-navigation.component';
import { DashboardSavedListingsComponent } from './dashboard-saved-listings/dashboard-saved-listings.component';
import { DashboardSavedEventsComponent } from './dashboard-saved-events/dashboard-saved-events.component';
import { DashboardMarketingComponent } from './dashboard-marketing/dashboard-marketing.component';
import { DashboardAlertsComponent } from './dashboard-alerts/dashboard-alerts.component';
import { DashboardListingCardComponent } from './dashboard-listing-card/dashboard-listing-card.component';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        DashboardRoutingModule,
        SharedModule.forRoot()
    ],
    declarations: [
        DashboardComponent,
        DashboardNavigationComponent,
        DashboardSavedListingsComponent,
        DashboardSavedEventsComponent,
        DashboardMarketingComponent,
        DashboardAlertsComponent,
        DashboardListingCardComponent
    ]
})
export class DashboardModule { }

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardSavedListingsComponent } from './dashboard-saved-listings.component';

describe('DashboardSavedListingsComponent', () => {
  let component: DashboardSavedListingsComponent;
  let fixture: ComponentFixture<DashboardSavedListingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardSavedListingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardSavedListingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

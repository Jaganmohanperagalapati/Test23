import {IPropertyMedia} from "./property-media.model";

export interface IProperty{
    propertyId:string;
    model:string;
    createdDate:string;
    lotSizeAcreageDescription:string;
    websiteUrl:string;
    assetNumber:string;
    propertyType:string;
    bedrooms:number;
    latitude:number;
    longitude:number;
    address:string;
    interiorSqFt:number;
    county:string;
    fullBathrooms:number;
    yearBuilt:number;
    lotSize:number;
    postalCode:string;
    city:string;
    country:string;
    state:string;
    occupancyStatus:string;
    images:IPropertyMedia[];
    documents:IPropertyMedia;
}
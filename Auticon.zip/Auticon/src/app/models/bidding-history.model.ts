export interface IBidHistoryData {
    model: string;
    importId: number;
    bidTime: string;
    bidType: string;
    amount: number;
    proxy: number;
    userEntered: boolean;
    endTime: string;
    actionId: number;
    listingId: string;
    userId: string;
    userName: string;
    roleId: string;
    currentPrice: number;
    metReserve: number;
    currentTime: string;
    secsToEndTime: number;
}

export interface IBiddingHistory {
    model: string;
    data: IBidHistoryData[];
}
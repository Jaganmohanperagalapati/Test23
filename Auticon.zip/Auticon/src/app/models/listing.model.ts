
import {IProperty} from "./property.model";
import {IListingAuctionRun} from "./listing-auction-run.model";

export interface IListing{
    id:string;
    model:string;
    createdDate:string;
    interiorAccessAvailable:boolean;
    isCashOnly:boolean;
    isFinancible:boolean;
    listingProgramWebsite:string;
    lockboxCode:string;
    auctionProgram:string;
    stage:string;
    hideStateLicense:boolean;
    sellerSpecificInformation:string;
    additionalInformation:string;
    absoluteSale:boolean;
    status:string;
    listPrice:number;
    foreclosureSaleStatus:string;
    foreclosureSaleStatusWebsite:string;
    foreclosureSaleDate:string;
    tpsSaleLocation:string;
    tpsLocationUrl:string;
    tpsSaleTime:string;
    openingBid:number;
    disclosures:string;
    listingAgentName:string;
    listingAgentPhone:string;
    listingAgentBrokerageFirm:string;
    listingAgentEmail:string;
    clearedForSale:string;
    outbidPeriodExpirationDate:string;
    propertyInfo:IProperty;
    auctionRuns:IListingAuctionRun[];

}






































// export interface IAuctionEvent {
//     id: string;
//     awxId: string;
//     buyersPremiumPercentage: number;
//     buyersPremiumMinimum: number;
//     earnestMoneyDepositPercent: number;
//     earnestMoneyDepositMin: number;
//     startingBid: number;
//     auctionEndDate: string;
//     auctionMethod: string;
//     auctionNumber: string;
//     name: string;
//     coopCommissionMinimum: number;
//     coopCommissionPercentage: number;
//     auctionProgram: string;
//     auctionStartDate: string;
//     locationInformation: string;
//     pipDisclosure: string;
//     postAuctionEnd: string;
//     postAuctionStart: string;
//     preAuctionEnd: string;
//     preAuctionStart: string;
//     sellerAuctionName: string;
//     termsAndConditions: string;
//     websiteDescription: string;
//     websiteName: string;
// }

// export interface IEvent {
//     name: string;
//     startDate: string;
//     endDate: string;
// }

// export interface IImage {
//     mediaUrl: string;
//     url: string;
//     externalLink: string;
//     title: string;
//     tags: string;
// }

// export interface IDocument {
//     mediaUrl: string;
//     url: string;
//     externalLink: string;
//     title: string;
//     tags: string;
// }

// export interface IListing {
//     id: string;
//     interiorAccessAvailable: boolean;
//     createdDate: string;
//     lotSizeAcreageDescription: string;
//     websiteUrl: string;
//     isCashOnly: boolean;
//     isFinancible: boolean;
//     assetNumber: string;
//     listingProgramWebsite: string;
//     lockboxCode: string;
//     propertyType: string;
//     auctionProgram: string;
//     stage: string;
//     hideStateLicense: boolean;
//     sellerSpecificInformation: string;
//     additionalInformation: string;
//     absoluteSale: boolean;
//     status: string;
//     listPrice: number;
//     bedrooms: number;
//     latitude: number;
//     longitude: number;
//     foreclosureSaleStatus: string;
//     foreclosureSaleStatusWebsite: string;
//     foreclosureSaleDate: string;
//     tpsSaleLocation: string;
//     tpsLocationURL: string;
//     tpsSaleTime: string;
//     openingBid: number;
//     address: string;
//     disclosures: string;
//     interiorSqFt: number;
//     county: string;
//     fullBathrooms: number;
//     yearBuilt: number;
//     lotSize: number;
//     postalCode: string;
//     city: string;
//     country: string;
//     stateFullName: string;
//     state: string;
//     occupancyStatus: string;
//     auctionEvents: IAuctionEvent[];
//     listingAgentName: string;
//     listingAgentPhone: string;
//     listingAgentBrokerageFirm: string;
//     listingAgentEmail: string;
//     clearedForSale: boolean;
//     outbidPeriodExpirationDate: string;
//     events: IEvent[];
//     images: IImage[];
//     documents: IDocument[];
// }
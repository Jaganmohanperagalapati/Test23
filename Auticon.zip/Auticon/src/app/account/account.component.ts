import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl } from '@angular/forms'
import { BaseFormComponent } from '../shared/base-form/base-form.component'

@Component({
    selector: 'app-account',
    templateUrl: './account.component.html',
    styleUrls: ['./account.component.scss']
})
export class AccountComponent extends BaseFormComponent implements OnInit {
    public mode: string = 'default';
    public changePasswordForm: FormGroup;
    public editProfileForm: FormGroup;

    constructor(private _formBuilder: FormBuilder) {
        super();
    }

    ngOnInit() {
        this.initializeForm();
    }

    initializeForm(): void {
        this.formErrors = {
            'oldPassword': '',
            'newPassword': '',
            'confirmNewPassword': '',
            'firstName': '',
            'lastName': '',
            'company': '',
            'address1': '',
            'address2': '',
            'city': '',
            'state': '',
            'postalCode': '',
            'phone': '',
            'email': ''
        };

        this.validationMessages = {
            'oldPassword': {
                'required': 'Old Password is required.'
            },
            'newPassword': {
                'required': 'New Password is required.'
            },
            'confirmNewPassword': {
                'required': 'Confirm New Password is required.',
                'passwordMismatch': 'Passwords do not match.'
            },
            'firstName': {
                'required': 'First Name is required.'
            },
            'lastName': {
                'required': 'Last Name is required.'
            },
            'company': {
                'required': 'Company is required.'
            },
            'address1': {
                'required': 'Address 1 is required.'
            },
            'address2': {
                'required': 'Address 2 is required.'
            },
            'city': {
                'required': 'City is required.'
            },
            'state': {
                'required': 'State is required.'
            },
            'postalCode': {
                'required': 'Postal Code is required.'
            },
            'phone': {
                'required': 'Phone is required.'
            },
            'email': {
                'required': 'E-mail is required.'
            }
        };

        this.changePasswordForm = this._formBuilder.group({
            oldPassword: ['', [Validators.required]],
            newPassword: ['', [Validators.required]],
            confirmNewPassword: ['', [Validators.required, this.passwordMatchValidator]]
        });

        this.editProfileForm = this._formBuilder.group({
            firstName: ['', [Validators.required]],
            lastName: ['', [Validators.required]],
            company: ['', [Validators.required]],
            address1: ['', [Validators.required]],
            address2: ['', [Validators.required]],
            city: ['', [Validators.required]],
            state: ['', [Validators.required]],
            postalCode: ['', [Validators.required]],
            phone: ['', [Validators.required]],
            email: ['', [Validators.required]],
        });
    }

    passwordMatchValidator(control: AbstractControl): { [key: string]: any } | null {
        if (!control.parent)
            return null;

        const confirmNewPassword: string = control.value;
        const newPassword = control.parent.get('newPassword').value;

        if (confirmNewPassword !== newPassword) {
            return { 'passwordMismatch': true };
        }
    }

    onChangeMode(evt, mode: string): void {
        evt.stopPropagation();
        this.mode = mode;
    }

    onSubmit(): void {
        console.log('this.changePasswordForm.value', this.changePasswordForm.value);
        console.log('this.editProfileForm.value', this.editProfileForm.value);
        console.log('JSON.stringify(this.changePasswordForm.value)', JSON.stringify(this.changePasswordForm.value));
        console.log('JSON.stringify(this.editProfileForm.value)', JSON.stringify(this.editProfileForm.value));
    }
}
export const environment = {
  production: true,
  // Paths (not really, just placeholders)
  apiRoot: 'http://localhost:31000',
  apiPath: '/api/v1'
};

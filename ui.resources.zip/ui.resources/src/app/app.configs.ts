let configs = {
  jsonConfigs: {
    "global": {
      "api.keepalive.timeout": 3000,
      "apiKey": "kprwd65766367497853935616",
      "apiUrl": "http://localhost:9080",
      "apipApiUrl": "http://localhost:9080",
      "appName": "kp-foundation",
      "auditLogApiUri": "/mycare/event/event-handler/v1.0/auditLog",
      "careUserApiUri": "/care/v1.0/user",
      "componentName": "KP Foundation",
      "createProxyApiUri": "/mycare/v2.0/createproxyaccount",
      "entitlementsApiUri": "/mycare/v2.0/entitlements",
      "entitlementsComponentName": "Entitlements Component",
      "keepAliveComponentName": "Keep Alive Component",
      "memberDataApiUri": "/mycare/membership/v1.0/account",
      "mycareUserApiUri": "/mycare/v1.0/user",
      "proxyApiUri": "/mycare/v2.0/proxyinformation",
      "proxyComponentName": "Proxy Component",
      "proxyNoCacheApiUri": "/mycare/v2.1/proxyinformation",
      "userComponentName": "User Profile Component",
      "userNameApiUri": "/mycare/v1.0/username",
      "userProfileFeature": "all"
    },
    "feature": {
      "apiKey": "6e5a65fe-b6ea-4b17-8d98-c545d8b9d945",
      "appName": "coverage-costs",
      "xIbmClientId": "6e5a65fe-b6ea-4b17-8d98-c545d8b9d945",
      "componentName": "MCC"
    },
    "NodeApiHeaders": {
      "X-appName": "coverage-costs",
      "X-componentName": "MCC",
      "X-useragentcategory": "I",
      "Content-Type": "application/json; charset\u003dUTF-8",
      "X-apiKey": "6e5a65fe-b6ea-4b17-8d98-c545d8b9d945"
    }
  }
};

export default configs; 
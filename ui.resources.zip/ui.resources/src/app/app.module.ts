import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";

import { AppComponent } from "./app.component";
import { MCCPBProxyPickerComponent } from "./components/mcc-pb-proxy-picker/mcc-pb-proxy-picker.component";
import { MCCPBIFrameComponent, SafePipe } from "./components/mcc-pb-iframe/mcc-pb-iframe.component";
import { UserDataService } from "./services/user.data.service";
import configs from "./app.configs";

/**
 * for local development add the jsonConfigs object to the document prior to bootstrapping the application
 */
document.write(`
  <script type="text/javascript">
    (function () {
      if (!window.jsonConfigs) {
        window.jsonConfigs = ${JSON.stringify(configs.jsonConfigs)};
      }
    })();
  </script>
`);

@NgModule({
  declarations: [
    AppComponent,
    MCCPBProxyPickerComponent,
    MCCPBIFrameComponent,
    SafePipe
  ],
  imports: [BrowserModule],
  providers: [UserDataService],
  bootstrap: [AppComponent]
})
export class AppModule {}

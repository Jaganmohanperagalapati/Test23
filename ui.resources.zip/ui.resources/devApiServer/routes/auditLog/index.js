module.exports = (req, res) => {
  console.log('\n\x1b[36m%s\x1b[0m', '>>>>> In audit API\n');
  res.status(200).json( { "message" : "Success" });
};
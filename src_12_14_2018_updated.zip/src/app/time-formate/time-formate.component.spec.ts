import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TimeFormateComponent } from './time-formate.component';

describe('TimeFormateComponent', () => {
  let component: TimeFormateComponent;
  let fixture: ComponentFixture<TimeFormateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TimeFormateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TimeFormateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

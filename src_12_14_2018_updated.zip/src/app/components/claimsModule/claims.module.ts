import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClaimsRoutingModule } from './claims.routing';
import { PoliciesMainComponent } from './policies-main/policies-main.component';
import { ReportClaimComponent } from './report-claim/report-claim.component';
import { ReportClaimLandingComponent } from './report-claim-landing/report-claim-landing.component';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { ClaimsTabsLayoutComponent } from './claims-tabs-layout/claims-tabs-layout/claims-tabs-layout.component';
import { NavbarComponent } from './claims-tabs-layout/navbar/navbar.component';
import { CompleteComponent } from './complete/complete.component';
import { ModalModule } from 'ngx-bootstrap';

@NgModule({
  imports: [
      CommonModule,
    ClaimsRoutingModule,
    DateInputsModule,
    ModalModule.forRoot()
  ],
  declarations: [
    PoliciesMainComponent,
    ReportClaimComponent,
    ReportClaimLandingComponent,
    ClaimsTabsLayoutComponent,
    NavbarComponent,
    CompleteComponent
  ],
  providers: []

})
export class ClaimsModule { }

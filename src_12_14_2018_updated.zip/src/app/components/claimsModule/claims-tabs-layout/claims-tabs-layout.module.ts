import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ClaimsTabsLayoutRoutingModule } from './claims-tabs-layout-routing.module';
import { ReportTypeAutoComponent } from './report-type-auto/report-type-auto.component';
import { UserLocationInfoComponent } from './user-location-info/user-location-info.component';
import { AutoClaimDetailsComponent } from './auto-claim-details/auto-claim-details.component';
import { ContactInfoComponent } from './contact-info/contact-info.component';
import { ConfirmationAutoComponent } from './confirmation-auto/confirmation-auto.component';
import { FormWizardModule } from 'angular2-wizard';
import { FormsModule } from '@angular/forms';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { ConfirmationPropertyComponent } from './confirmation-property/confirmation-property.component';
import { PropertyClaimDetailsComponent } from './property-claim-details/property-claim-details.component';
import { ReportTypePropertyComponent } from './report-type-property/report-type-property.component';
import { CommonModule } from '@angular/common';

@NgModule({
    declarations: [
        ReportTypeAutoComponent,
        UserLocationInfoComponent,
        AutoClaimDetailsComponent,
        ContactInfoComponent,
        ConfirmationAutoComponent,
        ConfirmationPropertyComponent,
        PropertyClaimDetailsComponent,
        ReportTypePropertyComponent
    ],
    imports: [
        CommonModule,
        ClaimsTabsLayoutRoutingModule,
    FormWizardModule,
    FormsModule,
    
    DateInputsModule,
    InputsModule
    ],
    providers: [
    ]
})
export class ClaimsTabsLayoutModule {


}

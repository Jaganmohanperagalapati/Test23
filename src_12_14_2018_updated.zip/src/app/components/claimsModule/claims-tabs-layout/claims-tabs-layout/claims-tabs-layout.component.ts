import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kyfb-claims-tabs-layout',
  templateUrl: './claims-tabs-layout.component.html',
  styleUrls: ['./claims-tabs-layout.component.scss']
})
export class ClaimsTabsLayoutComponent implements OnInit {
  selectedPolicyData: any[];
  constructor() { }

  ngOnInit() {
    this.selectedPolicyData = JSON.parse(localStorage.getItem('selectedPolicy'));
  }

}

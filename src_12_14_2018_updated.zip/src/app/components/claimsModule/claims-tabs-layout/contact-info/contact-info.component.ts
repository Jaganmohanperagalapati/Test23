import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { ClaimService } from 'src/app/services/claim.service';
import { Router } from '@angular/router';

@Component({
  selector: 'kyfb-contact-info',
  templateUrl: './contact-info.component.html',
  styleUrls: ['./contact-info.component.scss']
})
export class ContactInfoComponent implements OnInit {
  selectedPolicyData: any[] = [];
  contactInfoData: any[];
  selectedContact: string = '';
  selectedContactNumber: string = '';
  contactNumbers: any[] = [];
  constructor(private claimService: ClaimService, private router: Router) { }

  ngOnInit() {
    this.selectedPolicyData = JSON.parse(localStorage.getItem('selectedPolicy'));
    this.getPolicyDetailsInfo();
  }

  goToPrevious() {
    if (this.selectedPolicyData['type'] == "A" || this.selectedPolicyData['type'] == "B") {
      this.router.navigate(['/claims/claims-tabs/auto-claim-details']);
    } else {
      this.router.navigate(['/claims/claims-tabs/property-claim-detail']);
    }
  }

  goToNext() {
    if (this.selectedPolicyData['type'] == "A" || this.selectedPolicyData['type'] == "B") {
      this.router.navigate(['/claims/claims-tabs/confirmation-auto']);
    } else {
      this.router.navigate(['/claims/claims-tabs/confirmation-property']);
    }
  }

  getPolicyDetailsInfo(){
    this.claimService.getPolicyInfoData(this.selectedPolicyData['policyNumber']).subscribe((policy) =>
    {
       this.contactInfoData = policy.contactNameNumbersDTOList;
       if(this.contactInfoData) {
        this.selectedContact = this.contactInfoData[0].clientReferenceNo;
        this.prepareContactNumbers();
       }
    },    
    error => { }
    );
  }

  prepareContactNumbers() {
    this.contactNumbers = [];
    const index = this.contactInfoData.findIndex(c => c.clientReferenceNo==this.selectedContact);
    if (index >= 0) {
      if (this.contactInfoData[index].workPhoneNumber) {
        this.contactNumbers.push({"label": `Work: ${this.contactInfoData[index].workPhoneNumber}`});
      }
      if (this.contactInfoData[index].cellPhoneNumber) {
        this.contactNumbers.push({"label": `Cell: ${this.contactInfoData[index].cellPhoneNumber}`});
      }
      if (this.contactInfoData[index].homePhoneNumber) {
        this.contactNumbers.push({"label": `Home: ${this.contactInfoData[index].homePhoneNumber}`});
      }  
    }
    if(this.selectedContact === 'other') {
      this.selectedContactNumber = 'other';
    }
  }
  /*goToPrevious() {
    if (this.selectedPolicyData['type'] == "A" || this.selectedPolicyData['type'] == "B") {
      this.router.navigate(['/claims/claims-tabs/report-type-auto']);
    } else {
      this.router.navigate(['/claims/claims-tabs/report-type-property']);
    }
  }

  goToNext() {
    if (this.selectedPolicyData['type'] == "A" || this.selectedPolicyData['type'] == "B") {
      this.router.navigate(['/claims/claims-tabs/auto-claim-details']);
    } else {
      this.router.navigate(['/claims/claims-tabs/property-claim-detail']);
    }
  }*/


}

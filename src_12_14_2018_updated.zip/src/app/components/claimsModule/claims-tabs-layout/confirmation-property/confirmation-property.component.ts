import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'kyfb-confirmation-property',
  templateUrl: './confirmation-property.component.html',
  styleUrls: ['./confirmation-property.component.scss']
})
export class ConfirmationPropertyComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }

  goToPrevious(){
    this.router.navigate(['/claims/claims-tabs/contact-info']);
  }

  submitClaim(){
    this.router.navigate(['/claims/complete']);
  }


}

import { Component, OnInit } from '@angular/core';
import { AccountInformation, Payable, PayableType } from '../../kyfb/account-information';
import { PortalService } from '../../services/portal.service';
import * as _ from 'lodash';
import * as moment from 'moment';

@Component({
    selector: 'kyfb-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
    public portalService: PortalService;

    constructor(portalService: PortalService) {
        this.portalService = portalService;
    }

    ngOnInit() {}

    getPayablesDueSoon(): Payable[] {
        return _.filter(this.portalService.accountInformation.getPayablesDue(), payable => this.isPayableDueSoon(payable));
    }

    isPayableDueSoon(payable: Payable): boolean {
        const now = moment();
        const then = now.clone().add(5, 'days');

        return payable.getDueDate().isAfter(now) && payable.getDueDate().isBefore(then);
    }

    isPayablePolicy(payable: Payable): boolean {
        return payable.getType() === PayableType.POLICY;
    }

    isPayableAccountBill(payable: Payable): boolean {
        return payable.getType() === PayableType.ACCOUNT_BILL;
    }
}

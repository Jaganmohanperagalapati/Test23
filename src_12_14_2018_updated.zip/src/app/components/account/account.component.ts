import { Component, OnInit } from '@angular/core';
import { PortalService } from '../../services/portal.service';

@Component({
    selector: 'kyfb-account',
    templateUrl: './account.component.html',
    styleUrls: ['./account.component.scss']
})
export class AccountComponent implements OnInit {
    public portalService: PortalService;

    constructor(portalService: PortalService) {
        this.portalService = portalService;
    }

    ngOnInit() {
    }

}

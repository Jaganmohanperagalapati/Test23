import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClaimsRoutingModule } from './claims.routing';
import { PoliciesMainComponent } from './policies-main/policies-main.component';
import { BlockPasteDirective } from './block-paste.directive';
import { ReportClaimComponent } from './report-claim/report-claim.component';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { StepsProgressBarComponent } from './report-claim/components/steps-progressbar/steps-progressbar.component';
import { CompleteComponent } from './complete/complete.component';
import { ModalModule } from 'ngx-bootstrap';
import { ClaimTypeComponent } from './report-claim/components/claim-type/claim-type.component';
import { UserLocationInfoComponent } from './report-claim/components/user-location-info/user-location-info.component';
import { AutoClaimDetailsComponent } from './report-claim/components/auto-claim-details/auto-claim-details.component';
import { PropertyClaimDetailsComponent } from './report-claim/components/property-claim-details/property-claim-details.component';
import { ContactInfoComponent } from './report-claim/components/contact-info/contact-info.component';
import { ConfirmationAutoComponent } from './report-claim/components/confirmation-auto/confirmation-auto.component';
import { ConfirmationPropertyComponent } from './report-claim/components/confirmation-property/confirmation-property.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    ClaimsRoutingModule,
    DateInputsModule,
    FormsModule,
    ModalModule.forRoot()
  ],
  declarations: [
    PoliciesMainComponent,
    ReportClaimComponent,
    StepsProgressBarComponent,
    CompleteComponent,
    ClaimTypeComponent,
    UserLocationInfoComponent,
    AutoClaimDetailsComponent,
    PropertyClaimDetailsComponent,
    ContactInfoComponent,
    ConfirmationAutoComponent,
    ConfirmationPropertyComponent,
    BlockPasteDirective
  ],
  providers: []

})
export class ClaimsModule { }

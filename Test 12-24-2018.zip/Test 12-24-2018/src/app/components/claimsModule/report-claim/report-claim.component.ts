import { Component, OnInit, TemplateRef  } from '@angular/core';
import { ClaimService } from 'src/app/services/claim.service';
import { GenerateClaimInformation } from 'src/app/kyfb/generate-claim-information';
import { Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'kyfb-report-claim',
  templateUrl: './report-claim.component.html',
  styleUrls: ['./report-claim.component.scss']
})
export class ReportClaimComponent implements OnInit {
  dueDateDetails: any[];
  selectedPolicyData: any[];
  policiesInfo: any;
  claimInformation: GenerateClaimInformation;
  clientName: any = "";
  showLandingMessage: boolean = true;
  step: number;
  policyDetails: any;
  claimTypeFormData: object;
  userLocationFormData: object;
  autoClaimDetailsFormData: object;
  propertyClaimDetailsFormData:object;
  contactInfoFormData:object;
  constructor(private claimService: ClaimService, private router: Router, private modalService: BsModalService) { }

  ngOnInit() {
    this.selectedPolicyData = JSON.parse(localStorage.getItem('selectedPolicy'));
    this.claimService.currentDueDateDetails.subscribe(dueDateDetails => this.dueDateDetails = dueDateDetails);
    this.getPolicyDetailsInfo();
    this.setEmptyData();
    this.prepareFormDataObjects();
    if(localStorage.getItem('isPolicyMessageRead') && localStorage.getItem('isPolicyMessageRead') == 'true') {
      this.startClaimForm();
    }
  }

  prepareFormDataObjects() {
    this.claimTypeFormData = {
      type: this.selectedPolicyData['type'],
      claimType: this.claimInformation.imageClicked,
      claimSubType: this.claimInformation.incidentSubType
    }
    this.userLocationFormData = {
      type: this.selectedPolicyData['type'],
      overviewDescription: this.claimInformation.overviewDescription,
      datepicker: this.claimInformation.datepicker,
      timepicker: this.claimInformation.timepicker,
      propertyAddress: this.claimInformation.propertyAddress,
      address: this.claimInformation.address,
      address2: this.claimInformation.address2,
      city: this.claimInformation.city,
      state: this.claimInformation.state,
      otherState: null,
      zip: this.claimInformation.zip,
      country: this.claimInformation.country,
    }
    this.getAutoClaimFormData();
    this.getPropertyClaimFormData();  
    this.getContactInfoFormData();  
  }

  getAutoClaimFormData() {
    this.autoClaimDetailsFormData = {
      vehicle: this.claimInformation.vehicle,
      vehicleInfoDTOList: this.claimInformation.vehicleInfoDTOList,
      year: this.claimInformation.year,
      make: this.claimInformation.make,
      model: this.claimInformation.model,
      vin: this.claimInformation.vin,
      insuredVehicle: this.claimInformation.insuredVehicle,
      driver: this.claimInformation.driver,
      driverFirstname: this.claimInformation.driverFirstname,
      driverMiddlename:this.claimInformation. driverMiddlename,
      driverLastname: this.claimInformation.driverLastname,
      driverCity: this.claimInformation.driverCity,
      damageDescription: this.claimInformation.damageDescription,
      airBagsRadio: this.claimInformation.airBagsRadio,
      vehicleDriveRadio: this.claimInformation.vehicleDriveRadio,
      vehicleAddress:this.claimInformation.vehicleAddress ,
      vehicleAddress2: this.claimInformation.vehicleAddress2,
      vehicleCity:this.claimInformation.vehicleCity,
      vehicleState: this.claimInformation.vehicleState,
      vehicleZip: this.claimInformation.vehicleZip,
      vehicleCountry: this.claimInformation.vehicleCountry,
      injuryRadio: this.claimInformation.injuryRadio,
      injuryDescription: this.claimInformation.injuryDescription,
      policeReportRadio:  this.claimInformation.policeReportRadio,
      agencyNamePolice:  this.claimInformation.agencyNamePolice,
      reportNumberPolice:  this.claimInformation.reportNumberPolice,
      fireReportRadio:  this.claimInformation.fireReportRadio,
      agencyFire:  this.claimInformation.agencyFire,
      reportNumberFire:  this.claimInformation.reportNumberFire,      
    }  
   
  }
  getPropertyClaimFormData() {
   this.propertyClaimDetailsFormData =  {
    propertyDamageDescription: this.claimInformation.propertyDamageDescription,
    injuryRadio: this.claimInformation.injuryRadio,
    injuryDescription: this.claimInformation.injuryDescription,
    emergencyServiceRadio: this.claimInformation.emergencyServiceRadio,
    contractorName: this.claimInformation.contractorName,
    repairRadio: this.claimInformation.repairRadio,
    propertyUninhabitableRadio: this.claimInformation. propertyUninhabitableRadio,
    policeReportRadio: this.claimInformation.policeReportRadio,
    agencyNamePolice: this.claimInformation.agencyNamePolice,
    reportNumberPolice: this.claimInformation.reportNumberPolice,
    fireReportRadio: this.claimInformation.fireReportRadio,
    agencyFire: this.claimInformation.agencyFire,
    reportNumberFire: this.claimInformation.reportNumberFire,

   } 
  }

  getContactInfoFormData(){
    this.contactInfoFormData = {
      contactInfo: this.claimInformation.contactInfo,
      firstNameNew: this.claimInformation.firstNameNew,
      middleNameNew: this.claimInformation.middleNameNew,
      lastNameNew: this.claimInformation.lastNameNew,
      cityNew: this.claimInformation.cityNew,
      cellNumber: this.claimInformation.cellNumber,
      cellNumberNew: this.claimInformation.cellNumberNew,
      contactNameNumbersDTOList: this.claimInformation.contactNameNumbersDTOList,
    }
  }  


  startClaimForm() {
    localStorage.setItem('isPolicyMessageRead', 'true');
    this.showLandingMessage = false;
    this.step = 1;
  }

  changeStep(data) {
    this.setReturnData(data);
    if(data.direction == 'next') {
      this.step = this.step + 1;
    }
    if(data.direction == 'previous') {
      this.step = this.step - 1;
    }
    console.log(this.step);
  }

  setReturnData(data) {
    console.log(data);
    if(data.formData) {
      Object.keys(data.formData).forEach((key) => {
        this.claimInformation[key] = data[key];
      });
    }
  }

  openClaimsTabs() {
    if (this.selectedPolicyData['type'] == "A" || this.selectedPolicyData['type'] == "B") {
      this.router.navigate(['/claims/claims-tabs/report-type-auto']);
    } else if (this.selectedPolicyData['type'] == "P") {
      this.router.navigate(['/claims/claims-tabs/report-type-property']);
    }
  }

  openDash()
 {
  this.router.navigate(['/claims']);
 }
  getInfo() {
    this.claimService.getClaimsInfo().subscribe((claims) => {
      this.policiesInfo = claims.eBusAccountResponseType.policies.policyInfo;
      this.clientName = claims.eBusAccountResponseType.clientInfo.firstName;
    },
      error => { }
    );
  }

  getPolicyDetailsInfo(){
    this.claimService.getPolicyInfoData(this.selectedPolicyData['policyNumber']).subscribe((policy) =>
    {
       this.policyDetails = policy;
    },
    
      error => { }
    );
  }

  setEmptyData() {
    this.claimInformation = {
      imageClicked:  null,
      incidentSubType: null,
      radioDivLocation: null,
      overviewDescription: null,
      datepicker: '',
      timepicker: '',
      propertyAddress: '',
      address: null,
      address2: null,
      city: null,
      state: '',
      otherState: null,
      zip: null,
      country: 'USA',
      otherCountry: null,
      policyType: this.selectedPolicyData['type'],
      policyNumber: this.selectedPolicyData['policyNumber'],
      vehicle: '',
      vehicleInfoDTOList: [],
      year: null,
      make: null,
      model: null,
      vin: null,
      insuredVehicle: '',
      driver: null,
      driverFirstname: null,
      driverMiddlename: null,
      driverLastname: null,
      driverCity: null,
      damageDescription: null,
      propertyDamageDescription: null,
      airBagsRadio: null,
      emergencyServiceRadio: null,
      contractorName: null,
      repairRadio: null,
      propertyUninhabitableRadio : null,
      vehicleDriveRadio: null,
      vehicleAddress: null,
      vehicleAddress2: null,
      vehicleCity: null,
      vehicleState: null,
      vehicleZip: null,
      vehicleCountry: 'USA',
      injuryRadio: null,
      injuryDescription: null,
      policeReportRadio: null,
      agencyNamePolice: null,
      reportNumberPolice: null,
      fireReportRadio: null,
      agencyFire: null,
      reportNumberFire: null,
      contactInfo: '',
      firstNameNew: null,
      middleNameNew: null,
      lastNameNew: null,
      cityNew: null,
      cellNumber: '',
      contactNameNumbersDTOList: [],
      cellNumberNew: '',
      reportedByInfo: null,
      reportedFirstNameNew: null,
      reportedMiddleNameNew: null,
      reportedLastNameNew: null,
      reportedCityNew: null,
      reportedByCellNumberNew: null,
      claimFnolDTO: null,
      clientName: null,
      clientRefNum: null,
      agentNo: null,    
    }
  }
}
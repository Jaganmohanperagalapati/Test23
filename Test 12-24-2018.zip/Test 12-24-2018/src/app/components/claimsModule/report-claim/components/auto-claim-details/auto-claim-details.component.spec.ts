import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AutoClaimDetailsComponent } from './auto-claim-details.component';

describe('AutoClaimDetailsComponent', () => {
  let component: AutoClaimDetailsComponent;
  let fixture: ComponentFixture<AutoClaimDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AutoClaimDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoClaimDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

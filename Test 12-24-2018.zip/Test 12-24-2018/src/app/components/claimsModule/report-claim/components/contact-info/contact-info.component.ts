import { Component, OnInit, Input, TemplateRef, Output, EventEmitter } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { Router } from '@angular/router';

@Component({
  selector: 'kyfb-contact-info',
  templateUrl: './contact-info.component.html',
  styleUrls: ['./contact-info.component.scss']
})
export class ContactInfoComponent implements OnInit {
  @Input() contactInfoData;
  @Input() formData;
  @Output() stepChange: EventEmitter<any> = new EventEmitter();
  reportModalRef: BsModalRef;
  contactInfo: string = '';
  //contactName: any[] = [];
  formSubmitted: boolean = false;
  otherContactformSubmitted: boolean = false;
  // selectedContact: any[] = [];
  selectedContactNumber: string = '';
  cellNumber: any[] = [];
  contactNumbers: any[] = [];
  // contact : any[] =[];
  constructor(private router: Router, private modalService: BsModalService) { }

  ngOnInit() {
    this.setContactInfoData();
  }

  goToPrevious() {
    this.stepChange.emit({ direction: "previous", step: "contactInfo", "formData": this.formData });
  }

  goToNext(isValid) {
    this.formSubmitted = true;
    this.otherContactformSubmitted = true;
    if (isValid) {
      this.stepChange.emit({ direction: "next", step: "contactInfo", "formData": this.formData });
    }
  }

  setContactInfoData() {
    if (this.contactInfoData && this.formData.contactInfo === '') {
      this.formData.contactInfo = this.contactInfoData[0].clientReferenceNo;      
    }
    this.prepareContactNumbers();
  }

  onChangeContact() {
    if (this.formData.contactInfo === 'other') {
      this.formData.cellNumber = 'other';
      this.formData.contactNameNumbersDTOList = [];
      this.otherContactformSubmitted = false;
    } else {
      this.formData.cellNumber = '';
      this.prepareContactNumbers();
    }
  }

  prepareContactNumbers() {
    this.contactNumbers = [];
    const index = this.contactInfoData.findIndex(c => c.clientReferenceNo == this.formData.contactInfo);
    if (index >= 0) {
      this.formData.contactNameNumbersDTOList = this.contactInfoData[index];
      this.otherContactformSubmitted = false;
      if (this.contactInfoData[index].workPhoneNumber) {
        this.contactNumbers.push({ "label": `Work: ${this.contactInfoData[index].workPhoneNumber}`, "value": this.contactInfoData[index].workPhoneNumber });
      }
      if (this.contactInfoData[index].cellPhoneNumber) {
        this.contactNumbers.push({ "label": `Cell: ${this.contactInfoData[index].cellPhoneNumber}`, "value": this.contactInfoData[index].cellPhoneNumber });
      }
      if (this.contactInfoData[index].homePhoneNumber) {
        this.contactNumbers.push({ "label": `Home: ${this.contactInfoData[index].homePhoneNumber}`, "value": this.contactInfoData[index].homePhoneNumber });
      }
    }
  }

  openModalConfirmation(template6: TemplateRef<any>) {
    console.log("click is working");
    this.reportModalRef = this.modalService.show(template6);
  }


  goBackToDashboard(template6: TemplateRef<any>) {
    this.reportModalRef.hide();
    this.router.navigate(['/claims']);
  }
}

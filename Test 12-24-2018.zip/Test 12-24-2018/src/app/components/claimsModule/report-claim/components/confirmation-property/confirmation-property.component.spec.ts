import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmationPropertyComponent } from './confirmation-property.component';

describe('ConfirmationPropertyComponent', () => {
  let component: ConfirmationPropertyComponent;
  let fixture: ComponentFixture<ConfirmationPropertyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfirmationPropertyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmationPropertyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

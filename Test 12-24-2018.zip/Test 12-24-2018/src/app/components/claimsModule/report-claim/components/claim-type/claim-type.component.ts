import { Component, OnInit, Input, TemplateRef, Output, EventEmitter  } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { Router } from '@angular/router';

@Component({
  selector: 'kyfb-claim-type',
  templateUrl: './claim-type.component.html',
  styleUrls: ['./claim-type.component.scss']
})
export class ClaimTypeComponent implements OnInit {
  @Input() formData: any;
  @Output() stepChange: EventEmitter<any> = new EventEmitter();
  types: any;
  subTypes: any = [];
  reportModalRef: BsModalRef;
  submitted: boolean = false;
  imagesPath: string  = '/assets/img/icons/';
  constructor(private router: Router, private modalService: BsModalService) {
    this.types = {
      "A": [
        {
          "name": 'COLLISION',
          "icon": 'Loss-Cause-collision.svg',
          "subTypes": []
        },
        {
          "name": 'ANIMAL',
          "icon": 'Loss-Cause-animal.svg',
          "subTypes": ['Deer', 'Other Animal']
        },
        {
          "name": 'FIRE',
          "icon": 'Loss-Cause-fire.svg',
          "subTypes": []
        },
        {
          "name": 'WEATHER',
          "icon": 'Loss-Cause-weather.svg',
          "subTypes": ['Flood', 'Hail', 'Wind/Tornado']
        },        
        {
          "name": 'GLASS BREAKAGE',
          "icon": 'Loss-Cause-glass-breakage.svg',
          "subTypes": ['Glass Only', 'Glass and other breakage']
        },
        {
          "name": 'THEFT/VANDALISM',
          "icon": 'Loss-Cause-theft-vandalism.svg',
          "subTypes": ['Theft of vehicle', 'Vandalism','Theft of parts or contents of vehicle']
        },
        {
          "name": 'OTHER',
          "icon": 'Loss-Cause-other.svg',
          "subTypes": []
        },
      ],
      "B": [
        {
          "name": 'COLLISION',
          "icon": 'Loss-Cause-boat-collision.svg',
          "subTypes": []
        },
        {
          "name": 'FIRE',
          "icon": 'Loss-Cause-boat-fire.svg',
          "subTypes": []
        },
        {
          "name": 'WEATHER',
          "icon": 'Loss-Cause-fire.svg',
          "subTypes": ['Flood', 'Hail', 'Wind/Tornado']
        },
        {
          "name": 'GLASS BREAKAGE',
          "icon": 'Loss-Cause-boat-glass-breakage.svg',
          "subTypes": []
        },
        {
          "name": 'THEFT/VANDALISM',
          "icon": 'Loss-Cause-theft-vandalism.svg',
          "subTypes": ['Theft of vehicle', 'Vandalism','Theft of parts or contents of vehicle']
        },
        {
          "name": 'OTHER',
          "icon": 'Loss-Cause-other.svg',
          "subTypes": []
        }

      ],
      "P": [
        {
          "name": 'WEATHER',
          "icon": 'Loss-Cause-weather.svg',
          "subTypes": ['Flood', 'Hail', 'Wind/Tornado','Freezing', 'Lightning', 'Weight of Ice & Snow']
        }, 
        {
          "name": 'WATER DAMAGE',
          "icon": 'Loss-Cause-property-water-damage.svg',
          "subTypes": []
        }, 
        {
          "name": 'THEFT/VANDALISM',
          "icon": 'Loss-Cause-theft-vandalism.svg',
          "subTypes": ['Theft', 'Vandalism']
        },
        {
          "name": 'FIRE',
          "icon": 'Loss-Cause-property-fire.svg',
          "subTypes": []
        },
        {
          "name": 'GLASS BREAKAGE',
          "icon": 'Loss-Cause-glass-breakage.svg',
          "subTypes": []
        }, 
        {
          "name": 'VEHICLE',
          "icon": 'Loss-Cause-property-vehicle.svg',
          "subTypes": []
        }, 
        {
          "name": 'EARTHQUAKE',
          "icon": 'Loss-Cause-property-earthquake.svg',
          "subTypes": []
        },
        {
          "name": 'OTHER',
          "icon": 'Loss-Cause-other.svg',
          "subTypes": []
        } 

      ]
    }
   }

  ngOnInit() {
    if(this.formData.claimType != '' && this.formData.claimType !== null) {
      this.selectClaimType(this.formData.claimType);
    }
  }

  selectClaimType(ctype) {
    this.submitted = false;
    this.subTypes = [];
    this.formData.claimType = ctype;
    this.subTypes = this.types[this.formData.type][this.types[this.formData.type].findIndex(x => x.name==this.formData.claimType)].subTypes;    
  }

  openModalConfirmation(template2: TemplateRef<any>) {
    this.reportModalRef = this.modalService.show(template2);
  }

  goToNext() {
    this.submitted = true;
    if(this.formData.claimType && (this.subTypes.length == 0 || this.subTypes.length > 0 && this.formData.claimSubType !== '' && this.formData.claimSubType !== null)) {
      this.stepChange.emit({direction: "next", step: "claimType", formData: this.prepareReturnObject()});
    }
  }

  prepareReturnObject() {
    return {
      "imageClicked": this.formData.claimType,
      "incidentSubType": this.formData.claimSubType
    }
  }

  
  goBackToDashboard(template2: TemplateRef<any>) {
    this.reportModalRef.hide();
    this.router.navigate(['/claims']);
  }

}

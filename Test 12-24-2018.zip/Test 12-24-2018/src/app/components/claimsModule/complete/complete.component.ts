import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'kyfb-complete',
  templateUrl: './complete.component.html',
  styleUrls: ['./complete.component.scss']
})
export class CompleteComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  returnTo() {
    this.router.navigate(['/claims']);
  }


}

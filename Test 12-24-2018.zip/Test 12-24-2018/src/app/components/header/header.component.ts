import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AccountInformation } from '../../kyfb/account-information';
import { ClaimService } from 'src/app/services/claim.service';
import { Router } from '@angular/router';

@Component({
    selector: 'kyfb-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
    clientFirstName:any ="";
    clientMiddleName:any ="";
    clientLastName:any ="";
    wholeName:any ="";
    @Input() accountInformation: AccountInformation;
    @Output() toggleMenu = new EventEmitter<any>();

    constructor(private claimService: ClaimService, private router:Router) { }

    ngOnInit() {
  // this.getFullNameInfo();
    }
 returnTo(){
     this.router.navigate(['/dashboard']);
 }

// getFullNameInfo() {
//     this.claimService.getClaimsInfo.subscribe((name) => {
     
//      this.clientFirstName = name.eBusAccountResponseType.clientInfo.firstName;
//      this.clientMiddleName = name.eBusAccountResponseType.clientInfo.middleName;
//      this.clientLastName = name.eBusAccountResponseType.clientInfo.lastNameOrCompanyName;
//      return this.wholeName =  this.clientFirstName + ' ' + this.clientMiddleName  + ' ' +this.clientLastName; 
//     },  
//       error => { }
//     );
//   }


}

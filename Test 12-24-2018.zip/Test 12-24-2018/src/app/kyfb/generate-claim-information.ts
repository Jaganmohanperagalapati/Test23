interface ContactNameNumbersDTO {
    clientReferenceNo: number;
    firstName: string;
    middleName: string;
    lastName: string;
    workPhoneNumber: string;
    homePhoneNumber: string;
    cellPhoneNumber: string;
}

interface ClaimFnolDTO {
    policyNum: string;
    lob: string;
    firstName: string;
    lastName: string;
    country: string;
    city: string;
    state: string;
    zip: string;
    otherCountry: string;
    otherState: string;
    clientName: string;
}

interface UnitType {
    unitNumber: string;
    unitDescription: string;
    vehicle: Vehicle;
}

interface Vehicle {
    year: string;
    make: string;
    model: string;
    vin: string;
}


export class GenerateClaimInformation {    
    imageClicked: string;
    incidentSubType: string;
    radioDivLocation: string;
    overviewDescription: string;
    datepicker: string;
    timepicker: string;
    propertyAddress: string;
    address: string;
    address2: string;
    city: string;
    state: string;
    otherState: string;
    zip: string;
    country: string;
    otherCountry: string;
    policyType: string;
    policyNumber: string;
    vehicle: string;
    vehicleInfoDTOList: UnitType[];
    year: string;
    make: string;
    model: string;
    vin: string;
    insuredVehicle: string;
    driver: number;
    driverFirstname: string;
    driverMiddlename: string;
    driverLastname: string;
    driverCity: string;
    damageDescription: string;
    airBagsRadio: string;
    vehicleDriveRadio: string;
    vehicleAddress: string;
    vehicleAddress2: string;
    vehicleCity: string;
    vehicleState: string;
    vehicleZip: string;
    vehicleCountry: string;
    injuryRadio: string;
    injuryDescription: string;
    propertyDamageDescription: string;
    policeReportRadio: string;
    emergencyServiceRadio: string;
    contractorName: string;
    repairRadio: string;
    propertyUninhabitableRadio: string;
    agencyNamePolice: string;
    reportNumberPolice: string;
    fireReportRadio: string;
    agencyFire: string;
    reportNumberFire: string;
    contactInfo: string;
    firstNameNew: string;
    middleNameNew: string;
    lastNameNew: string;
    cityNew: string;
    cellNumber: string;
    contactNameNumbersDTOList: ContactNameNumbersDTO[];
    cellNumberNew: string;
    reportedByInfo: string;
    reportedFirstNameNew: string;
    reportedMiddleNameNew: string;
    reportedLastNameNew: string;
    reportedCityNew: string;
    reportedByCellNumberNew: string;
    claimFnolDTO: string;
    clientName: string;
    clientRefNum: string;
    agentNo: number;
}

export const environment = {
    production: true,
    portalApi: {
        // tslint:disable-next-line:max-line-length
        baseUrl: 'https://www.kyfb.com/KYFB/includes/themes/CodeBlue/display_objects/custom/remote/webservices/Crosby/'
    },
    agentApi: {
        // tslint:disable-next-line:max-line-length
        baseUrl: 'https://www.kyfb.com/KYFB/includes/themes/CodeBlue/display_objects/custom/remote/webservices/services.cfc'
    }
};

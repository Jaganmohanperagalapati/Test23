const fs = require("fs-extra");

const srcPath = './src';
const modulesPath = './node_modules';
const styleguideCssDest = `${srcPath}/styleguide.css`;
const srcRootCss = `${srcPath}/styles.css`;
const assetsDest = `${srcPath}/assets`;
const styleguideCssOrigin = `${modulesPath}/styleguide/styleguide.css`;
const assetsOrigin = `${modulesPath}/styleguide/lib/modern/assets`;

const lightMagenta = '\x1b[95m';
const systemColor = '\x1b[0m';

const argv = process.argv;
const settingBuildFlag = argv.indexOf('--build') !== -1;


/**
 * REMOVE THE STYLEGUIDE CSS IMPORT FROM STYLES.CSS IN THE SRC DIRECTORY IF THE "--BUILD" FLAG IS SET
 * --------------------------------------------------------------------------------------------------
 */

if (settingBuildFlag) {
    let stylesheetData = fs.readFileSync(srcRootCss)
        .toString()
        .split('\n');

    const styleguideCssImport = "@import './styleguide.css';";
    let styleguideImportExists = false;

    // check for the import statement
    stylesheetData.forEach((line) => {
        if (line.trim() === styleguideCssImport) {
            styleguideImportExists = true;
        }
    });

    // if styles.css has the import statement, remove it
    if (styleguideImportExists) {
        stylesheetData = stylesheetData.slice(1).join('\n');
        fs.writeFile(srcRootCss, stylesheetData);
        console.log(`\n${lightMagenta}`, `>>>>> Removing '${styleguideCssImport}' from '${srcRootCss}'${systemColor}\n`);
    }
}


/**
 * ADD THE STYLEGUIDE CSS IMPORT TO STYLES.CSS IN THE SRC DIRECTORY IF THE "--BUILD" FLAG IS NOT SET
 * -------------------------------------------------------------------------------------------------
 */

if (!settingBuildFlag) {
    const styleguideImport = "@import './styleguide.css';";
    let styleguideImportExists = false;

    // read the styles.css file
    let stylesheetData = fs.readFileSync(srcRootCss)
        .toString()
        .split('\n');

    // check for the import statement
    stylesheetData.forEach((line) => {
        if (line.trim() === styleguideImport) {
            styleguideImportExists = true;
        }
    });

    // if styles.css doesn't have the import statement, add it
    if (!styleguideImportExists) {
        stylesheetData.splice(0, 0, styleguideImport);
        let newImport = stylesheetData.join('\n');
        fs.writeFile(srcRootCss, newImport);
        console.log(`\n${lightMagenta}`, `>>>>> Adding '${styleguideImport}' to '${srcRootCss}${systemColor}\n`);
    }
}


/**
 * REMOVE THE STYLEGUIDE AND ASSETS DIRECTORY FROM THE SRC DIRECTORY
 * -----------------------------------------------------------------
 */

if (fs.existsSync(styleguideCssDest)) {
    // delete the "src/styleguide.css" file
    fs.removeSync(styleguideCssDest);
    console.log(`\n${lightMagenta}`, `>>>>> Deleting the '${styleguideCssDest}' file${systemColor}\n`)
}

if (fs.existsSync(assetsDest)) {
    // delete the "src/assets" directory
    fs.removeSync(assetsDest);
    console.log(`\n${lightMagenta}`, `>>>>> Deleting the '${assetsDest}' directory${systemColor}\n`);
}


/**
 * COPY THE STYLEGUIDE AND ASSETS DIRECTORY TO THE SRC DIRECTORY
 * -------------------------------------------------------------
 */

// copy the "styleguide.css" file to the desired location
fs.copy(styleguideCssOrigin, styleguideCssDest, (err) => {
    if (err) {
        return console.log(`\n${lightMagenta}`, `>>>>> ${err}${systemColor}\n`);
    }
    console.log(`\n${lightMagenta}`, `>>>>> '${styleguideCssOrigin}' was successfully copied to the 'src' directory${systemColor}\n`);
});

// copy the "assets" directory to the desired location
fs.copy(assetsOrigin, assetsDest, (err) => {
    if (err) {
        return console.log(`\n${lightMagenta}`, `>>>>> ${err}${systemColor}\n`);
    }
    console.log(`\n${lightMagenta}`, `>>>>> '${assetsOrigin}' folder was successfully copied to the 'src' directory${systemColor}\n`);
});
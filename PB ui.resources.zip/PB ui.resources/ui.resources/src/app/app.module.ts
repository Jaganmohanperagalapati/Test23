import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { MCCPBProxyPickerComponent } from "./components/mcc-pb-proxy-picker/mcc-pb-proxy-picker.component";
import { UserDataService } from './services/user.data.service';

@NgModule({
  declarations: [
    AppComponent,
    MCCPBProxyPickerComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [UserDataService],
  bootstrap: [AppComponent]
})
export class AppModule { }

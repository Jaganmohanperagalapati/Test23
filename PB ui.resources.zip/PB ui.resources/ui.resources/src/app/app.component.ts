import { OnInit, Component, NgZone } from '@angular/core';
import { SafeHtml } from '@angular/platform-browser';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import { UserDataService } from "./services/user.data.service";
import { User } from  "./interfaces/user.interface";

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  userData: BehaviorSubject<User>;
  proxyChanged: BehaviorSubject<String>;
  htmlStr: SafeHtml;
  relid: String;
  user: User;
  title: String = "Plan Benefits";

  constructor(private userService: UserDataService, private zone: NgZone) {
    this.userData = this.userService.userData;
    this.proxyChanged = this.userService.proxyChanged;
  }

  ngOnInit() {
    // set the html received from AEM to a variable
    this.htmlStr = this.parse(document.getElementById('_templates'));

    // get the data for the currently logged in user
    this.userData
      .subscribe((val) => {
        this.user = val;
      });
      // get the data for the currently selected proxy
    this.proxyChanged
      .subscribe((val) => {
        this.relid = val;
      });
  }

  /**
   * parse the dom for the node with the AEM html we expect
   * @param dom
   */
  parse(dom: any) {
    try {
      for (let node of dom.childNodes) {
        if (node.nodeName === "SCRIPT" && node.id === "pbrootcomp.html") {
          return node.innerHTML;
        }
      }
    } catch (e) { }
  }
}

import { OnInit, Component } from '@angular/core';
import ProxyPickerComponent from "kp-proxy-picker";

let ProxyPickerWidget: any;

@Component({
    selector: 'mcc-proxy-picker',
    template: '<div id="mcc-pb-proxy-picker-container"></div>'
})
export class MCCPBProxyPickerComponent implements OnInit {

    constructor() {
        ProxyPickerWidget = ProxyPickerComponent.ProxyPickerWidget;
    }

    ngOnInit() {
        // instantiate the proxy picker
        ProxyPickerWidget.render({
            selector: '#mcc-pb-proxy-picker-container'
        });
    }
}

import { Injectable, NgZone } from '@angular/core';
import { Observable } from "rxjs";
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import KPClientCommons from "kp-client-commons";

import { User } from  "../interfaces/user.interface";

import ProxyPickerComponent from "kp-proxy-picker";
import UserProfileHelper from "kp-user-profile";

@Injectable()
export class UserDataService {

  constructor(private zone: NgZone) {
    // convert the "UserProfileHelper.UserProfileClient.load()" promise to an observable and subscribe to it
    Observable.fromPromise(UserProfileHelper.UserProfileClient.load())
      .subscribe((val) => {
        // cast the user data from the profile helper to a type of User
        let user = val as User;
        // make use of angular's change detection to tie into the dom lifecycle
        this.zone.run(() => {
          // pass the value to the behavior subject
          this.userData.next(user);
        })
      });
    ProxyPickerComponent.ProxyPickerClient.onChange((rel) => {
      // make use of angular's change detection to tie into the dom lifecycle
      this.zone.run(() => {
        // pass the value to the behavior subject
        this.proxyChanged.next(rel.relid);
      })
    });
  }

  // define the behavior subjects with their initial values
  userData = new BehaviorSubject<User>({user: {guid: ''}});
  proxyChanged = new BehaviorSubject<String>(KPClientCommons.CookieManager.getProxyRelationshipCookie());
}
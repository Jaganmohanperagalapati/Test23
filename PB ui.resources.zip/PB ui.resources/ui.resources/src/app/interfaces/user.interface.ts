export interface User {
    user: {
        guid: String
    };
  }
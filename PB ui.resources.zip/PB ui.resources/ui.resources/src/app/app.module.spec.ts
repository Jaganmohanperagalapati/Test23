import { AppModule } from "./app.module";
import { async, inject, TestBed } from '@angular/core/testing';

declare var $: any;

describe('AppModule', () => {
  describe('exists', () => {
    it('should exist', async(inject(
      [],
      () => {
        expect(AppModule).toBeDefined();
      }
    )));
  });
});
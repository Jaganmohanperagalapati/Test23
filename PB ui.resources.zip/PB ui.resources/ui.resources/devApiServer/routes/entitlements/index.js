const entitlementsData = require('./data.json');

module.exports = (req, res) => {
  console.log('\n\x1b[36m%s\x1b[0m', '>>>>> In entitlements API\n');
  res.status(200).json( entitlementsData );
};
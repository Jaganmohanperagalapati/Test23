import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'kyfb-confirmation-auto',
  templateUrl: './confirmation-auto.component.html',
  styleUrls: ['./confirmation-auto.component.scss']
})
export class ConfirmationAutoComponent implements OnInit {
  @Output() stepChange: EventEmitter<any> = new EventEmitter();
  constructor(private router:Router) { }

  ngOnInit() {
  }

  goToPrevious(){
    this.stepChange.emit({direction: "previous", step: "autoConfirmation"});
  }

  submitClaim(){
    this.router.navigate(['/claims/complete']);
  }

}

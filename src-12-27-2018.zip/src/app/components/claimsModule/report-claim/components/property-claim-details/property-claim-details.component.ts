import { Component, OnInit, Input,TemplateRef, Output, EventEmitter } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { Router } from '@angular/router';

@Component({
  selector: 'kyfb-property-claim-details',
  templateUrl: './property-claim-details.component.html',
  styleUrls: ['./property-claim-details.component.scss']
})
export class PropertyClaimDetailsComponent implements OnInit {
  @Input() formData;
  @Output() stepChange: EventEmitter<any> = new EventEmitter();
  reportModalRef: BsModalRef;
  selectedPolicyData: any[] = [];
  formSubmitted: boolean = false;
  selectedService:string = '';
  temporaryRepairs: string = '';
  property: string ='';
  constructor(private router: Router, private modalService: BsModalService) { }

  ngOnInit() {
  }

  goToPrevious() {
    this.stepChange.emit({direction: "previous", step: "propertyClaimDetails", "formData": this.formData});
  }

  goToNext(isValid) {
  
    this.formSubmitted = true;
    console.log(isValid);
     if(isValid){
      this.stepChange.emit({direction: "next", step: "autoClaimDetails", "formData": this.formData});
    }

  }

  openModalConfirmation(template5: TemplateRef<any>) {
    console.log("click is working");
    this.reportModalRef = this.modalService.show(template5);
  }
 
  injuryOptionSelected(){
  this.formData.injuryDescription = '';
  }
  policeReportoptionChanged(){
    this.formData.agencyNamePolice = '';
    this.formData.reportNumberPolice = '';
  }
  emergencyOptionSelected(){
    this.formData.contractorName = '';
  }
  fireDepartmentOptionSelected(){
    this.formData.agencyFire= '';
    this.formData.reportNumberFire = '';
  }

  goBackToDashboard(template5: TemplateRef<any>) {
    this.reportModalRef.hide();
    this.router.navigate(['/claims']);
  }
}

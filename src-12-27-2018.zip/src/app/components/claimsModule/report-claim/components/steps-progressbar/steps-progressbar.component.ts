import { Component, OnInit, Input } from '@angular/core';

@Component({
    selector: 'claim-steps-navbar',
    templateUrl: './steps-progressbar.component.html'
})

export class StepsProgressBarComponent implements OnInit {
    @Input() currentStep: number = 1;
    steps: any[];
    constructor() {
      this.steps = ["Step 1", "Step 2", "Step 3", "Step 4", "Submit"]
    }
    
    ngOnInit() {
        
    }
}

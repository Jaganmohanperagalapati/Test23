import { Component, OnInit, Input, TemplateRef, Output, EventEmitter } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { Router } from '@angular/router';
import { ClaimService } from './../../../../../services/claim.service';
import { Location } from '@angular/common';

@Component({
  selector: 'kyfb-contact-info',
  templateUrl: './contact-info.component.html',
  styleUrls: ['./contact-info.component.scss']
})
export class ContactInfoComponent implements OnInit {
  @Input() contactInfoData;
  @Input() formData;
  @Output() stepChange: EventEmitter<any> = new EventEmitter();
  reportModalRef: BsModalRef;
  contactInfo: string = '';
  //contactName: any[] = [];
  formSubmitted: boolean = false;
  otherContactformSubmitted: boolean = false;
  // selectedContact: any[] = [];
  selectedContactNumber: string = '';
  cellNumber: any[] = [];
  contactNumbers: any[] = [];
  // contact : any[] =[];
  oldContactNumber = '';
  constructor(private router: Router, private modalService: BsModalService,
    private claimService: ClaimService) { }

  ngOnInit() {
    this.setContactInfoData();
    this.setContactName()
  }
  setContactName() {
    const claimtype = this.claimService.getclaimType();
    if (claimtype === 'property') {
      this.formData.contactInfo = '';
    }
  }

  goToPrevious() {
    this.stepChange.emit({ direction: "previous", step: "contactInfo", "formData": this.formData });
    this.setContactName();
  }

  onEnterContactNumber(event, tmpvar) {
  
    this.checkValidCharacters(event, tmpvar);

  }

  numberPressed(evt, tmpVar) {
    const flag = /^[0-9]$/.test(evt.key);
    return flag;
  }

  appendCharacters(tmpvar) {
    this.otherContactformSubmitted = false;
    let cellNumberVal = tmpvar.value;
    if (cellNumberVal.trim() != '') {
      var size = cellNumberVal.length;
      if (size === 0) {
        cellNumberVal = cellNumberVal;
      } else if (size === 3 ) {
        cellNumberVal = this.getNumbers(cellNumberVal);
        cellNumberVal = cellNumberVal + '-';
      }  else if (size === 7 ) {
        cellNumberVal = this.getNumbers(cellNumberVal);
        cellNumberVal = cellNumberVal.substring(0, 3) + '-' + cellNumberVal.substring(3, 6) + '-';
      }  else if (size === 12 ) {
        cellNumberVal = this.getNumbers(cellNumberVal);
        cellNumberVal = cellNumberVal.substring(0, 3) + '-' + cellNumberVal.substring(3, 6) + '-' +
          cellNumberVal.substring(6, 10) + 'x';
      } else if (size >= 6 && size < 8) {
        cellNumberVal = this.getNumbers(cellNumberVal);
        cellNumberVal = cellNumberVal.substring(0, 3) + '-' + cellNumberVal.substring(3, 6);
      } else if (size >= 11 && size < 13) {
        cellNumberVal = this.getNumbers(cellNumberVal);
        cellNumberVal = cellNumberVal.substring(0, 3) + '-' + cellNumberVal.substring(3, 6) + '-' +
          cellNumberVal.substring(6, 10);
      } else if (size >= 13 && size <= 16) {  
        cellNumberVal = this.getNumbers(cellNumberVal);      
        cellNumberVal = cellNumberVal.substring(0, 3) + '-' + cellNumberVal.substring(3, 6) + '-' +
          cellNumberVal.substring(6, 10) + 'x' + cellNumberVal.substring(10, 13);
      }
      this.formData.cellNumberNew = cellNumberVal;
    }

  }

  getNumbers(value) {
    const pattern = /[-x]+/g;
    value = value.replace(pattern, '');
    return value;
  }

  checkValidCharacters(event, tmpvar) {
    const flag = /^[0-9]$/.test(event.key);
    if (flag) {
      this.appendCharacters(tmpvar);
    }
  }

  goToNext(isValid) {
    this.formSubmitted = true;
    this.otherContactformSubmitted = true;
    if (isValid) {
      this.stepChange.emit({ direction: "next", step: "contactInfo", "formData": this.formData });
    }
    this.setContactName();
  }

  setContactInfoData() {
    if (this.contactInfoData && this.formData.contactInfo === '') {
      this.formData.contactInfo = this.contactInfoData[0].clientReferenceNo;
    }
    this.prepareContactNumbers();
  }

  onChangeContact() {
    if (this.formData.contactInfo === 'other') {
      this.formData.cellNumber = 'other';
      this.formData.contactNameNumbersDTOList = [];
      this.otherContactformSubmitted = false;
    } else {
      this.formData.cellNumber = '';
      this.prepareContactNumbers();
    }
  }

  prepareContactNumbers() {
    this.contactNumbers = [];
    const index = this.contactInfoData.findIndex(c => c.clientReferenceNo == this.formData.contactInfo);
    if (index >= 0) {
      this.formData.contactNameNumbersDTOList = this.contactInfoData[index];
      this.otherContactformSubmitted = false;
      if (this.contactInfoData[index].workPhoneNumber) {
        this.contactNumbers.push({ "label": `Work: ${this.contactInfoData[index].workPhoneNumber}`, "value": this.contactInfoData[index].workPhoneNumber });
      }
      if (this.contactInfoData[index].cellPhoneNumber) {
        this.contactNumbers.push({ "label": `Cell: ${this.contactInfoData[index].cellPhoneNumber}`, "value": this.contactInfoData[index].cellPhoneNumber });
      }
      if (this.contactInfoData[index].homePhoneNumber) {
        this.contactNumbers.push({ "label": `Home: ${this.contactInfoData[index].homePhoneNumber}`, "value": this.contactInfoData[index].homePhoneNumber });
      }
    }
  }

  openModalConfirmation(template6: TemplateRef<any>) {
    console.log("click is working");
    this.reportModalRef = this.modalService.show(template6);
  }


  goBackToDashboard(template6: TemplateRef<any>) {
    this.reportModalRef.hide();
    this.router.navigate(['/claims']);
  }
}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PoliciesMainComponent } from './policies-main/policies-main.component';

import { ReportClaimComponent } from './report-claim/report-claim.component';
import { CompleteComponent } from './complete/complete.component';

const routes: Routes = [
    { path: '', component: PoliciesMainComponent },
    { path:'policies-main',component:PoliciesMainComponent },
    { path:'report-claim',component:ReportClaimComponent },
    { path: 'complete', component:CompleteComponent }    
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ClaimsRoutingModule { }

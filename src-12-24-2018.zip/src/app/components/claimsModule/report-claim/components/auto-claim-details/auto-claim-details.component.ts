import { Component, OnInit, Input, TemplateRef, Output, EventEmitter } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { Router } from '@angular/router';



@Component({
  selector: 'kyfb-auto-claim-details',
  templateUrl: './auto-claim-details.component.html',
  styleUrls: ['./auto-claim-details.component.scss']
})
export class AutoClaimDetailsComponent implements OnInit {
  @Input() vehicleList;
  @Input() contactList;
  @Input() formData;
  @Output() stepChange: EventEmitter<any> = new EventEmitter();
  vehicleInvolved: string = "";
  vehicleYear: string ="";
  vehicleMake: string ="";
  vehicleModel: string ="";
  vehicleVIN: string ="";
  driverInvolved: string ="";
 // airbagsDeployed: string ="";
  airBagsRadio: string= '';
 
  vehicleInfoData: any[];
  //selectedVehicle : string ="";
  vehicleDriveRadio: string ="";
  driverFirstName : string ="";
  vehicleInvolvedChose: string= "";
  vehicleInfo: any;
  reportModalRef: BsModalRef;
  formSubmitted: boolean = false;
  otherVehicleformSubmitted: boolean = false;
  otherDriverformSubmitted: boolean = false;
  selectedVehicleInvolved: string = '';
  vehiclesInvolved: any[] =[];
  selectedPolicyData: any[] = [];
 // possibleInjuries: string ='';
  injuryRadio: string = '';
  driverDetail: string ='';
  public isValidZipCode = false;
  public vehicleZip;
  state: any = "";
  states = {
   "USA": {
     "stateTitle": 'State',
     // "statesList": ["Kentucky", "Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "District of Columbia", "Florida", "Georgia", "Hawaii", "Idaho",  "Illinois", "Indiana", "Iowa", "Kansas"," Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi"," Missouri", "Montana", "Nebraska", "Nevada"," New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah","Vermont", "Virginia", "Washington"," West Virginia","Wisconsin", "Wyoming"]
     "statesList": [
      {"shortName": "KY", "name": "Kentucky"}, 
      {"shortName": "AL", "name": "Alabama"},
      {"shortName": "AK", "name": "Alaska"},
      {"shortName": "AZ", "name": "Arizona"},
      {"shortName": "AR", "name": "Arkansas"},
      {"shortName": "CA", "name": "California"},
      {"shortName": "CO", "name": "Colorado"},
      {"shortName": "CT", "name": "Connecticut"},
      {"shortName": "DE", "name": "Delaware"},
      {"shortName": "DC", "name": "District ofColumbia"},
      {"shortName": "FL", "name": "Florida"},
      {"shortName": "GA", "name": "Georgia"},
      {"shortName": "HI", "name": "Hawaii"},
      {"shortName": "ID", "name": "Idaho"},
      {"shortName": "IL", "name": "Illinois"},
      {"shortName": "IN", "name": "Indiana"},
      {"shortName": "IA", "name": "Iowa"},
      {"shortName": "KS", "name": "Kansas"},
      {"shortName": "LA", "name": "Louisiana"},
      {"shortName": "ME", "name": "Maine"},
      {"shortName": "MA", "name": "Massachusetts"},
      {"shortName": "MI", "name": "Michigan"},
      {"shortName": "MN", "name": "Minnesota|"},
      {"shortName": "MS", "name": "Mississippi"},
      {"shortName": "MO", "name": "Missouri"},
      {"shortName": "MT", "name": "Montana"},
      {"shortName": "NE", "name": "Nebraska"},
      {"shortName": "NV", "name": "Nevada"},
      {"shortName": "NH", "name": "New Hampshire"},
      {"shortName": "NJ", "name": "New Jersey"},
      {"shortName": "NM", "name": "New Mexico"},
      {"shortName": "NC", "name": "North Carolina"},
      {"shortName": "ND", "name": "North Dakota"},
      {"shortName": "OH", "name": "Ohio"},
      {"shortName": "OK", "name": "Oklahoma"},
      {"shortName": "OR", "name": "Oregon"},
      {"shortName": "PA", "name": "Pennsylvania"},
      {"shortName": "RI", "name": "Rhode Island"},
      {"shortName": "SC", "name": "South Carolina"},
      {"shortName": "SD", "name": "South Dakota"},
      {"shortName": "TN", "name": "Tennessee"},
      {"shortName": "TX", "name": "Texas"},
      {"shortName": "UT", "name": "Utah"},
      {"shortName": "VT", "name": "Vermont"},
      {"shortName": "VA", "name": "Virginia"},
      {"shortName": "WA", "name": "Washington"},
      {"shortName": "WV", "name": "West Virginia"},
      {"shortName": "WI", "name": "Wisconsin"},
      {"shortName": "WY", "name": "Wyoming"}
      
     ] 
    },
   "CAN": {
    "stateTitle": 'Province',
    //"statesList": ["Alberta", "British Columbia", "Manitoba", "New Brunswick", "Newfoundland", "Northwest Territories", "Nova Scotia", "Nunavut", "Ontario", "Prince Edward Island", "Quebec", "Saskatchewan", "Yukon Territory"]
    "statesList": [
      {"shortName": "AB", "name": "Alberta"}, 
      {"shortName": "BC", "name": "British Columbia"}, 
      {"shortName": "MB", "name": "Manitoba"}, 
      {"shortName": "NB", "name": "New Brunswick"}, 
      {"shortName": "NL", "name": "Newfoundland and Labrador"}, 
      {"shortName": "NT", "name": "Northwest Territories"}, 
      {"shortName": "NU", "name": "Nunavut"}, 
      {"shortName": "ON", "name": "Ontario"}, 
      {"shortName": "PE", "name": "Prince Edward Island"}, 
      {"shortName": "QC", "name": "Quebec"}, 
      {"shortName": "SK", "name": "Saskatchewan"}, 
      {"shortName": "YT", "name": "Yukon"}
     
    ]
  },
   "MEX": {
    "stateTitle": 'Province',
   // "statesList": ["Aguascalientes","Baja California","Baja California Sur","Campeche","Chiapas","Chihuahua","Coahuila de Zaragoza","Colima","Distrito Federal","Durango|Guanajuato","Guerrero|Hidalgo","Jalisco","Mexico|Michoacan de Ocampo","Morelos","Nayarit","Nuevo Leon","Oaxaca","Puebla","Queretaro de Arteaga","Quintana Roo","San Luis Potosi","Sinaloa","Sonora","Tabasco","Tamaulipas","Tlaxcala","Veracruz-Llave","Yucatan","Zacatecas"]    
   "statesList": [
   {"shortName": "AG", "name": "Aguascalientes"}, 
   {"shortName": "BCN", "name": "Baja California"}, 
   {"shortName": "BS", "name": "Baja California Sur"}, 
   {"shortName": "CM", "name": "Campeche"}, 
   {"shortName": "CS", "name": "Chiapas"}, 
   {"shortName": "CH", "name": "Chihuahua"}, 
   {"shortName": "COA", "name": "Coahuila"}, 
   {"shortName": "CL", "name": "Colima"}, 
   {"shortName": "DF", "name": "Distrito Federal"}, 
   {"shortName": "DG", "name": "Durango"}, 
   {"shortName": "GT", "name": "Guanajuato"}, 
   {"shortName": "GR", "name": "Guerrero"}, 
   {"shortName": "HG", "name": "Hidalgo"}, 
   {"shortName": "JA", "name": "Jalisco"}, 
   {"shortName": "MEX", "name": "Mexico"}, 
   {"shortName": "MIC", "name": "Michoacan"}, 
   {"shortName": "MOR", "name": "Morelos"}, 
   {"shortName": "NA", "name": "Nayarit"}, 
   {"shortName": "NLE", "name": "Nuevo Leon"}, 
   {"shortName": "OA", "name": "Oaxaca"}, 
   {"shortName": "PB", "name": "Puebla"}, 
   {"shortName": "QT", "name": "Queretaro"}, 
   {"shortName": "QR", "name": "Quintana Roo"},
   {"shortName": "SL", "name": "San Luis Potosi"}, 
   {"shortName": "SI", "name": "Sinaloa"}, 
   {"shortName": "SO", "name": "Sonora"}, 
   {"shortName": "TB", "name": "Tabasco"}, 
   {"shortName": "TM", "name": "Tamaulipas"}, 
   {"shortName": "TL", "name": "Tlaxcala"},
   {"shortName": "VE", "name": "Veracruz"}, 
   {"shortName": "YU", "name": "Yucatan"}, 
   {"shortName": "ZA", "name": "Zacatecas"} 

 ]    
  }
  }
  country: string = 'USA';
  zipCodePattern: string;
  firstNamePattern: string = "[^?%^,.=_/\\:;@/~!#$*<>|{}+`]*";
  //firstNamePattern: string = "[a-zA-Z0-9 ]*";
  constructor(private router: Router, private modalService: BsModalService) { }

  ngOnInit() {
    this.selectedPolicyData = JSON.parse(localStorage.getItem('selectedPolicy'));
    this.getZipCodePattern();
  }

  onChangeVehicleInvolved() {
    if(this.formData.vehicle === 'other') {
      this.otherVehicleformSubmitted = false;
      this.formData.vehicleInfoDTOList = [];
    } else {
      const index = this.vehicleList.findIndex(v => v.vehicleDesc == this.formData.vehicle);
      if (index >= 0) {      
        this.formData.vehicleInfoDTOList = this.vehicleList[index];
      }
    }  
  }

  onChangeDriverInvolved(){
    if(this.formData.driver === 'other') {
      this.otherDriverformSubmitted = false;
    }
  }
 
  goToPrevious(){
    this.stepChange.emit({direction: "previous", step: "autoClaimDetails", "formData": this.formData});
  }

  goToNext(isValid){
    this.formSubmitted = true;
    this.otherVehicleformSubmitted = true;
    this.otherDriverformSubmitted = true;
    console.log(isValid);
    if(isValid){
      this.stepChange.emit({direction: "next", step: "autoClaimDetails", "formData": this.formData});
    }

  }
  openModalConfirmation(template4: TemplateRef<any>) {
    console.log("click is working");
    this.reportModalRef = this.modalService.show(template4);
  }
  optionSelected: any;
  //public country: string = 'USA';
   onOptionSelected(event){
    console.log(event); //option value will be sent as event
   }

  goBackToDashboard(template4: TemplateRef<any>) {
    this.reportModalRef.hide();
    this.router.navigate(['/claims']);
  }
 
  vehicleOptionChanged(){
    this.formData.vehicleAddress = '';
    this.formData.vehicleAddress2 ='';
    this.formData.vehicleCity = '';
    this.formData.vehicleState = '';
    this.formData.vehicleZip = '';
    //this.formData.vehicleCountry = '';

  }

  injuryOptionChanged(){
    this.formData.injuryDescription = '';
  }


  policeReportOptionChanged(){
  this.formData.agencyNamePolice = '';
  this.formData.reportNumberPolice = '';
  }

  FireDepartmentOptionChanged(){
    this.formData.agencyFire = '';
    this.formData.reportNumberFire = '';
  }



  getZipCodePattern() {
    switch (this.formData.vehicleCountry) {
      case 'USA': {
        this.zipCodePattern = "^([0-9]{5})(?:[-\s]*([0-9]{4}))?$";
        break;
      }
      case 'CAN': {
        this.zipCodePattern = "^([A-Z][0-9][A-Z])\s*([0-9][A-Z][0-9])$";
        break;
      }
      case 'MEX': {
        this.zipCodePattern = "^([0-9]{5})$";
        break;
      }      
    }
  }

  onCountryChange() {
    this.getZipCodePattern();
  }
  
}

var webpack = require('webpack');
var HtmlWebpackPlugin = require('html-webpack-plugin');
var ExternalsPlugin = require('webpack-externals-plugin');
var HtmlWebpackIncludeAssetsPlugin = require('html-webpack-include-assets-plugin');

//the following default values are environment-specific, can/do change for prod
var commonChunksPluginMode =
  new webpack.optimize.CommonsChunkPlugin(
    { name: 'polyfills' }
  );
var typeScriptFileToCompile = './demo/main.ts';
var entryList = {
  'ng2-proxy-picker-wrapper': typeScriptFileToCompile,
  'polyfills': [
    'core-js/es6',
    'core-js/es7/reflect',
    'zone.js/dist/zone'
  ]
};
var resolveExtensions = ['', '.js', '.ts', '.html', '.css'];
var htmlToExclude = null;


module.exports = {

  entry: entryList,
  output: {
    path: './temp_local_server_lib',
    filename: '[name].js'
  },
  devtool: 'source-map',
  module: {
    loaders: [
      {test: /\.component.ts$/, loader: 'ts!angular2-template'},
      {test: /\.ts$/, exclude: /\.component.ts$/, loader: 'ts'},
      {test: /\.html$/, loader: 'raw'},
      {test: /\.css$/, loader: 'raw'}
    ]
  },
  resolve: {
    extensions: resolveExtensions
  },
  plugins: [
    //new webpack.optimize.CommonsChunkPlugin({
    //  name: 'polyfills'
    //}),
    commonChunksPluginMode,
    new HtmlWebpackPlugin({
      template: './demo/index.html',
      inject: 'body'
    }),
    new HtmlWebpackIncludeAssetsPlugin({
      assets: [
        'node_modules/kp-proxy-picker/lib/kp-proxy-picker.css',
        'node_modules/jquery/dist/jquery.js',
        'node_modules/lodash/lodash.js',
        'node_modules/ua-parser-js/src/ua-parser.js',
        'node_modules/rsvp/dist/rsvp.js',
        'node_modules/js-cookie/src/js.cookie.js',
        'node_modules/postal/lib/postal.js',
        'node_modules/postal.request-response/lib/postal.request-response.js',
        'node_modules/kp-client-commons/lib/kp-client-commons.js',
        'node_modules/kp-user-profile/lib/kp-user-profile.js',
        'node_modules/kp-proxy-picker/lib/kp-proxy-picker.js'
      ],
      append: false
    }),
    new webpack.DefinePlugin({
      app: {
        environment: JSON.stringify(process.env.APP_ENVIRONMENT || 'development')
      }
    })
  ]
};

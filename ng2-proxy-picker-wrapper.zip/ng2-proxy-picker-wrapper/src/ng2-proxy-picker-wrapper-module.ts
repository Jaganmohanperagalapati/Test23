//import "reflect-metadata";
import {NgModule} from '@angular/core'
import {NGWrapperProxyPickerClient} from './ng2-proxy-picker-wrapper'

@NgModule({
  providers: [
    NGWrapperProxyPickerClient
  ],
  exports: [
    //NGWrapperProxyPickerClient
  ]
})
export class NGWrapperProxyPickerClientModule {
}

declare var $kp: any;

/**
 * This is the object emitted by NGWrapperProxyPickerClient.
 */
export class NGWrapperProxyPickerClientSubject {
  //private entitlementErrorOccurredForCurrentSelection:boolean;
  //private entitlementErrorOccurredForSelf:boolean;
  constructor(
      private relid: string,
      private userChangedStateOfProxyPickerAtLeastOnceSinceLoading: boolean) {
    //this.entitlementErrorOccurredForCurrentSelection =
    //  !$kp.KPUserProfile.UserProfileClient.getEntitlements(relid);
    //this.entitlementErrorOccurredForSelf =
    //  !$kp.KPUserProfile.UserProfileClient.getEntitlements('self');
  }
  /**
   * Return the relationship ID of the selected subject. The value 'self' means that the proxy has selected him/herself.
   */
  public getRelationshipId() {
    return this.relid;
  }
  /**
   * Return true if the proxy has selected someone else, false otherwise.
   */
  public isProxySelected():boolean {
    return (this.getRelationshipId() !== 'self');
  }
  /**
   * Return true if the proxy has selected changed the initial selected subject at least once, false otherwise.
   */
  public hasUserChangedStateOfProxyPickerAtLeastOnceSinceLoading():boolean {
    return this.userChangedStateOfProxyPickerAtLeastOnceSinceLoading;
  }
  /**
   * Return true if there was an error loading entitlement information for currently-selected subject, false otherwise.
   */
  public isEntitlementErrorOccurredForCurrentSelection():boolean {
    //console.log('ngppw this.relid = ' + this.relid);
    //Note - for some strange reason, 'this.relid' can briefly be 'undefined'
    //  when eventual subject is selected whose 'getEntitlements()' returns null
    let weirdIntermediaryStateOfSubjectWhoseEntitlementsCallFailed =
      (typeof this.relid === 'undefined');
    return weirdIntermediaryStateOfSubjectWhoseEntitlementsCallFailed
      || !$kp.KPUserProfile.UserProfileClient.getEntitlements(this.relid);
  }
  /**
   * Return true if there was an error loading entitlement information for the proxy him/herself, false otherwise.
   */
  public isEntitlementErrorOccurredForSelf():boolean {
    return !$kp.KPUserProfile.UserProfileClient.getEntitlements('self');
  }
}
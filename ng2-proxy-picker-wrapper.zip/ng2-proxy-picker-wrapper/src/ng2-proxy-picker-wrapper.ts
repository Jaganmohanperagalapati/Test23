import {Injectable, NgZone} from '@angular/core'
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {Observable} from 'rxjs/Observable';
//import {Subscription} from 'rxjs/Subscription';
import {NGWrapperProxyPickerClientSubject} from './ng2-proxy-picker-wrapper-subject'

declare var $kp: any;

/**
 * This is the Ng2 proxy picker wrapper class that should be imported/used by client projects.
 *
 * It's of type 'BehaviorSubject' which is a type of Observable that always returns the last-emitted object
 * whenever a subscriber first subscribes to this class. The subscriber will also receive emitted objects afterwards.
 *
 * This 'BehaviorSubject' is initialized (first emitted object) with the initial state of the proxy picker.
 */
@Injectable()
export class NGWrapperProxyPickerClient
    extends BehaviorSubject<NGWrapperProxyPickerClientSubject> {
  constructor(private zone: NgZone) {
    super(
      new NGWrapperProxyPickerClientSubject(
        (<string>$kp.KPProxyPicker.ProxyPickerClient.getRelationshipId()), false)
    );
    //$kp.KPClientCommons.Communicator.CHANNEL[
    //  $kp.KPClientCommons.Communicator.ENUMS.CHANNEL.GLOBAL].subscribe(
    //    $kp.KPClientCommons.Communicator.ENUMS.TOPIC.CHANGE_ENTITLEMENTS,
    //    function()  {console.log('Entitlements Call Made')});
    $kp.KPProxyPicker.ProxyPickerClient.onChange(
      (data: any) => {
        this.zone.run( () => {
          this.fireOnChangeNotification(data);
        } );
      }
    );
  }
  /**
   * This is a callback function for the proxy picker to notify this component when the proxy picker's subject changes.
   * This function should not be called by anything else.
   */
  fireOnChangeNotification(data: any) {
    this.next(new NGWrapperProxyPickerClientSubject((<string>data.relid), true));
  }
}

var proxies = require("./proxyinformation/proxyinformation.json");

module.exports = {
    path: '/mycare/v2.1/proxyinformation',
    template: function(params, query, body, cookie) {
        //return proxies to test
        return proxies;
    }
}

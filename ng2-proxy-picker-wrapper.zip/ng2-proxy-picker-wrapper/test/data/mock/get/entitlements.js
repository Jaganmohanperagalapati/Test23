var entitlement0 = require("./entitlements/default.json");
var entitlement1 = require("./entitlements/613TASNPXTBB.json");
var entitlement2 = require("./entitlements/613KTPFFKLW.json");
var entitlement3 = require("./entitlements/613KTP1111.json");
var entitlement4 = require("./entitlements/noPrescription.json");


module.exports = {
    path: '/mycare/v2.0/entitlements',
    template: function(params, query, body) {
        if (query.relid == "613TASNPXTBB") {
            return entitlement1;
        } else if (query.relid == "613KTPFFKLW") {
            return entitlement2;
        } else if (query.relid == "613KTP1111") {
            return entitlement3;
        } else if (query.relid == "613KTP1201") {
            return entitlement3;
        } else {
            return entitlement0;
        }
    }

}

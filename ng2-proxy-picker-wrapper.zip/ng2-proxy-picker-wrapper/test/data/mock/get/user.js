var member = require("./user/member.json");
var nma = require("./user/nma.json");

module.exports = {
    path: '/mycare/v1.0/user',
    template: function(params, query, body, cookie) {
        //return member to test member case
        return member;
    }
}

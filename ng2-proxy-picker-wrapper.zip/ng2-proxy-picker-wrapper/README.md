# Ng2 Proxy Picker Wrapper
This project provides an Angular2-compliant wrapper for the Proxy Picker shared component.
  - './src/ng2-proxy-picker-wrapper.ts' is the main file of this project and it assumes that the Proxy Picker has successfully loaded onto the web page (with associated JavaScript variable residing at namespace location '$kp.KPProxyPicker.ProxyPickerClient').
  - The files in the './demo' directory are used to create a demo web page to test the interface class at './src/ng2-proxy-picker-wrapper.ts'.
  - The files in the './test' directory are to provide supporting (dyson) mock web services for the demo page.
  - The actual (compiled) library with supporting files resides in the './lib' directory.

## Using This Component in Another Project
The './lib' directory contains the files that should be used by another project. Obviously, these files should be treated just like any other shared JavaScript library and follow the conventions of the 'npm' system. For instance, this library could be imported into another project by adding the following entry under the 'dependencies' section of that project's 'package.json' file (note - the version used here is just an example, check for newer versions).

```
"ng2-proxy-picker-wrapper": "^0.1.4"
```

Then import the 'NGWrapperProxyPickerClient' class and declare it as a provider in the main Angular2 (module) class of the project. In general, this is the only place in the project where the 'NGWrapperProxyPickerClient' class should be declared as a provider. Here's an example (the '...' refers to unrelated text removed for brevity).

```
...
import { NGWrapperProxyPickerClient } from "ng2-proxy-picker-wrapper";
...

@NgModule({
    ...
    providers: [
        ...
        NGWrapperProxyPickerClient,
    ],
})
export class AppModule {}
```

Then import the 'NGWrapperProxyPickerClient' class as a constructor argument (not as a provider) in the class that wants to use it. Here's an example (the '...' refers to unrelated text removed for brevity).

```
...
import { NGWrapperProxyPickerClient } from "ng2-proxy-picker-wrapper";
...
    constructor( ...,
                 private ngwppc: NGWrapperProxyPickerClient ) {
                 }
...
    somefunction(): void {
                if ( this.ngwppc.getValue().isProxySelected() == false ) {
                    ...
                }
    }
```

## Project Setup
Run 'npm install' to setup this project. That command downloads all the necessary libraries needed to compile and execute the project.

## Run Demo Page
Run 'npm run serve' to run a local server which will create this project's demo page at URL http://localhost:8080/ . Also run 'npm run dyson' in a separate window to provide the supporting (mock) web services for the proxy picker. Read the instructions on that page and then interact with its components to get a more complete understanding of how this wrapper functions.

## Create Build
Run 'npm run build' to update this project's library files (for public use) in the './lib' directory.

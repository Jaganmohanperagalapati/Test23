import { Component } from '@angular/core';
import { NGWrapperProxyPickerClient } from '../../src/ng2-proxy-picker-wrapper';
import { NGWrapperProxyPickerClientSubject } from '../../src/ng2-proxy-picker-wrapper';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  public subscriberOne:NGWrapperProxyPickerClientSubject =
    new NGWrapperProxyPickerClientSubject('No Message Received', false);
  public subscriberTwo:NGWrapperProxyPickerClientSubject =
    new NGWrapperProxyPickerClientSubject('No Message Received', false);
  public subscriberTwoInitialized:boolean = false;
  constructor(private ppc : NGWrapperProxyPickerClient) {
    this.ppc.subscribe(
      (data) => {
        console.log(
          'Updating "subscriberOne" ('
            + this.subscriberOne.getRelationshipId()
            + ') to - ' + data.getRelationshipId());
        this.subscriberOne = data;
      });
  }
  clickAction() {
    //
    console.log("");
    console.log('(subscriberOne)');
    console.log('getRelationshipId() = '
      + this.subscriberOne.getRelationshipId());
    console.log('isProxySelected() = '
      + this.subscriberOne.isProxySelected());
    console.log('hasUserChangedStateOfProxyPickerAtLeastOnceSinceLoading() = '
      + this.subscriberOne.hasUserChangedStateOfProxyPickerAtLeastOnceSinceLoading());
    console.log('isEntitlementErrorOccurredForCurrentSelection() = '
      + this.subscriberOne.isEntitlementErrorOccurredForCurrentSelection());
    console.log('isEntitlementErrorOccurredForSelf() = '
      + this.subscriberOne.isEntitlementErrorOccurredForSelf());
    //
    console.log("");
    console.log('(subscriberTwo)');
    console.log('getRelationshipId() = '
      + this.subscriberTwo.getRelationshipId());
    console.log('isProxySelected() = '
      + this.subscriberTwo.isProxySelected());
    console.log('hasUserChangedStateOfProxyPickerAtLeastOnceSinceLoading() = '
      + this.subscriberTwo.hasUserChangedStateOfProxyPickerAtLeastOnceSinceLoading());
    console.log('isEntitlementErrorOccurredForCurrentSelection() = '
      + this.subscriberTwo.isEntitlementErrorOccurredForCurrentSelection());
    console.log('isEntitlementErrorOccurredForSelf() = '
      + this.subscriberTwo.isEntitlementErrorOccurredForSelf());
    //
    //console.log('getRelationshipId = ' + this.ppc.getRelationshipId());
    //console.log('isProxySelected = ' + this.ppc.isProxySelected());
  }
  registerSecondSubscriber() {
    if (!this.subscriberTwoInitialized) {
      this.subscriberTwoInitialized = true;
      this.ppc.subscribe(
        (data) => {
          console.log(
            'Updating "subscriberTwo" ('
              + this.subscriberTwo.getRelationshipId()
              + ') to - ' + data.getRelationshipId());
          this.subscriberTwo = data;
        });
      console.log('The second subscriber has been registered');
    } else {
      console.log('You already did that (register a second subscriber)');
    }
  }
}

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { NGWrapperProxyPickerClient } from '../../src/ng2-proxy-picker-wrapper';

@NgModule({
  imports: [BrowserModule],
  declarations: [AppComponent],
  bootstrap: [AppComponent],
  providers: [NGWrapperProxyPickerClient]
})
export class AppModule { }

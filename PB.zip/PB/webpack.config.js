'use strict';

var webpack = require('webpack');
var CopyWebpackPlugin = require('copy-webpack-plugin');
var HtmlWebpackPlugin = require('html-webpack-plugin');
var HtmlWebpackIncludeAssetsPlugin = require('html-webpack-include-assets-plugin');

var path = require('path');
var bourbon = require('node-bourbon').includePaths;
var neat = require('node-neat').includePaths;
var MiniCssExtractPlugin = require('mini-css-extract-plugin');
var WebpackStrip = require('webpack-strip');
var UglifyJSPlugin = require('uglifyjs-webpack-plugin');

var stripConsoleLog = (process.env.STRIP_CONSOLE_LOG === 'true');

var loadersToUse = [
    {
        test: /\.ts$/,
        loader: 'ts-loader'
    },
    // {
    //     test: /\.css$/,
    //     use: MiniCssExtractPlugin.extract({
    //         fallback: 'style-loader',
    //         use: [
    //         {
    //           loader: MiniCssExtractPlugin.loader,
    //           options: {
    //             // you can specify a publicPath here
    //             // by default it use publicPath in webpackOptions.output
    //             publicPath: '../'
    //           }
    //         },
    //         "css-loader"
    //       ]
    //     })
    // },
    // {
    //     test: /\.(eot|svg|ttf|woff|woff2)$/,
    //     loader: 'url-loader'
    // },
    // {
    //     test: /\.(png)$/,
    //     loader: 'file-loader'
    // },
    {
        test: /[^\s]*[^index]\.html/,
        use: 'file-loader?name=views/[name].[ext]'
    }
];

var pluginsToUse = [
    new HtmlWebpackPlugin({
        template: './src/index.html'
    }),
    new CopyWebpackPlugin([
        {from: 'test/data'}
    ]),
    new HtmlWebpackIncludeAssetsPlugin({
        assets: [
            'node_modules/kp-proxy-picker/lib/kp-proxy-picker.css',
            'node_modules/jquery/dist/jquery.js',
            'node_modules/lodash/lodash.js',
            'node_modules/ua-parser-js/src/ua-parser.js',
            'node_modules/rsvp/dist/rsvp.js',
            'node_modules/js-cookie/src/js.cookie.js',
            'node_modules/postal/lib/postal.js',
            'node_modules/postal.request-response/lib/postal.request-response.js',
            'node_modules/kp-client-commons/lib/kp-client-commons.js',
            'node_modules/kp-user-profile/lib/kp-user-profile.js',
            'node_modules/kp-proxy-picker/lib/kp-proxy-picker.js'
            ],
        append: false
    }),
    new MiniCssExtractPlugin({
      filename: 'styles.bundle.css'
    })
];

module.exports = {
  optimization: {
    minimizer: [
      new UglifyJSPlugin({
        sourceMap: true,
        warningsFilter: function() {return false;},
        uglifyOptions: {
          // Eliminate comments
          // comments: false,
          // Compression specific options
          compress: {
            // remove warnings
            // warnings: false,
            // Drop console statements
            drop_console: stripConsoleLog
          }
        }
      })
     ]
   },

    entry: {
        app: ['./src/main.ts', './src/styles.css']
    },
    devtool: "#inline-source-map",
    stats: {warnings: false},
    output: {
        filename: '[name].bundle.js',
        path: path.resolve(__dirname, 'dist/pb')
    },
    mode: 'development',
    module: {
      // loaders: loadersToUse,
      // exprContextCritical: false,
      rules: [
       {
         test: /\.(sa|sc|c)ss$/,
         use: [
            {
              loader: MiniCssExtractPlugin.loader,
              options: {
                // you can specify a publicPath here
                // by default it use publicPath in webpackOptions.output
                publicPath: '../'
              }
            },
            'css-loader'
          ]
       },
       {
        test: /\.tsx?$/,
        use: [
          {
            loader: 'ts-loader',
            options: {
              transpileOnly: true
            }
          }
        ]
       }
     ]
    },
    performance: {
      hints: false
    },
    resolve: {
        modules: ['node_modules', 'node_modules/styleguide', __dirname + '/src'],
        extensions: ['.js', '.ts', '.css']
    },

    plugins: pluginsToUse

};

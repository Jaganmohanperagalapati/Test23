'use strict';

var directories = {
    node_modules: 'node_modules',
    styleguide_modern: 'node_modules/styleguide/lib/modern',
    ui_apps_dest: '../ui.apps/src/main/content/jcr_root/etc/designs/kporg/plan-benefits/clientlib-site/'
};

function generateAemFileArray() {
    var outValue = [];
    //General Functions
    var addFileFunction = function (srcFilePath, destFileName, subDir) {
        outValue.push({
            expand: true,
            flatten: true,
            rename: function (dest, src) {
                var lastSlashIndexPlusOne = srcFilePath.lastIndexOf('/') + 1;
                var localFileName = srcFilePath.substring(lastSlashIndexPlusOne);
                return dest + "/" + src.replace(localFileName, destFileName);
            },
            src: srcFilePath,
            dest: directories.ui_apps_dest + subDir
        });
    };

    var addCSSFileFunction = function (srcFilePath, destFileName) {
        addFileFunction(srcFilePath, destFileName, 'css');
    };
    addCSSFileFunction('dist/pb/styles.bundle.css', 'page.css');

    var addJSLibFunction = function (srcFilePath, destFileName) {
        addFileFunction(srcFilePath, destFileName, 'js');
    };
    addJSLibFunction('dist/pb/app.bundle.js', 'app.bundle.js');
    return outValue;
}

module.exports = function (grunt) {
    var styleguidePath = grunt.file.expand(directories.node_modules + '/styleguide');
    grunt.log.write(styleguidePath);

    grunt.initConfig({
        copy: {
            assets_pb: {
                files: [
                    {
                        expand: true,
                        cwd: directories.styleguide_modern,
                        src: 'assets/**/*',
                        dest: 'src'
                    }
                ]
            },
            toAem: {
                files: generateAemFileArray()
            }
        },
        exec: {
            pbLocal: {
                command: 'npm run build:pb',
                maxBuffer: 500 * 1024
            },
            pbAem: {
                command: 'npm run build:pbAem',
                maxBuffer: 500 * 1024
            }
        }
    });

    grunt.registerTask('default', 'Making sure gruntfile runs', function () {
        grunt.log.write("All is good.").ok();
    });

    grunt.loadNpmTasks('grunt-contrib-copy');
    grunt.loadNpmTasks('grunt-exec');

    grunt.registerTask('copyAssets', ['copy:assets_pb']);
    grunt.registerTask('build', ['exec:pb']);

    // Full Build
    grunt.registerTask('buildAem', ['exec:pbAem', 'copy:toAem']);

    //Clean Task
    grunt.registerTask('clean', 'Delete directories and files', function () {
    	var options = this.options();
    	options.force = true;
        grunt.file.delete('dist');
        grunt.file.delete('target');
        grunt.file.delete('src/assets');
        grunt.file.delete('coverage');
        grunt.file.delete(directories.ui_apps_dest + 'js', options);
        grunt.file.delete(directories.ui_apps_dest + 'css', options);
        grunt.log.write("'clean' task has completed").ok();
    });
};

import { Component } from '@angular/core';
import { templates } from './helpers/template.helper';

@Component({
  selector: 'app-root',
  template: templates.GetTemplate('pbrootcomp.html'),
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
}

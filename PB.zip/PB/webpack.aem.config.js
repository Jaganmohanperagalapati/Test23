'use strict';

var webpack = require('webpack');
var CopyWebpackPlugin = require('copy-webpack-plugin');
var HtmlWebpackPlugin = require('html-webpack-plugin');
var HtmlWebpackIncludeAssetsPlugin = require('html-webpack-include-assets-plugin');

var path = require('path');
var neat = require('node-neat').includePaths;
var MiniCssExtractPlugin = require('mini-css-extract-plugin');
const UglifyJSPlugin = require('uglifyjs-webpack-plugin');

var stripConsoleLog = (process.env.STRIP_CONSOLE_LOG === 'true');
var whiteHat = (process.env.WHITE_HAT === 'true');

var distPath = whiteHat? 'dist/pb-whitehat' : 'dist/pb';

var loadersToUse = [
    {
        test: /\.ts$/,
        loader: 'ts-loader'
    }
    // {
    //     test: /\.css$/,
    //     use: MiniCssExtractPlugin.extract({
    //         fallback: 'style-loader',
    //         use: [
    //             {
    //                 loader: 'css-loader',
    //                 options: { url:false, minimize: true } // translates CSS into CommonJS
    //             },
    //             {
    //                 loader: 'sass-loader', // compiles Sass to CSS
    //                 options: {
    //                     includePaths: [].concat(neat) // Loads Bourbon Neat
    //                 }
    //             }]
    //     })
    // },
    // {
    //     test: /\.(eot|svg|ttf|woff|woff2)$/,
    //     loader: 'url-loader'
    // },
    // {
    //     test: /[^\s]*[^index]\.html/,
    //     use: 'file-loader?name=views/[name].[ext]'
    // }
];

var pluginsToUse = [
    new HtmlWebpackPlugin({
        template: './src/index.html'
    }),
    // new CopyWebpackPlugin([
    //     {from: 'test/data'}
    // ]),
    new HtmlWebpackIncludeAssetsPlugin({
        assets: [
        // 'node_modules/kp-proxy-picker/lib/kp-proxy-picker.css',
        // 'node_modules/jquery/dist/jquery.js',
        // 'node_modules/lodash/lodash.js',
        // 'node_modules/ua-parser-js/src/ua-parser.js',
        // 'node_modules/rsvp/dist/rsvp.js',
        // 'node_modules/js-cookie/src/js.cookie.js',
        // 'node_modules/postal/lib/postal.js',
        // 'node_modules/postal.request-response/lib/postal.request-response.js',
        // 'node_modules/kp-client-commons/lib/kp-client-commons.js',
        // 'node_modules/kp-user-profile/lib/kp-user-profile.js',
        // 'node_modules/kp-proxy-picker/lib/kp-proxy-picker.js'
        ],
        append: false
    }),
    new MiniCssExtractPlugin({
      filename: 'styles.bundle.css'
    }),
    new webpack.DefinePlugin({
        'process.env': {
            'NODE_ENV': JSON.stringify('production')
        }
    })
];

const webpackConfig = {
    entry: {
        app: ['./src/main.ts']
    },
    devtool: "#inline-source-map",
    stats: {warnings: false},
    output: {
        filename: '[name].bundle.js',
        path: path.resolve(__dirname, distPath)
    },
    module: {
        rules: loadersToUse,
        exprContextCritical: false
    },
    resolve: {
        modules: ['node_modules', 'node_modules/styleguide', __dirname + '/src'],
        extensions: ['.js', '.ts', '.css']
    },
    plugins: pluginsToUse
};

if (!whiteHat) {
    const uglifyJSPlugin = new UglifyJSPlugin({
        sourceMap: false,
        // Eliminate comments
        // comments: false,
        // Compression specific options
        uglifyOptions: {
            compress: true,
            // remove warnings
            // warnings: false,
            // Drop console statements
            drop_console: stripConsoleLog
        },
    });

    webpackConfig.plugins.push(uglifyJSPlugin);
  }

  module.exports = webpackConfig;

let serviceWorker = {
  register: function(self) {

    // Listen to install event
    self.addEventListener('install', function (event) {
      var host;
  
      switch (self.location.hostname) {
        case "localhost:8080":
          host = "http://localhost:8090";
          break;
        case "wppdev3.kaiserpermanente.org":
          host = "https://api-dev3.kaiserpermanente.org";
          break;
        case "hint2.kaiserpermanente.org":
          host = "https://api-hint2.kaiserpermanente.org";
          break;
        case "healthy.kaiserpermanente.org":
          host = "https://healthy.kaiserpermanente.org";
          break;
      }
  
      // fetch the calls for the user data once the service worker is initialized
      event.waitUntil(
        caches.open("user-data")
          .then(function (cache) {
            // add the fetched values to the cache
            cache.addAll([
              `${host}/mycare/v1.0/user`,
              `${host}/mycare/v2.1/proxyinformation`,
              `${host}/mycare/v2.0/entitlements`
            ]);
          })
      );
    });
  
    // Listen to fetch event
    self.addEventListener('fetch', function (event) {
      var urlFragment = '/mycare/';
  
      // if the request is for either the user, proxy, or entitlement data, return the cached data
      if (event.request.url.indexOf(urlFragment) > -1) {
        event.respondWith(
          caches.open("user-data")
            .then(function (cache) {
              return cache.match(event.request)
                .then(function (response) {
                  // if the cached value doesn't exist, fetch it
                  return response || fetch(event.request)
                    .then(function (response) {
                      // add the fetched value to the cache
                      cache.put(event.request, response.clone());
                      return response;
                    });
                });
            })
        );
      }
    });
  }
};

export default serviceWorker;
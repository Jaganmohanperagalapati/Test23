import { OnInit, Component } from "@angular/core";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import * as ProxyPickerComponent from "kp-proxy-picker";

import { UserDataService } from "../../services/user.data.service";
import { IUser } from "../../interfaces/user.interface";

@Component({
  selector: "mcc-proxy-picker",
  template: '<div id="mcc-pb-proxy-picker-container"></div>',
  styleUrls: ["./mcc-pb-proxy-picker.component.css"]
})
export class MCCPBProxyPickerComponent implements OnInit {
  proxyPickerWidget: any;
  userData$: BehaviorSubject<IUser>;
  user: IUser;

  constructor(private userService: UserDataService) {
    this.proxyPickerWidget = ProxyPickerComponent.ProxyPickerWidget;
    this.userData$ = this.userService.userData$;
  }

  ngOnInit() {
    // get the data for the currently logged in user
    this.userData$.subscribe(val => {
      this.user = val;
      // initialize the proxy picker
      this.initializeProxyPicker();
    });
  }

  initializeProxyPicker() {
    this.proxyPickerWidget.render({
      selector: "#mcc-pb-proxy-picker-container"
    });
  }
}

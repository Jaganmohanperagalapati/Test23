import { TestBed, ComponentFixture } from "@angular/core/testing";
import * as ProxyPickerComponent from "kp-proxy-picker";

import { UserDataService } from "../../services/user.data.service";
import { UserDataServiceStub } from "../../services/user.data.service.stub";
import { MCCPBProxyPickerComponent } from "./mcc-pb-proxy-picker.component";

describe("MCCPBProxyPickerComponent", () => {
  let fixture: ComponentFixture<MCCPBProxyPickerComponent>;
  let MCCPBroxyPicker: MCCPBProxyPickerComponent;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MCCPBProxyPickerComponent],
      providers: [
        {
          provide: UserDataService,
          useClass: UserDataServiceStub
        }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(MCCPBProxyPickerComponent);
    MCCPBroxyPicker = fixture.debugElement.componentInstance;
    this.proxyPickerWidget = ProxyPickerComponent.ProxyPickerWidget;
  });

  it("should create the mcc-proxy-pickger component", () => {
    expect(MCCPBroxyPicker).toBeDefined();
  });

  it("should attempt to render the proxy picker", () => {
    spyOn(this.proxyPickerWidget, "render");
    MCCPBroxyPicker.ngOnInit();
    expect(this.proxyPickerWidget.render).toHaveBeenCalledWith({
      selector: "#mcc-pb-proxy-picker-container"
    });
  });
});

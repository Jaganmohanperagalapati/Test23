import { OnInit, Component, PipeTransform, Pipe } from "@angular/core";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { DomSanitizer } from "@angular/platform-browser";

import { UserDataService } from "../../services/user.data.service";
import { IUser } from "../../interfaces/user.interface";

@Pipe({ name: "safe" })
export class SafePipe implements PipeTransform {
  constructor(private sanitizer: DomSanitizer) {}
  transform(url) {
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
}
@Component({
  selector: "mcc-iframe",
  templateUrl: "./mcc-pb-iframe.component.html",
  styleUrls: ["./mcc-pb-iframe.component.css"]
})
export class MCCPBIFrameComponent implements OnInit {
  userData$: BehaviorSubject<IUser>;
  source: String;
  regionMapping: Object;
  language: String;

  constructor(private userService: UserDataService) {
    this.userData$ = this.userService.userData$;
    this.language = this.userService.language;
    this.regionMapping = {
      gga: "ga",
      col: "co"
    };
  }

  ngOnInit() {
    // get the data for the currently logged in user
    this.userData$.subscribe(val => {
      if (val.user["region"]) {
        this.source = `/hconline/${
          this.regionMapping[val.user["region"].toLowerCase()]}/inside.asp?mode=insurance&lang=${this.language}`;
      }
    });
  }
}

import { TestBed, ComponentFixture } from "@angular/core/testing";

import { AppComponent } from "./app.component";
import { UserDataService } from "./services/user.data.service";
import { UserDataServiceStub } from "./services/user.data.service.stub";
import { MCCPBProxyPickerComponent } from "./components/mcc-pb-proxy-picker/mcc-pb-proxy-picker.component";
import { MCCPBIFrameComponent, SafePipe } from "./components/mcc-pb-iframe/mcc-pb-iframe.component";

describe("AppComponent", () => {
  let fixture: ComponentFixture<AppComponent>;
  let app: AppComponent;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent,
        MCCPBProxyPickerComponent,
        MCCPBIFrameComponent,
        SafePipe],
      providers: [
        {
          provide: UserDataService,
          useClass: UserDataServiceStub
        }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(AppComponent);
    app = fixture.debugElement.componentInstance;
    this.userService = TestBed.get(UserDataService);
  });

  it("should create the app component", () => {
    expect(app).toBeDefined();
  });

  it(`should set the 'htmlStr' to the inner html returned from parsing the dom for an element whose node id is "pbrootcomp.html" and whose node name is "SCRIPT"`, () => {
    let div = document.createElement('div');
    div.id = "_templates";
    let scriptElem = `
      <script type="text/ng-template" id="pbrootcomp.html">
        <div>Main Content</div>
      </script>
    `;
    div.innerHTML = scriptElem.trim();
    spyOn(document, "getElementById").and.callFake(function() {
      return div;
    });
    app.ngOnInit();
    expect(app.htmlStr.replace(/[\n\r]+/g, '').trim()).toEqual(`<div>Main Content</div>`);
  });

  it(`should not set the 'htmlStr' to the inner html returned from parsing the dom for an element whose node id is "rootcomp.html" and whose node name is "SCRIPT"`, () => {
    let div = document.createElement('div');
    div.id = "_templates";
    let scriptElem = `
      <script type="text/ng-template" id="rootcomp.html">
        <div>Main Content</div>
      </script>
    `;
    div.innerHTML = scriptElem.trim();
    spyOn(document, "getElementById").and.callFake(function() {
      return div;
    });
    app.ngOnInit();
    expect(app.htmlStr).toBeUndefined();
  });

  // it(`should set the 'user' variable after initialization of the component`, () => {
  //   expect(app.user).toBeUndefined();
  //   app.ngOnInit();
  //   expect(app.user).toBeDefined();
  // });

  it(`should set the 'relid' variable after initialization of the component`, () => {
    expect(app.relid).toBeUndefined();
    app.ngOnInit();
    expect(app.relid).toBeDefined();
  });
});

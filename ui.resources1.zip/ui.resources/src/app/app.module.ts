import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";

import { AppComponent } from "./app.component";
import { MCCPBProxyPickerComponent } from "./components/mcc-pb-proxy-picker/mcc-pb-proxy-picker.component";
import { MCCPBIFrameComponent, SafePipe } from "./components/mcc-pb-iframe/mcc-pb-iframe.component";
import { UserDataService } from "./services/user.data.service";
import configs from "./app.configs";
import serviceWorker from "../service-worker";

var script = document.createElement("script");
script.innerHTML = `
(function () {
  // for local development add the jsonConfigs object to the document prior to bootstrapping the application
  if (!window.jsonConfigs) {
    window.jsonConfigs = ${JSON.stringify(configs.jsonConfigs)};
  }
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
      ${serviceWorker.register(window)}
    });
  }
})();`;
document.currentScript.parentNode.insertBefore(script, document.currentScript);

@NgModule({
  declarations: [
    AppComponent,
    MCCPBProxyPickerComponent,
    MCCPBIFrameComponent,
    SafePipe
  ],
  imports: [BrowserModule],
  providers: [UserDataService],
  bootstrap: [AppComponent]
})
export class AppModule {}

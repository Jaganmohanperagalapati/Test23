export interface IUser {
    user: {
        guid: String
    };
  }
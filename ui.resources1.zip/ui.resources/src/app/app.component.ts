import { OnInit, Component } from "@angular/core";
import { BehaviorSubject } from "rxjs/BehaviorSubject";

import { UserDataService } from "./services/user.data.service";

@Component({
  selector: "app-root",
  templateUrl: "app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent implements OnInit {
  proxyChanged$: BehaviorSubject<String>;
  htmlStr: String;
  relid: String;

  constructor(private userService: UserDataService) {
    this.proxyChanged$ = this.userService.proxyChanged$;
  }

  ngOnInit() {
    // set the html received from AEM to a variable
    this.htmlStr = this.parse(document.getElementById("_templates"));
    // get the data for the currently selected proxy
    this.proxyChanged$.subscribe(val => {
      this.relid = val;
    });
  }

  /**
   * parse the dom for the node with the AEM html we expect
   * @param dom
   */
  parse(dom: any) {
    try {
      for (let node of dom.childNodes) {
        if (node.nodeName === "SCRIPT" && node.id === "pbrootcomp.html") {
          return node.innerHTML;
        }
      }
    } catch (e) {}
  }
}

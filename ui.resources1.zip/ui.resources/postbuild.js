const fs = require("fs-extra");
const concat = require("concat-files");

const distPath = "./dist";
const srcPath = "./src";
const aemPath =
  "../ui.apps/src/main/content/jcr_root/etc/designs/kporg/plan-benefits/clientlib-site";
const bundledCss = `${distPath}/styles.bundle.css`;
const jsDest = `${aemPath}/js`;
const cssDest = `${aemPath}/css`;
const styleguideCssDest = `${srcPath}/styleguide.css`;
const assetsDest = `${srcPath}/assets`;

const lightMagenta = "\x1b[95m";
const systemColor = "\x1b[0m";

const argv = process.argv;
const settingAemFlag = argv.indexOf("--aem") !== -1;

/**
 * REMOVE THE STYLEGUIDE.CSS AND ASSETS DIRECTORY FROM THE SRC DIRECTORY
 * ---------------------------------------------------------------------
 */

if (fs.existsSync(styleguideCssDest)) {
  // delete the "src/styleguide.css" file
  fs.removeSync(styleguideCssDest);
  console.log(
    `\n${lightMagenta}`,
    `>>>>> Deleting the '${styleguideCssDest}' file${systemColor}\n`
  );
}

if (fs.existsSync(assetsDest)) {
  // delete the "src/assets" directory
  fs.removeSync(assetsDest);
  console.log(
    `\n${lightMagenta}`,
    `>>>>> Deleting the '${assetsDest}' directory${systemColor}\n`
  );
}

/**
 * REPLACE RELATIVE PATHS IN PROXY-PICKER CSS TO REFERENCE ./ASSETS/FONTS/* OR ./ASSETS/IMAGES/* IF THE "--AEM" FLAG IS SET
 * ------------------------------------------------------------------------------------------------------------------------
 */

if (settingAemFlag) {
  // replace the asset relative paths in the "styles.bundle.css" file
  fs.readFile(bundledCss, "utf8", (err, data) => {
    if (err) {
      return console.log(`\n${lightMagenta}`, `>>>>> ${err}${systemColor}\n`);
    }
    let r1 = data.replace(
      /96AFA220F80ED4389/g,
      "assets/fonts/96AFA220F80ED4389"
    );
    let r2 = r1.replace(/2108F2E63BC303060/g, "assets/fonts/2108F2E63BC303060");
    let r3 = r2.replace(/365B298D61694CBD3/g, "assets/fonts/365B298D61694CBD3");
    let r4 = r3.replace(/4D5066C4BE0490771/g, "assets/fonts/4D5066C4BE0490771");
    let r5 = r4.replace(/clear_x/g, "assets/images/clear_x");
    let r6 = r5.replace(
      /error-inline-16x16/g,
      "assets/images/error-inline-16x16"
    );
    let r7 = r6.replace(/kp-icons/g, "assets/fonts/kp-icons");
    let r8 = r7.replace(/clear_x/g, "assets/images/loading-icon");

    fs.writeFile(bundledCss, r8, "utf8", err => {
      if (err) {
        return console.log(`\n${lightMagenta}`, `>>>>> ${err}${systemColor}\n`);
      }
      console.log(
        `\n${lightMagenta}`,
        `>>>>> relative paths in '${bundledCss}' were successfully updated${systemColor}\n`
      );
      ClearAndPopulateUiAppsDistributables();
    });
  });
}

/**
 * REMOVE THE JS AND CSS DIRECTORIES FROM THE UI.APPS DIRECTORY AND REPOPULATE THEM WITH THE LATEST BUILDS
 * -------------------------------------------------------------------------------------------------------
 */
function ClearAndPopulateUiAppsDistributables() {
  if (fs.existsSync(jsDest)) {
    // delete the js directory from ui.apps
    fs.removeSync(jsDest);
    console.log(
      `\n${lightMagenta}`,
      `>>>>> Deleting the '${jsDest}' directory${systemColor}\n`
    );
  }

  if (fs.existsSync(cssDest)) {
    // delete the css directory from ui.apps
    fs.removeSync(cssDest);
    console.log(
      `\n${lightMagenta}`,
      `>>>>> Deleting the '${cssDest}' directory${systemColor}\n`
    );
  }

  // create the css directory
  fs.mkdirSync(cssDest);
  // add the latest css bundle to ui.apps
  concat([`${distPath}/styles.bundle.css`], `${cssDest}/page.css`, function(
    err
  ) {
    if (err) {
      console.log(
        `\n${lightMagenta}`,
        `>>>>> There was an error bundling the css files ::: ${err}${systemColor}\n`
      );
    } else {
      console.log(
        `\n${lightMagenta}`,
        `>>>>> The css files were successfully bundled to '${cssDest}${systemColor}\n`
      );
    }
  });

  // add the latest assets folder to ui.apps
  fs.copy(`${distPath}/assets`, `${cssDest}/assets`, err => {
    if (err) {
      return console.log(`\n${lightMagenta}`, `>>>>> ${err}`);
    }
    console.log(
      `\n${lightMagenta}`,
      `>>>>> The assets folder was successfully moved to '${cssDest}${systemColor}\n`
    );
  });

  // create the js directory
  fs.mkdirSync(jsDest);
  // add the latest concatenated js bundle to ui.apps
  concat(
    [
      `${distPath}/inline.bundle.js`,
      `${distPath}/polyfills.bundle.js`,
      `${distPath}/vendor.bundle.js`,
      `${distPath}/main.bundle.js`
    ],
    `${jsDest}/app.bundle.js`,
    function(err) {
      if (err) {
        console.log(
          `\n${lightMagenta}`,
          `>>>>> There was an error bundling the js files ::: ${err}${systemColor}\n`
        );
      }
      console.log(
        `\n${lightMagenta}`,
        `>>>>> The js files were successfully bundled to '${jsDest}${systemColor}\n`
      );

      // delete the dist directory
      if (fs.existsSync(distPath)) {
        fs.removeSync(distPath);
        console.log(
          `\n${lightMagenta}`,
          `>>>>> Deleting the '${distPath}' file${systemColor}\n`
        );
      }
    }
  );
}

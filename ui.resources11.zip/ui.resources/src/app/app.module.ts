import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";

import { AppComponent } from "./app.component";
import { MCCActionAreaComponent } from "./components/mcc-action-area/mcc-action-area.component";
import { MCCUtilityBarComponent } from "./components/mcc-utility-bar/mcc-utility-bar.component";
import { MCCProxyPickerComponent } from "./components/mcc-proxy-picker/mcc-proxy-picker.component";
import { MCCIFrameComponent } from "./components/mcc-iframe/mcc-iframe.component";
import { UserDataService } from "./services/user.data.service";
import { TemplateService } from "./services/template.service";
import configs from "./app.configs";
import { ErrorMessageComponent } from "./components/error-message/error-message.component";
import { ErrorMessageService } from "./services/error-message.service";
import { HttpClientModule, HttpClient } from "@angular/common/http";

var script = document.createElement("script");
script.innerHTML = `
(function () {
  // for local development add the jsonConfigs object to the document prior to bootstrapping the application
  if (!window.jsonConfigs) {
    window.jsonConfigs = ${JSON.stringify(configs.jsonConfigs)};
  }
})();`;
document.currentScript.parentNode.insertBefore(script, document.currentScript);

@NgModule({
  declarations: [
    AppComponent,
    MCCActionAreaComponent,
    MCCUtilityBarComponent,
    MCCProxyPickerComponent,
    MCCIFrameComponent,
    ErrorMessageComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule
  ],
  providers: [
    UserDataService,
    TemplateService,
    HttpClient,
    ErrorMessageService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}

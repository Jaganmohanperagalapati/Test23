import { TestBed, ComponentFixture } from "@angular/core/testing";

import { MCCIFrameComponent } from "./mcc-iframe.component";
import { TemplateService } from "../../services/template.service";
import { UserDataService } from "../../services/user.data.service";
import { UserDataServiceStub } from "../../services/user.data.service.stub";

describe("MCCIFrameComponent", () => {
  let fixture: ComponentFixture<MCCIFrameComponent>;
  let app: MCCIFrameComponent;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MCCIFrameComponent],
      providers: [
        TemplateService,
        {
          provide: UserDataService,
          useClass: UserDataServiceStub
        }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(MCCIFrameComponent);
    app = fixture.debugElement.componentInstance;
    this.templateService = TestBed.get(TemplateService);
    this.userService = TestBed.get(UserDataService);
    this.userData$ = this.userService.userData$;
  });

  it("should create the iframe component", () => {
    expect(app).toBeDefined();
  });

  it(`should attempt to set the 'mccIFrame' template`, () => {
    spyOn(this.templateService, "GetTemplate");
    expect(app.mccIFrame).toBe("<div>Loading mcc-iframe…</div>");
    app.ngOnInit();
    expect(app.mccIFrame).not.toBe("<div>Loading mcc-iframe…</div>");
  });

  it(`should attempt to get the elements on which to set the "data-pqe" attributes`, () => {
    spyOn(this.templateService, "GetTemplate");
    spyOn(document, "querySelector").and.returnValue({
      setAttribute: (a, b) => {
        return;
      }
    });
    app.ngAfterViewInit();
    expect(document.querySelector).toHaveBeenCalledWith(
      "#mcc-iframe #datatilesframe"
    );
  });
});

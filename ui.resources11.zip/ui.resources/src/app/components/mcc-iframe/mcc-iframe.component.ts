import { Component, ViewEncapsulation } from "@angular/core";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { DomSanitizer } from "@angular/platform-browser";

import { UserDataService } from "../../services/user.data.service";
import { TemplateService } from "../../services/template.service";

let selector = "mcc-iframe";

@Component({
  selector: `${selector}`,
  template: `<div id="${selector}" class="container" [innerHTML]="mccIFrame"></div>`,
  styleUrls: ["./mcc-iframe.component.css"],
  encapsulation: ViewEncapsulation.None
})
export class MCCIFrameComponent {
  iframeElement: Element;
  proxyChanged$: BehaviorSubject<String>;
  mccIFrame: any = `<div>Loading ${selector}…</div>`;

  constructor(
    private templateService: TemplateService,
    private userService: UserDataService,
    private sanitizer: DomSanitizer
  ) {
    this.proxyChanged$ = this.userService.proxyChanged$;
  }

  ngOnInit() {
    // bypass security and trust the given value to be safe HTML.
    this.mccIFrame = this.sanitizer.bypassSecurityTrustHtml(
      this.templateService.GetTemplate("pbrootcomp.html", selector)
    );
  }

  ngAfterViewInit() {
    // set the reference to the iframe
    this.iframeElement = document.querySelector("#mcc-iframe #datatilesframe");
    this.iframeElement.setAttribute("data-pqe", "mcc-iframe");
    // reload the iframe every time the proxy picker changes
    this.proxyChanged$.subscribe(
      function handleProxyChanged() {
        this.iframeElement.src = this.iframeElement.src;
      }.bind(this)
    );
  }
}

import { Component, ViewEncapsulation, OnInit } from "@angular/core";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import * as ProxyPickerComponent from "kp-proxy-picker";

import { UserDataService } from "../../services/user.data.service";
import { IUser } from "../../interfaces/user.interface";

@Component({
  selector: "mcc-proxy-picker",
  template: '<div id="mcc-proxy-picker" class="container"></div>',
  styleUrls: ["./mcc-proxy-picker.component.css"],
  encapsulation: ViewEncapsulation.None
})
export class MCCProxyPickerComponent {
  proxyPickerWidget: any;
  userData$: BehaviorSubject<IUser>;

  constructor(private userService: UserDataService) {
    this.proxyPickerWidget = ProxyPickerComponent.ProxyPickerWidget;
    this.userData$ = this.userService.userData$;
  }

  ngOnInit() {
    // get the data for the currently logged in user
    this.userData$.subscribe(
      function handleUserDataLoaded(val) {
        if (val.user.guid) {
          // initialize the proxy picker
          this.proxyPickerWidget.render({
            selector: "#mcc-proxy-picker"
          });
        }
      }.bind(this)
    );

    // since the proxy picker is loaded dynamically, check for when it is intantiated to add the data-pqe attributes
    this.proxyPickerLoaded(
      "#mcc-proxy-picker #proxy-picker-select-dropdown",
      () => {
        let proxyPicker = document.querySelector(
          "#mcc-proxy-picker #proxy-picker-select-dropdown"
        );
        proxyPicker.setAttribute("data-pqe", "mcc-proxy-picker");
      }
    );
  }

  proxyPickerLoaded(id, cb) {
    let interval = setInterval(() => {
      if (document.querySelector(id)) {
        clearInterval(interval);
        cb();
      }
    }, 100);
  }
}

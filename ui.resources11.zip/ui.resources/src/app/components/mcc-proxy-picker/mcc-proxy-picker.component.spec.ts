import { TestBed, ComponentFixture } from "@angular/core/testing";
import * as ProxyPickerComponent from "kp-proxy-picker";

import { UserDataService } from "../../services/user.data.service";
import { UserDataServiceStub } from "../../services/user.data.service.stub";
import { MCCProxyPickerComponent } from "./mcc-proxy-picker.component";

describe("MCCProxyPickerComponent", () => {
  let fixture: ComponentFixture<MCCProxyPickerComponent>;
  let MCCProxyPicker: MCCProxyPickerComponent;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MCCProxyPickerComponent],
      providers: [
        {
          provide: UserDataService,
          useClass: UserDataServiceStub
        }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(MCCProxyPickerComponent);
    MCCProxyPicker = fixture.debugElement.componentInstance;
    this.proxyPickerWidget = ProxyPickerComponent.ProxyPickerWidget;
    this.userService = TestBed.get(UserDataService);
    this.userData$ = this.userService.userData$;
  });

  it("should create the mcc-proxy-pickger component", () => {
    expect(MCCProxyPicker).toBeDefined();
  });

  it("should attempt to render the proxy picker if user data is returned", () => {
    spyOn(this.proxyPickerWidget, "render");
    spyOn(this.userService, "userData$");
    MCCProxyPicker.ngOnInit();
    this.userService.userData$.subscribe(val => {
      if (val.user.guid) {
        expect(this.proxyPickerWidget.render).toHaveBeenCalledWith({
          selector: "#mcc-proxy-picker"
        });
      }
    });
  });
});

import { Component, ViewEncapsulation } from "@angular/core";

import { TemplateService } from "../../services/template.service";

let selector = "mcc-utility-bar";

@Component({
  selector: `${selector}`,
  template: `
    <div id="${selector}" class="container" [innerHTML]="mccUtilityBar"></div>
  `,
  styleUrls: ["./mcc-utility-bar.component.css"],
  encapsulation: ViewEncapsulation.None
})
export class MCCUtilityBarComponent {
  mccUtilityBar: any = `<div>Loading ${selector}…</div>`;

  constructor(private templateService: TemplateService) {}

  ngOnInit() {
    this.mccUtilityBar = this.templateService.GetTemplate(
      "pbrootcomp.html",
      selector
    );
  }

  ngAfterViewInit() {
    let backLink = document.querySelector(
      "#mcc-utility-bar .back-link-container a"
    );
    backLink.setAttribute("data-pqe", "mcc-back-link");
    let helpLink = document.querySelector("#mcc-utility-bar nav a");
    helpLink.setAttribute("data-pqe", "mcc-help-link");
  }
}

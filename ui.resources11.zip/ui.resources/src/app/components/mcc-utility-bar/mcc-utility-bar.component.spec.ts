import { TestBed, ComponentFixture } from "@angular/core/testing";

import { MCCUtilityBarComponent } from "./mcc-utility-bar.component";
import { TemplateService } from "../../services/template.service";

describe("MCCUtilityBarComponent", () => {
  let fixture: ComponentFixture<MCCUtilityBarComponent>;
  let app: MCCUtilityBarComponent;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MCCUtilityBarComponent],
      providers: [TemplateService]
    }).compileComponents();

    fixture = TestBed.createComponent(MCCUtilityBarComponent);
    app = fixture.debugElement.componentInstance;
    this.templateService = TestBed.get(TemplateService);
  });

  it("should create the utility bar component", () => {
    expect(app).toBeDefined();
  });

  it(`should attempt to set the 'mccUtilityBar' template`, () => {
    spyOn(this.templateService, "GetTemplate");
    expect(app.mccUtilityBar).toBe("<div>Loading mcc-utility-bar…</div>");
    app.ngOnInit();
    expect(app.mccUtilityBar).not.toBe("<div>Loading mcc-utility-bar…</div>");
  });

  it(`should attempt to get the elements on which to set the "data-pqe" attributes`, () => {
    spyOn(this.templateService, "GetTemplate");
    spyOn(document, "querySelector").and.returnValue({
      setAttribute: (a, b) => {
        return;
      }
    });
    app.ngAfterViewInit();
    expect(document.querySelector).toHaveBeenCalledWith(
      "#mcc-utility-bar nav a"
    );
  });
});

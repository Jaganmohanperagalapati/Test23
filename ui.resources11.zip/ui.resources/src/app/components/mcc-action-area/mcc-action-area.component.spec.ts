import { TestBed, ComponentFixture } from "@angular/core/testing";

import { MCCActionAreaComponent } from "./mcc-action-area.component";
import { TemplateService } from "../../services/template.service";

describe("MCCActionAreaComponent", () => {
  let fixture: ComponentFixture<MCCActionAreaComponent>;
  let app: MCCActionAreaComponent;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MCCActionAreaComponent],
      providers: [TemplateService]
    }).compileComponents();

    fixture = TestBed.createComponent(MCCActionAreaComponent);
    app = fixture.debugElement.componentInstance;
    this.templateService = TestBed.get(TemplateService);
  });

  it("should create the action area component", () => {
    expect(app).toBeDefined();
  });

  it(`should attempt to set the 'mccActionArea' template`, () => {
    spyOn(this.templateService, "GetTemplate");
    expect(app.mccActionArea).toBe("<div>Loading mcc-action-area…</div>");
    app.ngOnInit();
    expect(app.mccActionArea).not.toBe("<div>Loading mcc-action-area…</div>");
  });

  it(`should attempt to get the elements on which to set the "data-pqe" attributes`, () => {
    spyOn(this.templateService, "GetTemplate");
    spyOn(document, "querySelector").and.returnValue({
      setAttribute: (a, b) => {
        return;
      }
    });
    app.ngAfterViewInit();
    expect(document.querySelector).toHaveBeenCalledWith(
      "#mcc-action-area .header-styles"
    );
  });
});

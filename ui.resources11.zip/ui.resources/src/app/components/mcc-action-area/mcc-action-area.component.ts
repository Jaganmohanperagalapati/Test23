import { Component, ViewEncapsulation } from "@angular/core";

import { TemplateService } from "../../services/template.service";

let selector = "mcc-action-area";

@Component({
  selector: `${selector}`,
  template: `
    <div id="${selector}" [innerHTML]="mccActionArea"></div>
  `,
  styleUrls: ["./mcc-action-area.component.css"],
  encapsulation: ViewEncapsulation.None
})
export class MCCActionAreaComponent {
  mccActionArea: any = `<div>Loading ${selector}…</div>`;

  constructor(private templateService: TemplateService) {}

  ngOnInit() {
    this.mccActionArea = this.templateService.GetTemplate(
      "pbrootcomp.html",
      selector
    );
  }

  ngAfterViewInit() {
    let actionArea = document.querySelector("#mcc-action-area .header-styles");
    actionArea.setAttribute("data-pqe", "mcc-action-area");
  }
}

import { async, ComponentFixture, TestBed ,inject} from '@angular/core/testing';
import { ErrorMessageComponent } from './error-message.component';
import { HttpHandler, HttpClient } from '@angular/common/http';
import { Response, ResponseOptions } from '@angular/http';
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { AppObject, ErrorMessageService } from "./../../services/error-message.service";
import { UserDataService } from './../../services/user.data.service';
import { IUser } from "../../interfaces/user.interface";


describe('ErrorMessageComponent test', () => {
  let component: ErrorMessageComponent;
  let fixture: ComponentFixture<ErrorMessageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ErrorMessageComponent ],
      // providers: [
      //   HttpHandler,
      //   HttpClient,
      //   ErrorMessageService,
      //   UserDataService
      // ]
      providers: [
        {
            provide: HttpClient,
            useValue: {}
        },
        {
            provide: ErrorMessageService,
            useValue: {
                getMccMessageJsonUrlLocation: () => "DoesNotMatter"
            }
        },
        {
            provide: UserDataService,
            useValue: {}
        }
    ]
    })
    TestBed.compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ErrorMessageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });

  it('should have blank error message/code when internal app error code is blank', async(inject(
    [ ErrorMessageService, ,UserDataService,HttpClient], (errms, uds, http) => {
    http.get = () => new BehaviorSubject(new Response(new ResponseOptions()));
    uds.userData$ = () => new BehaviorSubject<IUser>;
    let emc : ErrorMessageComponent = new ErrorMessageComponent(errms,uds, http);
    emc.ngOnInit();
    expect(emc.getErrorType("SomethingElse")).toBe("-hard-interruption");
    //
    // emc.getErrorMessage().subscribe(
    //     (data) => {
    //         expect(data.getCode()).toBe("");
    //         expect(data.getMessage()).toBe("");
    //     });
})));
});

import { Component, OnInit } from '@angular/core';
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/combineLatest';
import { HttpClient } from '@angular/common/http';
import { UserDataService } from './../../services/user.data.service';
import { IUser } from "../../interfaces/user.interface";
import { AppObject, ErrorMessageService } from "./../../services/error-message.service";

import configs from "./../../app.configs";

@Component({
  selector: 'app-error-message',
  templateUrl: './error-message.component.html',
  styleUrls: ['./error-message.component.css']
})

export class ErrorMessageComponent implements OnInit {
  data: any = {};
  public appObject$: Observable<AppObject>;
  userData$: BehaviorSubject<IUser>;
  show: Boolean = false;

  constructor(private errorMessageService: ErrorMessageService, private http: HttpClient, private userDataService: UserDataService) {
    this.userData$ = this.userDataService.userData$;
  }

  ngOnInit() {
    // NOTE: Verify with Reg that this is the best approach.
    this.userData$.subscribe(
      function handleUserDataLoaded(val) {
        if (val.user.guid) {
          this.getErrorMessages(val.user.language.toLowerCase());
        }
      }.bind(this)
    );
  }

  // This method gets the error message object and stores it into this.data
  getErrorMessages(lang): void {
    try {
      // Get the message object for the user's current language.
      this.errorMessageService.getErrorMessages(this.errorMessageService.getMccMessageJsonUrlLocation(), lang).subscribe(resp => {
        // Store the object into a local variable.
        this.data = resp;
      },
      error => {
        console.log(error, "error");
      })
    } catch (e) {
      console.log(e);
    }
  }

  // This method assigns a class to the error message for the look and feel.
  // TODO: Make this coditional on the error type.
  public getErrorType( errorCode: string ): string {
    let outValue: string;
    // Add the class name here.
    outValue = "-system-error--small";
    return outValue;
  }

  // This method gets the error code for the current message.
  public getCode(): string {
    // NOTE: This needs to come from AEM server.
    return this.data["jcr:content"]["jcr:title"];
  }

  // This gets the error text for the current message in HTML format.
  public getErrorMessage(): string {
    return this.data["jcr:content"]["text"]["text"];
  }
}

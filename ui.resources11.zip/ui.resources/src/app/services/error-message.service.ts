import { Injectable, NgZone, OnInit } from "@angular/core";
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import * as extend from '../../../node_modules/lodash/extend.js';
import { UserDataService } from './../services/user.data.service';

declare var configs: any;

// This creates a container for storing the error codes.
export class AppObject {
    public errorCode: string;

    constructor( errorCode: string ) {
        this.errorCode = errorCode;
    }
}

@Injectable()

// This service provides data for displaying error messages on the page.
export class ErrorMessageService implements OnInit {
  private appObject$: Observable<AppObject>;
  private queryParams : HttpParams;

  // Create an object defining the error codes we are using for the page.
  public static ErrorCodes = {
      NonMemberAccount: "1004",
      TechnicalError: "1003"
  };

  // Include these headers in the server request.
  static headers: any = {
    'X-useragenttype': navigator.userAgent,
    'X-osversion': navigator.appVersion
  };

  constructor(private http : HttpClient, private userDataService: UserDataService) {
    // Hard-coding AppObject for now.
    let ao: AppObject;
    ao = new AppObject(ErrorMessageService.ErrorCodes.TechnicalError);
  }

  ngOnInit() {}

  // This provides the relative url for JSON data in the user's language.
  getErrorMessages(url: string, lang: string) {
    if (lang === 'en') {
      return this.http.get(url + '/system/messages/gem');
    } else {
      return this.http.get(url + '/' + lang + '/system/messages/gem');
    }
  }

  // This gets the AppObject instance.
  getAppObject$() {
    return this.appObject$;
  }

  // This defines the root domain from which to get JSON data.
  public getMccMessageJsonUrlLocation(): string {
    if (this.userDataService.language === undefined) {
      return 'http://localhost:9080';
    } else {
      return '';
    }
  }
}

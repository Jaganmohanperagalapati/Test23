import { Injectable } from "@angular/core";


@Injectable()
export class TemplateService {
  templates = document.getElementById("_templates");
  templatesHash: object = {};

  constructor() {
    this.parse(this.templates);
  }

  // parse the div._templates element
  parse(dom) {
    let parser = new DOMParser();
    try {
      for (let node of dom.childNodes) {
        if (node.nodeName === "SCRIPT") {
          // when in a script tag, set its id as a key on the templatesHash object and its innerHTML as the value
          if (!this.templatesHash[node.id]) {
            this.templatesHash[node.id] = {};
            // parse the string html inside the script tag
            var elements = parser.parseFromString(node.innerHTML, "text/html");
            // loop through the parsed html
            for (var i = 0; i < elements.body.children.length; i++) {
              if (elements.body.children[i].nodeName === "DIV") {
                // set key/value pairs of the id/innerHTML of each template (i.e mcc-action-area, mcc-utility-bar, mcc-iframe)
                this.templatesHash[node.id][elements.body.children[i].id] =
                  elements.body.children[i].innerHTML;
              }
            }
          }
        }
      }
    } catch (e) {}
  }

  GetTemplate(parentNodeID: string, childNodeID: string) {
    return this.templatesHash[parentNodeID][childNodeID];
  }
}

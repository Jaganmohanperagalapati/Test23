import { Injectable } from '@angular/core';

import configs from "./../app.configs";

@Injectable()

// This service provides configuration data from which to make API calls.
export class JsonConfigsService {

  private jCon: any;

  constructor() {
    // Create a private variable instance for JSON configuarions.
    this.jCon = configs;
  }

  // Get the URL from which to make API calls.
  // public apiUrl(): string {
  //   return this.jCon.global.apiUrl;
  // }

  // Get the NodeJS URL from which to make API calls.
  // public nodeApiUrl(): string {
  //   return this.jCon.global.apipApiUrl;
  // }

  // Get the headers with which to make API calls.
  // public apiHeaders(): any {
  //   return this.jCon.feature.apiHeaders;
  // }

  // Get the Node headers with which to make API calls.
  // public nodeApiHeaders(): any {
  //   return this.jCon.feature.NodeApiHeaders;
  // }

  // Get the url for exception messages.
  // public exceptionMessageUrl( language: string ): string {
  //   return this.jCon.feature[ language ].ExceptionMsgURL;
  // }

  // Get the url for MCC messages.
  // public mccMessageUrl( language: string ): string {
  //   return this.jCon.feature[ language ].MCCMsgURL;
  // }
}

import { TestBed, inject } from '@angular/core/testing';

import { JsonConfigsService } from './json-configs.service';

describe('JsonConfigsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
           JsonConfigsService
      ]
    });
  });

  it('should be created', inject([JsonConfigsService], (service: JsonConfigsService) => {
    expect(service).toBeTruthy();
  }));

});



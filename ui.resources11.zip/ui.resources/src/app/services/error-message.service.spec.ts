import { TestBed, inject } from '@angular/core/testing';

import { ErrorMessageService } from './error-message.service';
import { HttpClientModule } from "@angular/common/http";
import { HttpClientTestingModule, HttpTestingController } from "@angular/common/http/testing";
import { JsonConfigsService } from "./json-configs.service";
import { UserDataService } from "./user.data.service";

describe('ErrorMessageService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientModule,
        HttpClientTestingModule
      ],
      providers: [
        ErrorMessageService,
        JsonConfigsService,
        UserDataService
      ]
    });
  });

  // it('should be created', inject([ErrorMessageService], (service: ErrorMessageService) => {
  //   expect(service).toBeTruthy();
  // }));
});

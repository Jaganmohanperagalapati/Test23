import { TemplateService } from "./template.service";

describe("TemplateService", () => {
  let service: TemplateService;

  beforeEach(() => {
    service = new TemplateService();
    service.templatesHash = {
      "pbrootcomp.html": {
        "mcc-action-area": `
          <h1>Eligibility and benefits</h1>
        `
      }
    };
  });
  
  it("should have a GetTemplate method", () => {
    expect(service.GetTemplate).toBeDefined();
  });

  it(`should return the template for an element whose parent node id is "pbrootcomp.html" and whose node id is "mcc-action-area"`, () => {
    expect(service.GetTemplate("pbrootcomp.html", "mcc-action-area").replace(/[\n\r]+/g, '').trim()).toEqual("<h1>Eligibility and benefits</h1>");
  });
});

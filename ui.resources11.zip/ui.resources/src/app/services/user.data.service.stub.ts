import { Injectable, NgZone } from "@angular/core";
import { Observable, BehaviorSubject } from "rxjs";

import { IUser } from "../interfaces/user.interface";

// create a fake proxy picker component that rerturns fake data on change
const ProxyPickerComponent = {
  ProxyPickerClient: {
    onChange: cb => {
      return cb({ relid: "456" });
    }
  }
};

@Injectable()
export class UserDataServiceStub {
  constructor(private zone: NgZone) {
    // convert the fake promise to an observable and subscribe to it
    Observable.fromPromise(
      Promise.resolve({ "user": { guid: "123" } })
    ).subscribe(val => {
      // cast the user data from the promise to a type of User
      let user = val as IUser;
      // make use of angular's change detection to tie into the dom lifecycle
      this.zone.run(() => {
        // pass the value to the behavior subject
        this._userData$.next(user);
        // terminate the behavior subject as no other data is expected
        this._userData$.complete();
      });
    });
    ProxyPickerComponent.ProxyPickerClient.onChange(rel => {
      // make use of angular's change detection to tie into the dom lifecycle
      this.zone.run(() => {
        // pass the value to the behavior subject
        this._proxyChanged$.next(rel.relid);
      });
    });
  }

  // define the behavior subjects with their initial values
  private _userData$ = new BehaviorSubject<IUser>({ user: { guid: "" } });
  private _proxyChanged$ = new BehaviorSubject<String>("");

  // return the _userData$ behavior object via a getter
  get userData$() {
    return this._userData$;
  }

  // return the proxyChanged$ behavior object via a getter
  get proxyChanged$() {
    return this._proxyChanged$;
  }
}

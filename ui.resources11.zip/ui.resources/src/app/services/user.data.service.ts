import { Injectable, NgZone } from "@angular/core";
import { Observable, BehaviorSubject } from "rxjs";
import { CookieManager } from "kp-client-commons";
import * as ProxyPickerComponent from "kp-proxy-picker";
import * as UserProfileHelper from "kp-user-profile";

import { IUser } from "../interfaces/user.interface";

@Injectable()
export class UserDataService {
  profileHelper: UserProfileHelper;
  proxyPicker: ProxyPickerComponent;
  constructor(private zone: NgZone) {
    this.profileHelper = UserProfileHelper;
    this.proxyPicker = ProxyPickerComponent;
    // convert the "UserProfileHelper.UserProfileClient.load()" promise to an observable and subscribe to it
    Observable.fromPromise(
      this.profileHelper.UserProfileClient.load()
    ).subscribe(
      function handleUserDataLoaded(val) {
        // cast the user data from the profile helper to a type of User
        let user = val as IUser;
        // make use of angular's change detection to tie into the dom lifecycle
        this.zone.run(() => {
          // pass the value to the behavior subject
          this._userData$.next(user);
          // terminate the behavior subject as no other data is expected
          this._userData$.complete();
        });
      }.bind(this)
    );
    this.proxyPicker.ProxyPickerClient.onChange(
      function handleProxiPickerChanged(rel) {
        // make use of angular's change detection to tie into the dom lifecycle
        this.zone.run(() => {
          // pass the value to the behavior subject
          this._proxyChanged$.next(rel.relid);
        });
      }.bind(this)
    );
  }

  // define the behavior subjects with their initial values
  private _userData$ = new BehaviorSubject<IUser>({ user: { guid: "" } });
  private _proxyChanged$ = new BehaviorSubject<String>(
    CookieManager.getProxyRelationshipCookie()
  );

  // return the _userData$ behavior object via a getter
  get userData$() {
    return this._userData$;
  }

  // return the proxyChanged$ behavior object via a getter
  get proxyChanged$() {
    return this._proxyChanged$;
  }

  // return the default locale for the current user
  get language() {
    // get the cookie value of the currently selected language
    let languageValue = document.cookie.replace(
      /(?:(?:^|.*;\s*)kpLanguage\s*\=\s*([^;]*).*$)|^.*$/,
      "$1"
    );
    let languageMapping = {
      "en-US": "english",
      "es-US": "espanol"
    };
    return languageMapping[languageValue];
  }
}

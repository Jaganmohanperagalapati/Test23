import { NgZone } from "@angular/core";
import { UserDataService } from "./user.data.service";

describe("UserDataService", () => {
  let service: UserDataService;
  // create a fake zone object and cast it to a type of NgZone
  let zone = {
    run: (fn: Function) => fn()
  } as NgZone;

  beforeEach(() => {
    service = new UserDataService(zone);
    service.proxyPicker.ProxyPickerClient.onChange = (cb) => {
      return cb({ relid: "456" });
    };
    service.profileHelper.UserProfileClient.load = () => {
      return Promise.resolve({ user: { guid: "123" } });
    };
  });
  
  it("should have a getter for the _userData$ behavior subject", () => {
    expect(service.userData$).toBeDefined();
  });
  
  it("should have a getter for the _proxyChanged$ behavior subject", () => {
    expect(service.proxyChanged$).toBeDefined();
  });
});

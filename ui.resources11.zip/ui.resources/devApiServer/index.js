// Bring in our dependencies
const app = require('express')();

const port = 9080;
const userRoute = require('./routes/user');
const proxyRoute = require('./routes/proxy');
const entitlementsRoute = require('./routes/entitlements');
const auditLogRoute = require('./routes/auditLog');
const errorMessageRoute = require('./routes/errorMessage');
const errorMessageRouteEs = require('./routes/errorMessage/es');


// specify the allowed headers
let allowedHeaders = [
    'Content-Type',
    'Authorization',
    'Content-Length',
    'X-Requested-With',
    'X-includeEntitlements',
    'X-useragentcategory',
    'X-useragentcategory',
    'X-appName',
    'X-apiKey',
    'X-retainJsonSchema',
    'X-sessionToken',
    'X-componentName',
    'X-inclusionJsonPath',
    'X-includeProxyEntitlements',
    'X-useragenttype',
    'X-osversion',
    'X-encryption',
    'X-RelId',
    'SessionToken'
].join();

// Add the headers
app.use("/*", function (req, res, next) {
    res.header('Access-Control-Allow-Origin', 'http://localhost:8080');
    res.header('Access-Control-Allow-Credentials', true);
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
    res.header('Access-Control-Allow-Headers', allowedHeaders);
    next();
});

// Connect the api routes
app.get("/mycare/v1.0/user", userRoute);
app.get("/mycare/v2.1/proxyinformation", proxyRoute);
app.get("/mycare/v2.0/entitlements", entitlementsRoute);
app.get("/mycare/event/event-handler/v1.0/auditLog", auditLogRoute);
app.post("/mycare/event/event-handler/v1.0/auditLog", auditLogRoute);
app.get("/system/messages/gem", errorMessageRoute);
app.get("/es/system/messages/gem", errorMessageRouteEs);

// Turn on the server!
app.listen(port, () => {
    console.log('\n\x1b[36m%s\x1b[0m', `>>>>> API Server started on http://localhost:${port}\n`);
});

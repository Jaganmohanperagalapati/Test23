const entitlementsData = require('./data.json');
const restrictedEntitlementsData = require('./restrictedData.json');

module.exports = (req, res) => {
  console.log('\n\x1b[36m%s\x1b[0m', '>>>>> In entitlements API\n');
  if (req.url.indexOf("relid=411DEJTNBVR") > -1) {
    res.status(200).json( restrictedEntitlementsData );
  } else {
    res.status(200).json( entitlementsData );
  }
};
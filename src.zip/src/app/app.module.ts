import { BrowserModule } from '@angular/platform-browser';
import {CommonModule} from '@angular/common';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { httpInterceptorProviders } from './interceptors';
import { SnotifyModule, SnotifyService, ToastDefaults } from 'ng-snotify';
import { SwiperModule, SWIPER_CONFIG, SwiperConfigInterface } from 'ngx-swiper-wrapper';
import { ContentLoaderModule } from '@netbasal/content-loader';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AccountComponent } from './components/account/account.component';
import { HeaderComponent } from './components/header/header.component';
import { PaymentsComponent } from './components/payments/payments.component';
import { DocumentsComponent } from './components/documents/documents.component';
import { ClaimsComponent } from './components/claims/claims.component';
import { PreferencesComponent } from './components/preferences/preferences.component';
import { MembershipComponent } from './components/membership/membership.component';
import { QuoteComponent } from './components/quote/quote.component';
import { SupportComponent } from './components/support/support.component';
import { SearchComponent } from './components/search/search.component';
import { AgentComponent } from './components/common/agent/agent.component';
import { BenefitsComponent } from './components/common/benefits/benefits.component';
import { FileComponent as FileClaimComponent } from './components/claims/file/file.component';
import { TimeFormateComponent } from './time-formate/time-formate.component';
import { CalendarModule } from 'primeng/calendar';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { PaymentsService } from './services/payments.service';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { PaymentSummaryComponent } from './components/payment-summary/payment-summary.component';
import { ClaimsLayoutComponent } from './components/claimsModule/claims-layout/claims-layout.component';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { FooterComponent } from './components/footer/footer.component';



const DEFAULT_SWIPER_CONFIG: SwiperConfigInterface = {
    direction: 'horizontal',
    slidesPerView: 'auto'
};

@NgModule({
    declarations: [
        AppComponent,
        DashboardComponent,
        AccountComponent,
        HeaderComponent,
        PaymentsComponent,
        DocumentsComponent,
        ClaimsComponent,
        PreferencesComponent,
        MembershipComponent,
        QuoteComponent,
        SupportComponent,
        SearchComponent,
        AgentComponent,
        BenefitsComponent,
        FileClaimComponent,
        TimeFormateComponent,
        PaymentSummaryComponent,
        ClaimsLayoutComponent,
        FooterComponent
    ],
    imports: [
        BrowserModule,
        CommonModule,
        AppRoutingModule,
        HttpClientModule,
        SnotifyModule,
        ContentLoaderModule,
        SwiperModule,
        CalendarModule,
        FormsModule,
        ReactiveFormsModule,
        BrowserAnimationsModule,
        DateInputsModule,
        InputsModule

    ],
    providers: [
        httpInterceptorProviders,
        SnotifyService,
        PaymentsService,
        { provide: 'SnotifyToastConfig', useValue: ToastDefaults },
        { provide: SWIPER_CONFIG, useValue: DEFAULT_SWIPER_CONFIG },
    ],
    bootstrap: [AppComponent]
})
export class AppModule {


}

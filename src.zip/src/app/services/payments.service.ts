import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';
import { ClaimInformation } from '../kyfb/claim-information';

@Injectable()
export class PaymentsService {
data:any[]=[];
    private messageSource = new BehaviorSubject(this.data);
    currentMessage = this.messageSource.asObservable();



    constructor(private http: HttpClient) { }

    changeMessage(message: any[]) {
        message = message.filter(function (el) {
            return el != null;
          });
         
        this.messageSource.next(message)
    }
    /**
  * 
  */
    getPaymentsInformation(): Observable<any> {
        return this.http.get<any>('hfg')
            .pipe(
                map((response: any) => {
                    return response;
                }),
                // catchError(this.handleError('getClaimInformation', []))
            );
    }
}

import { Component, OnInit, Input } from '@angular/core';
import { AgentService } from '../../../services/agent.service';
import { Agent } from '../../../kyfb/agent';
import { SnotifyService } from 'ng-snotify';

@Component({
    selector: 'kyfb-agent',
    templateUrl: './agent.component.html',
    styleUrls: ['./agent.component.scss']
})
export class AgentComponent implements OnInit {
    @Input() agentNumber: number;
    public agent: Agent;

    constructor(private agentService: AgentService, private messageService: SnotifyService) { }

    ngOnInit() {
        this.fetchAgent();
    }

    private fetchAgent(): void {
        this.agentService.getAgent(Number(this.agentNumber)).subscribe(
            agent => this.agent = agent,
            error => this.messageService.error(error.message, 'Error!', { showProgressBar: false, timeout: 0 })
        );
    }

}

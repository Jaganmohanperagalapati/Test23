import { Component, OnInit, TemplateRef  } from '@angular/core';
import { ClaimService } from 'src/app/services/claim.service';
import { ClaimInformation } from 'src/app/kyfb/claim-information';
import { Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'kyfb-report-claim',
  templateUrl: './report-claim.component.html',
  styleUrls: ['./report-claim.component.scss']
})
export class ReportClaimComponent implements OnInit {
  dueDateDetails: any[];
  selectedPolicyData: any[];
  policiesInfo: any;
  claimInformation?: ClaimInformation;
  clientName: any = "";
  constructor(private claimService: ClaimService, private router: Router, private modalService: BsModalService) { }

  ngOnInit() {
    this.selectedPolicyData = JSON.parse(localStorage.getItem('selectedPolicy'));
    this.claimService.currentDueDateDetails.subscribe(dueDateDetails => this.dueDateDetails = dueDateDetails)
  }

  openClaimsTabs() {
    if (this.selectedPolicyData['type'] == "A" || this.selectedPolicyData['type'] == "B") {
      this.router.navigate(['/claims/claims-tabs/report-type-auto']);
    } else if (this.selectedPolicyData['type'] == "P") {
      this.router.navigate(['/claims/claims-tabs/report-type-property']);
    }
  }

  openDash()
 {
  this.router.navigate(['/claims']);
 }
  getInfo() {
    this.claimService.getClaimsInfo().subscribe((claims) => {
      this.policiesInfo = claims.eBusAccountResponseType.policies.policyInfo;
      this.clientName = claims.eBusAccountResponseType.clientInfo.firstName;
    },
      error => { }
    );
  }
}

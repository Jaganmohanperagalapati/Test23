import { Component, OnInit, TemplateRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';

@Component({
  selector: 'kyfb-report-type-property',
  templateUrl: './report-type-property.component.html',
  styleUrls: ['./report-type-property.component.scss']
})
export class ReportTypePropertyComponent implements OnInit {
  reportModalRef: BsModalRef;
  public claimType: any;
  public submitted: boolean = false;
  public x: boolean = false;
  public y: boolean = false;
  public ClaimTypeOptions = {
    'animal': false,
    'Theft/Vandalism': false
  };
  public claimTypes = [
   
    {
      'DisplayLabel': 'weather',
      'field': 'weather',
    },
   
    {
      'DisplayLabel': 'Theft/Vandalism',
      'field': 'theftVandalism',
    }
  ];

  selectedPolicyDetails: {
    policyNumber: number,
    type: string,
    dueDate: string
  };


  constructor( private router: Router, private modalService: BsModalService) { }

  ngOnInit() {
  }


  isRadioButtonChecked() {
    const field = this.getField(this.claimType);
    if (!field) {
      return true;
    }
    const flag = (this.ClaimTypeOptions[field]) ? true : false;
    return flag;
  }

  getField(label) {
    const obj = this.getObj(this.claimTypes, label);
    if (obj && this.checkForPolicyType(obj)) {
      return obj.field;
    } else {
      return undefined;
    }

  }

  checkForPolicyType(obj) {
    if (obj.policyType) {
      return (obj.policyType === this.selectedPolicyDetails.type);
    } else {
      return true;
    }
  }

  getObj(list, label) {
    const obj = list.find(this.isExist, label);
    return obj;
  }

  isExist(value, index, arr) {
    const selectedValue = this;
    return (value.DisplayLabel === selectedValue);
  }


  openModalConfirmation(template1: TemplateRef<any>) {
    this.reportModalRef = this.modalService.show(template1);
  }


  
  goToNext() {
    // this.router.navigate(['/claims/claims-tabs/user-location-info']);
    console.log(this.claimType);
    this.submitted = true;
    if (this.claimType && this.isRadioButtonChecked()) {
      this.router.navigate(['/claims/claims-tabs/user-location-info']);
    }
  }
  goBackToDashboard(template1: TemplateRef<any>) {
    this.reportModalRef.hide();
    this.router.navigate(['/claims']);
  }

}

import React from 'react';
import { Switch, Route } from 'react-router-dom';
import Header from './components/Header/Header';
import LandingPage from './components/Landing_page/LandingPage';
import DetailsPage from './components/DetailsPage/DetailsPage';




const Router = () => (
  <>
    <Header />

    <Switch>
      <Route exact path="/" component={LandingPage} />
      <Route exact path="/landingscreen" component={LandingPage} />
      <Route exact path="/detailspage" component={DetailsPage} />
    </Switch>
  </>
);

export default Router;

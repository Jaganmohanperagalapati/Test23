import React, { Component } from 'react';
import { Layout } from 'antd';
import { Form, Row, Col, Button } from 'react-bootstrap';
import './DetailsPage.css';

class DetailsPage extends Component {
    constructor(props) {
        super(props);

        this.state = {
            name: "",
            experience: '',
            technology: '',
            number: '',
            status: '',
            isFormDisable: true
        }
        this.handleChange = this.handleChange.bind(this);
    }
    componentWillMount() {
        if (this.props.location.state.selected !== undefined) {
            let data = this.props.location.state.selected;
            this.setState({ name: data.name, experience: data.experience, technology: data.technology, number: data.number, status: data.status });
        }
    }
    navigateToLandingPage = () => {
        this.props.history.push("/landingscreen")
    }
    changeStatus = () => {
        this.setState({ isFormDisable: false })
    }

    handleSubmit = () => {
        let updatedObj = {
            name: this.state.name,
            experience: this.state.experience,
            technology: this.state.technology,
            number: this.state.number,
            status: this.state.status
        };
        const id = this.props.location.state.selected.id;
        fetch('http://localhost:8080/engineers/' + id, {
            method: 'PUT',
            body: JSON.stringify(updatedObj),
            headers: {
                "Content-type": "application/json; charset=UTF-8"
            }
        })
            .then(response => {
                return response.json();
            }).then(data => {
                // Work with JSON data here
                this.navigateToLandingPage();
                this.setState({ isFormDisable: true })
            }).catch(err => {
                // Do something for an error here
                console.log("Error Reading data " + err);
            });
    }
    handleChange = (event) => {
        this.setState({
            [event.target.id]: event.target.value
        })
    }
    render() {
        
        return (
            <Layout>
                <div className="m-20">
                    <Row>
                        <span><Button variant="primary" onClick={() => this.navigateToLandingPage()}>Back</Button></span>
                        <span className="p-r-20 p-l-20">
                            {this.state.isFormDisable ?
                                <Button variant="primary" onClick={() => this.changeStatus()}>Change Status</Button> :
                                <Button variant="primary" onClick={() => this.handleSubmit()} >Save</Button>
                            }
                        </span>
                    </Row>
                </div>
                <div className="m-20">
                    <Form>
                        <Form.Group as={Row} controlId="name">
                            <Col md={2}></Col>
                            <Col md={2} className="right">Name of candidate : </Col>
                            <Col md={6}>
                                <Form.Control input
                                    type="text"
                                    value={this.state.name}
                                    onChange={this.handleChange}
                                    disabled={this.state.isFormDisable}
                                    placeholder="Enter Name of candidate"
                                />
                            </Col>
                        </Form.Group>
                        <Form.Group as={Row} controlId="experience">
                            <Col md={2}></Col>
                            <Col md={2} className="right">Year of experience: </Col>
                            <Col md={6}>
                                <Form.Control input
                                    type="number"
                                    value={this.state.experience}
                                    onChange={this.handleChange}
                                    disabled={this.state.isFormDisable}
                                    placeholder="Enter years of experience" />
                            </Col>
                        </Form.Group>
                        <Form.Group as={Row} controlId="technology">
                            <Col md={2}></Col>
                            <Col md={2} className="right">Technology : </Col>
                            <Col md={6}>
                                <Form.Control input
                                    type="text"
                                    value={this.state.technology}
                                    onChange={this.handleChange}
                                    disabled={this.state.isFormDisable}
                                    placeholder="Enter technology" />
                            </Col>
                        </Form.Group>
                        <Form.Group as={Row} controlId="number">
                            <Col md={2}></Col>
                            <Col md={2} className="right">Mobile Number : </Col>
                            <Col md={6}>
                                <Form.Control input
                                    type="number"
                                    value={this.state.number}
                                    onChange={this.handleChange}
                                    disabled={this.state.isFormDisable}
                                    placeholder="Enter mobile number" />
                            </Col>
                        </Form.Group>
                        <Form.Group as={Row} controlId="status">
                            <Col md={2}></Col>
                            <Col md={2} className="right">Status : </Col>
                            <Col md={6}>
                                <Form.Control
                                    as="select"
                                    value={this.state.status}
                                    onChange={this.handleChange}
                                    disabled={this.state.isFormDisable}
                                >
                                    <option>assigned</option>
                                    <option>available</option>
                                </Form.Control>
                            </Col>
                        </Form.Group>
                    </Form>
                </div>
            </Layout>

        )
    }
}
export default DetailsPage;
import React, { Component } from 'react';
import { Row, Col } from 'react-bootstrap';
import { Table } from 'antd';
import './Landingpage.css'

class LandingPage extends Component {
    constructor(props) {
        super(props);
        this.state = {
            columns : [
                {
                  title: 'Name of the candidate',
                  dataIndex: 'name',
                  key: 'name',
                },
                {
                  title: 'Years of experience',
                  dataIndex: 'experience',
                  key: 'experience',
                },
                {
                  title: 'Technology',
                  dataIndex: 'technology',
                  key: 'technology',
                },
                {
                    title: 'Mobile Number',
                    dataIndex: 'number',
                    key: 'number',
                },
                {
                    title: 'Status',
                    dataIndex: 'status',
                    key: 'status',
                }
            ],
            engineersList : []
        };
    }
    componentDidMount() {
        this.getEngineersList();
    }
    getEngineersList = () => {
        fetch('http://localhost:8080/engineers').then(response => {
            return response.json();
          }).then(data => {
            // Work with JSON data here
            this.setState({engineersList : data})
          }).catch(err => {
            // Do something for an error here
            console.log("Error Reading data " + err);
          });
    }

    navigateToDetailsPage(record){
        console.log(record,"record")
        this.props.history.push({
            pathname : "/detailspage",
            state : {selected : record}
        });
    }
   
    render() {
        return (
            <div>
                <div>
                    <Row className="p-20">
                        <Col md={12}>
                            <Table 
                            dataSource={this.state.engineersList} 
                            columns={this.state.columns} 
                            onRow={(selected) => ({
                                onClick: () => {this.navigateToDetailsPage(selected)}
                            })}/>;
                        </Col>
                    </Row>

                </div>
            </div>
        );
    }

}
export default LandingPage;
import React, { Component } from 'react';
import {
    Layout, Avatar
} from 'antd';
import headerStyles from './header.module.css';
import logoImage from '../../assets/images/BizGive_logo_final.svg';

const { Header } = Layout;

class Header1 extends Component {
    constructor(props) {
        super(props);
        this.state = {};
    }
    render() {
        return (
            <Layout>
                <Layout>
                    <Layout className={headerStyles.slantCurve}>
                        <Avatar
                            src={logoImage}
                        />
                    </Layout>
                </Layout>
                <Header className={headerStyles.topHeader}>
                </Header>    
            </Layout>

        )
    }
}
export default Header1;

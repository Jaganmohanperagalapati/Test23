/* eslint-disable react/destructuring-assignment */
import React from 'react';
import { HashRouter } from 'react-router-dom';
import Router from './Router';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div>
        <HashRouter>
          <Router />
        </HashRouter>
      </div>
    );
  }
}

export default App;

